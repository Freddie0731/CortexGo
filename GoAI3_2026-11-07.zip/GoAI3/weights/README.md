# 权重文件说明

本目录**不放二进制权重**（单个 250MB，不适合进 git）。需要的文件按下面方式获取：

## 1. 引擎用的网络（`kata1.bin.gz`，约 250 MB）

这是本项目 C++ 引擎实际加载的 KataGo v17 网络
（`Model name: kata1-tf3-b11c768-s11003M-d5973M-7gres`，70.4M 参数）。

放到**仓库根目录**（与 `go_ai.cpp` 同级），引擎会自动按以下顺序查找：

```
kata1_value_fixed.bin.gz  ->  kata1.bin.gz  ->  nn_weights.bin.gz  ->  nn_weights.bin
```

获取方式（二选一）：

* **GitHub Releases**：把 `kata1.bin.gz` 作为 release asset 上传，然后
  `curl -L -o kata1.bin.gz <release-asset-url>`
* **官方 KataGo 网络**（等价、可直接用）：任何 **`-fs` 或 `-fson` 后缀**的 v15+ 网络都行，例如
  ```bash
  # 38MB 小网络，速度约为 70M 网络的 2.9 倍，每访问质量不输（空盘胜率与官方逐点一致）
  wget https://github.com/lightvector/KataGo/releases/download/v1.17.1/b10c384h6nbttflrs.bin.gz
  # 94MB 中等网络
  wget https://github.com/lightvector/KataGo/releases/download/v1.17.1/b10c512h8nbt3tflrs-fson-silu-rsnh.bin.gz
  ```
  > 命名规律：**只有 `-fs` / `-fson` 后缀才是 fixscale**，不带后缀的是 fixup（本引擎也支持，
  > 见 HANDOFF §10；但 `fson` 系列的末端是 batchnorm，务必选带 `-fson` 的版本）。

## 2. GPU 路径用的 ONNX（`kata1_b11.onnx`，约 279 MB）

由 `tools/export_onnx_fson.py` 从 `.bin.gz` 导出，**必须用 `-fson` 语义的图**，
否则 trunk 末端的 batchnorm 会被漏掉（这是本项目踩过的最深的一个坑，见 HANDOFF §10）。
导出后放在仓库根目录，引擎检测到 `onnxruntime.dll` 就自动走 DirectML GPU。

## 3. 训练用的编码数据集（`data/dump.bin`，约 24 MB）

16,680 个职业对局局面的 V7 编码 + 胜者标签，由 `kg/test/dump_enc.cpp` 生成。
仅在跑价值头训练时需要；`python tools/export_for_github.py --with-dump` 可以把
本地已有的那份一起打进来。
