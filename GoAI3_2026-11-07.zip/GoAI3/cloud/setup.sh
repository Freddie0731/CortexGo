#!/usr/bin/env bash
# =============================================================================
#  cloud/setup.sh —— 云端 GPU 机器的环境准备（Linux, CUDA）
#
#  只装训练/导出用的 Python 依赖，不编译 C++ 引擎（云端不需要 Win32 GUI）。
#  用法：
#     bash cloud/setup.sh            # 自动装 CUDA 版 torch
#     bash cloud/setup.sh cpu        # 只装 CPU 版（无 GPU 的机器）
# =============================================================================
set -euo pipefail

MODE="${1:-cuda}"
cd "$(dirname "$0")/.."

echo "== python =="
python3 -V

if [ "$MODE" = "cpu" ]; then
  echo "== pip: CPU torch =="
  python3 -m pip install --upgrade pip
  python3 -m pip install numpy onnx
  python3 -m pip install torch --index-url https://download.pytorch.org/whl/cpu
else
  echo "== pip: CUDA torch =="
  python3 -m pip install --upgrade pip
  python3 -m pip install numpy onnx
  # 默认装 CUDA 12.x 轮子；如果机器是 CUDA 11.8 就改 cu118
  python3 -m pip install torch --index-url https://download.pytorch.org/whl/cu124
fi

echo "== 自检 =="
python3 - <<'PY'
import sys, os
sys.path.insert(0, os.getcwd())
import numpy, torch
print('numpy', numpy.__version__)
print('torch', torch.__version__, 'cuda_available=', torch.cuda.is_available())
if torch.cuda.is_available():
    print('gpu:', torch.cuda.get_device_name(0),
          'capability', torch.cuda.get_device_capability(0))
import onnx
print('onnx', onnx.__version__)
PY

echo
echo "OK. 下一步："
echo "  1) 生成清单（可选，已在包里就跳过）: python3 tools/value_sgf_manifest.py"
echo "  2) 全量重训价值头:                    bash cloud/run_value_full.sh"
echo "  3) 自对弈闭环（可跑很久）:             bash cloud/run_selfplay_loop.sh"
