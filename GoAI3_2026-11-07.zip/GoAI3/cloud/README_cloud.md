# 用云端 GPU 跑 GoAI3 —— 可行性与操作手册

> 结论先给：**可以，而且值得 —— 但只在"训练"这一侧。推理不要放云端。**
> 本文给出为什么、租什么、跑什么、多久、多少钱、以及怎么把成果拿回来。

---

## 0. 一句话判断

| 用途 | 云端 GPU 合适吗 | 原因 |
|---|---|---|
| **训练 / 微调 / 自对弈产数据** | ✅ **非常合适，这是唯一正确的用法** | 本地只有 CPU（0.24 s/前向、1.9 局面/秒提特征）；一张 4090 是几十倍到上百倍 |
| **推理（对局时算棋）** | ❌ 不合适 | 本地 iGPU(DirectML) 已经 **0.077 s/前向**；云端往返 RTT 通常 20~80 ms，加上去跟本地差不多，还依赖网络 |
| 顺手下载更小更快的 KataGo 网络 | ✅ 很值 | 本机 HTTPS 被墙，云端能直接下；`b10c128`/`b6c96` 在固定每手时间内通常**比现在的 b11c768 更强** |

---

## 1. 云端能干的三件事（按性价比排序）

### A. 全量重训价值头（最便宜、最确定，~30 分钟，~¥3）

本地 v1 只用了 3,000 局面（test 612 个，AUC 0.7158）。云端可以做：

```bash
bash cloud/run_value_full.sh                     # 全量 16,680 局面，GPU 提特征
UNFREEZE=1 bash cloud/run_value_full.sh          # 额外连 value conv1 一起训（更慢更好）
```

预期：AUC 从 0.72 提到 0.75~0.80 量级（受"冻结 trunk"这个天花板限制），
空盘/中盘胜率标定更准。**收益确定、风险最低，先做这个。**

### B. 策略头微调（中等收益，几小时）

用 96,121 局职业棋谱 + **已经修好的编码器**做策略监督微调。现状基线（已测）：
`top-1 = 0.2907`、`top-5 = 0.5800`（3,000 局面，legal 口径）。
云端可以把数据量放大到全部棋谱，并连策略头一起训。

需要新写一个 `train_policy.py`（本地 `tools/value_*.py` 只训价值头）——
这是本仓库目前**唯一缺的训练脚本**。

### C. AlphaZero 式自对弈闭环（收益最大、最贵，几小时~几天）

```bash
ROUNDS=3 GAMES=40 VISITS=200 bash cloud/run_selfplay_loop.sh
```

复用 `_kg_pipeline.py`（selfplay → train → export 都已验证，导出走 `_kg_map.py` 的
字节级写回）。**关键**：策略目标必须来自搜索访问分布（`--mcts-visits 200+`），
不能用纯策略自对弈（那样梯度恒为 0）。

成本估算（4090）：一次前向约 10 ms，一局 250 手 × 200 访问 ≈ **8 分钟**；
40 局 ≈ 5.5 小时 ≈ **¥12~18**；训 400 步几分钟。
**风险**：自对弈数据质量低于职业棋谱，网络越大越容易"学会自己的坏习惯"，
每一轮都必须留一个 held-out 指标做门禁。

### D. 顺手拿更强的网络（性价比可能最高）

```bash
bash cloud/fetch_stronger_nets.sh b10c128 b6c96 b18c384nbt
```

脚本会下载并**校验格式**（必须是 `modelVersion>=15` 的 fixscale 结构，否则我们的
C++ 解析器读不对）。拿到后用 `--benchmark` 对比"同一 `--time` 下的访问数"与选点质量。

> 这条路的直觉：KataGo 自己的经验是"每手固定时间下，小网络比大网络强"。
> 现在的 b11c768 是它最大的一档，单次前向 0.077 s；b10c128 大约快 25 倍，
> 每手 30 秒能搜近万次。**如果只做一件事，我会先试这个。**

---

## 2. 怎么把东西传上去

本地打包（只会带训练需要的东西，约 **320 MB**）：

```bat
python tools\pack_cloud_bundle.py
:: 输出 build_out\cloud_bundle.tar.gz（约 294 MB），并打印 scp 命令
:: 加 --no-weights 可以打一个只有脚本和数据的轻包（约 55 MB，权重到云端再说）
```

包内容：`cloud/*.sh`、`tools/value_*.py`、`_katago_src/*.py`（官方 PyTorch 模型定义）、
`_katago_v17_load.py / _kg_ref.py / _kg_map.py / _kg_pipeline.py`、
编码好的 `build_out/value/dump.bin`（23 MB）+ `manifest.txt`、
`kg/build/sgf/games.7z`（28 MB 棋谱）、`kata1.bin.gz`（250 MB）、`HANDOFF.md`。

云端解包并准备：

```bash
mkdir -p ~/goai3 && cd ~/goai3
tar -xzf cloud_bundle.tar.gz
bash cloud/setup.sh            # 装 CUDA 版 torch + numpy + onnx
bash cloud/run_value_full.sh   # 或 run_selfplay_loop.sh / fetch_stronger_nets.sh
```

---

## 3. 需要你决定的两件事

1. **租哪家**：AutoDL / 恒源云（国内，便宜、付款方便）或 RunPod / Vast.ai（国外，
   4090 约 ¥2~3/小时）。只要 **>=16 GB 显存**即可（b11c768 fp32 约 280 MB 权重，
   训练时 batch 16 也够）。
2. **给我什么访问方式**：
   - 只把产物拷回来：最简单，你按上面命令跑，把 `kata1_value_fixed.bin.gz` +
     `build_out/value/train_report.txt` 拷回本地，我做集成（重导 ONNX + 自检 + 提交）。
   - 给我 SSH 访问：我可以远程把整条流程跑完、自动校验、自动取回，你只看结果。
     （本机 `ssh.exe` 存在、TCP 出网正常；需要你提供主机/端口/用户名与密钥或密码。）

---

## 4. 拿回本地之后我做什么（已验证的固定流程）

1. 覆盖 `kata1_value_fixed.bin.gz`（原生 CPU 路径优先加载它）
2. `tools\export_onnx_fixed.bat` 重新导出 `kata1_value_fixed.onnx`
   —— **必须做**，否则 GPU 路径还在用旧价值头，两条路会下出不同的棋
3. `x64\Release\GoAI3.exe --selftest`：空盘胜率必须回到 **45~55%**
4. 代理指标 A/B（比完整对局省几十倍算力）：固定 200 个职业局面，
   比较"搜索选中职业实战着法"的命中率
5. 通过才提交并更新 `HANDOFF.md`

---

## 5. 不建议做的事（省得白花钱）

| 想法 | 为什么不做 |
|---|---|
| 云端跑推理、本地引擎远程调用 | 本地 GPU 已经 0.077 s/前向；RTT 一加，收益基本抹平，还多一个故障点 |
| 云端做完整 A/B 对局证明棋力 | 检测 60% 胜率需 158 局；即使 4090 也要十几小时。用代理指标 + 监督指标更划算 |
| 用纯策略自对弈产数据 | 策略目标等于网络自己的输出，交叉熵梯度恒为 0，学不到东西 |
| 换成更老（v8~v14）的 KataGo 网络 | 那个年代是 fixup 归一化，我们的 C++ 解析器按 fixscale 实现，会静默算错 |
