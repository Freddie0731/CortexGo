#!/usr/bin/env bash
# =============================================================================
#  cloud/run_value_full.sh —— 在云端 GPU 上把价值头重训到"全量 + 可选解冻第一层"
#
#  相比本地做的 v1（冻结 trunk 与 value conv1，只重训最后两层），这里能做的改进：
#    * 全量局面（16,680 起，可加大 samples-per-game / max-games）
#    * 可选 --unfreeze conv1（连 value_head.conv1 一起训）
#      —— 这需要把 361x768 的空间特征也拿进来，显存/内存代价大，
#         所以默认关闭；打开后请把 --batch 调小。
#
#  用法：
#     bash cloud/run_value_full.sh                 # 全量、只训最后两层
#     UNFREEZE=1 bash cloud/run_value_full.sh      # 连 conv1 一起训（更慢）
#     BATCH=32 bash cloud/run_value_full.sh
# =============================================================================
set -euo pipefail
cd "$(dirname "$0")/.."

BATCH="${BATCH:-16}"
THREADS="${THREADS:-8}"
DATASET="${DATASET:-build_out/value/dump.bin}"
AUX="${AUX:-build_out/value/aux.bin}"
MANIFEST="${MANIFEST:-build_out/value/manifest.txt}"
FEATURES="${FEATURES:-build_out/value/features_full.npz}"
WEIGHTS="${WEIGHTS:-kata1.bin.gz}"
OUTW="${OUTW:-build_out/value/value_head_full.npz}"
OUTBIN="${OUTBIN:-kata1_value_fixed.bin.gz}"

echo "== 0. 环境 =="
python3 - <<'PY'
import torch
print('torch', torch.__version__, 'cuda', torch.cuda.is_available())
if not torch.cuda.is_available():
    raise SystemExit('没有检测到 CUDA：请用 bash cloud/setup.sh 装 CUDA 版 torch，'
                     '或改用 --device cpu 慢跑')
PY

echo "== 1. 数据自检（位图 vs 棋盘 / 征子平面位置）=="
python3 tools/value_features.py --dump "$DATASET" --aux "$AUX" --weights "$WEIGHTS" \
  --device cuda --batch 8 --threads "$THREADS" --limit 256 \
  --out "" || true

echo "== 2. 全量特征提取（GPU）=="
python3 tools/value_features.py --dump "$DATASET" --aux "$AUX" --weights "$WEIGHTS" \
  --device cuda --batch "$BATCH" --threads "$THREADS" --out "$FEATURES"

echo "== 3. 训练（held-out 按棋局划分，报告里会打 AUC/acc/Brier/校准）=="
python3 tools/value_train.py --features "$FEATURES" --manifest "$MANIFEST" \
  --out-weights "$OUTW" --threads "$THREADS"

if [ "${UNFREEZE:-0}" = "1" ]; then
  echo "== 3b. 解冻 value_head.conv1 一起微调 =="
  python3 tools/value_train_unfreeze_conv1.py --features "$FEATURES" \
    --manifest "$MANIFEST" --weights "$WEIGHTS" --device cuda \
    --out-weights "$OUTW" --threads "$THREADS" || {
      echo "!! 没有 value_train_unfreeze_conv1.py（这个增强版还没写），跳过。"
      echo "   需要时按 HANDOFF §4.1 的思路补：缓存 361x768 空间特征后联合训练。"
    }
fi

echo "== 4. 导出成引擎能直接加载的 .bin.gz（字节原位改写 4 个张量）=="
python3 tools/value_export.py --new "$OUTW" --src "$WEIGHTS" --out "$OUTBIN"

echo "== 5. 黑白互换规范化自检 =="
python3 tools/value_selfcheck.py || echo "(selfcheck 脚本参数可能不同，按它的 --help 调整)"

echo
echo "== 完成 =="
ls -lh "$OUTBIN" "$FEATURES" "$OUTW" 2>/dev/null || true
cat <<'EOF'

把下面这些文件带回来（其余不用带）：
  * kata1_value_fixed.bin.gz     <- 新的价值头权重（原生 CPU 路径用）
  * build_out/value/train_report.txt <- 训练/评估报告（AUC/acc/Brier/校准）
本地要做的事（HANDOFF §7.5 有完整说明）：
  1) 拷到仓库根
  2) 重新导出 GPU 用的 ONNX： tools\export_onnx_fixed.bat
     （输出固定叫 kata1_b11_b1.onnx，手动改名为 kata1_value_fixed.onnx）
  3) x64\Release\GoAI3.exe --selftest  （空盘胜率应回到 45~55%）
EOF
