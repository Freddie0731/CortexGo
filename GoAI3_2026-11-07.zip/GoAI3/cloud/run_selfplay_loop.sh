#!/usr/bin/env bash
# =============================================================================
#  cloud/run_selfplay_loop.sh —— 云端 GPU 上的 AlphaZero 式自对弈闭环
#
#  这是"真正把棋力往上推"的那条路：自对弈产生 (局面, 搜索访问分布, 胜负)
#  数据 -> 微调 -> 导出 -> 用新权重继续自对弈。本地 CPU 跑不动，云端 GPU 才能做。
#
#  复用仓库里已有的闭环脚本 _kg_pipeline.py（它的 selfplay/train/export 三个子命令
#  都已经验证过；导出路径 _kg_map.py 声称逐字节往返验证过）。
#
#  ★ 关键：**策略目标必须来自搜索访问分布，不能用纯策略**
#    （纯策略自对弈时目标=网络自己的输出，交叉熵梯度恒为 0，学不到东西）。
#    所以 --mcts-visits 必须够大（200 起步）。
#
#  用法：
#     ROUNDS=3 GAMES=40 VISITS=200 bash cloud/run_selfplay_loop.sh
#     RESUME=1 bash cloud/run_selfplay_loop.sh      # 接着上次的 ckpt
#     BASE=kata1_value_fixed.bin.gz ...             # 从修好价值头的版本起步
# =============================================================================
set -euo pipefail
cd "$(dirname "$0")/.."

ROUNDS="${ROUNDS:-3}"
GAMES="${GAMES:-40}"
VISITS="${VISITS:-200}"
STEPS="${STEPS:-400}"
CKPT="${CKPT:-build_out/cloud/finetune.pt}"
DATA="${DATA:-build_out/cloud/data}"
BASE="${BASE:-kata1.bin.gz}"
OUTBIN="${OUTBIN:-kata1_selfplay.bin.gz}"

mkdir -p "$DATA" build_out/cloud

# 如果指定了别的起点权重，先把它放到工作目录（_kg_pipeline 默认读 kata1.bin.gz）
if [ "$BASE" != "kata1.bin.gz" ]; then
  cp -f "$BASE" kata1.bin.gz
  echo "[base] 用 $BASE 覆盖了 kata1.bin.gz（原文件请自己留备份）"
fi

for r in $(seq 1 "$ROUNDS"); do
  echo
  echo "################ 第 $r/$ROUNDS 轮 ################"
  echo "== 1) 自对弈 $GAMES 局（每手 $VISITS 次 MCTS 访问）=="
  # 注意：GPU 上单次前向约 10ms，一局约 250 手 × 200 访问 ≈ 8 分钟
  python3 _kg_pipeline.py selfplay --games "$GAMES" --out "$DATA" --mcts-visits "$VISITS"

  echo "== 2) 微调 $STEPS 步（每轮都从上一轮 ckpt 接着训）=="
  if [ -f "$CKPT" ] && [ "${RESUME:-1}" = "1" ]; then
    python3 _kg_pipeline.py train --data "$DATA" --steps "$STEPS" --ckpt "$CKPT" --resume "$CKPT"
  else
    python3 _kg_pipeline.py train --data "$DATA" --steps "$STEPS" --ckpt "$CKPT"
  fi

  echo "== 3) 导出引擎权重 =="
  python3 _kg_pipeline.py export --ckpt "$CKPT" --out "$OUTBIN"

  echo "== 4) 检查点信息 =="
  python3 _kg_pipeline.py info --ckpt "$CKPT" || true
done

echo
echo "== 完成：$OUTBIN =="
ls -lh "$OUTBIN" "$CKPT"
cat <<'EOF'

带回本地后：
  1) 拷到仓库根，改名为 kata1_value_fixed.bin.gz（或保留原名，用 --weights 指定）
  2) 用 native C++ 前向做数值抽查：
       build_out\ort\test_ort.exe --no-native --iters 1        （只验 GPU 路径）
       x64\Release\GoAI3.exe --selftest                        （空盘胜率应 45~55%）
  3) 与上一版做代理指标 A/B（比完整对局省几十倍算力）：
       固定 200 个职业局面，比较"搜索选中实战着法"的命中率
  4) 确认没退步再替换仓库根的文件，并重导 ONNX（tools\export_onnx_fixed.bat）

注意：自对弈学出来的东西**可能变差**（自对弈数据质量低于职业棋谱，
      网络越大越容易过拟合自己的错误）。每轮都要留一个 held-out 指标做门禁。
EOF
