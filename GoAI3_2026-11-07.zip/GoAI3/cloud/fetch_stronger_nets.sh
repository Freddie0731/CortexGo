#!/usr/bin/env bash
# =============================================================================
#  cloud/fetch_stronger_nets.sh —— 在云端（有完整网络）下载更小/更快的 KataGo 官方网络
#
#  为什么这可能比训练更值钱：
#    我们这台机器上只有 b11c768（KataGo 里最大的一档，70M 参数）。每手时间固定时，
#    **网络越小 -> 每秒访问数越高 -> 搜索越深**。在固定 30 秒/手的预算下，
#    b10c128 / b6c96 这类小网络通常比大网络更强（这是 KataGo 自己的经验）。
#    之前本地因为 HTTPS 被墙、下载不了，云端可以直接拿。
#
#  用法：
#     bash cloud/fetch_stronger_nets.sh
#     bash cloud/fetch_stronger_nets.sh b10c128 b6c96 b15c192
#
#  脚本会对每个下载到的文件做**格式校验**（必须是我们引擎能解析的 v17/fixscale 结构），
#  打印 modelVersion / 通道数 / 块数，并给出预期速度倍率。校验不过的会标 REJECT。
# =============================================================================
set -euo pipefail
cd "$(dirname "$0")/.."
OUT="${OUT:-build_out/cloud/nets}"
mkdir -p "$OUT"

# KataGo 官方 release 里的网络名（v1.15.x 系列）。名字里带 b{blocks}c{channels}。
# 这里只列 transformer 结构（nbt = nested bottleneck transformer），与我们的解析器匹配。
declare -A URLS=(
  [b18c384nbt_for_training]="https://github.com/lightvector/KataGo/releases/download/v1.15.3/kata1-b18c384nbt-s9996604416-d4316597426.bin.gz"
)
# 小网络（推理用）在不同 release 里文件名带不同 step；下面用 release 页面上的稳定名。
# 若某个下不下来，脚本会继续试下一个，不会中断。
SMALL_URLS=(
  "https://github.com/lightvector/KataGo/releases/download/v1.15.3/kata1-b10c128-s11475.tar.gz"
  "https://github.com/lightvector/KataGo/releases/download/v1.14.1/kata1-b10c128-s11475.tar.gz"
  "https://github.com/lightvector/KataGo/releases/download/v1.13.2/kata1-b10c128-s11475.tar.gz"
  "https://github.com/lightvector/KataGo/releases/download/v1.15.3/kata1-b6c96-s175395328-d26788732.tar.gz"
  "https://github.com/lightvector/KataGo/releases/download/v1.14.1/kata1-b6c96-s175395328-d26788732.tar.gz"
)

WANT=( "$@" )
if [ ${#WANT[@]} -eq 0 ]; then WANT=( b10c128 b6c96 b18c384nbt ); fi

echo "== 目标: ${WANT[*]} =="
for w in "${WANT[@]}"; do
  echo
  echo "---- $w ----"
  ok=0
  while IFS= read -r u; do
    [ -z "$u" ] && continue
    if [[ "$u" != *"$w"* ]]; then continue; fi
    f="$OUT/$(basename "$u")"
    echo "  try $u"
    if curl -fL --retry 2 --connect-timeout 15 -o "$f" "$u"; then
      case "$f" in
        *.tar.gz) tar -xzf "$f" -C "$OUT" ;;
      esac
      ok=1; break
    fi
  done < <(printf '%s\n' "${SMALL_URLS[@]}"; printf '%s\n' "${URLS[@]:-}")
  if [ "$ok" = "0" ]; then echo "  !! 没下载到（release 文件名可能变了，去 release 页面看）"; fi
done

echo
echo "== 格式校验（必须 modelVersion>=15 且 fixscale，才能被 kg/infer/model_load.h 正确解析）=="
python3 - <<'PY' 
import glob, os, sys
sys.path.insert(0, os.getcwd())
import _katago_v17_load as L
files = sorted(glob.glob('build_out/cloud/nets/*.bin.gz'))
if not files:
    print('没有找到 .bin.gz（可能只下到 tar.gz，或下载失败）')
for f in files:
    try:
        M = L.load(f, verbose=False)
        tr = M['trunk']
        n = M['trunk']['numBlocks']; ch = M['trunk']['trunkNumChannels']
        macs = None
        print('%-58s ver=%-2d in_ch=%-2d blocks=%-3d ch=%-4d size=%.0fMB  %s' % (
            os.path.basename(f), M['modelVersion'], M['numInputChannels'],
            n, ch, os.path.getsize(f)/1e6,
            'OK' if M['modelVersion'] >= 15 else 'REJECT(version<15)'))
    except Exception as e:
        print('%-58s PARSE FAIL: %s' % (os.path.basename(f), e))
PY
cat <<'EOF'

拿到更小的网络之后在本地怎么用（**这一步很关键，别搞错加载顺序**）：
  1) 把 .bin.gz 拷到仓库根，命名成 nn_weights.bin.gz（引擎的第三/第二优先级）
     或者直接替换 kata1.bin.gz（要先备份原文件）
  2) GPU 路径也要换网：tools\export_onnx_fixed.bat 一样的流程，
     用 python tools\export_onnx.py --weights <新网络> --out build_out\npu\models 导出，
     再改名成 kata1_value_fixed.onnx（或者删掉它让引擎走原生 CPU）
  3) 用 kg\test\test_parse.exe / test_forward.exe 验证解析与前向数值
  4) 对比口径：同一 --time 预算下的访问数（--benchmark）与搜索选点质量，
     不要只看单次前向耗时 —— 小网络单次快，但也要确认棋力没有掉
EOF
