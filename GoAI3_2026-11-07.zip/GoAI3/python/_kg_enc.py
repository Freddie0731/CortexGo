# -*- coding: utf-8 -*-
"""V7 编码的 Python 复刻 + 与官方 PyTorch 模型联调验证。

目的：在没有官方 Python 编码器的情况下，
  1) 用 Python 实现同一套编码（便于快速试错）
  2) 喂给官方 PyTorch 模型，观察空盘/实战局面的输出是否合理
如果 Python 版输出合理而 C++ 版不合理，差异就在两者的实现之间。

用法: python _kg_enc.py <weights.bin.gz>
"""
import sys, os
import numpy as np
import torch

sys.stdout.reconfigure(encoding='utf-8', errors='replace')
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
os.environ.setdefault('TORCHDYNAMO_DISABLE', '1')

import _katago_v17_load as L
from _katago_official import load_official
from _kg_ref import build_state_dict

N = 19
PASS = -1
EMPTY, BLACK, WHITE = 0, 1, 2


class GoBoard:
    def __init__(self, n=19):
        self.n = n
        self.c = np.zeros((n, n), dtype=np.int8)
        self.ko = -1

    def neighbors(self, x, y):
        if x > 0: yield x - 1, y
        if x < self.n - 1: yield x + 1, y
        if y > 0: yield x, y - 1
        if y < self.n - 1: yield x, y + 1

    def group(self, x, y):
        col = self.c[y, x]
        seen = {(x, y)}
        st = [(x, y)]
        g = []
        while st:
            cx, cy = st.pop()
            g.append((cx, cy))
            for nx, ny in self.neighbors(cx, cy):
                if (nx, ny) not in seen and self.c[ny, nx] == col:
                    seen.add((nx, ny))
                    st.append((nx, ny))
        return g

    def libs(self, x, y):
        lib = set()
        for gx, gy in self.group(x, y):
            for nx, ny in self.neighbors(gx, gy):
                if self.c[ny, nx] == EMPTY:
                    lib.add((nx, ny))
        return len(lib)

    def play(self, x, y, col):
        self.c[y, x] = col
        opp = 3 - col
        captured = 0
        cap_at = None
        for nx, ny in list(self.neighbors(x, y)):
            if self.c[ny, nx] == opp and self.libs(nx, ny) == 0:
                g = self.group(nx, ny)
                for gx, gy in g:
                    self.c[gy, gx] = EMPTY
                captured += len(g)
                if len(g) == 1:
                    cap_at = (nx, ny)
        if captured == 0 and self.libs(x, y) == 0:
            self.c[y, x] = EMPTY
            return -1
        self.ko = cap_at if (captured == 1 and self.libs(x, y) == 1) else None
        return captured


def encode(board, history, pla, komi=7.5):
    """返回 (spatial(1,22,19,19), global(1,19))。"""
    n = board.n
    S = n * n
    sp = np.zeros((22, n, n), dtype=np.float32)
    gl = np.zeros(19, dtype=np.float32)
    opp = 3 - pla

    # 平面 0：在盘上
    sp[0, :, :] = 1.0

    for y in range(n):
        for x in range(n):
            c = board.c[y, x]
            if c == pla:
                sp[1, y, x] = 1.0
            elif c == opp:
                sp[2, y, x] = 1.0
            if c != EMPTY:
                lb = board.libs(x, y)
                if lb == 1: sp[3, y, x] = 1.0
                elif lb == 2: sp[4, y, x] = 1.0
                elif lb == 3: sp[5, y, x] = 1.0

    # 平面 6：劫（ko 为 None 或 (x,y)）
    if board.ko is not None and hasattr(board.ko, '__len__'):
        sp[6, board.ko[1], board.ko[0]] = 1.0

    # 平面 18/19：领地（简化：单色完全包围的空区）
    visited = np.zeros((n, n), dtype=bool)
    for y in range(n):
        for x in range(n):
            if board.c[y, x] != EMPTY or visited[y, x]:
                continue
            st = [(x, y)]
            visited[y, x] = True
            region = []
            tb = tw = False
            while st:
                cx, cy = st.pop()
                region.append((cx, cy))
                for nx, ny in board.neighbors(cx, cy):
                    v = board.c[ny, nx]
                    if v == EMPTY:
                        if not visited[ny, nx]:
                            visited[ny, nx] = True
                            st.append((nx, ny))
                    elif v == BLACK:
                        tb = True
                    else:
                        tw = True
            if tb and not tw:
                pl = 18 if pla == BLACK else 19
                for gx, gy in region:
                    sp[pl, gy, gx] = 1.0
            elif tw and not tb:
                pl = 18 if pla == WHITE else 19
                for gx, gy in region:
                    sp[pl, gy, gx] = 1.0

    # 平面 9..13：最近 5 手
    used = 0
    want = opp
    for k in range(5):
        idx = len(history) - 1 - k
        if idx < 0:
            break
        if history[idx][1] != want:
            break
        loc = history[idx][0]
        if loc == PASS:
            gl[k] = 1.0
        else:
            sp[9 + k, loc[1], loc[0]] = 1.0
        used += 1
        want = 3 - want

    # 平面 14：打吃（气<=2）；17：被叫吃串的逃出点
    done = np.zeros((n, n), dtype=bool)
    for y in range(n):
        for x in range(n):
            c = board.c[y, x]
            if c == EMPTY or done[y, x]:
                continue
            if board.libs(x, y) <= 2:
                for gx, gy in board.group(x, y):
                    sp[14, gy, gx] = 1.0
                    done[gy, gx] = True
    done = np.zeros((n, n), dtype=bool)
    for y in range(n):
        for x in range(n):
            c = board.c[y, x]
            if c == EMPTY or done[y, x]:
                continue
            if board.libs(x, y) == 1:
                for gx, gy in board.group(x, y):
                    done[gy, gx] = True
                    for nx, ny in board.neighbors(gx, gy):
                        if board.c[ny, nx] == EMPTY:
                            sp[17, ny, nx] = 1.0

    # ---- 全局特征 ----
    self_komi = -komi if pla == BLACK else komi
    area = float(S)
    KR = 20.0
    self_komi = max(-area - KR, min(area + KR, self_komi))
    gl[5] = self_komi / 20.0
    gl[6] = 1.0
    gl[7] = 0.5          # positional ko
    gl[8] = 1.0          # multi-stone suicide legal
    gl[9] = 1.0          # area scoring
    gl[14] = 0.0         # pass 不结束对局
    # 18：贴目奇偶三角波
    boardAreaIsEven = (S % 2) == 0
    drawableEven = boardAreaIsEven
    if drawableEven:
        komiFloor = np.floor(self_komi / 2.0) * 2.0
    else:
        komiFloor = np.floor((self_komi - 1.0) / 2.0) * 2.0 + 1.0
    delta = min(2.0, max(0.0, self_komi - komiFloor))
    if delta < 0.5:
        wave = delta
    elif delta < 1.5:
        wave = 1.0 - delta
    else:
        wave = delta - 2.0
    gl[18] = wave

    return sp.reshape(1, 22, n, n), gl.reshape(1, 19)


def main():
    M = L.load(sys.argv[1], verbose=False)
    Model, mc = load_official()
    model = Model(mc.config_of_name['b11c768h12nbt3tflrs-silu'], 19).eval()
    model.initialize()
    sd = build_state_dict(M)
    t = {}
    for k, v in model.state_dict().items():
        if k in sd:
            a = np.array(sd[k], dtype=np.float32, copy=True)
            if tuple(a.shape) == tuple(v.shape):
                t[k] = torch.from_numpy(a).clone()
    model.load_state_dict(t, strict=False)

    def run(board, hist, pla):
        sp, gl = encode(board, hist, pla)
        with torch.no_grad():
            res = model._forward_per_block_units(torch.from_numpy(sp), torch.from_numpy(gl))
        # _forward_per_block_units 返回 ((policy, value, ...), (policy, value, ...))。
        # 取第一个（head 0）。
        head = res[0]
        pol = head[0].numpy().reshape(6, 362)
        val = head[1].numpy().reshape(3)
        return pol, val

    # ---- 空盘，黑先 ----
    b = GoBoard()
    pol, val = run(b, [], BLACK)
    print('=== 空盘，黑先，komi 7.5 ===')
    print('  value (win/loss/noresult) =', np.round(val, 4).tolist())
    p = pol[0]
    order = np.argsort(-p)
    cols = 'ABCDEFGHJKLMNOPQRST'
    print('  前 12 个着法:')
    for i in range(12):
        l = int(order[i])
        if l < 361:
            print('    %2d. %c%d   logit %+8.3f' % (i + 1, cols[l % 19], 19 - l // 19, p[l]))
    print('    pass            logit %+8.3f' % p[361])

    # ---- 黑 D4 后，白先 ----
    b2 = GoBoard()
    b2.play(3, 3, BLACK)
    pol2, val2 = run(b2, [((3, 3), BLACK)], WHITE)
    print()
    print('=== 黑 D4 后，白先 ===')
    print('  value =', np.round(val2, 4).tolist())
    p2 = pol2[0]
    order2 = np.argsort(-p2)
    for i in range(8):
        l = int(order2[i])
        if l < 361:
            print('    %2d. %c%d   logit %+8.3f' % (i + 1, cols[l % 19], 19 - l // 19, p2[l]))
    print('    pass            logit %+8.3f' % p2[361])


if __name__ == '__main__':
    main()
