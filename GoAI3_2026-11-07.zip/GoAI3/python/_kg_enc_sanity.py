# -*- coding: utf-8 -*-
"""决定性实验：网络对输入的响应是否合理？

  1) 空盘 vs 只在中心放一子 vs 铺满黑子 —— value 是否会随局面变强而变化？
  2) 只留掩码、全局特征全零 —— 输出是否仍异常？
  3) 把平面 0（掩码）换到别的平面 —— 判断掩码位置是否搞错。
"""
import sys, os
import numpy as np
import torch
sys.stdout.reconfigure(encoding='utf-8', errors='replace')
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
os.environ.setdefault('TORCHDYNAMO_DISABLE', '1')

import _katago_v17_load as L
from _katago_official import load_official
from _kg_ref import build_state_dict
from _kg_enc import GoBoard, encode, BLACK, WHITE

M = L.load(sys.argv[1], verbose=False)
Model, mc = load_official()
model = Model(mc.config_of_name['b11c768h12nbt3tflrs-silu'], 19).eval()
model.initialize()
sd = build_state_dict(M)
t = {}
for k, v in model.state_dict().items():
    if k in sd:
        a = np.array(sd[k], dtype=np.float32, copy=True)
        if tuple(a.shape) == tuple(v.shape):
            t[k] = torch.from_numpy(a).clone()
model.load_state_dict(t, strict=False)


def run(sp, gl):
    with torch.no_grad():
        r = model._forward_per_block_units(torch.from_numpy(sp.copy()),
                                           torch.from_numpy(gl.copy()))
    h = r[0]
    return h[0].numpy().reshape(6, 362)[0], h[1].numpy().reshape(3), \
        h[4].numpy().reshape(-1)


def report(tag, sp, gl):
    p, v, own = run(sp, gl)
    print('%-34s pass=%+8.3f boardMax=%+8.3f  val=[%+7.2f,%+7.2f,%+7.2f]  ownSum=%+8.2f'
          % (tag, p[361], p[:361].max(), v[0], v[1], v[2], own.sum()))


# --- 1. 局面强度递增 ---
b = GoBoard()
sp, gl = encode(b, [], BLACK)
report('空盘 黑先', sp, gl)

b1 = GoBoard(); b1.play(9, 9, BLACK)
sp1, gl1 = encode(b1, [((9, 9), BLACK)], WHITE)
report('黑天元一子 白先', sp1, gl1)

b2 = GoBoard()
for y in range(19):
    for x in range(19):
        if (x + y) % 2 == 0:
            b2.c[y, x] = BLACK
sp2, gl2 = encode(b2, [], WHITE)
report('黑铺满半盘 白先', sp2, gl2)

b3 = GoBoard()
for y in range(19):
    for x in range(19):
        b3.c[y, x] = BLACK
sp3, gl3 = encode(b3, [], WHITE)
report('黑铺满全盘 白先', sp3, gl3)

# --- 2. 只留掩码 + 全局全零 ---
sp4 = np.zeros_like(sp); sp4[0, 0] = 1.0
report('只掩码(平面0) + 全局全零', sp4, np.zeros_like(gl))
report('只掩码(平面0) + 正确全局', sp4, gl)

# --- 3. 掩码换到平面 5 试试（万一 index 搞错）---
sp5 = np.zeros_like(sp); sp5[0, 5] = 1.0
report('掩码放平面5 + 正确全局', sp5, gl)
sp6 = np.zeros_like(sp); sp6[0, 21] = 1.0
report('掩码放平面21 + 正确全局', sp6, gl)

# --- 4. 用真实参考输入（此前 ref.bin 里的随机输入）确认前向本身没问题 ---
import struct
rp = 'kg/build/ref.bin'
try:
    f = open(rp, 'rb'); assert f.read(8) == b'KGREF001'
    n = struct.unpack('<i', f.read(4))[0]
    for _ in range(n):
        nl = struct.unpack('<i', f.read(4))[0]; name = f.read(nl).decode()
        nd = struct.unpack('<i', f.read(4))[0]
        dims = [struct.unpack('<i', f.read(4))[0] for _ in range(nd)]
        c = 1
        for d in dims: c *= d
        arr = np.frombuffer(f.read(4 * c), dtype='<f4').reshape(dims).copy()
        if name == 'input.spatial': rin_sp = arr
        if name == 'input.global': rin_gl = arr
    report('随机参考输入(此前已验证对齐)', rin_sp, rin_gl)
except Exception as e:
    print('跳过参考输入:', e)
