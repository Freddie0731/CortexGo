# -*- coding: utf-8 -*-
"""读模型侧 q 分支 norm/reference 的真实参数与内部归一化选择。"""
import sys, os
import numpy as np
import torch

sys.stdout.reconfigure(encoding='utf-8', errors='replace')
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
os.environ.setdefault('TORCHDYNAMO_DISABLE', '1')

from _katago_official import load_official

Model, mc = load_official()
cfg = mc.config_of_name['b11c768h12nbt3tflrs-silu']
model = Model(cfg, 19).eval()
model.initialize()

for nm in ('normactconvp', 'normactconvq'):
    m = getattr(model.blocks[0], nm)
    n = m.norm
    print('=== blocks[0].%s ===' % nm)
    print('  固定参数: c_in=%d norm_kind=%s is_batchnorm=%s use_gamma=%s fixup_use_gamma=%s'
          % (n.c_in, n.norm_kind, n.is_using_batchnorm, n.use_gamma, n.fixup_use_gamma))
    print('  self.scale =', n.scale)
    print('  self.gamma =', None if n.gamma is None else 'shape %s' % (tuple(n.gamma.shape),))
    print('  self.beta  = shape %s' % (tuple(n.beta.shape),))
    print('  skip_mask  =', n.skip_mask)
    print('  epsilon    =', n.epsilon)
    print('  初始化后是否被 NormActConv.initialize 改过 scale：', n.scale)
    print('  模块类型:', type(n).__name__)
    for child_name, ch in n.named_children():
        print('     child %-16s %s' % (child_name, type(ch).__name__))
    for bn, buf in n.named_buffers():
        print('     buffer %-16s %s' % (bn, tuple(buf.shape)))
    print()

# 观察 normactconvq 实际调用了什么（monkeypatch forward 记录）
print('=== 实际调用追踪 ===')
orig = type(model.blocks[0].normactconvq).forward
calls = []


def patched(self, x, mask, mask_sum_hw, mask_sum, extra_outputs, block_shared_data=None):
    calls.append(('normactconv', self.name, tuple(x.shape), x.dim()))
    return orig(self, x, mask=mask, mask_sum_hw=mask_sum_hw, mask_sum=mask_sum,
                extra_outputs=extra_outputs, block_shared_data=block_shared_data)


type(model.blocks[0].normactconvq).forward = patched

import struct
rp = sys.argv[2] if len(sys.argv) > 2 else 'kg/build/ref.bin'
f = open(rp, 'rb')
assert f.read(8) == b'KGREF001'
n = struct.unpack('<i', f.read(4))[0]
inp = None
for _ in range(n):
    nl = struct.unpack('<i', f.read(4))[0]
    name = f.read(nl).decode()
    nd = struct.unpack('<i', f.read(4))[0]
    dims = [struct.unpack('<i', f.read(4))[0] for _ in range(nd)]
    c = 1
    for d in dims:
        c *= d
    arr = np.frombuffer(f.read(4 * c), dtype='<f4').reshape(dims)
    if name == 'input.spatial':
        inp = torch.from_numpy(arr.astype(np.float32).copy())
    if name == 'input.global':
        ing = torch.from_numpy(arr.astype(np.float32).copy())

with torch.no_grad():
    model._forward_per_block_units(inp, ing)
print('  calls:', calls)
type(model.blocks[0].normactconvq).forward = orig
