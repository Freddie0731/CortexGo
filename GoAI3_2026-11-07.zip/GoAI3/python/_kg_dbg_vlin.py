# -*- coding: utf-8 -*-
"""用参考自己的 gpool 输入复算 linear2，与模型自身输出对比。"""
import struct, sys, os
import numpy as np
import torch
sys.stdout.reconfigure(encoding='utf-8', errors='replace')
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
os.environ.setdefault('TORCHDYNAMO_DISABLE', '1')
import _katago_v17_load as L
from _katago_official import load_official
from _kg_ref import build_state_dict


def read_ref(path):
    f = open(path, 'rb')
    assert f.read(8) == b'KGREF001'
    n = struct.unpack('<i', f.read(4))[0]
    D = {}
    for _ in range(n):
        nl = struct.unpack('<i', f.read(4))[0]
        name = f.read(nl).decode()
        nd = struct.unpack('<i', f.read(4))[0]
        dims = [struct.unpack('<i', f.read(4))[0] for _ in range(nd)]
        c = 1
        for d in dims:
            c *= d
        D[name] = np.frombuffer(f.read(4 * c), dtype='<f4').reshape(dims).copy()
    return D


M = L.load(sys.argv[1], verbose=False)
D = read_ref(sys.argv[2])
Model, mc = load_official()
model = Model(mc.config_of_name['b11c768h12nbt3tflrs-silu'], 19).eval()
model.initialize()
sd = build_state_dict(M)
t = {}
for k, v in model.state_dict().items():
    if k in sd:
        a = np.array(sd[k], dtype=np.float32, copy=True)
        if tuple(a.shape) == tuple(v.shape):
            t[k] = torch.from_numpy(a).clone()
model.load_state_dict(t, strict=False)
vh = model.value_head

pooled = torch.from_numpy(D['value_head.gpool'].reshape(-1).astype(np.float32).copy())
print('pooled shape', tuple(pooled.shape), ' rms=%.5f' % pooled.pow(2).mean().sqrt().item())

# 1) 用模型自身的 linear2
with torch.no_grad():
    y_model = vh.linear2(pooled)
    y_manual = torch.nn.functional.linear(pooled, vh.linear2.weight, vh.linear2.bias)
print('模型 linear2 与 F.linear 一致: %.3e' % (y_model - y_manual).abs().max().item())
print('y_model[:4] =', np.round(y_model.numpy()[:4], 6).tolist())

# 2) 与参考的 value_head.linear2 比
ref = torch.from_numpy(D['value_head.linear2'].reshape(-1).astype(np.float32).copy())
print('参考 linear2[:4] =', np.round(ref.numpy()[:4], 6).tolist())
print('|y_model - ref|max = %.6e' % (y_model - ref).abs().max().item())

# 3) 反过来：解出 ref = pooled @ A^T + b 的 A
A = torch.linalg.lstsq(pooled.unsqueeze(0), ref.unsqueeze(0)).solution
print()
print('最小二乘解出的 A 形状', tuple(A.shape))
print('|A - linear2.weight^T|max = %.6e'
      % (A - vh.linear2.weight.t()).abs().max().item())

# 4) 也许参考的 pooled 不是这个？检查参考 value_head.gpool 是否等于我用 act1 算的
act1 = torch.from_numpy(D['value_head.act1'].astype(np.float32).copy())
mask = torch.ones(1, 1, 19, 19)
msum = mask.sum()
off = torch.sqrt(msum) - 14.0
mean = act1.sum(dim=(2, 3), keepdim=True) / msum
p_mine = torch.cat([mean, mean * (off / 10.0),
                    mean * ((off * off) / 100.0 - 0.1)], dim=1).reshape(-1)
print()
print('|我算的 pooled - 参考 gpool|max = %.6e'
      % (p_mine - torch.from_numpy(D['value_head.gpool'].reshape(-1).astype(np.float32).copy())).abs().max().item())
