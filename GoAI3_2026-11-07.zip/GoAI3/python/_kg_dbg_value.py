# -*- coding: utf-8 -*-
"""手算验证 value head 的池化与输出，定位 value 发散原因。"""
import struct, sys
import numpy as np
import torch
sys.stdout.reconfigure(encoding='utf-8', errors='replace')
sys.path.insert(0, '.')
import _katago_v17_load as L


def read_ref(path):
    f = open(path, 'rb')
    assert f.read(8) == b'KGREF001'
    n = struct.unpack('<i', f.read(4))[0]
    D = {}
    for _ in range(n):
        nl = struct.unpack('<i', f.read(4))[0]
        name = f.read(nl).decode()
        nd = struct.unpack('<i', f.read(4))[0]
        dims = [struct.unpack('<i', f.read(4))[0] for _ in range(nd)]
        c = 1
        for d in dims:
            c *= d
        D[name] = np.frombuffer(f.read(4 * c), dtype='<f4').reshape(dims).copy()
    return D


M = L.load(sys.argv[1], verbose=False)
D = read_ref(sys.argv[2])

# 参考的 act1（空间特征，(1,192,19,19)）→ 池化 → 576
act1 = torch.from_numpy(D['value_head.act1'].astype(np.float32))
C = 192
S = 361
mask = torch.ones(1, 1, 19, 19)
msum = mask.sum()
off = torch.sqrt(msum) - 14.0
mean = act1.sum(dim=(2, 3), keepdim=True) / msum
pooled_mine = torch.cat([
    mean,
    mean * (off / 10.0),
    mean * ((off * off) / 100.0 - 0.1),
], dim=1).reshape(-1).numpy()
ref_pooled = D['value_head.gpool'].reshape(-1)
print('value gpool: |mine - ref|max = %.6e' % np.abs(pooled_mine - ref_pooled).max())
print('  mine[:3]=', np.round(pooled_mine[:3], 6).tolist())
print('  ref [:3]=', np.round(ref_pooled[:3], 6).tolist())
print('  mine[192:195]=', np.round(pooled_mine[192:195], 6).tolist())
print('  ref [192:195]=', np.round(ref_pooled[192:195], 6).tolist())

# linear2: 576 -> 192 -> act2
W2 = torch.from_numpy(np.asarray(M['valueHead']['v2Mul']['w'], dtype=np.float32))
b2 = torch.from_numpy(np.asarray(M['valueHead']['v2Bias']['b'], dtype=np.float32))
pooled_t = torch.from_numpy(ref_pooled)
h = torch.nn.functional.linear(pooled_t, W2, b2)
h = torch.nn.functional.silu(h)
ref_h = torch.from_numpy(D['value_head.linear2'].reshape(-1).astype(np.float32).copy())
print('\nlinear2(192): |mine - ref|max = %.6e' % (h - ref_h).abs().max().item())
print('  mine[:3]=', np.round(h[:3].numpy(), 6).tolist())
print('  ref [:3]=', np.round(ref_h[:3].numpy(), 6).tolist())

# act2：池化后过 act2 的结果（192 维），参考里没有单独的键，用 silu(linear2) 复算
h_act = torch.nn.functional.silu(h)
ref_h_act = torch.nn.functional.silu(ref_h)
print('  silu(linear2) 一致性: %.3e' % (h_act - ref_h_act).abs().max().item())

# value = v3Mul(act2) + v3Bias
W3 = torch.from_numpy(np.asarray(M['valueHead']['v3Mul']['w'], dtype=np.float32))
b3 = torch.from_numpy(np.asarray(M['valueHead']['v3Bias']['b'], dtype=np.float32))
val = torch.nn.functional.linear(ref_h, W3, b3)
ref_val = D['out.policy.1'].reshape(-1)
print('\nvalue(手算 self 参考 act2): ', np.round(val.numpy(), 6).tolist())
print('value(参考 out.policy.1)  : ', np.round(ref_val, 6).tolist())
print('|diff|max = %.6e' % np.abs(val.numpy() - ref_val).max())

# misc：file v2Mul 是 linear2，sv3Mul 是 misc 的前 6 通道
Wm = torch.from_numpy(np.asarray(M['valueHead']['sv3Mul']['w'], dtype=np.float32))
bm = torch.from_numpy(np.asarray(M['valueHead']['sv3Bias']['b'], dtype=np.float32))
misc = torch.nn.functional.linear(ref_h, Wm, bm)
ref_misc = D['value_head.linear_miscvaluehead'].reshape(-1)
print('\nmisc(手算 sv3Mul, 6 通道):', np.round(misc.numpy(), 5).tolist())
print('misc(参考 10 通道)      :', np.round(ref_misc, 5).tolist())
print('前 6 通道 |diff|max = %.6e' % np.abs(misc.numpy() - ref_misc[:6]).max())
