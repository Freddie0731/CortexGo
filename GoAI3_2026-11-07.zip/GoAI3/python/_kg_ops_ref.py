# -*- coding: utf-8 -*-
"""逐算子参考值生成器：为每个 C++ 算子单独生成 PyTorch 参考。

做法：用同一个权重文件，构造小规模、可控的输入，直接调用 PyTorch 的等价算子，
把输入与输出一起写进 ops_ref.bin。C++ 侧读同一文件、复算、比对。

这样能精确定位是哪个算子实现错了，不受张量布局（NCHW vs (S,C)）的干扰。

用法: python _kg_ops_ref.py <weights.bin.gz> <ops_ref.bin> [--seed 7]
"""
import sys, os, struct
import numpy as np
import torch

try:
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
except Exception:
    pass

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
os.environ.setdefault('TORCHDYNAMO_DISABLE', '1')

import _katago_v17_load as L
from _kg_ref import Dumper

torch.manual_seed(7)
np.random.seed(7)


def rnd(*shape):
    return torch.randn(*shape, dtype=torch.float32)


def main():
    wpath = sys.argv[1]
    outpath = sys.argv[2]
    M = L.load(wpath, verbose=False)
    d = Dumper(outpath)

    # ---------- 1. linear (matmul) ----------
    W = torch.from_numpy(np.ascontiguousarray(M['trunk']['initialMatMul']['w']))
    OC, IC = W.shape
    x = rnd(5, IC)
    d.add('linear.x', x)
    d.add('linear.W', W)
    d.add('linear.out', torch.nn.functional.linear(x, W))

    # ---------- 2. conv 3x3 (initialConv) ----------
    c = M['trunk']['initialConv']
    Wc = torch.from_numpy(np.ascontiguousarray(c['w']))   # (oc,ic,ky,kx)
    x3 = rnd(1, c['ic'], 19, 19)
    d.add('conv3.x', x3)
    d.add('conv3.W', Wc)
    d.add('conv3.out', torch.nn.functional.conv2d(x3, Wc, padding='same'))

    # ---------- 3. conv 1x1 (policy p1Conv) ----------
    c1 = M['policyHead']['p1Conv']
    W1 = torch.from_numpy(np.ascontiguousarray(c1['w']))
    x1 = rnd(1, c1['ic'], 19, 19)
    d.add('conv1.x', x1)
    d.add('conv1.W', W1)
    d.add('conv1.out', torch.nn.functional.conv2d(x1, W1, padding='same'))

    # ---------- 4. NormMask（y = x * scaleMul + beta，再乘掩码） ----------
    # 算子层只做 y = x * mul + beta 再乘掩码；mul 由解析器按分支算好。
    n = M['trunk']['blocks'][0]['q']['norm']
    C = n['c']
    xs = rnd(3, C)
    bi = np.array(n['bias'], dtype=np.float32, copy=True)
    mul = (0.5 * (1.0 + np.array(n['scale'], dtype=np.float32))).astype(np.float32)
    mk = torch.tensor([[1.0], [0.0], [1.0]], dtype=torch.float32)
    d.add('norm.x', xs)
    d.add('norm.bias', torch.from_numpy(bi))
    d.add('norm.mul', torch.from_numpy(mul))
    d.add('norm.mask', mk)
    y = (xs * torch.from_numpy(mul) + torch.from_numpy(bi)) * mk
    d.add('norm.out', y)

    # ---------- 5. RMSNorm（非 spatial） ----------
    a = M['trunk']['blocks'][0]['stack'][0]   # transformer_attention_block
    w = torch.from_numpy(np.ascontiguousarray(a['preLN']['weight']))
    eps = a['preLN']['eps']
    xr = rnd(4, w.shape[0])
    d.add('rmsnorm.x', xr)
    d.add('rmsnorm.weight', w)
    d.add('rmsnorm.eps', torch.tensor([eps], dtype=torch.float32))
    d.add('rmsnorm.out', torch.nn.functional.rms_norm(xr, (w.shape[0],), w, eps))

    # ---------- 6. SiLU ----------
    xa = rnd(4, 7)
    d.add('silu.x', xa)
    d.add('silu.out', torch.nn.functional.silu(xa))

    # ---------- 7. RoPE（可学习 2D） ----------
    H = a['numHeads']
    D = a['qHeadDim']
    S = 19 * 19
    fr = torch.from_numpy(np.ascontiguousarray(a['ropeFreqs'])).reshape(H, D // 2, 2)
    q = rnd(S, H, D)
    k = rnd(S, H, D)
    d.add('rope.q', q)
    d.add('rope.k', k)
    d.add('rope.freqs', fr)
    d.add('rope.poslen', torch.tensor([19], dtype=torch.float32))
    # 官方 apply_learnable_rotary_emb（batch 维为 1）
    s_idx = torch.arange(S)
    s_y = (s_idx // 19).float()
    s_x = (s_idx % 19).float()
    angles = (s_x.unsqueeze(-1).unsqueeze(-1) * fr[:, :, 0]
              + s_y.unsqueeze(-1).unsqueeze(-1) * fr[:, :, 1])   # (S,H,P)
    cos = torch.cos(angles).unsqueeze(0)   # (1,S,H,P)
    sin = torch.sin(angles).unsqueeze(0)

    def rotate(x):
        B, SS, HH, DD = x.shape
        P = DD // 2
        xp = x.view(B, SS, HH, P, 2)
        x0, x1 = xp.unbind(dim=-1)
        out = torch.stack([x0 * cos - x1 * sin, x0 * sin + x1 * cos], dim=-1)
        return out.reshape(B, SS, HH, DD)

    d.add('rope.qout', rotate(q.unsqueeze(0)).squeeze(0))
    d.add('rope.kout', rotate(k.unsqueeze(0)).squeeze(0))

    # ---------- 8. attention（含掩码） ----------
    H2, D2, V2 = 4, 8, 8
    S2 = 6
    qa = rnd(1, H2, S2, D2)
    ka = rnd(1, H2, S2, D2)
    va = rnd(1, H2, S2, V2)
    mk2 = torch.tensor([1.0, 1.0, 0.0, 1.0, 0.0, 1.0], dtype=torch.float32)
    d.add('attn.q', qa)
    d.add('attn.k', ka)
    d.add('attn.v', va)
    d.add('attn.mask', mk2)
    am = torch.zeros(1, 1, 1, S2)
    am.masked_fill_(mk2.view(1, 1, 1, S2) == 0, float('-inf'))
    d.add('attn.out', torch.nn.functional.scaled_dot_product_attention(
        qa, ka, va, attn_mask=am, scale=1.0 / (D2 ** 0.5)))

    # ---------- 9. gpool（用 (S,C) 行优先，与 C++ 完全同布局）----------
    # 官方公式来自 KataGPool.forward / KataValueHeadGPool.forward：
    #   mean = sum(x*mask)/maskSum
    #   pool1 = mean
    #   pool2 = mean * ((sqrt(maskSum)-14)/10)
    #   pool3 = mean * (((sqrt(maskSum)-14)^2)/100 - 0.1)   [value head 版]
    #           或 max(x + (mask-1))                          [policy head 版]
    Cg, Sg = 5, 4
    xg = rnd(Sg, Cg)                       # (S,C) 行优先
    mkg = torch.tensor([1.0, 1.0, 0.0, 1.0], dtype=torch.float32)
    d.add('gpool.x', xg)
    d.add('gpool.mask', mkg)
    msum = mkg.sum()
    off = torch.sqrt(msum) - 14.0
    # (S,C) -> 按位置求和
    mean = (xg * mkg.unsqueeze(1)).sum(dim=0) / msum          # (C,)
    mx = (xg + (mkg.unsqueeze(1) - 1.0)).amax(dim=0)           # (C,)
    gp = torch.cat([mean, mean * (off / 10.0), mx], dim=0)     # 3C
    d.add('gpool.out', gp)
    # 另存 value head 版 pool3，供交叉检查
    d.add('gpool.out_valuepool3',
          torch.cat([mean, mean * (off / 10.0),
                     mean * ((off * off) / 100.0 - 0.1)], dim=0))

    # ---------- 10. SwiGLU ----------
    xsw = rnd(3, 6)
    W1s = rnd(9, 6)
    Wgs = rnd(9, 6)
    W2s = rnd(6, 9)
    d.add('swiglu.x', xsw)
    d.add('swiglu.W1', W1s)
    d.add('swiglu.Wg', Wgs)
    d.add('swiglu.W2', W2s)
    h1 = torch.nn.functional.linear(xsw, W1s)
    h2 = torch.nn.functional.linear(xsw, Wgs)
    d.add('swiglu.out', torch.nn.functional.linear(torch.nn.functional.silu(h1) * h2, W2s))

    n = d.close()
    print('写出 %s : %d 个张量, %.3f MB' % (outpath, n, os.path.getsize(outpath) / 1048576.0))


if __name__ == '__main__':
    main()
