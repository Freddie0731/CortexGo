# -*- coding: utf-8 -*-
"""KataGo v17 .bin.gz 权重解析器 —— 严格反照官方 export_model_pytorch.py 的写出顺序。

格式要点（全部来自官方源码，不是猜测）：
  * 元数据是**空白分隔的 token 流**（C++ operator>>），权重是 "@BIN@" + 4N 字节小端 float32
  * 每个层的名字也是从流里读出来的 token，**没有按名字查找**
  * 卷积权重写出前做 permute(2,3,1,0)：文件里是 (y,x,ic,oc)；
    读回 PyTorch 顺序需要 permute(3,2,0,1) -> (oc,ic,y,x)
  * Linear 权重写出前做 permute(1,0)：文件里是 (ic,oc)；读回需要转置 -> (oc,ic)
  * BatchNorm 写 running_std^2 - eps（**不是 variance**）
  * 内存布局一律 NCHW

用法: python _katago_v17_load.py <file.bin.gz> [--summary]
"""
import gzip, struct, sys

try:
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
except Exception:
    pass

try:
    import numpy as np
except ImportError:
    np = None


class Tok(object):
    """模拟 C++ istream：空白分隔 token + @BIN@ 二进制块。"""

    def __init__(self, data):
        self.d = data
        self.p = 0

    def _ws(self):
        d, n = self.d, len(self.d)
        while self.p < n and d[self.p] in (32, 9, 10, 13, 11, 12):
            self.p += 1

    def s(self):
        """读一个字符串 token。"""
        self._ws()
        d, n = self.d, len(self.d)
        if self.p >= n:
            raise EOFError('eof reading token at %d' % self.p)
        st = self.p
        while self.p < n and d[self.p] not in (32, 9, 10, 13, 11, 12):
            self.p += 1
        return d[st:self.p].decode('utf-8')

    def i(self):
        return int(float(self.s()))

    def f(self):
        return float(self.s())

    def w(self, count):
        """读 @BIN@ 后的 count 个 float32。"""
        self._ws()
        d = self.d
        k = 0
        while self.p < len(d) and d[self.p:self.p + 1] != b'@':
            self.p += 1
            k += 1
            if k > 100:
                raise EOFError('no @ within 100 chars at %d' % self.p)
        if d[self.p:self.p + 5] != b'@BIN@':
            raise EOFError('no @BIN@ at %d, saw %r' % (self.p, d[self.p:self.p + 12]))
        self.p += 5
        need = 4 * count
        if self.p + need > len(d):
            raise EOFError('binary block truncated at %d (need %d)' % (self.p, need))
        if np is not None:
            arr = np.frombuffer(d, dtype='<f4', count=count, offset=self.p)
        else:
            arr = struct.unpack_from('<%df' % count, d, self.p)
        self.p += need
        return arr

    def at_end(self):
        self._ws()
        return self.p >= len(self.d)


# ------------------------------------------------------------------ 层读取
def rd_conv(T):
    name = T.s()
    cy = T.i(); cx = T.i(); ic = T.i(); oc = T.i()
    dy = T.i(); dx = T.i()
    raw = T.w(cy * cx * ic * oc)
    if np is not None:
        # 文件 (y,x,ic,oc) -> torch (oc,ic,y,x)
        w = raw.reshape(cy, cx, ic, oc).transpose(3, 2, 0, 1).copy()
    else:
        w = raw
    return {'name': name, 'cy': cy, 'cx': cx, 'ic': ic, 'oc': oc, 'dy': dy, 'dx': dx, 'w': w}


def rd_bn(T):
    name = T.s()
    c = T.i()
    eps = T.f()
    has_scale = T.i()
    has_bias = T.i()
    rmean = T.w(c)
    rvar = T.w(c)
    scale = T.w(c) if has_scale else None
    bias = T.w(c) if has_bias else None
    return {'name': name, 'c': c, 'eps': eps, 'has_scale': has_scale, 'has_bias': has_bias,
            'running_mean': rmean, 'running_var': rvar, 'scale': scale, 'bias': bias}


def rd_act(T):
    name = T.s()
    kind = T.s()
    return {'name': name, 'kind': kind}


def rd_matmul(T):
    name = T.s()
    ic = T.i(); oc = T.i()
    raw = T.w(ic * oc)
    if np is not None:
        w = raw.reshape(ic, oc).transpose(1, 0).copy()   # -> (oc,ic)
    else:
        w = raw
    return {'name': name, 'ic': ic, 'oc': oc, 'w': w}


def rd_matbias(T):
    name = T.s()
    c = T.i()
    return {'name': name, 'c': c, 'b': T.w(c)}


def rd_rmsnorm(T):
    name = T.s()
    c = T.i()
    eps = T.f()
    spatial = T.i()
    cgroup = T.i()
    gamma = T.w(c)
    beta = T.w(c)
    return {'name': name, 'c': c, 'eps': eps, 'spatial': spatial, 'cgroup': cgroup,
            'gamma': gamma, 'beta': beta}


def rd_transformer_rmsnorm(T):
    name = T.s()
    c = T.i()
    eps = T.f()
    w = T.w(c)
    return {'name': name, 'c': c, 'eps': eps, 'weight': w}


def rd_transformer_attention(T, name):
    """transformer_attention_block 的**名字之后**的内容（desc.cpp:1175）。"""
    d = {'kind': 'transformer_attention_block', 'name': name}
    d['numHeads'] = T.i()
    d['numKVHeads'] = T.i()
    d['qHeadDim'] = T.i()
    d['vHeadDim'] = T.i()
    d['useRope'] = T.i()
    d['learnableRope'] = T.i()
    d['preLN'] = rd_transformer_rmsnorm(T)
    d['qProj'] = rd_matmul(T)
    d['kProj'] = rd_matmul(T)
    d['vProj'] = rd_matmul(T)
    d['outProj'] = rd_matmul(T)
    if d['useRope']:
        if d['learnableRope']:
            d['ropeFreqsName'] = T.s()
            d['ropeNumKVHeads'] = T.i()
            d['ropeNumPairs'] = T.i()
            rope_dim2 = T.i()
            if rope_dim2 != 2:
                raise ValueError('rope dim2 must be 2, got %d' % rope_dim2)
            d['ropeFreqs'] = T.w(d['ropeNumKVHeads'] * d['ropeNumPairs'] * 2)
        else:
            d['ropeThetaName'] = T.s()
            d['ropeTheta'] = T.f()
    return d


def rd_transformer_ffn(T, name):
    """transformer_ffn_block 的**名字之后**的内容（desc.cpp:1373）。"""
    d = {'kind': 'transformer_ffn_block', 'name': name}
    d['numChannels'] = T.i()
    d['ffnChannels'] = T.i()
    d['useSwiGLU'] = T.i()
    d['preLN'] = rd_transformer_rmsnorm(T)
    d['linear1'] = rd_matmul(T)
    if d['useSwiGLU']:
        d['linearGate'] = rd_matmul(T)
    d['linear2'] = rd_matmul(T)
    return d


def rd_normactconv(T, n):
    """NormActConv：norm(=BN) + act + conv（普通分支）。"""
    bn = rd_bn(T)
    act = rd_act(T)
    cv = rd_conv(T)
    return {'name': n, 'norm': bn, 'act': act, 'conv': cv}


def rd_normactconv_gpool(T, n):
    """NormActConv 的 gpool 分支：KataConvAndGPool（写侧 .convpool.*）。"""
    bn = rd_bn(T)
    act = rd_act(T)
    c1r = rd_conv(T)
    c1g = rd_conv(T)
    ng = rd_bn(T)
    ag = rd_act(T)
    lg = rd_matmul(T)
    return {'name': n, 'norm': bn, 'act': act, 'conv1r': c1r, 'conv1g': c1g,
            'normg': ng, 'actg': ag, 'linear_g': lg}


def rd_block(T, c_gpool):
    """按写侧 write_block 分派，覆盖全部 5 种块。"""
    kind = T.s()
    name = T.s()
    if kind == 'ordinary_block':
        return {'kind': kind, 'name': name,
                'normactconv1': rd_normactconv(T, name + '.normactconv1'),
                'normactconv2': rd_normactconv(T, name + '.normactconv2')}
    if kind == 'gpool_block':
        return {'kind': kind, 'name': name,
                'normactconv1': rd_normactconv_gpool(T, name + '.normactconv1'),
                'normactconv2': rd_normactconv(T, name + '.normactconv2')}
    if kind == 'nested_bottleneck_block':
        internal = T.i()
        p = rd_normactconv(T, name + '.normactconvp')
        subs = [rd_block(T, c_gpool) for _ in range(internal)]
        q = rd_normactconv(T, name + '.normactconvq')
        return {'kind': kind, 'name': name, 'internal_length': internal,
                'p': p, 'stack': subs, 'q': q}
    if kind == 'transformer_attention_block':
        return rd_transformer_attention(T, name)
    if kind == 'transformer_ffn_block':
        return rd_transformer_ffn(T, name)
    raise ValueError('unsupported block kind: %r (offset %d)' % (kind, T.p))


def _unused_legacy_after_kind(T):
    return None


# ------------------------------------------------------------------ 主解析
def load(path, verbose=True):
    with gzip.open(path, 'rb') as g:
        data = g.read()
    T = Tok(data)
    M = {'file_size': len(data)}

    # ---- ModelDesc ----
    M['name'] = T.s()
    M['modelVersion'] = T.i()
    M['numInputChannels'] = T.i()
    M['numInputGlobalChannels'] = T.i()
    if M['modelVersion'] >= 13:
        for k in ('tdScoreMultiplier', 'scoreMeanMultiplier', 'scoreStdevMultiplier',
                  'leadMultiplier', 'varianceTimeMultiplier',
                  'shorttermValueErrorMultiplier', 'shorttermScoreErrorMultiplier'):
            M[k] = T.f()
    if M['modelVersion'] >= 15:
        M['metaEncoderVersion'] = T.i()
        M['preferPassAliveUnderSuicideRules'] = T.i()
        M['preferExcludeTerritoryAdjacentToAtari'] = T.i()
        for i in range(5):
            v = T.i()
            if v != 0:
                raise ValueError('nonzero reserved model option %d = %d' % (i, v))

    # ---- TrunkDesc ----
    tr = {}
    tr['name'] = T.s()
    tr['numBlocks'] = T.i()
    tr['trunkNumChannels'] = T.i()
    tr['midNumChannels'] = T.i()
    tr['regularNumChannels'] = T.i()
    tr['dilatedNumChannels'] = T.i()
    tr['gpoolNumChannels'] = T.i()
    tr['trunkNormKind'] = 0
    if M['modelVersion'] >= 15:
        tr['trunkNormKind'] = T.i()
        for i in range(5):
            v = T.i()
            if v != 0:
                raise ValueError('nonzero reserved trunk option %d = %d' % (i, v))

    tr['initialConv'] = rd_conv(T)     # model.conv_spatial
    tr['initialMatMul'] = rd_matmul(T)  # model.linear_global
    if M.get('metaEncoderVersion', 0) > 0:
        raise NotImplementedError('sgf metadata encoder not handled yet')

    tr['blocks'] = [rd_block(T, tr['gpoolNumChannels']) for _ in range(tr['numBlocks'])]

    if tr['trunkNormKind'] == 0:
        tr['trunkTipNorm'] = rd_bn(T)
        tr['trunkTipNormIsRMS'] = False
    else:
        tr['trunkTipNorm'] = rd_rmsnorm(T)
        tr['trunkTipNormIsRMS'] = True
    tr['trunkTipAct'] = rd_act(T)
    M['trunk'] = tr

    # ---- PolicyHead ----
    ph = {}
    ph['name'] = T.s()
    if M['modelVersion'] >= 17:
        ph['numPolicyOutChannels'] = T.i()
        for i in range(3):
            v = T.i()
            if v != 0:
                raise ValueError('nonzero reserved policy option %d = %d' % (i, v))
    ph['p1Conv'] = rd_conv(T)
    ph['g1Conv'] = rd_conv(T)
    ph['g1BN'] = rd_bn(T)
    ph['g1Activation'] = rd_act(T)
    ph['gpoolToBiasMul'] = rd_matmul(T)
    ph['p1BN'] = rd_bn(T)
    ph['p1Activation'] = rd_act(T)
    ph['p2Conv'] = rd_conv(T)
    ph['gpoolToPassMul'] = rd_matmul(T)
    if M['modelVersion'] >= 15:
        ph['gpoolToPassBias'] = rd_matbias(T)
        ph['passActivation'] = rd_act(T)
        ph['gpoolToPassMul2'] = rd_matmul(T)
    M['policyHead'] = ph

    # ---- ValueHead ----
    vh = {}
    vh['name'] = T.s()
    if M['modelVersion'] >= 17:
        for i in range(3):
            v = T.i()
            if v != 0:
                raise ValueError('nonzero reserved value option %d = %d' % (i, v))
    vh['v1Conv'] = rd_conv(T)
    vh['v1BN'] = rd_bn(T)
    vh['v1Activation'] = rd_act(T)
    vh['v2Mul'] = rd_matmul(T)
    vh['v2Bias'] = rd_matbias(T)
    vh['v2Activation'] = rd_act(T)
    vh['v3Mul'] = rd_matmul(T)
    vh['v3Bias'] = rd_matbias(T)
    vh['sv3Mul'] = rd_matmul(T)
    vh['sv3Bias'] = rd_matbias(T)
    vh['vOwnershipConv'] = rd_conv(T)
    M['valueHead'] = vh

    M['bytes_consumed'] = T.p
    M['at_end'] = T.at_end()
    M['numParams'] = _count_params(M)

    if verbose:
        print('parsed %d / %d bytes (%.4f%%), at_end=%s'
              % (T.p, len(data), 100.0 * T.p / len(data), M['at_end']))
        print('params: %.2fM' % (M['numParams'] / 1e6))
    return M


def _sz(w):
    if w is None:
        return 0
    try:
        return int(w.size)
    except AttributeError:
        return len(w)


def _count_params(M):
    n = 0

    def acc_conv(c):
        return _sz(c.get('w')) if isinstance(c, dict) else 0

    def acc_norm(bn):
        if not isinstance(bn, dict):
            return 0
        return (_sz(bn.get('running_mean')) + _sz(bn.get('running_var'))
                + _sz(bn.get('scale')) + _sz(bn.get('bias'))
                + _sz(bn.get('weight')) + _sz(bn.get('gamma')))

    def acc_normactconv(nc):
        t = 0
        t += acc_norm(nc.get('norm'))
        t += acc_conv(nc.get('conv'))
        for k in ('conv1r', 'conv1g'):
            t += acc_conv(nc.get(k))
        t += acc_norm(nc.get('normg'))
        t += _sz(nc.get('linear_g', {}).get('w'))
        return t

    def acc_matmul(mm):
        return _sz(mm.get('w')) if isinstance(mm, dict) else 0

    def acc_matbias(mb):
        return _sz(mb.get('b')) if isinstance(mb, dict) else 0

    def acc_block(b):
        t = 0
        k = b['kind']
        if k in ('ordinary_block',):
            t += acc_normactconv(b['normactconv1']) + acc_normactconv(b['normactconv2'])
        elif k == 'gpool_block':
            t += acc_normactconv(b['normactconv1']) + acc_normactconv(b['normactconv2'])
        elif k == 'nested_bottleneck_block':
            t += acc_normactconv(b['p']) + acc_normactconv(b['q'])
            for sb in b['stack']:
                t += acc_block(sb)
        elif k == 'transformer_attention_block':
            t += acc_norm(b['preLN'])
            for kk in ('qProj', 'kProj', 'vProj', 'outProj'):
                t += acc_matmul(b[kk])
            t += _sz(b.get('ropeFreqs'))
        elif k == 'transformer_ffn_block':
            t += acc_norm(b['preLN'])
            t += acc_matmul(b['linear1'])
            if 'linearGate' in b:
                t += acc_matmul(b['linearGate'])
            t += acc_matmul(b['linear2'])
        return t

    tr = M['trunk']
    n += acc_conv(tr['initialConv']) + acc_matmul(tr['initialMatMul'])
    n += acc_norm(tr['trunkTipNorm'])
    for b in tr['blocks']:
        n += acc_block(b)

    ph = M['policyHead']
    for k in ('p1Conv', 'g1Conv', 'p2Conv'):
        n += acc_conv(ph[k])
    for k in ('g1BN', 'p1BN'):
        n += acc_norm(ph[k])
    n += acc_matmul(ph['gpoolToBiasMul'])
    n += acc_matmul(ph['gpoolToPassMul'])
    if 'gpoolToPassBias' in ph:
        n += acc_matbias(ph['gpoolToPassBias'])
        n += acc_matmul(ph['gpoolToPassMul2'])

    vh = M['valueHead']
    n += acc_conv(vh['v1Conv']) + acc_conv(vh['vOwnershipConv'])
    n += acc_norm(vh['v1BN'])
    for k in ('v2Mul', 'v3Mul', 'sv3Mul'):
        n += acc_matmul(vh[k])
    for k in ('v2Bias', 'v3Bias', 'sv3Bias'):
        n += acc_matbias(vh[k])
    return n


def summary(M):
    tr = M['trunk']
    print('\n================ 模型摘要 ================')
    print('name                    : %s' % M['name'])
    print('modelVersion            : %d' % M['modelVersion'])
    print('numInputChannels        : %d  (空间平面)' % M['numInputChannels'])
    print('numInputGlobalChannels  : %d  (全局特征)' % M['numInputGlobalChannels'])
    print('trunk: blocks=%d channels=%d mid=%d regular=%d gpool=%d normKind=%d'
          % (tr['numBlocks'], tr['trunkNumChannels'], tr['midNumChannels'],
             tr['regularNumChannels'], tr['gpoolNumChannels'], tr['trunkNormKind']))
    print('initialConv   : %s  %dx%d  %d -> %d' % (
        tr['initialConv']['name'], tr['initialConv']['cy'], tr['initialConv']['cx'],
        tr['initialConv']['ic'], tr['initialConv']['oc']))
    print('initialMatMul : %s  %d -> %d' % (
        tr['initialMatMul']['name'], tr['initialMatMul']['ic'], tr['initialMatMul']['oc']))
    for i, b in enumerate(tr['blocks']):
        k = b['kind']
        if k == 'nested_bottleneck_block':
            dims = 'p %d->%d, stack[%s], q %d->%d' % (
                b['p']['conv']['ic'], b['p']['conv']['oc'],
                ','.join(x['kind'].replace('transformer_', 'tf_').replace('_block', '')
                         for x in b['stack']),
                b['q']['conv']['ic'], b['q']['conv']['oc'])
        elif k in ('ordinary_block', 'gpool_block'):
            dims = '%d->%d' % (b['normactconv1']['conv']['ic'], b['normactconv1']['conv']['oc'])
        elif k == 'transformer_attention_block':
            dims = 'heads=%d kv=%d qdim=%d vdim=%d rope=%d learn=%d qProj %d->%d' % (
                b['numHeads'], b['numKVHeads'], b['qHeadDim'], b['vHeadDim'],
                b['useRope'], b['learnableRope'], b['qProj']['ic'], b['qProj']['oc'])
        else:
            dims = 'c=%d ffn=%d swiglu=%d' % (b['numChannels'], b['ffnChannels'], b['useSwiGLU'])
        print('  block %2d %-30s %s' % (i, k, dims))
    print('trunkTipNorm  : %s  c=%d  eps=%s  RMS=%s' % (
        tr['trunkTipNorm']['name'], tr['trunkTipNorm']['c'],
        tr['trunkTipNorm']['eps'], tr['trunkTipNormIsRMS']))
    print('trunkTipAct   : %s' % tr['trunkTipAct']['kind'])
    ph = M['policyHead']
    print('policyHead    : p1Conv %d->%d, g1Conv %d->%d, gpoolToBiasMul %d->%d, p2Conv out=%d, gpoolToPassMul %d->%d'
          % (ph['p1Conv']['ic'], ph['p1Conv']['oc'], ph['g1Conv']['ic'], ph['g1Conv']['oc'],
             ph['gpoolToBiasMul']['ic'], ph['gpoolToBiasMul']['oc'], ph['p2Conv']['oc'],
             ph['gpoolToPassMul']['ic'], ph['gpoolToPassMul']['oc']))
    vh = M['valueHead']
    print('valueHead     : v1Conv %d->%d, v2Mul %d->%d, v3Mul %d->%d, sv3Mul %d->%d, ownership %d->%d'
          % (vh['v1Conv']['ic'], vh['v1Conv']['oc'], vh['v2Mul']['ic'], vh['v2Mul']['oc'],
             vh['v3Mul']['ic'], vh['v3Mul']['oc'], vh['sv3Mul']['ic'], vh['sv3Mul']['oc'],
             vh['vOwnershipConv']['ic'], vh['vOwnershipConv']['oc']))


if __name__ == '__main__':
    path = sys.argv[1]
    M = load(path)
    summary(M)
