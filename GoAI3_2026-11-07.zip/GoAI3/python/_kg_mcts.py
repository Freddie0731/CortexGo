# -*- coding: utf-8 -*-
"""PUCT MCTS —— 用来给自我对弈产生**策略目标**。

## 为什么要它

纯策略自对弈时，策略目标就是网络自己的输出，交叉熵梯度恒为 0，学不到东西。
REINFORCE 式的策略梯度虽然无偏，但方差极大，需要海量对局才见效。

AlphaZero 的做法才是正路：**用 MCTS 的访问分布当策略目标**。
MCTS 用网络的价值做引导、比策略本身多想几步，于是访问分布里含有
"网络原来没看出来、但确实更好的招" —— 这才有真正的学习信号。

代价是每次落子要做 `visits` 次网络前向。本机 CPU 一次 0.19 秒，100 访问
就是 19 秒/手；云端 GPU 一次约 0.02 秒，同样 100 访问只要 2 秒/手。
**所以这个模块是为 GPU 设计的**，本机只用来做小规模正确性验证。

## 与 C++ 那套 search.h 的关系

算法同源（PUCT + 访问分布），但这里是 Python，因为训练要在同一个进程里
用同一个 PyTorch 模型（GPU 上才有意义）。C++ 那套是给引擎对弈用的。

## 价值视角约定

节点存的值都以"**该节点轮到的行棋方**"为视角（+1 = 该方赢）。
回传时按颜色翻转。这与 go_ai.cpp 里的做法一致。
"""
import math

import numpy as np


class Node(object):
    __slots__ = ('cells', 'pla', 'hist', 'move', 'parent', 'children',
                 'n', 'w', 'p', 'expanded', 'terminal', 'v', 'legal')

    def __init__(self, cells, pla, hist, move, parent, p=0.0):
        self.cells = cells
        self.pla = pla
        self.hist = hist
        self.move = move
        self.parent = parent
        self.children = []
        self.n = 0
        self.w = 0.0
        self.p = p
        self.expanded = False
        self.terminal = False
        self.v = 0.0
        self.legal = []

    def q(self):
        return (self.w / self.n) if self.n > 0 else 0.0


def _counts_to_policy(children, S):
    """访问次数 -> 长度 S+1 的概率分布（索引 S 表示 pass）。"""
    out = np.zeros(S + 1, dtype=np.float32)
    tot = 0
    for c in children:
        tot += c.n
    if tot <= 0:
        for c in children:
            out[c.move] = 1.0
        s = out.sum()
        return out / s if s > 0 else out
    for c in children:
        out[c.move] = c.n / float(tot)
    return out


def search(forward, rules, S, visits, komi,
           cpuct=1.5, fpu=0.2, rng=None,
           dirichlet_eps=0.25, dirichlet_alpha=0.3,
           temperature=1.0):
    """跑一次 MCTS，返回 (策略目标, 根节点视角价值, 选中的着法)。

    forward(sp, gl) -> (policy 概率长度 S+1, winrate[-1,1], ...)
    由调用方提供，内部负责把局面编码成网络输入。
    """
    cells0, pla0, hist0 = rules['cells'], rules['pla'], rules['hist']
    encode = rules['encode']
    play = rules['play']
    area = rules['area']
    max_moves = rules.get('max_moves', 500)

    if rng is None:
        rng = np.random.default_rng(0)

    root = Node(cells0, pla0, hist0, None, None, 1.0)
    _expand(root, forward, rules, S)

    # 根节点加 Dirichlet 噪声：否则搜索会反复走同一条线，自我对弈缺少多样性
    if dirichlet_eps > 0 and len(root.children) > 1:
        k = len(root.children)
        noise = rng.dirichlet([dirichlet_alpha] * k)
        for i, c in enumerate(root.children):
            c.p = (1.0 - dirichlet_eps) * c.p + dirichlet_eps * noise[i]

    for _ in range(visits):
        node = root
        path = [node]
        # ---- 选择 ----
        while node.expanded and not node.terminal:
            sqrt_n = math.sqrt(max(1, sum(c.n for c in node.children)))
            best = None
            best_sc = -1e30
            base_q = node.q()
            for c in node.children:
                q = c.q() if c.n > 0 else (base_q - fpu)
                u = cpuct * c.p * sqrt_n / (1.0 + c.n)
                sc = -q + u              # 子节点价值是对手视角，取负
                if sc > best_sc:
                    best_sc = sc
                    best = c
            if best is None:
                break
            node = best
            path.append(node)
            if node.terminal:
                break

        # ---- 展开 / 取值 ----
        if not node.expanded and not node.terminal:
            _expand(node, forward, rules, S)
        v = node.v if node.terminal else node.v

        # ---- 回传（按颜色翻转） ----
        leaf_pla = node.pla
        for n in reversed(path):
            w = v if n.pla == leaf_pla else -v
            n.n += 1
            n.w += w

    pol = _counts_to_policy(root.children, S)
    if temperature > 0 and temperature != 1.0:
        p = np.power(np.maximum(pol, 1e-12), 1.0 / temperature)
        pol = p / p.sum()

    if temperature <= 1e-6:
        pick = int(np.argmax(pol))
    else:
        pick = int(rng.choice(len(pol), p=pol / pol.sum()))

    return pol, root.q(), pick


def _expand(node, forward, rules, S):
    """展开一个节点：算先验、建子节点、求该节点价值。"""
    node.expanded = True
    play = rules['play']
    area = rules['area']
    encode = rules['encode']

    # 终局判定
    if rules.get('is_over') is not None and rules['is_over'](node):
        node.terminal = True
        sc = area(node.cells) - rules['komi']
        self_sc = sc if node.pla == 1 else -sc
        node.v = 1.0 if self_sc > 0 else -1.0
        return

    sp, gl = encode(node.cells, node.hist, node.pla, rules['komi'])
    pol, wr, _ = forward(sp, gl)
    node.v = float(wr)            # 已经是当前方视角

    for i in range(S):
        if node.cells[i] != 0:
            continue
        res = play(node.cells, i, node.pla)
        if res is None:
            continue
        child = Node(res[0], 3 - node.pla,
                     node.hist + [((i % 19, i // 19), node.pla)], i, node,
                     p=float(pol[i]))
        node.children.append(child)

    # 说明：这里**不把 pass 放进搜索树**。
    # 原因有二：(1) 训练数据只取开局到中盘，pass 几乎不出现；
    # (2) 历史数组用 (-1,-1) 表示 pass，而 _kg_enc.encode 会按坐标索引，
    #     传进去会越界。要支持 pass 就得同时改编码器的历史处理，
    #     不值得在验证阶段引入这个复杂度。对局由 max_moves 收尾。

    tot = sum(c.p for c in node.children)
    if tot > 0:
        for c in node.children:
            c.p /= tot
