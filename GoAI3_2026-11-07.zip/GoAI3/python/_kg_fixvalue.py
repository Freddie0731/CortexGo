# -*- coding: utf-8 -*-
"""修 value head —— 只重训价值头的小 MLP，冻结全部主干。

## 为什么这样做

价值头结构：gpool(576) -> linear2(192) -> act2(SiLU) -> linear_valuehead(3)

现状（实测）：
    空盘           win=-3.76  loss=+4.42   -> 说"行棋方输 99.97%"
    黑占1/4(白先)  win=-9.74  loss=+9.38   -> 方向对
    黑占3/4(白先)  win=-16.98 loss=+15.74  -> 方向对
方向是对的（随局面单调变化），但**幅度荒谬**：空盘上 win/loss 的 logit 差
就有 8.18，而训练好的网络在空盘应当接近 50%。

关键点：主干的特征本身是好的（策略头在空盘给出四个星位共 95% 概率，
与真实 KataGo 一致），坏的只是最后这两层的标定。

所以**不需要**反向传播穿过 70M 主干 —— 那在本机 CPU 上要 0.99 秒/局面。
只要：
  1. 对每个局面做一次前向，把 linear2 的输入（576 维）缓存下来
  2. 在这 576 维上重训 linear2 + act2 + linear_valuehead（约 11 万参数）
     —— 相当于一个两层 MLP 的 logistic 回归，本机 CPU 每秒能跑几千步

## 标签

用终局结果：当前行棋方赢了 -> [1,0,0]，输了 -> [0,1,0]，然后对 3 个通道做
softmax 交叉熵。这是确定真值，不依赖搜索质量。

## 用法

  # 1) 产数据（可以复用 _kg_pipeline.py selfplay 的产物）
  python _kg_pipeline.py selfplay --games 20 --out data/ --mcts-visits 0 --max-moves 200

  # 2) 修价值头
  python _kg_fixvalue.py --weights kata1.bin.gz --data data/ \
         --steps 3000 --out fixvalue.pt --export kata1_vfix.bin.gz

  # 3) 看效果
  python _kg_fixvalue.py --weights kata1.bin.gz --show-only
"""
import argparse
import glob
import os
import sys
import time

os.environ.setdefault('TORCHDYNAMO_DISABLE', '1')
os.environ.setdefault('TORCH_COMPILE_DISABLE', '1')

try:
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
except Exception:
    pass

import numpy as np
import torch

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

CUDA = torch.cuda.is_available()
if not CUDA:
    os.environ.setdefault('KATAGO_FLEX_ATTENTION', '0')
DEVICE = torch.device('cuda' if CUDA else 'cpu')

CFG_NAME = 'b11c768h12nbt3tflrs-fs-silu'
N = 19
S = 361


def log(m):
    print(m, flush=True)


# ---------------------------------------------------------------------------
def load_model(weights):
    import _katago_v17_load as L
    from _katago_official import load_official
    from _kg_ref import build_state_dict
    M = L.load(weights, verbose=False)
    Model, mc = load_official()
    model = Model(mc.config_of_name[CFG_NAME], N)
    model.initialize()
    sd = build_state_dict(M)
    t = {}
    for k, v in model.state_dict().items():
        if k in sd:
            a = np.array(sd[k], dtype=np.float32, copy=True)
            if tuple(a.shape) == tuple(v.shape):
                t[k] = torch.from_numpy(a)
    model.load_state_dict(t, strict=False)
    model.to(DEVICE)
    model.eval()
    return model


def value_head_layers(model):
    """返回 (linear2, act2_kind, linear_valuehead)。"""
    vh = None
    for name in ('value_head', 'valuehead'):
        if hasattr(model, name):
            vh = getattr(model, name)
            break
    if vh is None:
        raise SystemExit('找不到 value_head 属性')
    lin2 = getattr(vh, 'linear2', None)
    lin3 = getattr(vh, 'linear_valuehead', None)
    if lin2 is None or lin3 is None:
        raise SystemExit('找不到 linear2 / linear_valuehead')
    return lin2, lin3


def eval_board(model, cells, hist, pla, komi, encode, mkboard):
    """跑一次前向，返回 (winrate, win/loss/noresult 原始 logit)。"""
    sp, gl = encode(mkboard(cells), hist, pla, komi)
    sp = np.ascontiguousarray(sp, dtype=np.float32)
    gl = np.ascontiguousarray(gl, dtype=np.float32).reshape(-1)
    sp_t = torch.from_numpy(sp).to(DEVICE)
    if sp_t.dim() == 3:
        sp_t = sp_t.unsqueeze(0)
    gl_t = torch.from_numpy(gl).unsqueeze(0).to(DEVICE)
    with torch.no_grad():
        r = model._forward_per_block_units(sp_t, gl_t)
    val = r[0][1].reshape(-1).float().cpu().numpy().astype(np.float64)
    e = np.exp(val - val.max())
    e /= e.sum()
    return float(e[0] - e[1]), val


# ---------------------------------------------------------------------------
def collect_pooled(model, weights, data, komi, cap):
    """对数据里每个局面做一次前向，缓存 linear2 的输入（576 维）。"""
    import _kg_enc as E
    import _kg_pipeline as P

    lin2, lin3 = value_head_layers(model)
    grabbed = {}

    def hook(mod, inp, out):
        grabbed['x'] = inp[0].detach()

    h = lin2.register_forward_hook(hook)

    files = sorted(glob.glob(os.path.join(data, '*.npz')))
    log('  数据: %d 局' % len(files))
    X, Y = [], []
    t0 = time.time()
    n = 0
    for f in files:
        d = np.load(f)
        moves = d['moves']
        colors = d['colors']
        sc = float(d['score_black'])
        cells = np.zeros(N * N, dtype=np.int8)
        hist = []
        for i in range(len(moves)):
            pla = int(colors[i])
            sp, gl = E.encode(P.mk_enc_board(E, cells), hist, pla, komi)
            sp_t = torch.from_numpy(np.ascontiguousarray(sp, dtype=np.float32)).to(DEVICE)
            if sp_t.dim() == 3:
                sp_t = sp_t.unsqueeze(0)
            gl_t = torch.from_numpy(np.ascontiguousarray(gl, dtype=np.float32)
                                    .reshape(1, -1)).to(DEVICE)
            with torch.no_grad():
                model._forward_per_block_units(sp_t, gl_t)
            if 'x' not in grabbed:
                continue
            self_score = sc if pla == 1 else -sc
            X.append(grabbed['x'].reshape(-1).float().cpu().numpy())
            Y.append(0 if self_score > 0 else 1)     # 0=赢(win 通道), 1=输
            n += 1
            if cap and n >= cap:
                break
            if moves[i] != S:
                res = P.try_play(cells, int(moves[i]), pla)
                if res is None:
                    break
                cells = res[0]
                hist.append(((int(moves[i]) % N, int(moves[i]) // N), pla))
        if cap and n >= cap:
            break
        if (len(X) % 2000) < len(moves):
            log('    ... %d 个局面，%.0f 秒' % (len(X), time.time() - t0))
    h.remove()
    if not X:
        raise SystemExit('没收集到样本，检查数据目录')
    return np.asarray(X, dtype=np.float32), np.asarray(Y, dtype=np.int64)


# ---------------------------------------------------------------------------
def report(model, weights, komi, tag):
    """用几个强弱分明的局面看价值头是否合理。"""
    import _kg_enc as E
    import _kg_pipeline as P

    def eval_cells(cells, pla):
        return eval_board(model, cells, [], pla, komi, E.encode,
                          lambda c: P.mk_enc_board(E, c))

    cases = []
    e = np.zeros(N * N, dtype=np.int8)
    cases.append(('空盘(黑先)', e.copy(), 1))
    q = np.zeros(N * N, dtype=np.int8)
    for y in range(9):
        for x in range(9):
            q[y * N + x] = 1
    cases.append(('黑占1/4(白先)', q.copy(), 2))
    t3 = np.zeros(N * N, dtype=np.int8)
    for y in range(N):
        for x in range(N):
            t3[y * N + x] = 2 if (x >= 15 and y >= 15) else 1
    cases.append(('黑占3/4(白先)', t3.copy(), 2))
    t4 = np.zeros(N * N, dtype=np.int8)
    for y in range(N):
        for x in range(N):
            t4[y * N + x] = 1 if (x >= 15 and y >= 15) else 2
    cases.append(('白占3/4(黑先)', t4.copy(), 1))

    log('  %s' % tag)
    log('    %-16s %10s %10s %10s   %s' % ('局面', 'win', 'loss', 'noresult', '行棋方胜率'))
    for name, cells, pla in cases:
        wr, val = eval_cells(cells, pla)
        log('    %-16s %+10.3f %+10.3f %+10.3f   %6.1f%%'
            % (name, val[0], val[1], val[2], (wr + 1) * 50))


# ---------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--weights', default='kata1.bin.gz')
    ap.add_argument('--data', default='selfplay_data')
    ap.add_argument('--steps', type=int, default=3000)
    ap.add_argument('--lr', type=float, default=3e-3)
    ap.add_argument('--komi', type=float, default=7.5)
    ap.add_argument('--cap', type=int, default=0, help='>0 时限制收集的局面数')
    ap.add_argument('--out', default='fixvalue.pt')
    ap.add_argument('--export', default=None, help='同时导出成 .bin.gz')
    ap.add_argument('--seed', type=int, default=5)
    ap.add_argument('--show-only', action='store_true', help='只报告当前价值头，不训练')
    a = ap.parse_args()

    log('=========== 修 value head ===========')
    log('  设备: %s' % DEVICE)
    model = load_model(a.weights)
    lin2, lin3 = value_head_layers(model)
    log('  linear2: %s  linear_valuehead: %s'
        % (tuple(lin2.weight.shape), tuple(lin3.weight.shape)))

    report(model, a.weights, a.komi, '训练前')

    if a.show_only:
        return

    log('')
    log('  收集 linear2 的输入（每局面一次前向）...')
    X, Y = collect_pooled(model, a.weights, a.data, a.komi, a.cap)
    log('  收集到 %d 个样本，维度 %d' % (X.shape[0], X.shape[1]))
    log('  标签分布: 赢 %d / 输 %d' % (int((Y == 0).sum()), int((Y == 1).sum())))

    # ---- 只训练 linear2 + act2 + linear_valuehead ----
    Xt = torch.from_numpy(X).to(DEVICE)
    Yt = torch.from_numpy(Y).to(DEVICE)
    W2 = torch.nn.Parameter(lin2.weight.detach().clone())
    b2 = torch.nn.Parameter(lin2.bias.detach().clone())
    W3 = torch.nn.Parameter(lin3.weight.detach().clone())
    b3 = torch.nn.Parameter(lin3.bias.detach().clone())
    opt = torch.optim.Adam([W2, b2, W3, b3], lr=a.lr)

    act2_kind = getattr(lin2, 'activation', None)
    log('  act2: %s' % act2_kind)
    log('  可训练参数: %d' % (W2.numel() + b2.numel() + W3.numel() + b3.numel()))

    rng = np.random.default_rng(a.seed)
    tgt = torch.zeros(X.shape[0], 3, device=DEVICE)
    tgt[Yt == 0, 0] = 1.0
    tgt[Yt == 1, 1] = 1.0

    t0 = time.time()
    for it in range(a.steps):
        idx = torch.from_numpy(rng.integers(0, X.shape[0], size=256)).to(DEVICE)
        h = torch.nn.functional.silu(Xt[idx] @ W2.t() + b2)
        logits = h @ W3.t() + b3
        loss = -(tgt[idx] * torch.log_softmax(logits, dim=1)).sum(dim=1).mean()
        opt.zero_grad()
        loss.backward()
        opt.step()
        if (it + 1) % max(1, a.steps // 10) == 0:
            log('    step %-6d loss=%.4f  （%.0f 步/秒）'
                % (it + 1, float(loss.detach()),
                   (it + 1) / max(1e-9, time.time() - t0)))

    # ---- 写回模型 ----
    with torch.no_grad():
        lin2.weight.copy_(W2)
        lin2.bias.copy_(b2)
        lin3.weight.copy_(W3)
        lin3.bias.copy_(b3)

    log('')
    report(model, a.weights, a.komi, '训练后')

    torch.save({
        'format': 'kg-fixvalue-v1',
        'cfg': CFG_NAME,
        'steps': a.steps,
        'samples': int(X.shape[0]),
        'linear2.weight': lin2.weight.detach().cpu(),
        'linear2.bias': lin2.bias.detach().cpu(),
        'linear_valuehead.weight': lin3.weight.detach().cpu(),
        'linear_valuehead.bias': lin3.bias.detach().cpu(),
        'model': {k: v.detach().cpu() for k, v in model.state_dict().items()},
    }, a.out)
    log('  已存 %s' % a.out)

    if a.export:
        import _kg_map as KM
        sd_np = {}
        for k, v in model.state_dict().items():
            if isinstance(v, torch.Tensor):
                sd_np[k] = v.detach().to('cpu').numpy()
        _, _, _, mapping = KM.build_map(a.weights, verbose=False)
        n = KM.write_from_sd(a.weights, a.export, sd_np, mapping)
        log('  已导出 %s（写回 %d 个张量）' % (a.export, n))


if __name__ == '__main__':
    main()
