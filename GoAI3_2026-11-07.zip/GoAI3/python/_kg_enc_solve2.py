# -*- coding: utf-8 -*-
"""在正确的 fixscale 配置下，反解归一化的精确公式。

方法：给 norm 子模块挂 pre/post hook，拿到它对真实输入的 输入->输出 对，
逐通道解 y = A*x + B，与文件里的 scale/bias 对照。
"""
import sys, os
import numpy as np
import torch
sys.stdout.reconfigure(encoding='utf-8', errors='replace')
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
os.environ.setdefault('TORCHDYNAMO_DISABLE', '1')

import _katago_v17_load as L
from _katago_official import load_official
from _kg_ref import build_state_dict
from _kg_enc import GoBoard, encode, BLACK, WHITE

M = L.load(sys.argv[1], verbose=False)
Model, mc = load_official()
m = Model(mc.config_of_name['b11c768h12nbt3tflrs-fs-silu'], 19).eval()
m.initialize()
sd = build_state_dict(M)
t = {}
for k, v in m.state_dict().items():
    if k in sd:
        a = np.array(sd[k], dtype=np.float32, copy=True)
        if tuple(a.shape) == tuple(v.shape):
            t[k] = torch.from_numpy(a).clone()
m.load_state_dict(t, strict=False)

# 挂 hook
captured = {}
targets = [
    'blocks.0.normactconvp.norm', 'blocks.0.normactconvq.norm',
    'blocks.1.normactconvp.norm', 'blocks.1.normactconvq.norm',
    'blocks.0.blockstack.0.norm1', 'blocks.0.blockstack.1.norm',
    'norm_trunkfinal',
    'policy_head.biasg', 'policy_head.bias2', 'value_head.bias1',
]
for name, mod in m.named_modules():
    if name in targets:
        def mk(nm):
            def pre(module, inp):
                captured.setdefault(nm, {})['in'] = inp[0].detach().clone()
            def post(module, inp, out):
                captured.setdefault(nm, {})['out'] = out.detach().clone()
            return pre, post
        pre, post = mk(name)
        mod.register_forward_pre_hook(pre)
        mod.register_forward_hook(post)

b = GoBoard()
b.play(3, 3, BLACK); b.play(15, 15, WHITE)
sp, gl = encode(b, [], BLACK)
with torch.no_grad():
    m._forward_per_block_units(torch.from_numpy(sp), torch.from_numpy(gl))

# 参照参数表
params = {
    'blocks.0.normactconvp.norm': M['trunk']['blocks'][0]['p']['norm'],
    'blocks.0.normactconvq.norm': M['trunk']['blocks'][0]['q']['norm'],
    'blocks.1.normactconvp.norm': M['trunk']['blocks'][1]['p']['norm'],
    'blocks.1.normactconvq.norm': M['trunk']['blocks'][1]['q']['norm'],
    'blocks.0.blockstack.0.norm1': M['trunk']['blocks'][0]['stack'][0]['preLN'],
    'norm_trunkfinal': M['trunk']['trunkTipNorm'],
}

print('%-34s %-9s %10s %10s   %s' % ('layer', 'kind', 'A', 'B', '对照'))
for name in targets:
    if name not in captured:
        continue
    ci = captured[name].get('in')
    co = captured[name].get('out')
    if ci is None or co is None:
        print('%-34s (未捕获)' % name)
        continue
    # norm1 等是 RMSNorm，输入输出形状 (B,S,C) 或 (B,C,H,W)
    x = ci.numpy().astype(np.float64)
    y = co.numpy().astype(np.float64)
    if x.ndim == 3:
        xs = x.reshape(-1, x.shape[-1])
        ys = y.reshape(-1, y.shape[-1])
    else:
        xs = x.reshape(x.shape[1], -1).T
        ys = y.reshape(y.shape[1], -1).T
    C = xs.shape[1]
    A = np.zeros(C); B = np.zeros(C); resid = 0.0
    for c in range(C):
        xc = xs[:, c]; yc = ys[:, c]
        if np.ptp(xc) < 1e-12:
            A[c] = np.nan; B[c] = np.nan
            continue
        A[c], B[c] = np.polyfit(xc, yc, 1)
        resid = max(resid, np.abs(yc - (A[c] * xc + B[c])).max())
    ok = ~np.isnan(A)
    p = params.get(name)
    kind = ''
    cmp_txt = ''
    if p is not None:
        if 'scale' in p and p['scale'] is not None:
            sc = np.asarray(p['scale'], dtype=np.float64)
            if sc.size == C:
                d1 = np.abs(A[ok] - sc[ok]).max()
                d2 = np.abs(A[ok] - (1.0 + sc[ok])).max()
                cmp_txt = '|A-scale|=%.2e  |A-(1+scale)|=%.2e' % (d1, d2)
                kind = 'affine'
            else:
                cmp_txt = 'scale.size=%d != C=%d' % (sc.size, C)
        else:
            cmp_txt = '无 scale'
    print('%-34s %-9s %10.6f %10.6f   %s' % (name, kind, np.nanmean(A), np.nanmean(B), cmp_txt))
    print('      A[:4]=%s' % np.round(A[:4], 6).tolist())
    print('      B[:4]=%s  resid=%.2e' % (np.round(B[:4], 6).tolist(), resid))
    if p is not None and p.get('scale') is not None and len(p['scale']) == C:
        print('      scale[:4]=%s' % np.round(np.asarray(p['scale'])[:4], 6).tolist())
