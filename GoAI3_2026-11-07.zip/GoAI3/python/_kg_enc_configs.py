# -*- coding: utf-8 -*-
"""扫描配置变体：找出哪个配置能让空盘输出合理（pass 概率低、星位高）。

模型文件里 norm 是 BatchNorm 风格（有 running_mean/scale/bias），
而我此前用的是 fixup 配置。正确的配置变体应该让空盘输出落在合理范围。
"""
import sys, os
import numpy as np
import torch
sys.stdout.reconfigure(encoding='utf-8', errors='replace')
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
os.environ.setdefault('TORCHDYNAMO_DISABLE', '1')

import _katago_v17_load as L
from _katago_official import load_official
from _kg_ref import build_state_dict
from _kg_enc import GoBoard, encode, BLACK

M = L.load(sys.argv[1], verbose=False)
Model, mc = load_official()
sd = build_state_dict(M)

b = GoBoard()
sp, gl = encode(b, [], BLACK)
sp_t = torch.from_numpy(sp)
gl_t = torch.from_numpy(gl)

base = 'b11c768h12nbt3tflrs'
cands = [base, base + '-silu', base + '-bn', base + '-bn-silu', base + '-fs',
         base + '-fs-silu', base + '-brn', base + '-brn-silu',
         base + '-fson', base + '-fson-silu']

print('%-22s %10s %10s %9s %9s  %s' % ('config', 'pass', 'boardMax', 'val[0]', 'ownSum', 'note'))
for name in cands:
    if name not in mc.config_of_name:
        print('%-22s  (配置不存在)' % name)
        continue
    try:
        m = Model(mc.config_of_name[name], 19).eval()
        m.initialize()
        t = {}
        for k, v in m.state_dict().items():
            if k in sd:
                a = np.array(sd[k], dtype=np.float32, copy=True)
                if tuple(a.shape) == tuple(v.shape):
                    t[k] = torch.from_numpy(a).clone()
        m.load_state_dict(t, strict=False)
        with torch.no_grad():
            r = m._forward_per_block_units(sp_t, gl_t)
        h = r[0]
        pol = h[0].numpy().reshape(6, 362)[0]
        val = h[1].numpy().reshape(3)
        own = h[4].numpy().reshape(-1)
        note = ''
        if not np.isfinite(pol).all():
            note = 'NaN!'
        print('%-22s %+10.3f %+10.3f %+9.2f %+9.1f  %s'
              % (name, pol[361], pol[:361].max(), val[0], own.sum(), note))
    except Exception as e:
        print('%-22s  失败: %s' % (name, str(e)[:60]))
