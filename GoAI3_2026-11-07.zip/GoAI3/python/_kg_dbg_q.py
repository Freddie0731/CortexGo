# -*- coding: utf-8 -*-
"""反推参考在 normactconvq 之前的输入，与我的 preq 对比，定位差异结构。"""
import struct, sys
import numpy as np
sys.stdout.reconfigure(encoding='utf-8', errors='replace')
sys.path.insert(0, '.')
import _katago_v17_load as L


def read_ref(path):
    f = open(path, 'rb')
    assert f.read(8) == b'KGREF001'
    n = struct.unpack('<i', f.read(4))[0]
    D = {}
    for _ in range(n):
        nl = struct.unpack('<i', f.read(4))[0]
        name = f.read(nl).decode()
        nd = struct.unpack('<i', f.read(4))[0]
        dims = [struct.unpack('<i', f.read(4))[0] for _ in range(nd)]
        c = 1
        for d in dims:
            c *= d
        D[name] = np.frombuffer(f.read(4 * c), dtype='<f4').reshape(dims).copy()
    return D


M = L.load(sys.argv[1], verbose=False)
D = read_ref(sys.argv[2])
b0 = M['trunk']['blocks'][0]

p = D['blocks.0.normactconvp'].reshape(361, 384).astype(np.float64)
qn = D['blocks.0.normactconvq.norm'].reshape(361, 384).astype(np.float64)
bias = np.asarray(b0['q']['norm']['bias'], dtype=np.float64)

# 参考的 q-norm 输入 = 参考 norm 输出 - bias
refpre = qn - bias

# 我的 preq = p + sum(blockstack)
acc = p.copy()
for i in range(6):
    acc = acc + D['blocks.0.blockstack.%d' % i].reshape(361, 384).astype(np.float64)

print('=== RMS ===')
print('  参考 q-norm 输入 RMS = %.6f' % np.sqrt((refpre ** 2).mean()))
print('  我的 preq        RMS = %.6f' % np.sqrt((acc ** 2).mean()))
print('  p                RMS = %.6f' % np.sqrt((p ** 2).mean()))
print('  比值 参考/我的   = %.6f' % (np.sqrt((refpre ** 2).mean()) / np.sqrt((acc ** 2).mean())))

print('\n=== 差异结构检验 ===')
d = refpre - acc
print('  |refpre - acc|max = %.6e   RMS(diff) = %.6f' % (np.abs(d).max(), np.sqrt((d ** 2).mean())))
for name, cand in (('p', p), ('acc', acc), ('sum(blockstack)', acc - p)):
    A = np.c_[cand.ravel(), np.ones(cand.size)]
    sol, *_ = np.linalg.lstsq(A, refpre.ravel(), rcond=None)
    resid = refpre - (cand * sol[0] + sol[1])
    print('  用 %-16s 最小二乘: a=%.5f b=%.5f  残差RMS=%.5f'
          % (name, sol[0], sol[1], np.sqrt((resid ** 2).mean())))

print('\n=== 逐元素抽样 ===')
print('  refpre[0,:4] =', np.round(refpre[0, :4], 6).tolist())
print('  acc   [0,:4] =', np.round(acc[0, :4], 6).tolist())
print('  p     [0,:4] =', np.round(p[0, :4], 6).tolist())
print('  refpre[0,:4]/acc[0,:4] =', np.round(refpre[0, :4] / acc[0, :4], 4).tolist())
