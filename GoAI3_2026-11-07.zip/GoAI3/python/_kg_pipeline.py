# -*- coding: utf-8 -*-
"""KataGo v17 网络的自我对弈 + 可接力微调 + 导出。

## 用法

  # 1) 自我对弈产数据（想学更强招法必须加 --mcts-visits）
  python _kg_pipeline.py selfplay --games 20 --out data/ --mcts-visits 200
  # 本机小规模验证（CPU 慢，只验证流程）
  python _kg_pipeline.py selfplay --games 1 --out data/ --mcts-visits 4 --max-moves 30

  # 2) 训练并保存可接力的检查点
  python _kg_pipeline.py train --data data/ --steps 300 --ckpt finetune.pt
  # 下次接着训（完全恢复：模型 + 优化器 + 步数 + 已消费对局）
  python _kg_pipeline.py train --data data2/ --steps 300 --ckpt finetune.pt --resume finetune.pt

  # 3) 查看检查点
  python _kg_pipeline.py info --ckpt finetune.pt

  # 4) 导出成引擎能直接加载的权重
  python _kg_pipeline.py export --ckpt finetune.pt --out kata1_ft.bin.gz

## 三个必须知道的要点

**1. CPU 训练必须关掉 flex attention。**
官方模型用 torch.nn.attention.flex_attention，它在 CPU 上不支持反向传播
（NotImplementedError: FlexAttention does not support backward on CPU）。
本脚本在 import torch 之前设 KATAGO_FLEX_ATTENTION=0，模型退回
scaled_dot_product_attention，支持 CPU 反向，顺带前向从 0.39 秒降到 0.19 秒。

**2. 想学"更强的招法"就必须用 MCTS 访问分布作策略目标。**
纯策略自对弈时目标就是网络自己的输出，交叉熵梯度恒为 0，学不到任何东西。
--mcts-visits N 会用搜索的访问分布作目标 —— 里面含有"网络原来没看出来、
但确实更好"的招，这才是真实的学习信号。

代价是每手要 N 次网络前向：
    本机 CPU  0.19 秒/次 -> 100 访问约 19 秒/手 -> 一局(约 200 手)约 63 分钟
    云端 GPU  约 0.02 秒/次 -> 100 访问约 2 秒/手 -> 一局约 7 分钟
所以这个模式是**为云端 GPU 准备的**，本机只适合 --mcts-visits 4 之类的小验证。

**3. 数据只存棋谱和政策目标，不存编码后的平面。**
一个局面编码后是 22*361*4 = 31.8 KB，一局 200 手就是 6.4 MB，几百局直接爆盘。
所以只存 (落子序列, 每手的策略目标, 终局结果)，训练时重放棋谱重新编码。

## 检查点格式（可接力）

    format / cfg / step / model / optimizer / consumed / history
    base_weights / base_sha256_16 / komi

consumed 记录已消费的对局文件名，所以 --resume 时只会训练新增数据；
history 记录每一轮的样本数/损失/耗时，便于事后看清做了哪些轮。

## 导出

走 _kg_map.py 的写回路径。该路径已用"逐字节往返"验证过：
把 state_dict 写回后与原始 .bin.gz 逐字节相同（403 项映射，0 项不一致）。
"""
import argparse
import glob
import hashlib
import os
import sys
import time

os.environ.setdefault('TORCHDYNAMO_DISABLE', '1')
os.environ.setdefault('TORCH_COMPILE_DISABLE', '1')

try:
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
except Exception:
    pass

import numpy as np
import torch

# flex_attention 在 CPU 上不支持反向传播，所以无 CUDA 时必须关掉它，
# 让模型退回 scaled_dot_product_attention。有 CUDA 时开着更快。
# 注意：这两个开关由 model_pytorch 在构造 Model 时读取，所以只要在
# load_official() 之前设好即可（不必早于 import torch）。
CUDA = torch.cuda.is_available()
if not CUDA:
    os.environ.setdefault('KATAGO_FLEX_ATTENTION', '0')
else:
    os.environ.setdefault('KATAGO_FLEX_ATTENTION', '1')

DEVICE = torch.device('cuda' if CUDA else 'cpu')

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

CFG_NAME = 'b11c768h12nbt3tflrs-fs-silu'
CKPT_FORMAT = 'kg-finetune-v1'
S = 361
N = 19


def log(msg):
    print(msg, flush=True)


# ===========================================================================
#  模型
# ===========================================================================
def load_model(weights):
    import _katago_v17_load as L
    from _katago_official import load_official
    from _kg_ref import build_state_dict

    log('  解析 %s ...' % weights)
    t0 = time.time()
    M = L.load(weights, verbose=False)
    Model, mc = load_official()
    if CFG_NAME not in mc.config_of_name:
        raise SystemExit('配置名不存在: %s' % CFG_NAME)
    model = Model(mc.config_of_name[CFG_NAME], N)
    model.initialize()
    sd = build_state_dict(M)
    t = {}
    for k, v in model.state_dict().items():
        if k in sd:
            a = np.array(sd[k], dtype=np.float32, copy=True)
            if tuple(a.shape) == tuple(v.shape):
                t[k] = torch.from_numpy(a)
    model.load_state_dict(t, strict=False)
    model.to(DEVICE)
    log('  完成 %.1f 秒，载入 %d 个张量，%.2fM 参数，设备=%s'
        % (time.time() - t0, len(t),
           sum(p.numel() for p in model.parameters()) / 1e6, DEVICE))
    if DEVICE.type == 'cuda':
        log('  GPU: %s' % torch.cuda.get_device_name(0))
    return model


def forward_np(model, sp, gl):
    """-> (policy 概率长度 362, winrate[-1,1], value 原始 3 通道)

    _kg_enc.encode 返回的 sp 已经是 4 维 (1,22,19,19)（它当初就是为直接喂模型
    写的），所以按维度自适应，别再加 batch 维 —— 加错会变 5 维，
    conv2d 会报 "got input of size: [1, 1, 22, 19, 19]"。"""
    sp = np.ascontiguousarray(sp, dtype=np.float32)
    gl = np.ascontiguousarray(gl, dtype=np.float32).reshape(-1)
    sp_t = torch.from_numpy(sp).to(DEVICE)
    if sp_t.dim() == 3:
        sp_t = sp_t.unsqueeze(0)
    gl_t = torch.from_numpy(gl).to(DEVICE)
    if gl_t.dim() == 1:
        gl_t = gl_t.unsqueeze(0)
    with torch.no_grad():
        r = model._forward_per_block_units(sp_t, gl_t)
    pol = r[0][0].reshape(6, S + 1)[0].float().cpu().numpy().astype(np.float64)
    val = r[0][1].reshape(-1).float().cpu().numpy().astype(np.float64)
    p = np.exp(pol - pol.max())
    p /= p.sum()
    e = np.exp(val - val.max())
    e /= e.sum()
    return p, float(e[0] - e[1]), val


# ===========================================================================
#  围棋规则（够用即可：气/提子/自杀判定）
# ===========================================================================
def neighbors(idx):
    x, y = idx % N, idx // N
    o = []
    if x > 0: o.append(idx - 1)
    if x < N - 1: o.append(idx + 1)
    if y > 0: o.append(idx - N)
    if y < N - 1: o.append(idx + N)
    return o


def group_and_libs(cells, idx):
    c = cells[idx]
    seen = {idx}
    stack = [idx]
    libs = set()
    while stack:
        cur = stack.pop()
        for q in neighbors(cur):
            v = cells[q]
            if v == 0:
                libs.add(q)
            elif v == c and q not in seen:
                seen.add(q)
                stack.append(q)
    return seen, libs


def try_play(cells, idx, col):
    """返回 (新 cells, 提子数)，非法返回 None。"""
    if cells[idx] != 0:
        return None
    nc = cells.copy()
    nc[idx] = col
    opp = 3 - col
    captured = 0
    for q in neighbors(idx):
        if nc[q] == opp:
            g, libs = group_and_libs(nc, q)
            if not libs:
                for t in g:
                    nc[t] = 0
                captured += len(g)
    if captured == 0:
        _, libs = group_and_libs(nc, idx)
        if not libs:
            return None
    return nc, captured


def area_score(cells):
    visited = np.zeros(N * N, dtype=bool)
    sc = 0
    for i in range(N * N):
        if cells[i] == 1:
            sc += 1
        elif cells[i] == 2:
            sc -= 1
        elif not visited[i]:
            region = []
            stack = [i]
            visited[i] = True
            tb = tw = False
            while stack:
                cur = stack.pop()
                region.append(cur)
                for q in neighbors(cur):
                    v = cells[q]
                    if v == 0:
                        if not visited[q]:
                            visited[q] = True
                            stack.append(q)
                    elif v == 1:
                        tb = True
                    else:
                        tw = True
            if tb and not tw:
                sc += len(region)
            elif tw and not tb:
                sc -= len(region)
    return sc


def mk_enc_board(E, cells):
    b = E.GoBoard(N)
    b.c = cells.reshape(N, N).copy()
    return b


# ===========================================================================
#  selfplay
# ===========================================================================
def cmd_selfplay(a):
    import _kg_enc as E

    os.makedirs(a.out, exist_ok=True)
    model = load_model(a.weights)
    model.eval()

    use_mcts = a.mcts_visits > 0
    MT = None
    if use_mcts:
        import _kg_mcts as MT
        log('  搜索模式: MCTS %d 访问/手，策略目标 = 访问分布（有真实学习信号）'
            % a.mcts_visits)
        est = a.mcts_visits * 0.19
        if est > 5:
            log('  提示: 本机 CPU 一次前向约 0.19 秒，%d 访问约 %.0f 秒/手，'
                % (a.mcts_visits, est))
            log('        200 手约 %.0f 分钟/局。这个规模是为云端 GPU 准备的，'
                % (est * 200 / 60))
            log('        本机只适合 --mcts-visits 4 之类的小验证。')
    else:
        log('  搜索模式: 纯策略')
        log('  **警告: 策略目标就是网络自己的输出，交叉熵梯度恒为 0，')
        log('    学不到任何策略改进。想学更强招法必须加 --mcts-visits。**')

    rng = np.random.default_rng(a.seed)
    for g in range(a.games):
        cells = np.zeros(N * N, dtype=np.int8)
        hist = []
        moves, colors, pols = [], [], []
        pla = 1
        passes = 0
        mv = 0
        g0 = time.time()

        while mv < a.max_moves and passes < 2:
            if use_mcts:
                rules = {
                    'cells': cells, 'pla': pla, 'hist': hist, 'komi': a.komi,
                    'encode': (lambda c, h, p, k: E.encode(mk_enc_board(E, c), h, p, k)),
                    'play': try_play, 'area': area_score,
                    'max_moves': a.max_moves,
                }
                pol, _, pick = MT.search(
                    lambda sp, gl: forward_np(model, sp, gl), rules, S,
                    visits=a.mcts_visits, komi=a.komi, rng=rng,
                    cpuct=a.cpuct, temperature=a.temp,
                    dirichlet_eps=a.dirichlet_eps,
                    dirichlet_alpha=a.dirichlet_alpha)
            else:
                sp, gl = E.encode(mk_enc_board(E, cells), hist, pla, a.komi)
                p, wr, _ = forward_np(model, sp, gl)
                legal = [i for i in range(N * N)
                         if cells[i] == 0 and try_play(cells, i, pla) is not None]
                legal.append(S)
                pol = np.zeros(S + 1, dtype=np.float64)
                for i in legal:
                    pol[i] = p[i]
                tot = pol.sum()
                if tot <= 0:
                    pol[:] = 0
                    pol[legal] = 1.0
                    tot = pol.sum()
                pol /= tot
                if a.temp <= 0:
                    pick = int(np.argmax(pol))
                else:
                    q = pol ** (1.0 / a.temp)
                    q /= q.sum()
                    pick = int(rng.choice(len(q), p=q))

            pols.append(np.asarray(pol, dtype=np.float16))
            moves.append(pick)
            colors.append(pla)

            if pick == S:
                passes += 1
            else:
                passes = 0
                res = try_play(cells, pick, pla)
                cells = res[0]
                hist.append(((pick % N, pick // N), pla))
            pla = 3 - pla
            mv += 1

        sc = area_score(cells) - a.komi
        fn = os.path.join(a.out, 'game_%05d.npz' % (a.start_index + g))
        np.savez_compressed(fn,
                            moves=np.array(moves, dtype=np.int16),
                            colors=np.array(colors, dtype=np.int8),
                            policies=np.array(pols, dtype=np.float16),
                            score_black=np.float32(sc))
        log('  第 %d/%d 局: %d 手, 黑-白=%.1f, 用时 %.0f 秒'
            % (g + 1, a.games, mv, sc, time.time() - g0))
    log('  完成，数据在 %s' % a.out)
    log('  下一步: python _kg_pipeline.py train --data %s --steps 300 --ckpt finetune.pt'
        % a.out)


# ===========================================================================
#  train
# ===========================================================================
def game_to_samples(path, komi):
    """重放棋谱并重新编码，返回 [(sp, gl, 策略目标, 价值目标), ...]。"""
    import _kg_enc as E
    d = np.load(path)
    moves = d['moves']
    colors = d['colors']
    pols = d['policies'].astype(np.float32)
    sc = float(d['score_black'])

    cells = np.zeros(N * N, dtype=np.int8)
    hist = []
    out = []
    for i in range(len(moves)):
        pla = int(colors[i])
        sp, gl = E.encode(mk_enc_board(E, cells), hist, pla, komi)
        self_score = sc if pla == 1 else -sc
        z = 1.0 if self_score > 0 else -1.0
        out.append((np.ascontiguousarray(sp, dtype=np.float32),
                    gl.astype(np.float32), pols[i], z))
        if moves[i] != S:
            res = try_play(cells, int(moves[i]), pla)
            if res is None:
                break
            cells = res[0]
            hist.append(((int(moves[i]) % N, int(moves[i]) // N), pla))
    return out


def cmd_train(a):
    files = sorted(glob.glob(os.path.join(a.data, '*.npz')))
    if not files:
        raise SystemExit('在 %s 里没找到 .npz，先跑 selfplay' % a.data)
    log('  数据目录: %d 局' % len(files))

    model = load_model(a.weights)
    model.train()
    opt = torch.optim.Adam(model.parameters(), lr=a.lr)

    start_step = 0
    consumed, history = [], []
    base_sha = hashlib.sha256(open(a.weights, 'rb').read()).hexdigest()[:16]

    if a.resume:
        ck = torch.load(a.resume, map_location='cpu')
        if ck.get('format') != CKPT_FORMAT:
            raise SystemExit('检查点格式不符: %s' % ck.get('format'))
        model.load_state_dict(ck['model'], strict=False)
        model.to(DEVICE)
        opt.load_state_dict(ck['optimizer'])
        start_step = int(ck.get('step', 0))
        consumed = list(ck.get('consumed', []))
        history = list(ck.get('history', []))
        log('  接力: 从 step %d 继续（已消费 %d 局，历史 %d 轮）'
            % (start_step, len(consumed), len(history)))

    files = [f for f in files if os.path.basename(f) not in consumed]
    log('  本轮新增待训练: %d 局' % len(files))
    if not files:
        log('  没有新数据。想导出当前权重: python _kg_pipeline.py export --ckpt %s' % a.ckpt)
        return

    log('  重放编码 ...')
    t0 = time.time()
    samples = []
    for f in files:
        try:
            samples.extend(game_to_samples(f, a.komi))
        except Exception as ex:
            log('    跳过 %s: %s' % (os.path.basename(f), ex))
    log('    得到 %d 个局面，用时 %.0f 秒' % (len(samples), time.time() - t0))

    rng = np.random.default_rng(a.seed)
    order = rng.permutation(len(samples))
    step = start_step
    t0 = time.time()
    losses = []
    for it in range(a.steps):
        if it >= len(order):
            order = rng.permutation(len(samples))
        sp, gl, pol, z = samples[order[it % len(order)]]

        sp_t = torch.from_numpy(sp).to(DEVICE)
        if sp_t.dim() == 3:
            sp_t = sp_t.unsqueeze(0)
        gl_t = torch.from_numpy(gl).reshape(1, -1).to(DEVICE)
        res = model._forward_per_block_units(sp_t, gl_t)
        pol_out = res[0][0].reshape(1, 6, S + 1)
        val_out = res[0][1].reshape(1, 3)

        # 价值: 终局结果是确定真值
        v = torch.tanh(val_out[:, 0] - val_out[:, 1])
        loss_v = ((v - float(z)) ** 2).mean()

        # 策略: 对 MCTS 访问分布做交叉熵（软标签，信息量比 one-hot 大）
        tgt = torch.from_numpy(np.ascontiguousarray(pol, dtype=np.float32)).to(DEVICE)
        tgt = tgt / tgt.sum().clamp(min=1e-9)
        logp = torch.log_softmax(pol_out[:, 0, :], dim=1)
        loss_p = -(tgt.unsqueeze(0) * logp).sum(dim=1).mean()

        loss = a.w_value * loss_v + a.w_policy * loss_p
        opt.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        opt.step()

        step += 1
        losses.append((float(loss_v.detach()), float(loss_p.detach())))
        if (it + 1) % a.log_every == 0:
            rv = float(np.mean([x[0] for x in losses[-a.log_every:]]))
            rp = float(np.mean([x[1] for x in losses[-a.log_every:]]))
            log('    step %d  loss_v=%.4f  loss_p=%.4f  （%.2f 步/秒）'
                % (step, rv, rp, (it + 1) / max(1e-9, time.time() - t0)))

    consumed.extend(os.path.basename(f) for f in files)
    history.append({'step': step, 'games': len(files), 'samples': len(samples),
                    'loss_v': float(np.mean([x[0] for x in losses])),
                    'loss_p': float(np.mean([x[1] for x in losses])),
                    'seconds': time.time() - t0})

    ck = {
        'format': CKPT_FORMAT, 'cfg': CFG_NAME, 'step': step,
        'model': {k: v.detach().cpu() for k, v in model.state_dict().items()},
        'optimizer': opt.state_dict(),
        'consumed': consumed, 'history': history,
        'base_weights': os.path.basename(a.weights),
        'base_sha256_16': base_sha, 'komi': a.komi,
    }
    torch.save(ck, a.ckpt)
    log('  检查点已存 %s（step %d，累计消费 %d 局，%d 轮）'
        % (a.ckpt, step, len(consumed), len(history)))
    log('  下次接力: --resume %s' % a.ckpt)


# ===========================================================================
#  export / info
# ===========================================================================
def cmd_export(a):
    ck = torch.load(a.ckpt, map_location='cpu')
    log('  检查点 step=%d，%d 轮历史' % (ck.get('step', 0), len(ck.get('history', []))))

    import _kg_map as KM
    sd_np = {}
    for k, v in ck['model'].items():
        if isinstance(v, torch.Tensor):
            sd_np[k] = v.detach().to('cpu').numpy()
    _, _, _, mapping = KM.build_map(a.weights, verbose=False)
    n = KM.write_from_sd(a.weights, a.out, sd_np, mapping)
    log('  导出 %s（写回 %d 个张量）' % (a.out, n))
    log('  引擎用法: 把它放到工程根目录，用 run.bat 启动')


def cmd_info(a):
    ck = torch.load(a.ckpt, map_location='cpu')
    log('格式      : %s' % ck.get('format'))
    log('配置      : %s' % ck.get('cfg'))
    log('step      : %s' % ck.get('step'))
    log('起始权重  : %s (sha256[:16]=%s)'
        % (ck.get('base_weights'), ck.get('base_sha256_16')))
    log('贴目      : %s' % ck.get('komi'))
    log('已消费对局: %d' % len(ck.get('consumed', [])))
    log('历史轮次  : %d' % len(ck.get('history', [])))
    for h in ck.get('history', []):
        log('  step=%-6d 新增局=%-4d 局面=%-6d loss_v=%.4f loss_p=%.4f 用时=%.0fs'
            % (h['step'], h['games'], h['samples'], h['loss_v'], h['loss_p'],
               h['seconds']))


# ===========================================================================
def main():
    p = argparse.ArgumentParser()
    sub = p.add_subparsers(dest='cmd', required=True)

    sp = sub.add_parser('selfplay')
    sp.add_argument('--weights', default='kata1.bin.gz')
    sp.add_argument('--games', type=int, default=5)
    sp.add_argument('--out', default='selfplay_data')
    sp.add_argument('--temp', type=float, default=1.0)
    sp.add_argument('--komi', type=float, default=7.5)
    sp.add_argument('--max-moves', type=int, default=400)
    sp.add_argument('--seed', type=int, default=1)
    sp.add_argument('--start-index', type=int, default=0)
    sp.add_argument('--mcts-visits', type=int, default=0,
                    help='>0 用 MCTS 访问分布作策略目标（能真正提升棋力，但慢）')
    sp.add_argument('--cpuct', type=float, default=1.5)
    sp.add_argument('--dirichlet-eps', type=float, default=0.25)
    sp.add_argument('--dirichlet-alpha', type=float, default=0.3)
    sp.set_defaults(fn=cmd_selfplay)

    tr = sub.add_parser('train')
    tr.add_argument('--weights', default='kata1.bin.gz')
    tr.add_argument('--data', default='selfplay_data')
    tr.add_argument('--steps', type=int, default=100)
    tr.add_argument('--ckpt', default='finetune.pt')
    tr.add_argument('--resume', default=None)
    tr.add_argument('--lr', type=float, default=1e-5)
    tr.add_argument('--komi', type=float, default=7.5)
    tr.add_argument('--w-value', type=float, default=1.0)
    tr.add_argument('--w-policy', type=float, default=1.0)
    tr.add_argument('--log-every', type=int, default=10)
    tr.add_argument('--seed', type=int, default=7)
    tr.set_defaults(fn=cmd_train)

    ex = sub.add_parser('export')
    ex.add_argument('--weights', default='kata1.bin.gz')
    ex.add_argument('--ckpt', default='finetune.pt')
    ex.add_argument('--out', default='kata1_ft.bin.gz')
    ex.set_defaults(fn=cmd_export)

    inf = sub.add_parser('info')
    inf.add_argument('--ckpt', default='finetune.pt')
    inf.set_defaults(fn=cmd_info)

    a = p.parse_args()
    a.fn(a)


if __name__ == '__main__':
    main()
