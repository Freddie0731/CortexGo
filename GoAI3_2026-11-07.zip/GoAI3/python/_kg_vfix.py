# -*- coding: utf-8 -*-
"""修 value head —— 诚实的版本：最小改动 + 按对局切分验证 + 校准误差。

## 上一版为什么失败（必须记住）

上一版训了 linear2 + linear_valuehead 两层，111,363 个参数，只有 1050 个样本、
4000 步、无正则、无验证集。结果：
    train loss 降到 0.012（记住了）
    空盘 logit 差 8.18 -> 2.22（看着改善）
    但"黑占3/4"这种训练集里没有的局面 -> ±178（完全失控外推）

所以这一版：
  * **只训 linear_valuehead（192->3，579 个参数）** —— 纯 3 分类 logistic
    重标定。参数少 190 倍，过拟合风险低得多，而且改的就是那个失控的 logit 尺度。
  * **按对局切分训练/验证**（不是按局面切）—— 否则同一局的相邻局面高度相似，
    验证集等于泄漏，指标会虚高。
  * **加 weight decay**，并在验证 loss 变差时停止（早停）。
  * **报告校准误差（Brier）**：预测胜率和实际胜负的均方误差。这才是"修好了没有"
    的正确度量，而不是看几个精心挑的局面。

## 判断标准

  Brier 基线：永远预测 50% -> 0.25
  一个好的 value head -> 0.15~0.22（取决于数据量）
  修复前这种"恒说行棋方输" -> 接近 0.5（因为空盘也敢说 99.97%）

所以：**验证集 Brier 明显低于 0.25、且不随步数上升**才算修好。

## 用法

  python _kg_vfix.py --weights kata1.bin.gz --data data/ --export kata1_vfix.bin.gz
  python _kg_vfix.py --weights kata1.bin.gz --show-only
"""
import argparse
import glob
import os
import sys
import time

os.environ.setdefault('TORCHDYNAMO_DISABLE', '1')
os.environ.setdefault('TORCH_COMPILE_DISABLE', '1')

try:
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
except Exception:
    pass

import numpy as np
import torch

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

CUDA = torch.cuda.is_available()
if not CUDA:
    os.environ.setdefault('KATAGO_FLEX_ATTENTION', '0')
DEVICE = torch.device('cuda' if CUDA else 'cpu')
CFG_NAME = 'b11c768h12nbt3tflrs-fs-silu'
N, S = 19, 361


def log(m):
    print(m, flush=True)


def load_model(weights):
    import _katago_v17_load as L
    from _katago_official import load_official
    from _kg_ref import build_state_dict
    M = L.load(weights, verbose=False)
    Model, mc = load_official()
    model = Model(mc.config_of_name[CFG_NAME], N)
    model.initialize()
    sd = build_state_dict(M)
    t = {}
    for k, v in model.state_dict().items():
        if k in sd:
            arr = np.array(sd[k], dtype=np.float32, copy=True)
            if tuple(arr.shape) == tuple(v.shape):
                t[k] = torch.from_numpy(arr)
    model.load_state_dict(t, strict=False)
    model.to(DEVICE)
    model.eval()
    return model


def vhead(model):
    vh = getattr(model, 'value_head', None) or getattr(model, 'valuehead', None)
    if vh is None:
        raise SystemExit('找不到 value_head')
    return vh.linear2, vh.linear_valuehead


# ---------------------------------------------------------------------------
def collect(model, data, komi, cap=0):
    """按对局收集 linear2 的输出（192 维），返回 (X, Y, game_id)。"""
    import _kg_enc as E
    import _kg_pipeline as P

    lin2, lin3 = vhead(model)
    got = {}

    def hook(mod, inp, out):
        got['y'] = out.detach()

    h = lin2.register_forward_hook(hook)      # 取 linear2 的输出，直接喂给 linear_valuehead
    files = sorted(glob.glob(os.path.join(data, '*.npz')))
    log('  数据: %d 局' % len(files))
    X, Y, G = [], [], []
    t0 = time.time()
    for gi, f in enumerate(files):
        d = np.load(f)
        moves, colors = d['moves'], d['colors']
        sc = float(d['score_black'])
        cells = np.zeros(N * N, dtype=np.int8)
        hist = []
        for i in range(len(moves)):
            pla = int(colors[i])
            sp, gl = E.encode(P.mk_enc_board(E, cells), hist, pla, komi)
            sp_t = torch.from_numpy(np.ascontiguousarray(sp, dtype=np.float32)).to(DEVICE)
            if sp_t.dim() == 3:
                sp_t = sp_t.unsqueeze(0)
            gl_t = torch.from_numpy(np.ascontiguousarray(gl, dtype=np.float32)
                                    .reshape(1, -1)).to(DEVICE)
            with torch.no_grad():
                model._forward_per_block_units(sp_t, gl_t)
            if 'y' not in got:
                continue
            self_score = sc if pla == 1 else -sc
            X.append(got['y'].reshape(-1).float().cpu().numpy())
            Y.append(0.0 if self_score > 0 else 1.0)
            G.append(gi)
            if cap and len(X) >= cap:
                break
            if moves[i] != S:
                r = P.try_play(cells, int(moves[i]), pla)
                if r is None:
                    break
                cells = r[0]
                hist.append(((int(moves[i]) % N, int(moves[i]) // N), pla))
        if cap and len(X) >= cap:
            break
        log('    第 %d 局: 累计 %d 局面，%.0f 秒' % (gi + 1, len(X), time.time() - t0))
    h.remove()
    return (np.asarray(X, dtype=np.float32), np.asarray(Y, dtype=np.float32),
            np.asarray(G, dtype=np.int64))


def predict(model, cells, hist, pla, komi):
    import _kg_enc as E
    import _kg_pipeline as P
    sp, gl = E.encode(P.mk_enc_board(E, cells), hist, pla, komi)
    sp_t = torch.from_numpy(np.ascontiguousarray(sp, dtype=np.float32)).to(DEVICE)
    if sp_t.dim() == 3:
        sp_t = sp_t.unsqueeze(0)
    gl_t = torch.from_numpy(np.ascontiguousarray(gl, dtype=np.float32)
                            .reshape(1, -1)).to(DEVICE)
    with torch.no_grad():
        r = model._forward_per_block_units(sp_t, gl_t)
    v = r[0][1].reshape(-1).float().cpu().numpy().astype(np.float64)
    e = np.exp(v - v.max())
    e /= e.sum()
    return float(e[0]), v


def probe(model, komi, tag):
    log('  %s' % tag)
    log('    %-16s %9s %9s %9s   %s' % ('局面', 'win', 'loss', 'noresult', '行棋方胜率'))
    cases = []
    e = np.zeros((N, N), dtype=np.int8)
    cases.append(('空盘(黑先)', e.copy(), 1))
    q = np.zeros((N, N), dtype=np.int8)
    q[:9, :9] = 1
    cases.append(('黑占1/4(白先)', q.copy(), 2))
    t3 = np.zeros((N, N), dtype=np.int8)
    for y in range(N):
        for x in range(N):
            t3[y, x] = 2 if (x >= 15 and y >= 15) else 1
    cases.append(('黑占3/4(白先)', t3.copy(), 2))
    t4 = np.zeros((N, N), dtype=np.int8)
    for y in range(N):
        for x in range(N):
            t4[y, x] = 1 if (x >= 15 and y >= 15) else 2
    cases.append(('白占3/4(黑先)', t4.copy(), 1))
    for name, cells, pla in cases:
        p, v = predict(model, cells.reshape(-1), [], pla, komi)
        log('    %-16s %+9.3f %+9.3f %+9.3f   %6.1f%%'
            % (name, v[0], v[1], v[2], p * 100))


# ---------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--weights', default='kata1.bin.gz')
    ap.add_argument('--data', default='selfplay_data')
    ap.add_argument('--steps', type=int, default=4000)
    ap.add_argument('--lr', type=float, default=1e-2)
    ap.add_argument('--wd', type=float, default=1e-3)
    ap.add_argument('--komi', type=float, default=7.5)
    ap.add_argument('--val-frac', type=float, default=0.34)
    ap.add_argument('--cap', type=int, default=0)
    ap.add_argument('--out', default='vfix.pt')
    ap.add_argument('--export', default=None)
    ap.add_argument('--seed', type=int, default=5)
    ap.add_argument('--show-only', action='store_true')
    a = ap.parse_args()

    log('=========== 修 value head（最小改动版）===========')
    log('  设备: %s' % DEVICE)
    model = load_model(a.weights)
    lin2, lin3 = vhead(model)
    log('  只训 linear_valuehead: %s (%d 个参数)'
        % (tuple(lin3.weight.shape), lin3.weight.numel() + lin3.bias.numel()))

    probe(model, a.komi, '修复前')
    if a.show_only:
        return

    log('')
    log('  收集 linear2 的输出（每局面一次前向）...')
    X, Y, G = collect(model, a.data, a.komi, a.cap)
    n_games = int(G.max()) + 1
    log('  共 %d 局 / %d 局面，维度 %d' % (n_games, X.shape[0], X.shape[1]))

    # ---- 按对局切分（按局面切会让同局相邻局面泄漏进验证集）----
    rng = np.random.default_rng(a.seed)
    gperm = rng.permutation(n_games)
    n_val = max(1, int(round(n_games * a.val_frac)))
    val_g = set(gperm[:n_val].tolist())
    m_val = np.array([g in val_g for g in G])
    m_tr = ~m_val
    Xtr, Ytr = X[m_tr], Y[m_tr]
    Xva, Yva = X[m_val], Y[m_val]
    log('  按对局切分: 训练 %d 局面（%d 局）/ 验证 %d 局面（%d 局）'
        % (len(Ytr), n_games - n_val, len(Yva), n_val))
    if len(Yva) == 0 or len(Ytr) == 0:
        raise SystemExit('对局太少，无法切分验证集（至少 3 局）')

    Xtr_t = torch.from_numpy(Xtr).to(DEVICE)
    Ytr_t = torch.from_numpy(Ytr).to(DEVICE)
    Xva_t = torch.from_numpy(Xva).to(DEVICE)
    Yva_t = torch.from_numpy(Yva).to(DEVICE)

    # 目标：赢 -> win 通道，输 -> loss 通道
    Ttr = torch.zeros(len(Ytr), 3, device=DEVICE)
    Ttr[Ytr_t == 0, 0] = 1.0
    Ttr[Ytr_t == 1, 1] = 1.0
    Tva = torch.zeros(len(Yva), 3, device=DEVICE)
    Tva[Yva_t == 0, 0] = 1.0
    Tva[Yva_t == 1, 1] = 1.0

    # 只优化 linear_valuehead；linear2 是固定的特征提取器
    W = torch.nn.Parameter(lin3.weight.detach().clone())
    b = torch.nn.Parameter(lin3.bias.detach().clone())
    opt = torch.optim.Adam([W, b], lr=a.lr, weight_decay=a.wd)

    def brier(Xt, Yt):
        with torch.no_grad():
            lg = Xt @ W.t() + b
            p = torch.softmax(lg, dim=1)
            pw = p[:, 0]                      # 预测"行棋方赢"的概率
            return float(((pw - (1.0 - Yt)) ** 2).mean())

    base_tr, base_va = brier(Xtr_t, Ytr_t), brier(Xva_t, Yva_t)
    log('')
    log('  Brier（越小越好；恒预测 50%% = 0.25）')
    log('    训练前: 训练集 %.4f   验证集 %.4f' % (base_tr, base_va))

    best_va, best_W, best_b, best_step = 1e9, W.detach().clone(), b.detach().clone(), 0
    t0 = time.time()
    bs = min(256, len(Ytr))
    for it in range(a.steps):
        idx = torch.from_numpy(rng.integers(0, len(Ytr), size=bs)).to(DEVICE)
        lg = Xtr_t[idx] @ W.t() + b
        loss = -(Ttr[idx] * torch.log_softmax(lg, dim=1)).sum(dim=1).mean()
        opt.zero_grad()
        loss.backward()
        opt.step()
        if (it + 1) % 200 == 0:
            va = brier(Xva_t, Yva_t)
            if va < best_va:
                best_va, best_step = va, it + 1
                best_W, best_b = W.detach().clone(), b.detach().clone()
            if (it + 1) % 800 == 0:
                log('    step %-6d 训练集 %.4f  验证集 %.4f%s'
                    % (it + 1, brier(Xtr_t, Ytr_t), va,
                       '  <- 目前最好' if best_step == it + 1 else ''))

    log('  验证集最好 %.4f（step %d）；%.0f 步/秒，用时 %.0f 秒'
        % (best_va, best_step, a.steps / max(1e-9, time.time() - t0),
           time.time() - t0))
    log('  起点 %.4f -> 最好 %.4f  （基线 0.25）' % (base_va, best_va))
    if best_va >= base_va:
        log('  ** 验证集没有改善：这份数据量还不足以修好 value head **')

    with torch.no_grad():
        lin3.weight.copy_(best_W)
        lin3.bias.copy_(best_b)

    log('')
    probe(model, a.komi, '修复后')

    torch.save({'format': 'kg-vfix-v1', 'cfg': CFG_NAME, 'steps': a.steps,
                'val_brier_before': base_va, 'val_brier_after': best_va,
                'model': {k: v.detach().cpu() for k, v in model.state_dict().items()}},
               a.out)
    log('  已存 %s' % a.out)

    if a.export:
        import _kg_map as KM
        sd_np = {k: v.detach().to('cpu').numpy()
                 for k, v in model.state_dict().items() if isinstance(v, torch.Tensor)}
        _, _, _, mapping = KM.build_map(a.weights, verbose=False)
        n = KM.write_from_sd(a.weights, a.export, sd_np, mapping)
        log('  已导出 %s（写回 %d 个张量）' % (a.export, n))


if __name__ == '__main__':
    main()
