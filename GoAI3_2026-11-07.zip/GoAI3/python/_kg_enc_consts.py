# -*- coding: utf-8 -*-
"""测出所有块的归一化常量 A，确定 fixscale 的确切公式。

对每个 norm 层解 y = A*x + B，统计 A 是否常量、值是多少。
再与 1/sqrt(i+1) 等公式对照，反推 i 的计数方式与 q 分支的 gamma 关系。
"""
import sys, os
import numpy as np
import torch
sys.stdout.reconfigure(encoding='utf-8', errors='replace')
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
os.environ.setdefault('TORCHDYNAMO_DISABLE', '1')

import _katago_v17_load as L
from _katago_official import load_official
from _kg_ref import build_state_dict
from _kg_enc import GoBoard, encode, BLACK, WHITE

M = L.load(sys.argv[1], verbose=False)
Model, mc = load_official()
m = Model(mc.config_of_name['b11c768h12nbt3tflrs-fs-silu'], 19).eval()
m.initialize()
sd = build_state_dict(M)
t = {}
for k, v in m.state_dict().items():
    if k in sd:
        a = np.array(sd[k], dtype=np.float32, copy=True)
        if tuple(a.shape) == tuple(v.shape):
            t[k] = torch.from_numpy(a).clone()
m.load_state_dict(t, strict=False)

captured = {}
targets = []
for i in range(11):
    targets.append('blocks.%d.normactconvp.norm' % i)
    targets.append('blocks.%d.normactconvq.norm' % i)
targets.append('norm_trunkfinal')
tset = set(targets)
for name, mod in m.named_modules():
    if name in tset:
        def mk(nm):
            def pre(module, inp):
                captured.setdefault(nm, {})['in'] = inp[0].detach().clone()
            def post(module, inp, out):
                captured.setdefault(nm, {})['out'] = out.detach().clone()
            return pre, post
        pre, post = mk(name)
        mod.register_forward_pre_hook(pre)
        mod.register_forward_hook(post)

b = GoBoard()
b.play(3, 3, BLACK); b.play(15, 15, WHITE); b.play(3, 15, BLACK)
sp, gl = encode(b, [], WHITE)
with torch.no_grad():
    m._forward_per_block_units(torch.from_numpy(sp), torch.from_numpy(gl))


def solve(name):
    c = captured.get(name)
    if not c or 'in' not in c or 'out' not in c:
        return None
    x = c['in'].numpy().astype(np.float64)
    y = c['out'].numpy().astype(np.float64)
    if x.ndim == 3:
        xs = x.reshape(-1, x.shape[-1]); ys = y.reshape(-1, y.shape[-1])
    else:
        xs = x.reshape(x.shape[1], -1).T; ys = y.reshape(y.shape[1], -1).T
    C = xs.shape[1]
    A = np.zeros(C); B = np.zeros(C)
    for ch in range(C):
        xc = xs[:, ch]; yc = ys[:, ch]
        if np.ptp(xc) < 1e-12:
            A[ch] = np.nan; B[ch] = np.nan; continue
        A[ch], B[ch] = np.polyfit(xc, yc, 1)
    ok = ~np.isnan(A)
    resid = 0.0
    for ch in range(C):
        if ok[ch]:
            resid = max(resid, np.abs(ys[:, ch] - (A[ch] * xs[:, ch] + B[ch])).max())
    return A, B, ok, resid


print('%-30s %-14s %-11s %-11s %s' % ('layer', 'A常量?', 'A值', '1/sqrt', 'resid'))
for i in range(11):
    for br in ('p', 'q'):
        name = 'blocks.%d.normactconv%s.norm' % (i, br)
        r = solve(name)
        if r is None:
            print('%-30s (未捕获)' % name); continue
        A, B, ok, resid = r
        a0 = np.nanmean(A)
        const = np.nanmax(np.abs(A - a0)) < 1e-5
        # 与文件 scale 对照
        n = M['trunk']['blocks'][i][br]['norm']
        sc = np.asarray(n['scale'], dtype=np.float64)
        rel_scale = np.nanmax(np.abs(A[ok] - sc[ok])) if sc.size == A.size else float('nan')
        rel_1ps = np.nanmax(np.abs(A[ok] - (1.0 + sc[ok]))) if sc.size == A.size else float('nan')
        print('%-30s %-14s %-11.6f %-11.6f resid=%.1e  |>A-sc|=%.2e |A-(1+sc)|=%.2e'
              % (name, 'YES' if const else 'no', a0, 1.0 / np.sqrt(i + 1), resid,
                 rel_scale, rel_1ps))

r = solve('norm_trunkfinal')
if r:
    A, B, ok, resid = r
    a0 = np.nanmean(A)
    const = np.nanmax(np.abs(A - a0)) < 1e-5
    print('%-30s %-14s %-11.6f %-11.6f resid=%.1e'
          % ('norm_trunkfinal', 'YES' if const else 'no', a0, 1.0 / np.sqrt(11 + 1), resid))
