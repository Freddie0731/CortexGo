# -*- coding: utf-8 -*-
"""对照实验：initialize() 是否改变了推理结果？

官方 load_model.py 的流程是 initialize() 然后 load_state_dict()。
但 initialize() 会调用 norm.set_scale()，而 self.scale 不是 buffer，
不会被 state_dict 覆盖。如果 set_scale 影响了前向，那"加载官方权重"就必须
连 initialize 一起复现 —— 也可能反过来，scale 在正式导出时其实没生效。
"""
import sys, os
import numpy as np
import torch
sys.stdout.reconfigure(encoding='utf-8', errors='replace')
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
os.environ.setdefault('TORCHDYNAMO_DISABLE', '1')

import _katago_v17_load as L
from _katago_official import load_official
from _kg_ref import build_state_dict
from _kg_enc import GoBoard, encode, BLACK

M = L.load(sys.argv[1], verbose=False)
Model, mc = load_official()
sd = build_state_dict(M)


def build(do_init):
    m = Model(mc.config_of_name['b11c768h12nbt3tflrs-silu'], 19).eval()
    if do_init:
        m.initialize()
    t = {}
    for k, v in m.state_dict().items():
        if k in sd:
            a = np.array(sd[k], dtype=np.float32, copy=True)
            if tuple(a.shape) == tuple(v.shape):
                t[k] = torch.from_numpy(a).clone()
    m.load_state_dict(t, strict=False)
    return m


b = GoBoard()
sp, gl = encode(b, [], BLACK)
sp_t = torch.from_numpy(sp)
gl_t = torch.from_numpy(gl)

for do_init in (False, True):
    m = build(do_init)
    with torch.no_grad():
        r = m._forward_per_block_units(sp_t, gl_t)
    head = r[0]
    pol = head[0].numpy().reshape(6, 362)[0]
    val = head[1].numpy().reshape(3)
    print('initialize=%-5s  pass=%+8.3f  boardMax=%+8.3f  value=%s'
          % (do_init, pol[361], pol[:361].max(), np.round(val, 2).tolist()))
    # 看几个关键 norm 的 scale
    blk = m.blocks[0]
    print('        normactconvp.norm.scale =', blk.normactconvp.norm.scale)
    print('        normactconvq.norm.scale =', blk.normactconvq.norm.scale)
    print('        normactconvq.norm.gamma[:3] =',
          None if blk.normactconvq.norm.gamma is None
          else np.round(blk.normactconvq.norm.gamma.flatten()[:3].numpy(), 5).tolist())
    print('        biasg.scale =', m.policy_head.biasg.scale)
