# -*- coding: utf-8 -*-
"""建立「文件权重块序号 <-> PyTorch state_dict 键名」的映射，并支持写回。

## 为什么用字节匹配，而不是自己走一遍 desc.cpp 的顺序

文件里 470 个权重块是有固定顺序的，但那个顺序有一百多步、还夹杂
permute/转置/running_std 等细节。手写一遍遍历极易出错，而且**错了不会报错，
只会让网络悄悄变傻**。

所以这里反其道而行：对每个 PyTorch 张量，把它按几种候选变换转成字节，
再去文件里找**字节完全相同**的块。字节相等同时证明了：
  * 这个张量对应哪个块（映射）
  * 该用哪种变换（布局）
不可能"差不多对"——要么逐字节相同，要么不匹配。

## 变换候选

源自 _katago_v17_load.py 的读取代码（权威）：
  conv   : file(cy,cx,ic,oc) --transpose(3,2,0,1)--> torch(oc,ic,cy,cx)
           所以逆变换是 torch --transpose(2,3,1,0)--> file
  matmul : file(ic,oc) --transpose(1,0)--> torch(oc,ic)
           逆变换是 torch.T
  other  : 直接一样（rmsnorm weight / gamma / beta / bias）

## 写回

只写**可训练**的块（卷积/矩阵/归一化权重、gamma、beta、偏置）。
running_mean / running_var 在本模型里是占位数据（归一化走 fixscale/BiasMask），
不参与训练，也不改动。

用法:
  python _kg_map.py verify  <in.bin.gz>          # 建映射并逐个字节校验
  python _kg_map.py identity <in.bin.gz> <out.bin.gz>   # 用 state_dict 写回，必须逐字节相同
"""
import gzip
import hashlib
import os
import sys

try:
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
except Exception:
    pass

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import _katago_v17_load as L
import _kg_ref
import _kg_export


# ---------------------------------------------------------------------------
#  候选变换：torch 布局 -> 文件布局
# ---------------------------------------------------------------------------
def to_file_bytes(name, arr):
    """返回 [(候选名, 字节), ...]。字节匹配会挑出正确的那一个。"""
    a = np.ascontiguousarray(arr, dtype='<f4')
    cands = [('asis', a)]
    if a.ndim == 4:
        # torch(oc,ic,cy,cx) -> file(cy,cx,ic,oc)
        cands.append(('conv_T2310', np.ascontiguousarray(a.transpose(2, 3, 1, 0))))
    if a.ndim == 2:
        cands.append(('matmul_T', np.ascontiguousarray(a.transpose(1, 0))))
        if a.shape[0] == a.shape[1]:
            # 方阵时转置与不转置形状相同，两种都要试
            cands.append(('matmul_T_sq', np.ascontiguousarray(a.transpose(1, 0))))
    out = []
    seen = set()
    for cn, ca in cands:
        b = ca.tobytes()
        if b in seen:
            continue
        seen.add(b)
        out.append((cn, b))
    return out


def build_map(path, verbose=True):
    """返回 (raw, blocks, sd, mapping)
       blocks : [(序号, off, cnt, bytes)]
       sd     : {torch 键名: torch 布局 ndarray}
       mapping: {torch 键名: (块序号, off, cnt, 候选名)}"""
    raw, blocks_raw, M = _kg_export.read_blocks(path)
    blocks = []
    for idx, off, cnt in blocks_raw:
        b = raw[off:off + 4 * cnt]
        blocks.append((idx, off, cnt, b))

    # 按字节内容建索引；同样内容的块归到同一个列表（可能重复）
    by_bytes = {}
    for idx, off, cnt, b in blocks:
        by_bytes.setdefault(b, []).append((idx, off, cnt))

    sd = _kg_ref.build_state_dict(M)
    if verbose:
        print('  state_dict 张量 %d 个，文件权重块 %d 个' % (len(sd), len(blocks)))

    mapping = {}
    used = {}
    n_multi = 0
    for name, arr in sd.items():
        a = np.asarray(arr)
        if a.dtype != np.float32 or not np.isfinite(a).all():
            continue
        hit = None
        for cn, b in to_file_bytes(name, a):
            if b in by_bytes:
                hit = (cn, b)
                break
        if hit is None:
            continue
        cn, b = hit
        cand = by_bytes[b]
        # 同字节的块可能不止一个（例如常数块）。取一个还没被占用的。
        pick = None
        for c in cand:
            if c[0] not in used:
                pick = c
                break
        if pick is None:
            pick = cand[0]
            n_multi += 1
        used[pick[0]] = name
        mapping[name] = (pick[0], pick[1], pick[2], cn)

    if verbose:
        print('  建立映射 %d 项，覆盖文件块 %d / %d' % (len(mapping), len(used), len(blocks)))
        if n_multi:
            print('  （有 %d 项遇到同字节的多个块，按顺序分配）' % n_multi)
        unmapped_blocks = [b for b in blocks if b[0] not in used]
        print('  未被映射的块 %d 个（应为 running_mean/var 这类占位数据）' % len(unmapped_blocks))
    return raw, blocks, sd, mapping


# ---------------------------------------------------------------------------
#  写回
# ---------------------------------------------------------------------------
def write_from_sd(src, dst, sd, mapping, verbose=True):
    """把 sd 里的张量按映射写回文件。未出现在 sd 里的块保持原样。"""
    raw, blocks, _, _ = build_map(src, verbose=False)
    out = bytearray(raw)
    n = 0
    for name, (idx, off, cnt, cn) in mapping.items():
        if name not in sd:
            continue
        arr = np.asarray(sd[name], dtype=np.float32)
        # 只接受让字节与原来一致的那种变换 —— cn 在建模时已经定了
        f = _to_file_with(name, arr, cn)
        if f.size != cnt:
            raise ValueError('%s: 期望 %d 个 float，实际 %d' % (name, cnt, f.size))
        out[off:off + 4 * cnt] = f.astype('<f4').tobytes()
        n += 1
    with gzip.GzipFile(dst, 'wb', compresslevel=6, mtime=0) as g:
        g.write(bytes(out))
    if verbose:
        print('  写回 %d 个张量 -> %s (%.1f MB)' % (n, dst, os.path.getsize(dst) / 1e6))
    return n


def _to_file_with(name, arr, cn):
    a = np.ascontiguousarray(arr, dtype='<f4')
    if cn == 'conv_T2310':
        return np.ascontiguousarray(a.transpose(2, 3, 1, 0))
    if cn in ('matmul_T', 'matmul_T_sq'):
        return np.ascontiguousarray(a.transpose(1, 0))
    return a


def main():
    if len(sys.argv) < 3:
        print(__doc__)
        return 2
    mode = sys.argv[1]
    src = sys.argv[2]

    print('读取 %s ...' % src)
    raw, blocks, sd, mapping = build_map(src)
    print()

    if mode == 'verify':
        # 逐项核对：按映射取回文件字节，与 state_dict 的变换结果比对
        bad = 0
        for name, (idx, off, cnt, cn) in list(mapping.items()):
            a = np.asarray(sd[name], dtype=np.float32)
            f = _to_file_with(name, a, cn)
            if raw[off:off + 4 * cnt] != f.astype('<f4').tobytes():
                bad += 1
                if bad <= 5:
                    print('  不一致: %s (块 %d, %s)' % (name, idx, cn))
        print('字节校验: %d 项，不一致 %d 项' % (len(mapping), bad))
        # 变换候选的分布
        from collections import Counter
        c = Counter(v[3] for v in mapping.values())
        print('变换分布: %s' % dict(c))
        return 0 if bad == 0 else 1

    if mode == 'identity':
        dst = sys.argv[3]
        write_from_sd(src, dst, sd, mapping)
        # 决定性检查：与原始解压字节逐字节相同
        with gzip.open(dst, 'rb') as f:
            out_raw = f.read()
        same = (out_raw == raw)
        print('  逐字节对比: %s' % ('完全相同 ✓' if same else '不同 ✗'))
        if not same:
            diff = sum(1 for i in range(min(len(out_raw), len(raw))) if out_raw[i] != raw[i])
            print('  不同字节数 %d' % diff)
            return 1
        return 0

    print(__doc__)
    return 2


if __name__ == '__main__':
    sys.exit(main())
