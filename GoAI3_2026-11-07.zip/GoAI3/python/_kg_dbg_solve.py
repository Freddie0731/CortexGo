# -*- coding: utf-8 -*-
"""反解参考 norm 实际使用的 scale/bias，定位参数读取错误。

用两行不同输入解线性方程： y = x*A + B
解出 A、B 后与文件里的 scale/bias 对照，即可看出是否读错了张量/顺序/布局。
"""
import sys, os, struct
import numpy as np
import torch

try:
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
except Exception:
    pass
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import _katago_v17_load as L


def read_ref(path):
    f = open(path, 'rb')
    assert f.read(8) == b'KGREF001'
    n = struct.unpack('<i', f.read(4))[0]
    out = {}
    for _ in range(n):
        nl = struct.unpack('<i', f.read(4))[0]
        name = f.read(nl).decode()
        nd = struct.unpack('<i', f.read(4))[0]
        dims = [struct.unpack('<i', f.read(4))[0] for _ in range(nd)]
        cnt = 1
        for d in dims:
            cnt *= d
        out[name] = np.frombuffer(f.read(4 * cnt), dtype='<f4').reshape(dims).copy()
    return out


def main():
    M = L.load(sys.argv[1], verbose=False)
    R = read_ref(sys.argv[2])

    inp = torch.from_numpy(R['input.spatial'].astype(np.float32))
    ing = torch.from_numpy(R['input.global'].astype(np.float32))
    c = M['trunk']['initialConv']
    Wc = torch.from_numpy(np.ascontiguousarray(c['w'])).float()
    convOut = torch.nn.functional.conv2d(inp, Wc, padding='same')
    Wg = torch.from_numpy(np.ascontiguousarray(M['trunk']['initialMatMul']['w'])).float()
    gOut = torch.nn.functional.linear(ing, Wg)
    embed = (convOut + gOut.reshape(1, -1, 1, 1)).view(1, 768, 361).transpose(1, 2)[0]  # (361,768)
    x = embed.numpy().astype(np.float64)

    rn = R['blocks.0.normactconvp.norm'].reshape(361, 768).astype(np.float64)
    f = M['trunk']['blocks'][0]['p']['norm']
    sc = np.asarray(f['scale'], dtype=np.float64)
    bi = np.asarray(f['bias'], dtype=np.float64)

    print('=== 用 s=0 与 s=1 两行反解 y = x*A + B ===')
    A = np.zeros(768)
    B = np.zeros(768)
    bad = 0
    for ch in range(768):
        x0, x1 = x[0, ch], x[1, ch]
        y0, y1 = rn[0, ch], rn[1, ch]
        den = (x0 - x1)
        if abs(den) < 1e-12:
            A[ch] = float('nan'); B[ch] = float('nan'); bad += 1
            continue
        a = (y0 - y1) / den
        A[ch] = a
        B[ch] = y0 - a * x0
    ok = ~np.isnan(A)
    print('  可解通道数 %d / 768 (有 %d 个通道两行输入相同，无法解)' % (ok.sum(), bad))

    print('\n  反解出的 A[:6] =', np.round(A[:6], 6).tolist())
    print('  文件 scale[:6] =', np.round(sc[:6], 6).tolist())
    print('  反解出的 B[:6] =', np.round(B[:6], 6).tolist())
    print('  文件 bias [:6] =', np.round(bi[:6], 6).tolist())

    dA = np.abs(A[ok] - sc[ok])
    dB = np.abs(B[ok] - bi[ok])
    print('\n  |A - scale|max = %.6e   |B - bias|max = %.6e' % (dA.max(), dB.max()))

    # 如果反解出的 A 等于 1 且 B 就是 beta，说明参考根本没乘 scale
    print('\n  与"完全不乘 scale"假设比较: |A - 1|max = %.6e' % np.abs(A[ok] - 1.0).max())

    # 检验：用反解出的 A、B 能否完美复现整个参考张量
    y_hat = x * A + B
    print('  用反解 A,B 复现参考的误差 max = %.6e' % np.nanmax(np.abs(y_hat - rn)))

    # 检验：用文件的 scale,bias 复现
    y_file = x * sc + bi
    print('  用文件 scale,bias 复现参考的误差 max = %.6e' % np.max(np.abs(y_file - rn)))

    # 再看 A 与 scale 是否成比例（可能是 eps 处理差异）
    m = ok & (np.abs(sc) > 1e-8)
    ratio = A[m] / sc[m]
    print('\n  A/scale 的统计: min=%.6f max=%.6f mean=%.6f' % (ratio.min(), ratio.max(), ratio.mean()))


if __name__ == '__main__':
    main()
