# -*- coding: utf-8 -*-
"""KataGo v3 模型精确解析器（纯标准库，只读）。

严格镜像官方 C++ 读取顺序（cpp/neuralnet/desc.cpp）：
  * 全部元数据是**空白分隔的 token 流**（C++ operator>>）
  * 权重是 "@BIN@" 后跟 4*N 字节小端 float32
  * **每个层的名字也是从流里读的**，不存在按名字查找 —— 所以顺序读必然正确

已核对的官方读取顺序：
  ModelDesc:  name, modelVersion, numInputChannels, numInputGlobalChannels,
              [v>=13] tdScoreMultiplier, scoreMeanMultiplier, scoreStdevMultiplier,
                      leadMultiplier, varianceTimeMultiplier,
                      shorttermValueErrorMultiplier, shorttermScoreErrorMultiplier,
              [v>=15] metaEncoderVersion, preferPassAliveInt, preferExcludeTerritoryAdjAtariInt,
                      unused x5,
              trunk, policyHead, valueHead
  TrunkDesc:  name, numBlocks, trunkNumChannels, midNumChannels, regularNumChannels,
              dilatedNumChannels, gpoolNumChannels,
              [v>=15] trunkNormKind, unused x5,
              initialConv, then blocks, then trunk tip

用法: python _katago_v3_parse.py <file.bin.gz> [--dump-layers N]
"""
import sys, gzip, struct, math

try:
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
except Exception:
    pass


class EOF(Exception):
    pass


class ModelStream(object):
    """模拟 C++ istream：先读空白分隔 token，遇到 @BIN@ 则读二进制 float32。"""

    def __init__(self, data):
        self.d = data
        self.p = 0

    # ---------- 基础 ----------
    def _skip_ws(self):
        d, n = self.d, len(self.d)
        while self.p < n and d[self.p] in (0x20, 0x09, 0x0A, 0x0D, 0x0B, 0x0C):
            self.p += 1

    def token(self):
        self._skip_ws()
        d, n = self.d, len(self.d)
        if self.p >= n:
            raise EOF('end of stream while reading token')
        s = self.p
        while self.p < n and d[self.p] not in (0x20, 0x09, 0x0A, 0x0D, 0x0B, 0x0C):
            self.p += 1
        return d[s:self.p].decode('utf-8', 'replace')

    def i32(self):
        t = self.token()
        try:
            return int(t)
        except ValueError:
            # C++ 会先尝试整数读取；失败时按 float 截断
            return int(float(t))

    def f32(self):
        return float(self.token())

    def floats(self, n):
        """读 @BIN@ 后的 n 个小端 float32。"""
        self._skip_ws()
        d = self.d
        # 官方实现：跳过最多 100 个字符直到 '@'，再校验接下来是 "BIN@"
        cnt = 0
        while self.p < len(d) and d[self.p:self.p + 1] != b'@':
            self.p += 1
            cnt += 1
            if cnt > 100:
                raise EOF('did not find @ within 100 chars (offset %d)' % self.p)
        if d[self.p:self.p + 5] != b'@BIN@':
            raise EOF('missing @BIN@ at offset %d, saw %r' % (self.p, d[self.p:self.p + 12]))
        self.p += 5
        need = 4 * n
        if self.p + need > len(d):
            raise EOF('binary block truncated: need %d bytes at %d' % (need, self.p))
        vals = struct.unpack_from('<%df' % n, d, self.p)
        self.p += need
        return vals

    def at_end(self):
        self._skip_ws()
        return self.p >= len(self.d)


# ---------------------------------------------------------------- 层描述
class Layer(object):
    def __init__(self, kind, name, dims, nfloats):
        self.kind = kind
        self.name = name
        self.dims = dims
        self.nfloats = nfloats

    def __repr__(self):
        return '%-18s %-44s %-22s %d' % (self.kind, self.name, self.dims, self.nfloats)


def read_conv(inp):
    name = inp.token()
    convY = inp.i32(); convX = inp.i32()
    inCh = inp.i32(); outCh = inp.i32()
    dilY = inp.i32(); dilX = inp.i32()
    if dilX != 1 or dilY != 1:
        raise ValueError('dilation unsupported')
    n = convY * convX * inCh * outCh
    inp.floats(n)
    return Layer('conv', name, (convY, convX, inCh, outCh), n)


def read_bn(inp):
    name = inp.token()
    numCh = inp.i32()
    eps = inp.f32()
    hasScale = inp.i32()
    hasBias = inp.i32()
    n = 2 * numCh + (numCh if hasScale else 0) + (numCh if hasBias else 0)
    inp.floats(n)
    return Layer('batchnorm', name, (numCh,), n)


def read_activation(inp):
    name = inp.token()
    kind = inp.token()
    return Layer('activation', name, (kind,), 0)


def read_matmul(inp):
    name = inp.token()
    inCh = inp.i32(); outCh = inp.i32()
    n = inCh * outCh
    inp.floats(n)
    return Layer('matmul', name, (inCh, outCh), n)


def read_matbias(inp):
    name = inp.token()
    numCh = inp.i32()
    inp.floats(numCh)
    return Layer('matbias', name, (numCh,), numCh)


def read_rmsnorm(inp):
    name = inp.token()
    numCh = inp.i32()
    eps = inp.f32()
    spatial = inp.i32()
    cgroup = inp.i32()
    inp.floats(numCh)   # gamma
    inp.floats(numCh)   # beta
    return Layer('rmsnorm', name, (numCh, eps, spatial, cgroup), 2 * numCh)


def main():
    path = sys.argv[1]
    dump_layers = 40
    if '--dump-layers' in sys.argv:
        dump_layers = int(sys.argv[sys.argv.index('--dump-layers') + 1])

    with gzip.open(path, 'rb') as g:
        data = g.read()
    print('decompressed %d bytes (%.1f MB)' % (len(data), len(data) / 1048576.0))

    inp = ModelStream(data)
    layers = []

    # ---------- ModelDesc ----------
    name = inp.token()
    modelVersion = inp.i32()
    numInputChannels = inp.i32()
    numInputGlobalChannels = inp.i32()

    post = {}
    if modelVersion >= 13:
        post['tdScoreMultiplier'] = inp.f32()
        post['scoreMeanMultiplier'] = inp.f32()
        post['scoreStdevMultiplier'] = inp.f32()
        post['leadMultiplier'] = inp.f32()
        post['varianceTimeMultiplier'] = inp.f32()
        post['shorttermValueErrorMultiplier'] = inp.f32()
        post['shorttermScoreErrorMultiplier'] = inp.f32()

    metaEncoderVersion = 0
    preferPassAlive = preferExcludeAtari = 0
    if modelVersion >= 15:
        metaEncoderVersion = inp.i32()
        preferPassAlive = inp.i32()
        preferExcludeAtari = inp.i32()
        for i in range(5):
            unused = inp.i32()
            if unused != 0:
                raise ValueError('unexpected unused model option at slot %d: %d' % (i, unused))

    print('\n===== ModelDesc =====')
    print('  name                    : %s' % name)
    print('  modelVersion            : %d' % modelVersion)
    print('  numInputChannels        : %d' % numInputChannels)
    print('  numInputGlobalChannels  : %d' % numInputGlobalChannels)
    print('  metaEncoderVersion      : %d' % metaEncoderVersion)
    print('  preferPassAliveUnderSuic : %d' % preferPassAlive)
    print('  preferExcludeTerrAtari  : %d' % preferExcludeAtari)
    for k, v in post.items():
        print('  %-24s: %s' % (k, v))

    # ---------- TrunkDesc ----------
    tname = inp.token()
    numBlocks = inp.i32()
    trunkNumChannels = inp.i32()
    midNumChannels = inp.i32()
    regularNumChannels = inp.i32()
    dilatedNumChannels = inp.i32()
    gpoolNumChannels = inp.i32()
    trunkNormKind = 0
    if modelVersion >= 15:
        trunkNormKind = inp.i32()
        for i in range(5):
            unused = inp.i32()
            if unused != 0:
                raise ValueError('unexpected unused trunk option at slot %d: %d' % (i, unused))

    print('\n===== TrunkDesc =====')
    print('  name                    : %s' % tname)
    print('  numBlocks               : %d' % numBlocks)
    print('  trunkNumChannels        : %d' % trunkNumChannels)
    print('  midNumChannels          : %d' % midNumChannels)
    print('  regularNumChannels      : %d' % regularNumChannels)
    print('  dilatedNumChannels      : %d  (unused)' % dilatedNumChannels)
    print('  gpoolNumChannels        : %d' % gpoolNumChannels)
    print('  trunkNormKind           : %d' % trunkNormKind)

    layers.append(read_conv(inp))     # initialConv

    for b in range(numBlocks):
        kind = inp.token()
        if kind == 'ordinary_block':
            bn = read_bn(inp); cv = read_conv(inp); bn2 = read_bn(inp); cv2 = read_conv(inp)
            layers += [Layer('block.begin', 'blocks.%d' % b, (kind,), 0), bn, cv, bn2, cv2]
        elif kind == 'gpool_block':
            bn = read_bn(inp); cv = read_conv(inp); gcv = read_conv(inp)
            gbn = read_bn(inp); mm = read_matmul(inp); bn2 = read_bn(inp); cv2 = read_conv(inp)
            layers += [Layer('block.begin', 'blocks.%d' % b, (kind,), 0), bn, cv, gcv, gbn, mm, bn2, cv2]
        elif kind == 'nested_bottleneck_block':
            nm = inp.token()
            nsub = inp.i32()
            layers.append(Layer('block.begin', nm, (kind, nsub), 0))
            for j in range(nsub):
                sub = inp.token()
                if sub == 'normactconv':
                    bn = read_bn(inp)
                    act = read_activation(inp)
                    cv = read_conv(inp)
                    layers += [Layer('sub.begin', 'blocks.%d.sub.%d' % (b, j), (sub,), 0), bn, act, cv]
                elif sub == 'normactconvp':
                    # p 分支把 norm 换成 RMSNorm（文件里名字是 .norm / .act / .conv）
                    rn = read_rmsnorm(inp)
                    act = read_activation(inp)
                    cv = read_conv(inp)
                    layers += [Layer('sub.begin', 'blocks.%d.sub.%d' % (b, j), (sub,), 0), rn, act, cv]
                else:
                    raise ValueError('unknown nested sub-kind %r at block %d' % (sub, b))
        else:
            raise ValueError('unknown block kind %r at block %d (offset %d)' % (kind, b, inp.p))

    # trunk tip
    tipBN = read_bn(inp)
    tipAct = read_activation(inp)
    layers += [Layer('trunk.tip', 'trunk.tip', (), 0), tipBN, tipAct]

    print('\nlayers parsed so far: %d ; stream at %d / %d (%.1f%%)'
          % (len(layers), inp.p, len(data), 100.0 * inp.p / len(data)))

    print('\n===== layer list (first %d) =====' % dump_layers)
    for i, L in enumerate(layers[:dump_layers]):
        print('  [%3d] %s' % (i, L))
    if len(layers) > dump_layers:
        print('  ... (%d more)' % (len(layers) - dump_layers))
    return 0


if __name__ == '__main__':
    sys.exit(main())
