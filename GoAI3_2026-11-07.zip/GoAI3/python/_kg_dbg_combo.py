# -*- coding: utf-8 -*-
"""穷举组合，找出参考 qnorm 的输入到底怎么由参考自己的张量构成。"""
import struct, sys
import numpy as np
sys.stdout.reconfigure(encoding='utf-8', errors='replace')
sys.path.insert(0, '.')
import _katago_v17_load as L


def read_ref(path):
    f = open(path, 'rb')
    assert f.read(8) == b'KGREF001'
    n = struct.unpack('<i', f.read(4))[0]
    D = {}
    for _ in range(n):
        nl = struct.unpack('<i', f.read(4))[0]
        name = f.read(nl).decode()
        nd = struct.unpack('<i', f.read(4))[0]
        dims = [struct.unpack('<i', f.read(4))[0] for _ in range(nd)]
        c = 1
        for d in dims:
            c *= d
        D[name] = np.frombuffer(f.read(4 * c), dtype='<f4').reshape(dims).copy()
    return D


def rms(a):
    return float(np.sqrt((a ** 2).mean()))


M = L.load(sys.argv[1], verbose=False)
D = read_ref(sys.argv[2])
bias = np.asarray(M['trunk']['blocks'][0]['q']['norm']['bias'], dtype=np.float64)
qn = D['blocks.0.normactconvq.norm'].reshape(361, 384).astype(np.float64)
target = qn - bias                       # 参考 q-norm 的输入
p = D['blocks.0.normactconvp'].reshape(361, 384).astype(np.float64)
st = [D['blocks.0.blockstack.%d' % i].reshape(361, 384).astype(np.float64) for i in range(6)]

print('target RMS = %.6f' % rms(target))
for i, s in enumerate(st):
    print('  stack%d RMS = %.6f' % (i, rms(s)))
print('  p      RMS = %.6f' % rms(p))

cands = {
    'p+sum(stack)': p + sum(st),
    'sum(stack)': sum(st),
    'p+stack5': p + st[5],
    'stack5': st[5],
    'p+sum+stack5': p + sum(st) + st[5],
    'p': p,
}
print()
for k, v in cands.items():
    print('  %-16s RMS=%.6f  maxdiff=%.5f' % (k, rms(v), np.abs(target - v).max()))

A = np.c_[sum(st).ravel(), p.ravel()]
sol, *_ = np.linalg.lstsq(A, target.ravel(), rcond=None)
print()
print('最小二乘 target = a*sum(stack) + b*p : a=%.4f b=%.4f 残差RMS=%.5f'
      % (sol[0], sol[1], float(np.sqrt(((target - (A @ sol)) ** 2).mean()))))

A2 = np.c_[[s.ravel() for s in st] + [p.ravel()]].T
sol2, *_ = np.linalg.lstsq(A2, target.ravel(), rcond=None)
r2 = target - A2 @ sol2
print('联合最小二乘(p + 6 个 stack): 系数=%s 残差RMS=%.5f'
      % (np.round(sol2, 4).tolist(), float(np.sqrt((r2 ** 2).mean()))))

# 也检查 normactconvp 的输入（即 embed.out）是否就是 target 的某种缩放
for i in range(6):
    A3 = np.c_[st[i].ravel(), p.ravel()]
    s3, *_ = np.linalg.lstsq(A3, target.ravel(), rcond=None)
    r3 = target - A3 @ s3
    print('  用 stack%d + p 拟合: 系数=%s 残差RMS=%.5f'
          % (i, np.round(s3, 4).tolist(), float(np.sqrt((r3 ** 2).mean()))))
