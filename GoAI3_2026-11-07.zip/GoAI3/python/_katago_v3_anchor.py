# -*- coding: utf-8 -*-
"""KataGo v3 全局锚点验证（纯标准库，只读）。

观察：@BIN@ 出现 470 次；若文件含 468 个张量块 + 头部块 + 1，则多出 2 次。
本脚本对每一次 @BIN@ 出现，向前读"名字行 + 起始计数字段"，把它当作张量块，
验证块尾（@BIN@ 之后 4*prod(dims) 字节）是否恰好落在下一个块的名字起点上。

这能给出「块框架」的全局一致性判定，而不依赖对头部语义的猜测。

用法: python _katago_v3_anchor.py <file.bin.gz> [--verbose]
"""
import sys, gzip

try:
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
except Exception:
    pass

NAME_START = set('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_')
NAME_BODY = set('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_.-')
NUM_BODY = set('0123456789.eE+-')


def is_name(s):
    return bool(s) and s[0] in NAME_START and all(c in NAME_BODY for c in s)


def is_num(s):
    return bool(s) and all(c in NUM_BODY for c in s)


def lines_around(data, pos, back=12, fwd=12):
    """返回 pos 前后各若干行的 (offset, text) 列表，用于逆向定位。"""
    res = []
    # 向前找行
    starts = [pos]
    p = pos - 1
    while p > 0 and len(starts) < back:
        if data[p - 1] == 0x0A:
            starts.append(p)
        p -= 1
    starts = sorted(starts)
    for s in starts:
        nl = data.find(b'\n', s)
        res.append((s, data[s:nl].decode('utf-8', 'replace')))
    return res


def try_parse_tensor_block(data, bin_pos):
    """bin_pos 指向 @BIN@。向前试探：连续整数行 + 1 行 ndim + 1 行块名。
    浮点行（如 1e-20 的 Epsilon）不是维度，遇到即停止收集。"""
    total = len(data)
    num_lines = []
    p = bin_pos
    while True:
        if p == 0 or data[p - 1] != 0x0A:
            break
        s = data.rfind(b'\n', 0, p - 1) + 1
        txt = data[s:p - 1].decode('utf-8', 'replace')
        if not txt.isdigit():
            break
        num_lines.append((s, txt))
        p = s
    num_lines.reverse()   # 由早到晚
    results = []
    # ndim_line 是 num_lines 里最后一个；维度是它前面的 ndim 行
    if len(num_lines) >= 2:
        ndim_line = num_lines[-1]
        ndim = int(ndim_line[1])
        if 1 <= ndim <= 5 and len(num_lines) - 1 >= ndim:
            dim_lines = num_lines[-1 - ndim:-1]
            if len(dim_lines) == ndim:
                name_end = dim_lines[0][0] - 1
                if name_end > 0 and data[name_end - 1] == 0x0A:
                    ns = data.rfind(b'\n', 0, name_end - 1) + 1
                    name = data[ns:name_end - 1].decode('utf-8', 'replace')
                    if is_name(name):
                        dims = [int(t) for _o, t in dim_lines]
                        n = 1
                        for d in dims:
                            n *= d
                        results.append((name, dims, n, bin_pos + 5 + 4 * n))
    return results


def main():
    path = sys.argv[1]
    verbose = '--verbose' in sys.argv
    with gzip.open(path, 'rb') as g:
        data = g.read()
    total = len(data)

    bins = []
    p = 0
    while True:
        i = data.find(b'@BIN@', p)
        if i < 0:
            break
        bins.append(i)
        p = i + 1
    print('@BIN@ occurrences: %d' % len(bins))

    # 逐个 @BIN@ 解析，看能否形成从 139 附近开始、逐步衔接的链
    parsed = {}
    for b in bins:
        res = try_parse_tensor_block(data, b)
        if res:
            # 选择 payload 结束位置与下一个 @BIN@ 的候选对齐的那个
            parsed[b] = res

    print('@BIN@ with at least one valid interpretation: %d' % len(parsed))

    # 建立 name -> 张量 列表
    chosen = []
    for b in bins:
        res = parsed.get(b)
        if not res:
            continue
        # 优先取"结束位置恰好等于另一个 @BIN@ 的块名起点"的解释
        best = None
        for name, dims, n, end in res:
            score = 0
            if end <= total:
                score += 1
            if best is None or score > best[3]:
                best = (name, dims, n, score, end)
        if best:
            chosen.append((b, best[0], best[1], best[2], best[4]))

    print('tensor-like blocks: %d' % len(chosen))
    names = [c[1] for c in chosen]
    print('unique names: %d' % len(set(names)))

    from collections import Counter
    print('\nname suffix histogram (top 40):')
    for k, v in Counter(n.split('.')[-1] for n in names).most_common(40):
        print('  %-28s %d' % (k, v))

    print('\nprefix histogram:')
    for k, v in Counter(n.split('.')[0] for n in names).most_common(20):
        print('  %-28s %d' % (k, v))

    print('\nfirst 60 blocks (offset, name, dims):')
    for b, name, dims, n, end in chosen[:60]:
        print('  %-10d %-46s %-24s %8d' % (b, name[:46], str(dims), n))

    total_floats = sum(c[3] for c in chosen)
    print('\nsum floats over all tensor-like blocks: %d (%.1f MB)'
          % (total_floats, total_floats * 4 / 1048576.0))
    print('file size: %d (%.1f MB)' % (total, total / 1048576.0))
    return 0


if __name__ == '__main__':
    sys.exit(main())
