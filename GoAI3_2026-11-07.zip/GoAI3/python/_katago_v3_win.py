# -*- coding: utf-8 -*-
"""KataGo v3 指定区间字节转储（纯标准库，只读）。

用法: python _katago_v3_win.py <file.bin.gz> <start> <end> [--lines-only]
"""
import sys, gzip

try:
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
except Exception:
    pass


def main():
    path = sys.argv[1]
    start = int(sys.argv[2])
    end = int(sys.argv[3])
    with gzip.open(path, 'rb') as g:
        data = g.read()
    end = min(end, len(data))
    chunk = data[start:end]

    # 只打印可打印/换行字符构成的"行"，其余用 # 表示
    print('--- structure view of [%d, %d) ---' % (start, end))
    i = 0
    line_start = start
    while i < len(chunk):
        nl = chunk.find(b'\n', i)
        if nl < 0:
            seg = chunk[i:]
            printable = all(32 <= b < 127 for b in seg)
            print('  off %9d  %s  %s' % (start + i, 'TEXT' if printable else 'BIN ',
                  (seg[:70].decode('latin-1') if printable else '<%d bytes>' % len(seg))))
            break
        seg = chunk[i:nl]
        printable = all(32 <= b < 127 for b in seg)
        if printable:
            print('  off %9d  TEXT  %s' % (start + i, seg[:70].decode('latin-1')))
        else:
            print('  off %9d  BIN   <%d bytes> %s' % (start + i, len(seg),
                  seg[:12].hex()))
        i = nl + 1
    return 0


if __name__ == '__main__':
    sys.exit(main())
