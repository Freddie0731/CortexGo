# -*- coding: utf-8 -*-
"""
KataGo v3 元数据 / 组件清单侦察器  --  纯标准库，只读。

v3 的模型头是纯文本行：组件名 一行，随后是 "维度个数 N"，再 N 个维度值。
各组件再用 "维度个数" 声明自己有多少个参数。

用法:
    python _katago_v3_meta.py <file.bin.gz> [--tensors]
"""
import sys, gzip, struct, os

try:
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
except Exception:
    pass

KNOWN_PREFIXES = (
    'model.', 'trunk.', 'policy.', 'value.', 'score.', 'ownership.',
    'model', 'trunk', 'policy', 'value', 'score', 'ownership',
)


def split_lines(data, limit):
    """把 [0, limit) 按 \n 切成行；返回 (lines, end_pos)。"""
    lines = []
    pos = 0
    while pos < limit:
        nl = data.find(b'\n', pos, limit)
        if nl < 0:
            break
        lines.append(data[pos:nl].decode('utf-8', 'replace'))
        pos = nl + 1
    return lines, pos


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        return 2
    path = sys.argv[1]
    want_tensors = '--tensors' in sys.argv

    with gzip.open(path, 'rb') as g:
        data = g.read()
    print('decompressed: %d bytes (%.2f MB)\n' % (len(data), len(data) / 1048576.0))

    # ---------- 头部：magic, magicsize, numComponents ----------
    pos = 0
    nl = data.index(b'\n', pos)
    magic = data[pos:nl].decode('utf-8')
    pos = nl + 1
    nl = data.index(b'\n', pos)
    magic_size = int(data[pos:nl])
    pos = nl + 1
    nl = data.index(b'\n', pos)
    num_components = int(data[pos:nl])
    pos = nl + 1

    print('magic          : %s' % magic)
    print('magic size     : %d' % magic_size)
    print('numComponents  : %d' % num_components)

    # ---------- 头部组件（第一块） ----------
    print('\n--- header component values (first block) ---')
    first_vals = []
    for i in range(num_components):
        nl = data.index(b'\n', pos)
        first_vals.append(data[pos:nl].decode('utf-8'))
        pos = nl + 1
    for i, v in enumerate(first_vals):
        print('  [%2d] %s' % (i, v))

    # ---------- 模型组件 ----------
    # 结构: name \n ndim \n dim_1..dim_ndim \n @BIN@ \n <4*n floats> \n
    print('\n--- model components ---')
    components = []
    for _ in range(2000):
        if pos >= len(data):
            break
        nl = data.find(b'\n', pos)
        if nl < 0:
            break
        name = data[pos:nl].decode('utf-8', 'replace')
        if not name.startswith(KNOWN_PREFIXES) or not name:
            print('  !! stop at offset %d: not a component name: %r' % (pos, name[:60]))
            break
        pos = nl + 1
        nl = data.find(b'\n', pos)
        ndim = int(data[pos:nl])
        pos = nl + 1
        dims = []
        for _i in range(ndim):
            nl = data.find(b'\n', pos)
            dims.append(int(data[pos:nl]))
            pos = nl + 1
        # @BIN@ 标记
        if data[pos:pos + 5] != b'@BIN@':
            print('  !! %s: expected @BIN@ at %d, got %r' % (name, pos, data[pos:pos + 12]))
            break
        pos += 5
        n = 1
        for d in dims:
            n *= d
        pos += 4 * n
        components.append((name, dims, n))
        if len(components) <= 80 or len(components) % 25 == 0:
            print('  [%3d] %-38s ndim=%d %s  floats=%d' % (len(components), name, ndim, dims, n))

    print('\n  components parsed : %d' % len(components))
    print('  stream consumed   : to offset %d of %d (left %d)' % (pos, len(data), len(data) - pos))

    total_floats = sum(c[2] for c in components)
    print('  total floats      : %d (%.1f MB)' % (total_floats, total_floats * 4 / 1048576.0))

    # ---------- 自校验：文件名声称 b11c768 ----------
    print('\n' + '=' * 74)
    print('SELF-CHECK  (filename truth: 11 blocks, 768 channels)')
    print('=' * 74)
    for name, dims, _n in components:
        low = name.lower()
        if 'trunk' in low or 'block' in low or low.startswith('model.conv') or 'stem' in low:
            flag = ''
            if 11 in dims:
                flag += ' <-- contains 11'
            if 768 in dims:
                flag += ' <-- contains 768'
            print('  %-38s %s%s' % (name, dims, flag))

    # ---------- 张量流 ----------
    if want_tensors:
        print('\n--- tensor stream ---')
        p = pos
        count = 0
        while p < len(data) and count < 2000:
            nl = data.find(b'\n', p, p + 400)
            try:
                name_len = int(data[p:nl])
            except Exception:
                print('  stop at %d: cannot read name length (%r)' % (p, data[p:p + 24]))
                break
            p = nl + 1
            name = data[p:p + name_len].decode('ascii')
            p += name_len
            nl = data.find(b'\n', p)
            ndim = int(data[p:nl]); p = nl + 1
            dims = []
            for _i in range(ndim):
                nl = data.find(b'\n', p)
                dims.append(int(data[p:nl])); p = nl + 1
            n = 1
            for d in dims:
                n *= d
            p += 4 * n
            count += 1
            if count <= 60 or count % 100 == 0:
                print('  [%4d] %-40s %s  (floats=%d)' % (count, name, dims, n))
        print('  tensors read: %d ; consumed to offset %d of %d (left %d)'
              % (count, p, len(data), len(data) - p))
    return 0


if __name__ == '__main__':
    sys.exit(main())
