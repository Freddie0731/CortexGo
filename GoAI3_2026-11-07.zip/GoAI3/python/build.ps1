<#
  build.ps1 -- 统一编译入口（MSVC 19.51 / VS18 Community, x64）

  为什么要这个脚本：项目里 vcxproj 用 v145 工具集，但命令行 cl 不在 PATH 上，
  每次编译都要手写一长串 vcvars + 参数。这里固定一套已验证可用的标志，
  并允许每个工作流使用**独立的输出目录**，避免多人同时编译互相覆盖 .obj。

  用法：
    pwsh -File tools\build.ps1 -Target exe    -OutDir build_out\main
    pwsh -File tools\build.ps1 -Target bench  -OutDir build_out\perf
    pwsh -File tools\build.ps1 -Target testfwd -OutDir build_out\perf
    pwsh -File tools\build.ps1 -Target testops -OutDir build_out\perf
    pwsh -File tools\build.ps1 -Target parse  -OutDir build_out\perf
    pwsh -File tools\build.ps1 -Target <任意.cpp相对路径> -OutDir <目录>

  说明：
    * /utf-8 必须有：源码是 UTF-8，MSVC 默认按 936(GBK) 解码会把中文注释解坏。
    * /openmp 必须有：kg/infer/ops.h 的多线程路径靠 _OPENMP 宏开启。
    * 主程序要求 /std:c++20（vcxproj 里就是 stdcpp20）。
#>
param(
    [Parameter(Mandatory = $true)][string]$Target,
    [string]$OutDir = "build_out\main",
    [string]$Config = "Release"
)

$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
$vcvars = "C:\Program Files\Microsoft Visual Studio\18\Community\VC\Auxiliary\Build\vcvars64.bat"
if (-not (Test-Path $vcvars)) { throw "vcvars64.bat not found: $vcvars" }

$srcMap = @{
    "exe"     = "go_ai.cpp"
    "bench"   = "kg\test\bench_forward.cpp"
    "testfwd" = "kg\test\test_forward.cpp"
    "testops" = "kg\test\test_ops.cpp"
    "parse"   = "kg\test\test_parse.cpp"
    "gzip"    = "kg\test\test_gzip.cpp"
}
$src = if ($srcMap.ContainsKey($Target)) { $srcMap[$Target] } else { $Target }
if (-not (Test-Path (Join-Path $root $src))) { throw "source not found: $src" }

$outAbs = if ([System.IO.Path]::IsPathRooted($OutDir)) { $OutDir } else { Join-Path $root $OutDir }
New-Item -ItemType Directory -Force -Path $outAbs | Out-Null

$name = [System.IO.Path]::GetFileNameWithoutExtension($src)
$exe = Join-Path $outAbs "$name.exe"
$objDir = Join-Path $outAbs "obj\\"
New-Item -ItemType Directory -Force -Path $objDir | Out-Null

if ($src -eq "go_ai.cpp") {
    $std = "/std:c++20"
    $extraLink = "/link gdiplus.lib gdi32.lib user32.lib"
} else {
    $std = "/std:c++17"
    $extraLink = ""
}

$cmd = "`"$vcvars`" >nul && cd /d `"$root`" && cl /nologo /O2 /EHsc $std /W3 /DNDEBUG /utf-8 /openmp " +
       "/Fe:`"$exe`" /Fo:`"$objDir`" `"$src`" $extraLink"
Write-Host "[build] $src -> $exe" -ForegroundColor Cyan
cmd /c $cmd
if ($LASTEXITCODE -ne 0) { throw "compile failed (exit $LASTEXITCODE)" }
if (-not (Test-Path $exe)) { throw "compile reported success but $exe is missing" }
Write-Host "[build] OK $exe ($([math]::Round((Get-Item $exe).Length/1KB,0)) KB)" -ForegroundColor Green
