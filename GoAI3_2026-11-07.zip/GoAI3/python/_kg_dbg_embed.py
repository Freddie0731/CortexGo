# -*- coding: utf-8 -*-
"""手算 embedding 与第一块的 norm，定位发散点。

读 ref.bin 里的 input.spatial / input.global，用文件权重复算
  embed = conv3x3(input) + linear_global(input_global)
再看 blocks.0.normactconvp.norm 的参考输出是否等于 norm(embed)（用文件里的 scale/bias）。
"""
import sys, os, struct
import numpy as np
import torch

try:
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
except Exception:
    pass
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import _katago_v17_load as L


def read_ref(path):
    f = open(path, 'rb')
    assert f.read(8) == b'KGREF001'
    n = struct.unpack('<i', f.read(4))[0]
    out = {}
    for _ in range(n):
        nl = struct.unpack('<i', f.read(4))[0]
        name = f.read(nl).decode()
        nd = struct.unpack('<i', f.read(4))[0]
        dims = [struct.unpack('<i', f.read(4))[0] for _ in range(nd)]
        cnt = 1
        for d in dims:
            cnt *= d
        arr = np.frombuffer(f.read(4 * cnt), dtype='<f4').reshape(dims)
        out[name] = arr.copy()
    return out


def main():
    wpath = sys.argv[1]
    rpath = sys.argv[2]
    M = L.load(wpath, verbose=False)
    R = read_ref(rpath)

    inp = torch.from_numpy(R['input.spatial'].astype(np.float32))       # (1,22,19,19)
    ing = torch.from_numpy(R['input.global'].astype(np.float32))        # (1,19)
    print('input.spatial', tuple(inp.shape), ' input.global', tuple(ing.shape))
    print('  inp[0,0,0,:4] =', inp[0, 0, 0, :4].tolist())
    print('  inp[0,1,0,:4] =', inp[0, 1, 0, :4].tolist())

    c = M['trunk']['initialConv']
    Wc = torch.from_numpy(np.ascontiguousarray(c['w'])).float()
    convOut = torch.nn.functional.conv2d(inp, Wc, padding='same')       # (1,768,19,19)
    print('\nconvOut[0,:4,0,0] =', convOut[0, :4, 0, 0].tolist())

    Wg = torch.from_numpy(np.ascontiguousarray(M['trunk']['initialMatMul']['w'])).float()
    gOut = torch.nn.functional.linear(ing, Wg)                          # (1,768)
    print('gOut[0,:4]        =', gOut[0, :4].tolist())

    embed = convOut + gOut.reshape(1, -1, 1, 1)                         # (1,768,19,19)
    print('embed[0,:4,0,0]   =', embed[0, :4, 0, 0].tolist())

    # 转成 (1,S,C) 与参考布局一致
    embedSC = embed.view(1, 768, 361).transpose(1, 2).contiguous()      # (1,361,768)
    emb = embedSC[0].numpy()                                            # (361,768)
    print('\nembedSC[0,0,:4] =', emb[0, :4].tolist())
    print('embedSC[0,1,:4] =', emb[1, :4].tolist())

    # 用文件权重做 normactconvp.norm，与参考比较
    p = M['trunk']['blocks'][0]['p']
    n = p['norm']
    sc = torch.from_numpy(np.ascontiguousarray(n['scale'])).float()
    bi = torch.from_numpy(np.ascontiguousarray(n['bias'])).float()
    x = torch.from_numpy(emb)
    y = x * sc + bi
    print('\n我算的 norm(embed)[0,:4] =', y[0, :4].tolist())
    print('我算的 norm(embed)[1,:4] =', y[1, :4].tolist())

    rn = R.get('blocks.0.normactconvp.norm')
    if rn is not None:
        ref = torch.from_numpy(rn.astype(np.float32))
        print('参考形状', tuple(rn.shape))
        ref2 = ref.view(361, 768)
        print('参考 norm[0,:4] =', ref2[0, :4].tolist())
        print('参考 norm[1,:4] =', ref2[1, :4].tolist())

        # 关键检验：参考的输入反推
        # 若参考 = norm(我的 embed) 则 embedding 正确
        d = (ref2 - y).abs().max().item()
        print('\n|参考 norm - 我算 norm(我的embed)|max = %.6e' % d)

        # 反过来：如果参考的输入不同，会差多少
        # 用参考的 norm 输出反推输入，再与我的 embed 比
        inv = (ref2 - bi) / sc
        d2 = (inv - x).abs().max().item()
        print('|反推输入 - 我的 embed|max = %.6e' % d2)
        print('  参考反推输入[0,:4] =', inv[0, :4].tolist())


if __name__ == '__main__':
    main()
