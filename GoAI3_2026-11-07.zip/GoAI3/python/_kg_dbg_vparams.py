# -*- coding: utf-8 -*-
"""直接对比"解析出的权重"与"官方模型实际参数"，定位 value head 参数差异。"""
import sys, os
import numpy as np
import torch
sys.stdout.reconfigure(encoding='utf-8', errors='replace')
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
os.environ.setdefault('TORCHDYNAMO_DISABLE', '1')

import _katago_v17_load as L
from _katago_official import load_official
from _kg_ref import build_state_dict

M = L.load(sys.argv[1], verbose=False)
Model, mc = load_official()
cfg = mc.config_of_name['b11c768h12nbt3tflrs-silu']
model = Model(cfg, 19).eval()
model.initialize()

sd = build_state_dict(M)
target = {}
for k, v in model.state_dict().items():
    if k in sd:
        a = np.array(sd[k], dtype=np.float32, copy=True)
        if tuple(a.shape) == tuple(v.shape):
            target[k] = torch.from_numpy(a).clone()
model.load_state_dict(target, strict=False)

vh = model.value_head
print('=== 官方模型 value_head ===')
print('  linear2.weight shape', tuple(vh.linear2.weight.shape))
print('  linear2.bias   shape', tuple(vh.linear2.bias.shape))
print('  linear2.bias[:4]  =', np.round(vh.linear2.bias.detach().numpy()[:4], 6).tolist())
print('  linear2.weight[0,:4]=', np.round(vh.linear2.weight.detach().numpy()[0, :4], 6).tolist())

f = M['valueHead']
print()
print('=== 文件里的参数 ===')
print('  v2Mul.w shape', np.asarray(f['v2Mul']['w']).shape)
print('  v2Bias.b shape', np.asarray(f['v2Bias']['b']).shape)
print('  v2Bias[:4]   =', np.round(np.asarray(f['v2Bias']['b'])[:4], 6).tolist())
print('  v2Mul.w[0,:4]=', np.round(np.asarray(f['v2Mul']['w'])[0, :4], 6).tolist())

print()
print('==== 逐项 diff ====')
for name, a, b in (
    ('linear2.weight', vh.linear2.weight.detach().numpy(), np.asarray(f['v2Mul']['w'])),
    ('linear2.bias', vh.linear2.bias.detach().numpy(), np.asarray(f['v2Bias']['b'])),
    ('linear_valuehead.weight', vh.linear_valuehead.weight.detach().numpy(),
     np.asarray(f['v3Mul']['w'])),
    ('linear_valuehead.bias', vh.linear_valuehead.bias.detach().numpy(),
     np.asarray(f['v3Bias']['b'])),
    ('conv1.weight', vh.conv1.weight.detach().numpy(), np.asarray(f['v1Conv']['w'])),
):
    d = np.abs(a - b).max() if a.shape == b.shape else float('nan')
    print('  %-26s shape %-16s vs %-16s maxdiff=%.6e'
          % (name, a.shape, b.shape, d))

# 检查 misc 的真实形状
print()
print('  v3Mul shape', np.asarray(f['v3Mul']['w']).shape)
print('  sv3Mul shape', np.asarray(f['sv3Mul']['w']).shape)
print('  模型 linear_miscvaluehead.weight shape',
      tuple(vh.linear_miscvaluehead.weight.shape))
print('  模型 linear_moremiscvaluehead.weight shape',
      tuple(vh.linear_moremiscvaluehead.weight.shape))
print('  模型 linear_valuehead.weight shape', tuple(vh.linear_valuehead.weight.shape))
