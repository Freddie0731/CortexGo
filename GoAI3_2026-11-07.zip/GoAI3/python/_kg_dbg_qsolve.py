# -*- coding: utf-8 -*-
"""反解 q 分支 norm 的结构：用参考自己的输入/输出解出系数，再与参数对照。"""
import struct, sys
import numpy as np
sys.stdout.reconfigure(encoding='utf-8', errors='replace')
sys.path.insert(0, '.')
import _katago_v17_load as L


def read_ref(path):
    f = open(path, 'rb')
    assert f.read(8) == b'KGREF001'
    n = struct.unpack('<i', f.read(4))[0]
    D = {}
    for _ in range(n):
        nl = struct.unpack('<i', f.read(4))[0]
        name = f.read(nl).decode()
        nd = struct.unpack('<i', f.read(4))[0]
        dims = [struct.unpack('<i', f.read(4))[0] for _ in range(nd)]
        c = 1
        for d in dims:
            c *= d
        D[name] = np.frombuffer(f.read(4 * c), dtype='<f4').reshape(dims).copy()
    return D


M = L.load(sys.argv[1], verbose=False)
D = read_ref(sys.argv[2])
n = M['trunk']['blocks'][0]['q']['norm']
C = n['c']
x = D['blocks.0.normactconvq.norm.input'].reshape(361, C).astype(np.float64)
y = D['blocks.0.normactconvq.norm'].reshape(361, C).astype(np.float64)
sc = np.asarray(n['scale'], dtype=np.float64)
bi = np.asarray(n['bias'], dtype=np.float64)

# 反解每通道的仿射： y = x*A + B
A = np.zeros(C); B = np.zeros(C)
for c in range(C):
    xc = x[:, c]; yc = y[:, c]
    A[c], B[c] = np.polyfit(xc, yc, 1)
print('反解 A 统计: min=%.5f max=%.5f mean=%.5f' % (A.min(), A.max(), A.mean()))
print('反解 B 统计: min=%.5f max=%.5f mean=%.5f' % (B.min(), B.max(), B.mean()))
print('  A[:6]=', np.round(A[:6], 5).tolist())
print('  sc[:6]=', np.round(sc[:6], 5).tolist())
print('  bi[:6]=', np.round(bi[:6], 5).tolist())
print('  B[:6]=', np.round(B[:6], 5).tolist())
print()
print('|A - sc|max = %.5f' % np.abs(A - sc).max())
print('|B - bi|max = %.5f' % np.abs(B - bi).max())
print()
# 残差：仿射假设是否成立
fit = x * A + B
print('仿射拟合残差 max = %.6e' % np.abs(y - fit).max())

# 逐位置 RMS 归一化的检验： y/RMS(x) 与 x 的关系
r = np.sqrt((x ** 2).mean(axis=1, keepdims=True))
xA = x / r
A2 = np.zeros(C); B2 = np.zeros(C)
for c in range(C):
    A2[c], B2[c] = np.polyfit(xA[:, c], y[:, c], 1)
print()
print('按 RMS 归一化后反解: |A2 - sc|max=%.5f  |B2 - bi|max=%.5f'
      % (np.abs(A2 - sc).max(), np.abs(B2 - bi).max()))
print('  仿射(RMS归一化)残差 max = %.6e' % np.abs(y - (xA * A2 + B2)).max())
