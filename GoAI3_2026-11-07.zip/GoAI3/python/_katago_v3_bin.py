# -*- coding: utf-8 -*-
"""KataGo v3 @BIN@ 块计数与框架判定（纯标准库，只读）。

判据：文件里每个数据块都以 @BIN@ 结尾前缀。若 @BIN@ 恰好出现
numComponents 次，则整个文件就是 numComponents 个同构块，
第一个块（头部块）只是字段更多而已 —— 框架即确定。

用法: python _katago_v3_bin.py <file.bin.gz>
"""
import sys, gzip, struct

try:
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
except Exception:
    pass

NAME_CHARS = set('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_.-')


def is_name_tok(s):
    return bool(s) and s[0] not in '0123456789' and all(c in NAME_CHARS for c in s)


def main():
    path = sys.argv[1]
    with gzip.open(path, 'rb') as g:
        data = g.read()
    total = len(data)

    n_bin = data.count(b'@BIN@')
    print('@BIN@ occurrences : %d' % n_bin)

    # 头三行
    pos = 0
    nl = data.index(b'\n', pos); magic = data[pos:nl].decode('utf-8'); pos = nl + 1
    nl = data.index(b'\n', pos); magic_size = int(data[pos:nl]); pos = nl + 1
    nl = data.index(b'\n', pos); num_components = int(data[pos:nl]); pos = nl + 1
    print('magic=%s magicSize=%d numComponents=%d  (header ends at offset %d)'
          % (magic, magic_size, num_components, pos))

    # --- 通用块解析器：块 = 名字, ndim, dims..., @BIN@, data ---
    # 头部块内除数值行外还夹着"子块名"(如 trunk / model)，子块名之后跟着的
    # 数字是它的维度；因此这里对每一行做贪心判定。
    print('\n--- line-by-line token walk from offset %d ---' % pos)
    p = pos
    line_i = data[:pos].count(b'\n')
    while p < total:
        nl = data.find(b'\n', p)
        if nl < 0:
            print('  (EOF without newline at %d)' % p)
            break
        tok = data[p:nl].decode('utf-8', 'replace')
        if data[nl + 1:nl + 6] == b'@BIN@':
            kind = 'BIN-DIMS-LAST'      # 本行是维度，下一行就是 @BIN@
        elif is_name_tok(tok):
            kind = 'NAME'
        else:
            kind = 'NUM'
        if line_i < 60:
            print('  line %3d off %8d  %-6s  %s' % (line_i, p, kind, tok[:80]))
        p = nl + 1
        line_i += 1
        if line_i > 200:
            print('  ... (truncated)')
            break

    # --- 穷举：从某个偏移开始的块序列能否精确闭合 ---
    print('\n--- closure search over start offsets that follow a newline ---')
    print('(每块: 名字, ndim行, ndim个维度行, @BIN@, 4*prod(dims)字节)')
    best = []
    # 候选起点：头部行之后的所有行首位置
    cands = []
    q = pos
    while q < min(total, pos + 400):
        cands.append(q)
        nl = data.find(b'\n', q)
        if nl < 0:
            break
        q = nl + 1
    for start in cands:
        comps = []
        q = start
        ok = True
        while q < total:
            nl = data.find(b'\n', q)
            if nl < 0:
                ok = False; break
            name = data[q:nl].decode('utf-8', 'replace')
            if not is_name_tok(name):
                ok = False; break
            q = nl + 1
            nl = data.find(b'\n', q)
            if nl < 0:
                ok = False; break
            try:
                ndim = int(data[q:nl])
            except ValueError:
                ok = False; break
            if ndim < 0 or ndim > 8:
                ok = False; break
            q = nl + 1
            dims = []
            good = True
            for _ in range(ndim):
                nl = data.find(b'\n', q)
                if nl < 0:
                    good = False; break
                try:
                    dims.append(int(data[q:nl]))
                except ValueError:
                    good = False; break
                q = nl + 1
            if not good:
                ok = False; break
            if data[q:q + 5] != b'@BIN@':
                ok = False; break
            q += 5
            n = 1
            for d in dims:
                n *= d
            if q + 4 * n > total:
                ok = False; break
            q += 4 * n
            comps.append((name, dims, n))
        if ok and q == total:
            best.append((start, comps))
            print('  CLOSED at start offset %d : %d components  <===' % (start, len(comps)))

    if not best:
        print('  no closed parse found')
        return 1

    for start, comps in best:
        print('\n' + '=' * 100)
        print('CLOSED SOLUTION, start offset %d, %d components' % (start, len(comps)))
        print('=' * 100)
        print('%-4s %-42s %-26s %10s' % ('#', 'name', 'dims', 'floats'))
        print('-' * 100)
        for i, (name, dims, n) in enumerate(comps):
            print('%-4d %-42s %-26s %10d' % (i, name, str(dims), n))
        tf = sum(c[2] for c in comps)
        print('-' * 100)
        print('total floats %d (%.1f MB)' % (tf, tf * 4 / 1048576.0))
    return 0


if __name__ == '__main__':
    sys.exit(main())
