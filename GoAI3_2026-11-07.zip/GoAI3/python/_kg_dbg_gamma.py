# -*- coding: utf-8 -*-
"""验证：文件里的 scale 是否就是 fixup 的 gamma。

p 分支(fixup_use_gamma=False) → gamma=None → y = x + beta   （scale 是常量占位，无用）
q 分支(fixup_use_gamma=True)  → gamma 存在 → y = x * gamma + beta
                               文件用 scale*gamma 写在 has_scale 槽位里
                               （这是导出侧与运行侧不一致的地方）
"""
import struct, sys
import numpy as np
sys.stdout.reconfigure(encoding='utf-8', errors='replace')
sys.path.insert(0, '.')
import _katago_v17_load as L


def read_ref(path):
    f = open(path, 'rb')
    assert f.read(8) == b'KGREF001'
    n = struct.unpack('<i', f.read(4))[0]
    D = {}
    for _ in range(n):
        nl = struct.unpack('<i', f.read(4))[0]
        name = f.read(nl).decode()
        nd = struct.unpack('<i', f.read(4))[0]
        dims = [struct.unpack('<i', f.read(4))[0] for _ in range(nd)]
        c = 1
        for d in dims:
            c *= d
        D[name] = np.frombuffer(f.read(4 * c), dtype='<f4').reshape(dims).copy()
    return D


M = L.load(sys.argv[1], verbose=False)
D = read_ref(sys.argv[2])
b0 = M['trunk']['blocks'][0]

for branch, has_gamma in (('p', False), ('q', True)):
    n = b0[branch]['norm']
    sc = np.asarray(n['scale'], dtype=np.float64)
    bi = np.asarray(n['bias'], dtype=np.float64)
    x = D['blocks.0.normactconv%s.norm.input' % branch].reshape(361, n['c']).astype(np.float64)
    y = D['blocks.0.normactconv%s.norm' % branch].reshape(361, n['c']).astype(np.float64)
    print('=== %s 分支 (has_gamma=%s) ===' % (branch, has_gamma))
    print('  scale[:4]=', np.round(sc[:4], 6).tolist())
    print('  bias [:4]=', np.round(bi[:4], 6).tolist())
    if has_gamma:
        cand = {
            'x*scale+bias': x * sc + bi,
            'x+bias': x + bi,
            'x*scale': x * sc,
        }
    else:
        cand = {
            'x+bias': x + bi,
            'x*scale+bias': x * sc + bi,
        }
    for k, v in cand.items():
        print('  %-16s maxdiff=%.6e' % (k, np.abs(y - v).max()))
    print('  参考 y[0,:4] =', np.round(y[0, :4], 6).tolist())
    print()
