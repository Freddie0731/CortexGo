# -*- coding: utf-8 -*-
"""KataGo v3 头部长度穷举求解器（纯标准库，只读）。

思路：头部是「纯数值块」，随后是自描述组件表
    name \\n ndim \\n dims... \\n @BIN@ <4*prod(dims) 字节>
组件表必须**精确占满**整个解压后的文件（余 0 字节），这是极强的判据。
对每个候选头部值个数 H，从该处开始解析组件表，看是否恰好闭合。

用法: python _katago_v3_solve.py <file.bin.gz>
"""
import sys, gzip, struct

try:
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
except Exception:
    pass

NAME_CHARS = set('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_.-')
NUM_CHARS = set('0123456789.eE+-')


def is_name(s):
    return bool(s) and s[0] not in '0123456789' and all(c in NAME_CHARS for c in s)


def parse_components(data, pos):
    """从 pos 解析组件表，返回 (comps, endpos, err)。"""
    comps = []
    n_total = len(data)
    while pos < n_total:
        nl = data.find(b'\n', pos)
        if nl < 0:
            return comps, pos, 'no newline for component name'
        name = data[pos:nl].decode('utf-8', 'replace')
        if not is_name(name):
            return comps, pos, 'bad component name %r at %d' % (name[:40], pos)
        pos = nl + 1
        nl = data.find(b'\n', pos)
        if nl < 0:
            return comps, pos, 'no ndim line'
        try:
            ndim = int(data[pos:nl])
        except ValueError:
            return comps, pos, 'bad ndim %r for %s' % (data[pos:nl][:20], name)
        if ndim < 0 or ndim > 8:
            return comps, pos, 'ndim out of range %d for %s' % (ndim, name)
        pos = nl + 1
        dims = []
        for _ in range(ndim):
            nl = data.find(b'\n', pos)
            if nl < 0:
                return comps, pos, 'no dim line'
            try:
                dims.append(int(data[pos:nl]))
            except ValueError:
                return comps, pos, 'bad dim %r for %s' % (data[pos:nl][:20], name)
            pos = nl + 1
        if data[pos:pos + 5] != b'@BIN@':
            return comps, pos, '%s: missing @BIN@ at %d (saw %r)' % (name, pos, data[pos:pos + 12])
        pos += 5
        n = 1
        for d in dims:
            n *= d
        if pos + 4 * n > n_total:
            return comps, pos, '%s: payload overruns file (%d floats)' % (name, n)
        pos += 4 * n
        comps.append((name, dims, n))
    return comps, pos, None


def main():
    path = sys.argv[1]
    with gzip.open(path, 'rb') as g:
        data = g.read()
    total = len(data)

    pos = 0
    nl = data.index(b'\n', pos); magic = data[pos:nl].decode('utf-8'); pos = nl + 1
    nl = data.index(b'\n', pos); magic_size = int(data[pos:nl]); pos = nl + 1
    nl = data.index(b'\n', pos); num_components = int(data[pos:nl]); pos = nl + 1
    print('magic=%s  magicSize=%d  numComponents=%d' % (magic, magic_size, num_components))
    print('file size = %d bytes\n' % total)

    # 头部数值块：从 pos 开始，每个值一行，直到出现第一个"像组件名"的行
    hdr_vals = []
    p = pos
    hdr_end_after = None
    while True:
        nl = data.find(b'\n', p)
        if nl < 0:
            break
        tok = data[p:nl].decode('utf-8', 'replace')
        if not all(c in NUM_CHARS for c in tok) or not tok:
            print('first non-numeric line %r at offset %d (byte %d)' % (tok, p, p))
            hdr_end_after = p
            break
        hdr_vals.append(tok)
        p = nl + 1
    print('numeric header values seen: %d -> %s' % (len(hdr_vals), hdr_vals))

    print('\n--- brute force: which header length yields a closed component table? ---')
    solves = []
    for h in range(0, len(hdr_vals) + 1):
        # 计算跳过前 h 个数值行后的字节位置
        p2 = pos
        for _ in range(h):
            p2 = data.find(b'\n', p2) + 1
        comps, end, err = parse_components(data, p2)
        closed = (end == total and err is None)
        ncomp_ok = (len(comps) == num_components)
        mark = ''
        if closed:
            mark = '  <== CLOSED'
            if ncomp_ok:
                mark += ' and count==numComponents'
            solves.append((h, comps))
        print('  H=%2d (offset %6d): comps=%3d end=%9d left=%6d %s%s'
              % (h, p2, len(comps), end, total - end,
                 ('COMPONENTS==%d ' % num_components) if ncomp_ok else '',
                 mark if closed else ('err=%s' % err if err else '')))

    if not solves:
        print('\nno closed solution found')
        return 1

    for h, comps in solves:
        print('\n' + '=' * 96)
        print('SOLUTION H=%d : %d components' % (h, len(comps)))
        print('=' * 96)
        print('%-4s %-40s %-26s %10s' % ('#', 'name', 'dims', 'floats'))
        print('-' * 96)
        for i, (name, dims, n) in enumerate(comps):
            print('%-4d %-40s %-26s %10d' % (i, name, str(dims), n))
        print('-' * 96)
        tf = sum(c[2] for c in comps)
        print('total floats: %d (%.1f MB)' % (tf, tf * 4 / 1048576.0))
    return 0


if __name__ == '__main__':
    sys.exit(main())
