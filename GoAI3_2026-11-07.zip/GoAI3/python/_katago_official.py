# -*- coding: utf-8 -*-
"""在独立脚本里加载 KataGo 官方 model_pytorch.py 的工具。

官方文件用相对导入 `from ..train import modelconfigs`，且依赖 `packaging`（本机没装）。
这里用 sys.modules 合成包层级 + 给 packaging 打桩，从而在不安装任何依赖的前提下
直接复用官方模型定义。
"""
import sys, os, types

SRC = os.path.join(os.path.dirname(os.path.abspath(__file__)), '_katago_src')


def _stub_fused():
    """关闭 KataGo 的 Triton 融合内核，走纯 PyTorch 回退路径。

    model_pytorch.py 用 env_flag 读取两个开关（默认 True）：
      KATAGO_FUSED_SWIGLU_KERNEL  -> 为 0 时不 import .fused_swiglu
      KATAGO_FUSED_ROPE_BACKWARD  -> 为 0 时不 import .fused_rope
    本机无 triton，所以必须先关掉这两个开关再加载 model_pytorch。
    """
    os.environ['KATAGO_FUSED_SWIGLU_KERNEL'] = '0'
    os.environ['KATAGO_FUSED_ROPE_BACKWARD'] = '0'


def _stub_packaging():
    if 'packaging' in sys.modules:
        return
    pkg = types.ModuleType('packaging')
    ver = types.ModuleType('packaging.version')

    class Version(object):
        def __init__(self, s):
            self.s = str(s)
            parts = []
            for p in self.s.split('.'):
                num = ''
                for ch in p:
                    if ch.isdigit():
                        num += ch
                    else:
                        break
                parts.append(int(num) if num else 0)
            self.parts = tuple(parts)

        def _cmp(self, o):
            a, b = self.parts, Version(o).parts
            n = max(len(a), len(b))
            a = a + (0,) * (n - len(a))
            b = b + (0,) * (n - len(b))
            return (a > b) - (a < b)

        def __eq__(self, o): return self._cmp(o) == 0
        def __lt__(self, o): return self._cmp(o) < 0
        def __le__(self, o): return self._cmp(o) <= 0
        def __gt__(self, o): return self._cmp(o) > 0
        def __ge__(self, o): return self._cmp(o) >= 0
        def __repr__(self): return 'Version(%r)' % self.s

    ver.Version = Version
    ver.parse = Version
    pkg.version = ver
    sys.modules['packaging'] = pkg
    sys.modules['packaging.version'] = ver


def _mkpkg(name):
    m = types.ModuleType(name)
    m.__path__ = [SRC]
    sys.modules[name] = m
    return m


def _load(modname, filename):
    path = os.path.join(SRC, filename)
    with open(path, 'r', encoding='utf-8') as f:
        src = f.read()
    mod = types.ModuleType(modname)
    mod.__file__ = path
    sys.modules[modname] = mod
    exec(compile(src, path, 'exec'), mod.__dict__)
    return mod


def load_official():
    """返回 (Model, modelconfigs)。"""
    _stub_packaging()
    _mkpkg('katago')
    train = _mkpkg('katago.train')
    _stub_fused()
    mc = _load('katago.train.modelconfigs', 'modelconfigs.py')
    train.modelconfigs = mc
    th = _load('katago.train.trainloop_helpers', 'trainloop_helpers.py')
    train.trainloop_helpers = th
    mp = _load('katago.train.model_pytorch', 'model_pytorch.py')
    return mp.Model, mc


if __name__ == '__main__':
    Model, mc = load_official()
    print('loaded official Model:', Model)
    cfg = mc.config_of_name['b11c768h12nbt3tflrs']
    print('config version=%s norm_kind=%s blocks=%d ffn=%s heads=%s' % (
        cfg['version'], cfg['norm_kind'], len(cfg['block_kind']),
        cfg.get('transformer_ffn_channels'), cfg.get('transformer_heads')))
