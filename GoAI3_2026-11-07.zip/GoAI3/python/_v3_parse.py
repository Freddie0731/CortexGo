# -*- coding: utf-8 -*-
"""KataGo v3 (.bin.gz) 完整流式解析 + 闭合校验  —— 纯标准库，只读。

已由字节级侦察确定的格式（KataGo modelversion 3 / tf3）:

    行: <name>
    行: <numParams>
    行: <numComponents>
    行: <numParams 个模型参数值>
    行: <trunk 名>
    行: <trunk 参数个数>
    行: <trunk 参数值...>
    然后 numComponents 个权重块, 每块:
    行: <张量名>
    行: <ndim>
    行: <dim_1> ... <dim_ndim>
        "@BIN@"              <- 5 字节, 紧跟最后一个维度行的 \n 之后
        <prod(dims) 个 float32 小端>

头部声明了 numComponents 才算通过; 全部字节被吃掉才算闭合。
可选 --dump <path> 导出 JSON 清单。

用法:
    python _v3_parse.py <file.bin.gz> [--dump catalog.json] [--limit-components N]
"""
import sys, gzip, struct, json

try:
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
except Exception:
    pass

BIN = b'@BIN@'


class Reader:
    """对 gzip 流做只读顺序访问，保留小回看缓冲以读文本行。"""

    def __init__(self, fp, chunk=1 << 20):
        self.fp = fp
        self.buf = b''
        self.pos = 0          # 已从 buf 头部丢弃的字节数（全局偏移）
        self.eof = False
        self.chunk = chunk

    def _fill(self):
        if self.eof:
            return False
        d = self.fp.read(self.chunk)
        if not d:
            self.eof = True
            return False
        self.buf += d
        return True

    def read_line(self):
        """读到并含 \n，返回不含 \n 的 bytes；EOF 返回 None。"""
        while True:
            i = self.buf.find(b'\n')
            if i >= 0:
                line = self.buf[:i]
                self.buf = self.buf[i + 1:]
                self.pos += i + 1
                return line
            if not self._fill():
                if self.buf:
                    line = self.buf
                    self.pos += len(self.buf)
                    self.buf = b''
                    return line
                return None

    def read_exact(self, n):
        while len(self.buf) < n:
            if not self._fill():
                return None
        out = self.buf[:n]
        self.buf = self.buf[n:]
        self.pos += n
        return out

    def peek(self, n):
        while len(self.buf) < n:
            if not self._fill():
                break
        return self.buf[:n]

    def skip(self, n):
        return self.read_exact(n) is not None


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        return 2
    path = sys.argv[1]
    dump = None
    if '--dump' in sys.argv:
        dump = sys.argv[sys.argv.index('--dump') + 1]

    r = Reader(gzip.open(path, 'rb'))

    print('=' * 84)
    print('HEADER')
    print('=' * 84)
    name = r.read_line().decode('utf-8')
    num_params = int(r.read_line())
    num_components = int(r.read_line())
    print('name            : %s' % name)
    print('numParams       : %d' % num_params)
    print('numComponents   : %d' % num_components)
    print('header lines end at byte %d' % r.pos)

    params = [float(r.read_line()) for _ in range(num_params)]
    print('\nmodel params (idx: value):')
    for i, v in enumerate(params):
        print('  [%2d] %g' % (i, v))

    torso_name = r.read_line().decode('utf-8')
    n_torso = int(r.read_line())
    torso = [float(r.read_line()) for _ in range(n_torso)]
    print('\ntrunk           : %s' % torso_name)
    print('trunk params    : %d -> %s' % (n_torso, [('%g' % v) for v in torso]))

    # ---------- 权重块 ----------
    print()
    print('=' * 84)
    print('WEIGHT COMPONENTS (expected %d)' % num_components)
    print('=' * 84)
    print('%-4s %-46s %-24s %12s' % ('#', 'name', 'dims', 'floats'))
    print('-' * 84)

    comps = []
    ok = True
    for i in range(num_components):
        nm_b = r.read_line()
        if nm_b is None:
            print('!! EOF before component %d' % i)
            ok = False
            break
        nm = nm_b.decode('utf-8', 'replace')
        nd_b = r.read_line()
        try:
            nd = int(nd_b)
        except Exception:
            print('!! component %d (%s): bad ndim %r' % (i, nm, nd_b))
            ok = False
            break
        dims = []
        for _ in range(nd):
            dims.append(int(r.read_line()))
        marker = r.read_exact(len(BIN))
        if marker != BIN:
            print('!! component %d (%s): expected @BIN@, got %r' % (i, nm, marker))
            ok = False
            break
        n = 1
        for d in dims:
            n *= d
        byte_len = 4 * n
        if not r.skip(byte_len):
            print('!! component %d (%s): truncated data (wanted %d bytes)' % (i, nm, byte_len))
            ok = False
            break
        comps.append({'name': nm, 'dims': dims, 'floats': n})
        print('%-4d %-46s %-24s %12d' % (i, nm, str(dims), n))

    total = sum(c['floats'] for c in comps)
    print('-' * 84)
    print('components parsed : %d / %d' % (len(comps), num_components))
    print('total floats      : %d  (%.1f MB as float32)' % (total, total * 4 / 1048576.0))

    # ---------- 闭合校验 ----------
    print()
    print('=' * 84)
    print('CLOSURE CHECK')
    print('=' * 84)
    trailing = r.peek(64)
    if trailing:
        print('!! NOT CLOSED: %d+ unexpected bytes remain after last component' % r.pos)
        print('   next bytes: %r' % trailing[:48])
        ok = False
    else:
        print('CLOSED: stream fully consumed at byte %d, no trailing bytes.' % r.pos)
    print('decompressed size : %d bytes (%.2f MB)' % (r.pos, r.pos / 1048576.0))

    # ---------- 自校验: 文件名声称 b11c768 ----------
    print()
    print('=' * 84)
    print('SELF-CHECK against filename claim "b11c768"')
    print('=' * 84)
    names = [c['name'] for c in comps]
    has_768 = any(768 in c['dims'] for c in comps)
    blk_ids = sorted({int(p.split('.')[2]) for nm in names
                      for p in [nm] if nm.startswith('model.blocks.') and p.split('.')[2].isdigit()})
    print('any dim == 768        : %s' % has_768)
    print('distinct block indices: %s' % (blk_ids if blk_ids else 'none'))
    print('block count           : %d   (filename claims 11)' % len(blk_ids))
    print('header-model-param[0] (should be 11)  : %g' % params[0])
    print('trunk params          : %s' % [('%g' % v) for v in torso])
    verdict = (len(comps) == num_components and not trailing
               and has_768 and len(blk_ids) == 11)
    print()
    print('FORMAT VERDICT: %s' % ('VALIDATED' if verdict else 'INCONCLUSIVE'))

    if dump and comps:
        with open(dump, 'w', encoding='utf-8') as f:
            json.dump({'name': name, 'numParams': num_params,
                       'numComponents': num_components, 'params': params,
                       'trunk': torso, 'components': comps},
                      f, indent=1)
        print('catalog written to %s' % dump)

    return 0 if (ok and verdict) else 1


if __name__ == '__main__':
    sys.exit(main())
