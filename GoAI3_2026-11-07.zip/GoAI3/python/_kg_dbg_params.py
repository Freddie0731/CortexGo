# -*- coding: utf-8 -*-
"""对比"文件里的参数"与"官方模型实际使用的参数"。

关键怀疑点：fixup 归一化下，官方 NormMask 用 self.scale（外部 set_scale 设置），
而导出侧在 scale is None 时写的是 scale*ones = 常量。若二者不一致，
则"文件里的 scale"并不等于"模型里的 scale"。

本脚本直接打印模型侧的真实参数，与文件值对照。
"""
import sys, os
import numpy as np
import torch

try:
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
except Exception:
    pass
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
os.environ.setdefault('TORCHDYNAMO_DISABLE', '1')

import _katago_v17_load as L
from _katago_official import load_official
from _kg_ref import build_state_dict


def main():
    wpath = sys.argv[1]
    M = L.load(wpath, verbose=False)
    Model, mc = load_official()
    cfg = mc.config_of_name['b11c768h12nbt3tflrs']
    model = Model(cfg, 19).eval()
    print('=== initialize() 之前 ===')
    print('  blocks[0].normactconvp.norm.scale =', model.blocks[0].normactconvp.norm.scale)
    model.initialize()
    print('=== initialize() 之后 ===')
    print('  blocks[0].normactconvp.norm.scale =', model.blocks[0].normactconvp.norm.scale)
    print('  blocks[0].normactconvq.norm.scale =', model.blocks[0].normactconvq.norm.scale)

    # 灌权重
    sd = build_state_dict(M)
    ref = model.state_dict()
    target = {}
    for k, v in ref.items():
        if k in sd:
            a = np.array(sd[k], dtype=np.float32, copy=True)
            if tuple(a.shape) == tuple(v.shape):
                target[k] = torch.from_numpy(a).clone()
    model.load_state_dict(target, strict=False)

    p = model.blocks[0].normactconvp
    print('=== 模型侧 blocks[0].normactconvp ===')
    print('  norm_kind        =', p.norm.norm_kind)
    print('  is_using_batchnorm =', p.norm.is_using_batchnorm)
    print('  fixup_use_gamma  =', p.norm.fixup_use_gamma)
    print('  use_gamma        =', p.norm.use_gamma)
    print('  scale            =', p.norm.scale)
    print('  gamma            =', None if p.norm.gamma is None else p.norm.gamma.flatten()[:4].tolist())
    print('  beta[:4]         =', p.norm.beta.flatten()[:4].tolist())
    print('  epsilon          =', p.norm.epsilon)
    print('  skip_mask        =', p.norm.skip_mask)

    f = M['trunk']['blocks'][0]['p']['norm']
    print('\n=== 文件里的参数 ===')
    print('  scale[:4] =', np.asarray(f['scale'])[:4].tolist())
    print('  bias[:4]  =', np.asarray(f['bias'])[:4].tolist())
    print('  eps       =', f['eps'])

    # 模型侧 q 分支
    q = model.blocks[0].normactconvq
    print('\n=== 模型侧 blocks[0].normactconvq ===')
    print('  fixup_use_gamma =', q.norm.fixup_use_gamma)
    print('  scale           =', q.norm.scale)
    print('  gamma[:4]       =', None if q.norm.gamma is None else q.norm.gamma.flatten()[:4].tolist())

    # 用模型自身的 forward 复算 norm（绕过我的实现）
    print('\n=== 用模型自身模块复算 ===')
    R = None
    import struct
    rpath = sys.argv[2]
    fh = open(rpath, 'rb')
    assert fh.read(8) == b'KGREF001'
    n = struct.unpack('<i', fh.read(4))[0]
    for _ in range(n):
        nl = struct.unpack('<i', fh.read(4))[0]
        name = fh.read(nl).decode()
        nd = struct.unpack('<i', fh.read(4))[0]
        dims = [struct.unpack('<i', fh.read(4))[0] for _ in range(nd)]
        cnt = 1
        for d in dims:
            cnt *= d
        arr = np.frombuffer(fh.read(4 * cnt), dtype='<f4').reshape(dims)
        if name == 'input.spatial':
            inp = torch.from_numpy(arr.astype(np.float32).copy())
    with torch.no_grad():
        embed = model.conv_spatial(inp) + model.linear_global(
            torch.from_numpy(np.zeros((1, 19), dtype=np.float32))).reshape(1, -1, 1, 1)
        # 上面故意只算 conv 部分（global 置零），先看 conv
        mask = torch.ones(1, 1, 19, 19)
        msum = mask.sum()
        y = p.norm(embed, mask=mask, mask_sum_hw=msum, mask_sum=msum)
        print('  模型自己算的 norm(conv only)[0,:4,0,0] =', y[0, :4, 0, 0].tolist())
        # 手算 x*scale+bias
        sc = p.norm.scale
        if sc is not None:
            man = embed * sc.reshape(1, -1, 1, 1) + p.norm.beta
            print('  手算 x*scale+beta[0,:4,0,0]          =', man[0, :4, 0, 0].tolist())
        else:
            man = embed + p.norm.beta
            print('  手算 x+beta[0,:4,0,0]                =', man[0, :4, 0, 0].tolist())


if __name__ == '__main__':
    main()
