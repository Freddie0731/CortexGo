# -*- coding: utf-8 -*-
"""测试 Batchnorm 变体（-bng / -brng）：它们才带逐通道 gamma。

.bin.gz 的 scale 槽位里有负值（如 -0.000074），说明它是**学出来的**逐通道参数，
不可能是 fixup/fixscale 的常量归一化系数。带 gamma 的只有 batchnorm 变体。
这里用"零统计量"策略初始化 BN（running_mean=0, running_std=1），
避免官方 initialize() 在 BN 上的额外约束。
"""
import sys, os
import numpy as np
import torch
sys.stdout.reconfigure(encoding='utf-8', errors='replace')
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
os.environ.setdefault('TORCHDYNAMO_DISABLE', '1')

import _katago_v17_load as L
from _katago_official import load_official
from _kg_ref import build_state_dict
from _kg_enc import GoBoard, encode, BLACK

M = L.load(sys.argv[1], verbose=False)
Model, mc = load_official()
sd = build_state_dict(M)

b = GoBoard()
sp, gl = encode(b, [], BLACK)
sp_t = torch.from_numpy(sp)
gl_t = torch.from_numpy(gl)

base = 'b11c768h12nbt3tflrs'
cands = [base + '-bng', base + '-bng-silu', base + '-brng', base + '-brng-silu',
         base + '-bn', base + '-bn-silu', base + '-fbrng', base + '-fbrng-silu']

print('%-24s %10s %10s %9s %9s  %s' % ('config', 'pass', 'boardMax', 'val[0]', 'ownSum', 'note'))
for name in cands:
    if name not in mc.config_of_name:
        print('%-24s (不存在)' % name)
        continue
    try:
        m = Model(mc.config_of_name[name], 19).eval()
        # 手动初始化 BN 统计量，避免 initialize() 的约束
        for mod in m.modules():
            if hasattr(mod, 'running_mean') and hasattr(mod, 'running_std'):
                with torch.no_grad():
                    mod.running_mean.zero_()
                    mod.running_std.fill_(1.0)
        t = {}
        for k, v in m.state_dict().items():
            if k in sd:
                a = np.array(sd[k], dtype=np.float32, copy=True)
                if tuple(a.shape) == tuple(v.shape):
                    t[k] = torch.from_numpy(a).clone()
        m.load_state_dict(t, strict=False)
        with torch.no_grad():
            r = m._forward_per_block_units(sp_t, gl_t)
        h = r[0]
        pol = h[0].numpy().reshape(6, 362)[0]
        val = h[1].numpy().reshape(3)
        own = h[4].numpy().reshape(-1)
        note = 'NaN!' if not np.isfinite(pol).all() else ''
        print('%-24s %+10.3f %+10.3f %+9.2f %+9.1f  %s'
              % (name, pol[361], pol[:361].max(), val[0], own.sum(), note))
    except Exception as e:
        print('%-24s 失败: %s' % (name, str(e)[:70]))
