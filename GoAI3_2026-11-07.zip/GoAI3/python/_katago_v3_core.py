# -*- coding: utf-8 -*-
"""KataGo v3 核心机制发现（纯标准库，只读）。

已证实的规则：
  张量块 := <块名>\n<字段数 n>\n<n 个字段行>\n@BIN@<4*prod(dims) 字节>
  字段行可为 int（维度、groups）或 float（如 1e-20 = Epsilon）
  容器块 := <块名>\n<n>\n<n 个子项行>\n<子项1 的完整定义><子项2 ...>
  （容器块没有 @BIN@，其字段行是子块名，形如 model.blocks.0）

本脚本从文件头部开始，逐块打印偏移与名字，并给出每个块的"边界证据"。

用法: python _katago_v3_core.py <file.bin.gz> [--to OFFSET]
"""
import sys, gzip

try:
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
except Exception:
    pass


def main():
    path = sys.argv[1]
    stop_at = int(sys.argv[sys.argv.index('--to') + 1]) if '--to' in sys.argv else 700000
    with gzip.open(path, 'rb') as g:
        data = g.read()
    total = len(data)
    print('file size %d' % total)

    # 打印 [0, stop_at) 里所有"整行可打印 ASCII"的行，带偏移
    print('\n--- printable lines in [0, %d) ---' % stop_at)
    pos = 0
    shown = 0
    while pos < min(stop_at, total):
        nl = data.find(b'\n', pos)
        if nl < 0:
            break
        seg = data[pos:nl]
        printable = all(32 < b < 127 for b in seg)
        if printable:
            print('  %9d  %s' % (pos, seg.decode('ascii')))
            shown += 1
        else:
            # 若这一行以 @BIN@ 开头则特别标注
            if seg.startswith(b'@BIN@'):
                print('  %9d  @BIN@ + %d bytes binary' % (pos, len(seg) - 5))
            else:
                print('  %9d  <binary %d bytes> %s' % (pos, len(seg), seg[:16].hex()))
        pos = nl + 1
        if shown > 400:
            print('  ... (stopped after 400 printable lines)')
            break

    print('\n--- lines just before/after key offsets ---')
    for anchor in (100, 139, 202930, 608435, 666836, 679284):
        print('  anchor %d:' % anchor)
        p = anchor
        for _ in range(3):
            nl = data.find(b'\n', p)
            if nl < 0:
                break
            seg = data[p:nl]
            pr = all(32 < b < 127 for b in seg)
            print('    %9d  %s' % (p, seg.decode('ascii') if pr else '<bin %d>' % len(seg)))
            p = nl + 1
    return 0


if __name__ == '__main__':
    sys.exit(main())
