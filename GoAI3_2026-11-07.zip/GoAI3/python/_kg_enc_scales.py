# -*- coding: utf-8 -*-
"""确认文件里的 scale 在 fixscale 语义下到底是什么。

fixscale 分支： NormActConv.initialize(scale=1.0, norm_scale=fixup_scale)
    -> norm.set_scale(norm_scale)   # 标量！
    -> apply_gamma_beta_scale_mask: y = x * self.scale + beta   （gamma 为 None）
导出侧 write_bn： scale is not None 且 gamma is None
    -> write_weights(normmask.scale * ones)
所以文件里的每个"scale 数组"应当是**常量**（等于 norm_scale）。

本脚本统计各层的 scale 是否为常量，并推算各层应有的 norm_scale，
从而反推 num_total_blocks 与配置。
"""
import sys
import numpy as np
sys.stdout.reconfigure(encoding='utf-8', errors='replace')
sys.path.insert(0, '.')
import _katago_v17_load as L

M = L.load(sys.argv[1], verbose=False)
tr = M['trunk']

def stat(tag, n):
    sc = n.get('scale')
    if sc is None:
        print('  %-34s (无 scale)' % tag)
        return None
    a = np.asarray(sc, dtype=np.float64)
    const = float(np.abs(a - a[0]).max()) < 1e-6
    print('  %-34s n=%-4d const=%-5s min=%+.6f max=%+.6f  首值=%+.6f'
          % (tag, a.size, const, a.min(), a.max(), a[0]))
    return a[0] if const else None

print('=== fixscale 语义下，各层的 scale 应为常量 ===')
vals = {}
vals['trunkTipNorm'] = stat('trunkTipNorm (期望 1/sqrt(B+1))', tr['trunkTipNorm'])
for i in (0, 1, 5, 10):
    b = tr['blocks'][i]
    vals['b%d_p' % i] = stat('blocks.%d.normactconvp' % i, b['p']['norm'])
    vals['b%d_q' % i] = stat('blocks.%d.normactconvq' % i, b['q']['norm'])

print()
print('=== 由 trunkTipNorm 反推 num_total_blocks ===')
v = vals.get('trunkTipNorm')
if v is not None and v > 0:
    # norm_scale = 1/sqrt(B+1)
    B = 1.0 / (v * v) - 1.0
    print('  1/sqrt(B+1) = %.6f  =>  B ≈ %.4f' % (v, B))

print()
print('=== 由 blocks.0.normactconvp 反推 ===')
v0 = vals.get('b0_p')
if v0 is not None and v0 > 0:
    # norm_scale = fixup_scale^(1/(1+L))，L 为 internal_length
    print('  blocks.0.normactconvp scale = %.6f' % v0)
    L0 = tr['blocks'][0]['internal_length']
    bb = 1.0 / (v0 ** (1.0 + L0))
    print('  若 L=%d，则 fixup_scale = %.6f  =>  num_total_blocks ≈ %.4f'
          % (L0, v0 ** (1.0 + L0), 1.0 / (v0 ** (2.0 * (1.0 + L0)))))
