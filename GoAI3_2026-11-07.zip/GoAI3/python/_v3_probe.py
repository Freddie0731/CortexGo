# -*- coding: utf-8 -*-
"""KataGo v3 结构侦察 v2 —— 字节级，不预设"按行"。

目的：找出 @BIN@ 标记前面真正的结构。
判据：如果一个块是 "name\nndim\ndims...\n@BIN@\n<float data>"，
      那么紧接 @BIN@ 之后应当是 4*prod(dims) 字节数据，且下一个块名可读。

用法: python _v3_probe.py <file.bin.gz> [max_mb]
"""
import sys, gzip, re

try:
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
except Exception:
    pass


def main():
    path = sys.argv[1]
    max_mb = int(sys.argv[2]) if len(sys.argv) > 2 else 3
    limit = max_mb * 1024 * 1024

    with gzip.open(path, 'rb') as g:
        data = g.read(limit)
    print('read %d bytes (%.2f MB)\n' % (len(data), len(data) / 1048576.0))

    # ---------- 1. 头部原样 ----------
    print('=' * 78)
    print('FIRST 512 BYTES, RAW')
    print('=' * 78)
    head = data[:512]
    for off in range(0, len(head), 64):
        chunk = head[off:off + 64]
        txt = ''.join(chr(c) if 32 <= c < 127 else '.' for c in chunk)
        print('%06d  %s' % (off, txt))
    print()

    print('=' * 78)
    print('FIRST 512 BYTES, HEX')
    print('=' * 78)
    for off in range(0, len(head), 32):
        chunk = head[off:off + 32]
        hx = ' '.join('%02x' % c for c in chunk)
        print('%06d  %s' % (off, hx))
    print()

    # ---------- 2. @BIN@ 标记位置与前后文 ----------
    print('=' * 78)
    print('ALL @BIN@ OCCURRENCES (first 60), with preceding 48 bytes')
    print('=' * 78)
    positions = [m.start() for m in re.finditer(re.escape(b'@BIN@'), data)]
    print('count in first %d MB: %d\n' % (max_mb, len(positions)))
    for i, p in enumerate(positions[:60]):
        pre = data[max(0, p - 48):p]
        pre_txt = pre.decode('utf-8', 'replace').replace('\n', '|')
        print('[%2d] off %8d  BEFORE: %s' % (i, p, pre_txt))

    # ---------- 3. 纯文本前缀长度 ----------
    print()
    print('=' * 78)
    print('LEADING PRINTABLE RUN')
    print('=' * 78)
    n = 0
    while n < len(data) and (32 <= data[n] < 127 or data[n] in (10, 13, 9)):
        n += 1
    print('first non-text byte at offset %d (byte=0x%02x)' % (n, data[n] if n < len(data) else 0))
    print('--- that text region ---')
    print(repr(data[:n].decode('utf-8', 'replace')))
    print()
    print('--- 200 bytes AFTER it (hex) ---')
    after = data[n:n + 200]
    for off in range(0, len(after), 32):
        chunk = after[off:off + 32]
        print('%06d  %s' % (n + off, ' '.join('%02x' % c for c in chunk)))
    return 0


if __name__ == '__main__':
    sys.exit(main())
