# -*- coding: utf-8 -*-
"""
KataGo v3 (.bin.gz) 网络文件侦察器  --  纯标准库，只读，不写任何文件。

目的：在没有 KataGo 源码可查的情况下，先确定 v3 容器的真实字节结构。
自校验依据：文件名 kata1-tf3-b11c768-... 已给出真值
    blocks = 11, trunk channels = 768
若解析结果恰好是 11 与 768，则格式推断被证实。

用法:
    python _katago_v3_recon.py <file.bin.gz> [--dump-strings]
"""
import sys, gzip, struct, io

INT32_MAX = 2 ** 31 - 1


class Reader(object):
    """大端 + varint(LEB128) 读取器，只为侦察用，带边界检查。"""

    def __init__(self, data, pos=0):
        self.d = data
        self.p = pos

    def eof(self):
        return self.p >= len(self.d)

    def left(self):
        return len(self.d) - self.p

    def u8(self):
        if self.p + 1 > len(self.d):
            raise EOFError('u8 at %d' % self.p)
        v = self.d[self.p]
        self.p += 1
        return v

    def i32be(self):
        if self.p + 4 > len(self.d):
            raise EOFError('i32be at %d' % self.p)
        v = struct.unpack_from('>i', self.d, self.p)[0]
        self.p += 4
        return v

    def u32be(self):
        if self.p + 4 > len(self.d):
            raise EOFError('u32be at %d' % self.p)
        v = struct.unpack_from('>I', self.d, self.p)[0]
        self.p += 4
        return v

    def varint(self):
        """LEB128，最多 5 字节（KataGo 的 writeInt32）。"""
        shift = 0
        val = 0
        start = self.p
        while True:
            if self.p >= len(self.d):
                raise EOFError('varint at %d' % start)
            b = self.d[self.p]
            self.p += 1
            val |= (b & 0x7F) << shift
            if not (b & 0x80):
                break
            shift += 7
            if shift > 35:
                raise ValueError('varint too long at %d' % start)
        return val

    def float_le(self):
        if self.p + 4 > len(self.d):
            raise EOFError('float at %d' % self.p)
        v = struct.unpack_from('<f', self.d, self.p)[0]
        self.p += 4
        return v


def peek_varint(data, pos):
    """返回 (value, newpos)，不移动外部状态。"""
    r = Reader(data, pos)
    v = r.varint()
    return v, r.p


def hexdump(data, pos, n):
    chunk = data[pos:pos + n]
    out = []
    for i in range(0, len(chunk), 16):
        row = chunk[i:i + 16]
        hx = ' '.join('%02x' % b for b in row)
        asc = ''.join(chr(b) if 32 <= b < 127 else '.' for b in row)
        out.append('%08x  %-47s  %s' % (pos + i, hx, asc))
    return '\n'.join(out)


def read_metadata_string(raw):
    """v3 元数据以 varint 长度开头的字符串（少数版本可能不含长度字段）。"""
    v, p = peek_varint(raw, 0)
    if v > 0 and p + v <= len(raw):
        s = raw[p:p + v]
        try:
            txt = s.decode('utf-8')
            if all(ch.isprintable() or ch in '\n\r\t' for ch in txt):
                return txt, p, v
        except UnicodeDecodeError:
            pass
    try:
        txt = raw.decode('utf-8')
        if all(ch.isprintable() or ch in '\n\r\t' for ch in txt):
            return txt, 0, len(raw)
    except UnicodeDecodeError:
        pass
    return None, 0, 0


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        return 2
    path = sys.argv[1]
    dump_strings = '--dump-strings' in sys.argv

    print('=' * 78)
    print('FILE : %s' % path)
    import os
    print('SIZE : %d bytes (%.1f MB)' % (os.path.getsize(path), os.path.getsize(path) / 1048576.0))
    print('=' * 78)

    # ---------- 1. gzip 内嵌文件名 ----------
    with open(path, 'rb') as f:
        head = f.read(64)
    flags = head[3]
    if flags & 0x08:  # FNAME
        i = 10
        j = head.index(b'\x00', i)
        print('[gzip] embedded name : %s' % head[i:j].decode('latin-1'))
    print('[gzip] flags=0x%02x mtime=%d' % (flags, struct.unpack_from('<I', head, 4)[0]))

    # ---------- 2. 解压到内存 ----------
    with gzip.open(path, 'rb') as g:
        data = g.read()
    print('[gzip] decompressed  : %d bytes (%.1f MB)' % (len(data), len(data) / 1048576.0))

    print('\n--- first 160 bytes ---')
    print(hexdump(data, 0, 160))

    # ---------- 3. 容器头 ----------
    print('\n--- container header hypotheses ---')
    try:
        be = struct.unpack_from('>i', data, 0)[0]
        le = struct.unpack_from('<i', data, 0)[0]
        print('  as i32 big-endian    : %d' % be)
        print('  as i32 little-endian : %d' % le)
    except Exception as e:
        print('  header read failed: %s' % e)

    pos = 0
    hdr = Reader(data, pos)
    version = hdr.i32be()
    if version <= 0 or version > 1000:
        print('  !! big-endian version looks wrong (%d), trying little-endian' % version)
        version = struct.unpack_from('<i', data, 0)[0]
        hdr = Reader(data, 4)
    print('  model version        : %d' % version)

    hdr2 = hdr.i32be()
    print('  next i32be           : %d' % hdr2)
    hdr3 = hdr.i32be()
    print('  3rd i32be            : %d' % hdr3)

    # 判定 (metadataLen, payloadLen) 的位置
    meta_len = None
    payload_len = None
    meta_off = None
    for cand_meta, cand_payload, off in ((hdr2, hdr3, 12), (hdr3, None, 16)):
        if 0 < cand_meta < len(data):
            probe = data[off:off + min(4096, cand_meta)]
            txt, _, _ = read_metadata_string(probe)
            if txt and ('{' in txt or 'model' in txt.lower()):
                meta_len, payload_len, meta_off = cand_meta, cand_payload, off
                break

    if meta_len is None:
        print('  !! could not locate metadata block; giving up on container parse')
        return 1

    print('\n  --> metadata length  : %d (at offset %d)' % (meta_len, meta_off))
    print('  --> payload length   : %s' % str(payload_len))

    meta_raw = data[meta_off:meta_off + meta_len]
    txt, skip, slen = read_metadata_string(meta_raw)
    print('\n--- metadata (length prefix %d bytes skipped) ---' % skip)
    print(txt)
    if dump_strings:
        print('\n--- raw metadata bytes ---')
        print(hexdump(meta_raw, 0, min(len(meta_raw), 2048)))

    # ---------- 4. 张量流 ----------
    tstart = meta_off + meta_len
    end = len(data)
    if payload_len is not None and 0 < payload_len <= end - tstart:
        end = tstart + payload_len
    print('\n--- tensor stream: %d .. %d (%d bytes) ---' % (tstart, end, end - tstart))
    print(hexdump(data, tstart, 96))

    r = Reader(data, tstart)
    tensors = []
    fmt = None
    try:
        while r.p < end:
            name_len = r.varint()
            if name_len <= 0 or name_len > 300 or r.p + name_len > end:
                raise ValueError('bad name length %d at %d' % (name_len, r.p))
            name = data[r.p:r.p + name_len].decode('ascii')
            r.p += name_len
            ndim = r.varint()
            if ndim < 0 or ndim > 8:
                raise ValueError('bad ndim %d for %s' % (ndim, name))
            dims = [r.varint() for _ in range(ndim)]
            n = 1
            for d in dims:
                n *= d
            if n < 0 or r.p + 4 * n > end:
                raise ValueError('data overflow for %s dims=%s' % (name, dims))
            r.p += 4 * n
            tensors.append((name, dims, n))
            if len(tensors) <= 40 or len(tensors) % 50 == 0:
                print('  [%3d] %-46s %s' % (len(tensors), name, dims))
        fmt = 'varint name / varint ndim / varint dims'
    except Exception as e:
        print('  varint framing failed: %s' % e)
        # 尝试第二种：i32 长度前缀
        r = Reader(data, tstart)
        tensors = []
        try:
            while r.p < end:
                nl = r.i32be()
                if nl <= 0 or nl > 300 or r.p + nl > end:
                    raise ValueError('bad name length %d at %d' % (nl, r.p))
                name = data[r.p:r.p + nl].decode('ascii')
                r.p += nl
                nd = r.i32be()
                if nd < 0 or nd > 8:
                    raise ValueError('bad ndim %d for %s' % (nd, name))
                dims = [r.i32be() for _ in range(nd)]
                n = 1
                for d in dims:
                    n *= d
                if r.p + 4 * n > end:
                    raise ValueError('overflow %s' % name)
                r.p += 4 * n
                tensors.append((name, dims, n))
            fmt = 'i32be name / i32be ndim / i32be dims'
        except Exception as e2:
            print('  i32 framing also failed: %s' % e2)
            return 1

    print('\n  framing style : %s' % fmt)
    print('  tensor count  : %d' % len(tensors))
    print('  stream consumed: %d / %d bytes (trailing %d)' % (r.p - tstart, end - tstart, end - r.p))

    # ---------- 5. 自校验 ----------
    print('\n' + '=' * 78)
    print('SELF-CHECK against filename truth: blocks=11, channels=768')
    print('=' * 78)
    names = [t[0] for t in tensors]
    block_idx = set()
    for nm in names:
        if nm.startswith('block') and '/' in nm:
            head = nm.split('/')[0]
            digits = ''.join(ch for ch in head if ch.isdigit())
            if digits:
                block_idx.add(int(digits))
    print('  residual blocks found : %d  %s' % (len(block_idx), sorted(block_idx)[:15]))

    stems = [t for t in tensors if 'stem' in t[0].lower()]
    for nm, dims, n in stems:
        if len(dims) == 4 and dims[0] > 64:
            print('  stem conv %-28s out_ch=%d  (filename says 768) -> %s'
                  % (nm, dims[0], 'MATCH' if dims[0] == 768 else 'MISMATCH'))

    # 找每次卷积的输入通道，推断 in_ch
    for nm, dims, n in tensors:
        if nm.endswith('conv.weight') and len(dims) == 4:
            print('  first conv seen: %-34s in_ch=%d out_ch=%d' % (nm, dims[1], dims[0]))
            break

    # 策略/价值头
    for nm, dims, n in tensors:
        low = nm.lower()
        if ('policy' in low or 'p1' in low or 'value' in low or 'v1' in low) and len(dims) <= 2:
            print('  head tensor: %-34s %s' % (nm, dims))

    if dump_strings:
        print('\n--- full tensor list ---')
        for i, (nm, dims, n) in enumerate(tensors):
            print('%4d  %-50s %s' % (i, nm, dims))

    return 0


if __name__ == '__main__':
    sys.exit(main())
