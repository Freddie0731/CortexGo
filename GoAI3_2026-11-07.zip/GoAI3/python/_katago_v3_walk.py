# -*- coding: utf-8 -*-
"""KataGo v3 全文件块行走器（纯标准库，只读）。

格式（已由字节转储证实）：
    块 := <名字行> <N行(整数,该块的字段个数)> <N行字段> @BIN@ <4*prod(dims) 字节>
字段行可以是整数，也可以是浮点（如 1e-20 = Epsilon）。
维度 = 字段里 >= 1 的整数（浮点是非维度标量，如 Epsilon）。
嵌套块：字段里出现块名，例如
    nested_bottleneck_block
    model.blocks.0
    6
    model.blocks.0.normactconvp.norm
    768
    1e-20
    1
    1
    @BIN@ ...
其中 nested_bottleneck_block 是"描述符"，其后的 model.blocks.0 / 6 声明该容器含 6 个嵌套块。

用法: python _katago_v3_walk.py <file.bin.gz> [--max N] [--quiet]
"""
import sys, gzip, struct

try:
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
except Exception:
    pass

NAME_START = set('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_')
NAME_BODY = set('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_.-')
NUM_BODY = set('0123456789.eE+-')


def read_line(data, pos):
    nl = data.find(b'\n', pos)
    if nl < 0:
        return None, pos
    return data[pos:nl].decode('utf-8', 'replace'), nl + 1


def is_name(s):
    return bool(s) and s[0] in NAME_START and all(c in NAME_BODY for c in s)


def is_num(s):
    return bool(s) and all(c in NUM_BODY for c in s)


def parse_fields(data, pos, count):
    """读 count 行字段，返回 (fields, newpos)。字段可能是数字或块名。"""
    fields = []
    for _ in range(count):
        line, pos = read_line(data, pos)
        if line is None:
            return None, pos
        fields.append(line)
    return fields, pos


def dims_of(fields):
    """从字段里取维度：整数且 >=1。浮点（含 . e E）不算维度。"""
    dims = []
    for f in fields:
        if is_num(f) and ('.' not in f and 'e' not in f and 'E' not in f):
            try:
                v = int(f)
            except ValueError:
                continue
            if v >= 1:
                dims.append(v)
    return dims


def main():
    path = sys.argv[1]
    max_blocks = 100000
    quiet = '--quiet' in sys.argv
    if '--max' in sys.argv:
        max_blocks = int(sys.argv[sys.argv.index('--max') + 1])

    with gzip.open(path, 'rb') as g:
        data = g.read()
    total = len(data)

    pos = 0
    line, pos = read_line(data, pos)
    magic = line
    line, pos = read_line(data, pos)
    magic_size = int(line)
    line, pos = read_line(data, pos)
    num_components = int(line)
    print('magic=%s magicSize=%d numComponents=%d' % (magic, magic_size, num_components))

    # 第一块：头部块，没有名字？按转储，头部块直接是 N 行数值。
    # 从字节转储看 [45,100) 是 16 行数值，随后是 trunk 块。
    # 所以头部块 = {N=16, 16 个字段}，然后正常块。
    hdr_n_line, pos2 = read_line(data, pos)
    hdr_n = int(hdr_n_line)
    hdr_fields, pos3 = parse_fields(data, pos2, hdr_n)
    print('header block: N=%d fields=%s' % (hdr_n, hdr_fields))
    pos = pos3

    blocks = []
    errors = []
    while pos < total and len(blocks) < max_blocks:
        start = pos
        name, p2 = read_line(data, pos)
        if name is None:
            errors.append('EOF while reading name at %d' % start)
            break
        if not is_name(name):
            errors.append('not a block name at %d: %r' % (start, name[:60]))
            break
        nline, p3 = read_line(data, p2)
        if nline is None or not is_num(nline):
            errors.append('bad field count for %s at %d: %r' % (name, p2, (nline or '')[:40]))
            break
        n = int(nline)
        if n < 0 or n > 40:
            errors.append('field count out of range %d for %s at %d' % (n, name, start))
            break
        fields, p4 = parse_fields(data, p3, n)
        if fields is None:
            errors.append('EOF in fields of %s' % name)
            break
        if data[p4:p4 + 5] != b'@BIN@':
            errors.append('%s: no @BIN@ at %d, saw %r' % (name, p4, data[p4:p4 + 16]))
            break
        p5 = p4 + 5
        dims = dims_of(fields)
        nf = 1
        for d in dims:
            nf *= d
        if p5 + 4 * nf > total:
            errors.append('%s: payload overruns (%d floats from dims %s)' % (name, nf, dims))
            break
        nxt = p5 + 4 * nf
        blocks.append((name, n, fields, dims, nf, start, nxt))
        pos = nxt

    print('\nblocks parsed: %d ; ended at %d / %d (left %d)'
          % (len(blocks), pos, total, total - pos))
    if errors:
        print('FIRST ERROR: %s' % errors[0])

    if not quiet:
        print('\n%-4s %-11s %-46s %-4s %-30s %10s' % ('#', 'offset', 'name', 'N', 'dims', 'floats'))
        print('-' * 116)
        for i, (name, n, fields, dims, nf, start, nxt) in enumerate(blocks):
            if i < 70:
                print('%-4d %-11d %-46s %-4d %-30s %10d'
                      % (i, start, name[:46], n, str(dims)[:30], nf))
        if len(blocks) > 70:
            print('... (%d more)' % (len(blocks) - 70))

    tf = sum(b[4] for b in blocks)
    print('\ntotal floats in parsed blocks: %d (%.1f MB)' % (tf, tf * 4 / 1048576.0))

    # 名字分类统计
    from collections import Counter
    c = Counter()
    for name, n, fields, dims, nf, start, nxt in blocks:
        key = name.split('.')[-1]
        c[key] += 1
    print('\nleaf-name histogram (top 30):')
    for k, v in c.most_common(30):
        print('  %-30s %d' % (k, v))
    return 0


if __name__ == '__main__':
    sys.exit(main())
