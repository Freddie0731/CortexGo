# -*- coding: utf-8 -*-
"""在 -fs-silu 配置下反解 normactconvq 的精确公式。

模型侧 fixscale + fixup_use_gamma=True 时：
    y = x * (gamma * scale) + beta
其中 scale = 1/sqrt(i+1)，gamma 存在文件的 has_scale 槽位。
本脚本用真实输入反解 A、B 并和几种组合对照。
"""
import sys, os
import numpy as np
import torch
sys.stdout.reconfigure(encoding='utf-8', errors='replace')
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
os.environ.setdefault('TORCHDYNAMO_DISABLE', '1')

import _katago_v17_load as L
from _katago_official import load_official
from _kg_ref import build_state_dict
from _kg_enc import GoBoard, encode, BLACK, WHITE

M = L.load(sys.argv[1], verbose=False)
Model, mc = load_official()
m = Model(mc.config_of_name['b11c768h12nbt3tflrs-fs-silu'], 19).eval()
m.initialize()
sd = build_state_dict(M)
t = {}
for k, v in m.state_dict().items():
    if k in sd:
        a = np.array(sd[k], dtype=np.float32, copy=True)
        if tuple(a.shape) == tuple(v.shape):
            t[k] = torch.from_numpy(a).clone()
m.load_state_dict(t, strict=False)

cap = {}
tg = set()
for i in range(3):
    tg.add('blocks.%d.normactconvp.norm' % i)
    tg.add('blocks.%d.normactconvq.norm' % i)
for name, mod in m.named_modules():
    if name in tg:
        def mk(nm):
            def pre(module, inp): cap.setdefault(nm, {})['in'] = inp[0].detach().clone()
            def post(module, inp, out): cap.setdefault(nm, {})['out'] = out.detach().clone()
            return pre, post
        p, q = mk(name)
        mod.register_forward_pre_hook(p)
        mod.register_forward_hook(q)

b = GoBoard()
b.play(3, 3, BLACK); b.play(15, 15, WHITE)
sp, gl = encode(b, [], BLACK)
with torch.no_grad():
    m._forward_per_block_units(torch.from_numpy(sp), torch.from_numpy(gl))


def solve(name):
    c = cap.get(name)
    x = c['in'].numpy().astype(np.float64)
    y = c['out'].numpy().astype(np.float64)
    if x.ndim == 3:
        xs = x.reshape(-1, x.shape[-1]); ys = y.reshape(-1, y.shape[-1])
    else:
        xs = x.reshape(x.shape[1], -1).T; ys = y.reshape(y.shape[1], -1).T
    C = xs.shape[1]
    A = np.zeros(C); B = np.zeros(C)
    for ch in range(C):
        xc, yc = xs[:, ch], ys[:, ch]
        if np.ptp(xc) < 1e-12:
            A[ch] = np.nan; B[ch] = np.nan; continue
        A[ch], B[ch] = np.polyfit(xc, yc, 1)
    ok = ~np.isnan(A)
    return A, B, ok


for i in range(3):
    for br in ('p', 'q'):
        name = 'blocks.%d.normactconv%s.norm' % (i, br)
        A, B, ok = solve(name)
        n = M['trunk']['blocks'][i][br]['norm']
        sc = np.asarray(n['scale'], dtype=np.float64)
        bi = np.asarray(n['bias'], dtype=np.float64)
        k = 1.0 / np.sqrt(i + 1)
        useGamma = (br == 'q')
        if useGamma:
            pred = k * sc
        else:
            pred = np.full_like(sc, k)
        dA = np.nanmax(np.abs(A[ok] - pred[ok]))
        dB = np.nanmax(np.abs(B[ok] - bi[ok]))
        print('%-30s A常数=%-5s  与预测(k*gamma)差=%.3e  B与beta差=%.3e'
              % (name, 'YES' if np.nanstd(A[ok]) < 1e-6 else 'no', dA, dB))
        print('    A[:4]=%s' % np.round(A[:4], 6).tolist())
        print('    k*sc[:4]=%s  (k=%.6f)' % (np.round((k * sc)[:4], 6).tolist(), k))
        print('    B[:4]=%s  beta[:4]=%s'
              % (np.round(B[:4], 6).tolist(), np.round(bi[:4], 6).tolist()))
