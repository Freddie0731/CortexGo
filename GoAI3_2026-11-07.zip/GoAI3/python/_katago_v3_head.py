# -*- coding: utf-8 -*-
"""KataGo v3 头部原样转储 + 组件清单（纯标准库，只读）。

用法: python _katago_v3_head.py <file.bin.gz> [nbytes]
"""
import sys, gzip

try:
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
except Exception:
    pass


def main():
    path = sys.argv[1]
    n = int(sys.argv[2]) if len(sys.argv) > 2 else 1400
    with gzip.open(path, 'rb') as g:
        data = g.read(n + 64)
    txt = data[:n].decode('utf-8', 'replace')
    print('===== RAW TEXT (first %d bytes) =====' % n)
    print(txt)
    print('===== END RAW =====')
    lines = txt.split('\n')
    print('\n===== LINE INDEX =====')
    for i, ln in enumerate(lines):
        print('%3d | %s' % (i, ln))
    return 0


if __name__ == '__main__':
    sys.exit(main())
