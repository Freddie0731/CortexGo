# -*- coding: utf-8 -*-
"""核对 value head 的池化与 misc 输出结构，以及 policy 头的通道映射。"""
import struct, sys
import numpy as np
sys.stdout.reconfigure(encoding='utf-8', errors='replace')
sys.path.insert(0, '.')
import _katago_v17_load as L


def read_ref(path):
    f = open(path, 'rb')
    assert f.read(8) == b'KGREF001'
    n = struct.unpack('<i', f.read(4))[0]
    D = {}
    for _ in range(n):
        nl = struct.unpack('<i', f.read(4))[0]
        name = f.read(nl).decode()
        nd = struct.unpack('<i', f.read(4))[0]
        dims = [struct.unpack('<i', f.read(4))[0] for _ in range(nd)]
        c = 1
        for d in dims:
            c *= d
        D[name] = np.frombuffer(f.read(4 * c), dtype='<f4').reshape(dims).copy()
    return D


M = L.load(sys.argv[1], verbose=False)
D = read_ref(sys.argv[2])

print('=== 可用的 value/policy 相关参考键 ===')
for k in sorted(D):
    if k.startswith('value_head') or k.startswith('policy_head') or k.startswith('out.'):
        print('  %-50s %s' % (k, D[k].shape))

print()
print('=== value_head 模块 hook 输入 ===')
for k in ('value_head.bias1.input', 'value_head.linear2.input'):
    if k in D:
        print('  %-40s %s' % (k, D[k].shape))

# misc 池化公式核对：3 路 = [mean, mean*((sqrt(sum)-14)/10), mean*(((sqrt(sum)-14)^2)/100-0.1)]
if 'value_head.linear2.input' in D:
    pooled = D['value_head.linear2.input']
    print('\n  linear2.input shape', pooled.shape)
    p = pooled.reshape(-1)
    C = 192
    if p.size == 3 * C:
        print('  pool1 rms=%.5f pool2 rms=%.5f pool3 rms=%.5f'
              % (np.sqrt((p[:C] ** 2).mean()), np.sqrt((p[C:2 * C] ** 2).mean()),
                 np.sqrt((p[2 * C:] ** 2).mean())))
        ratio = p[C:2 * C] / np.where(np.abs(p[:C]) > 1e-12, p[:C], np.nan)
        rr = ratio[~np.isnan(ratio)]
        print('  pool2/pool1 = %.5f (期望 (sqrt(361)-14)/10 = %.5f)'
              % (np.median(rr), (np.sqrt(361) - 14) / 10))
        ratio3 = p[2 * C:] / np.where(np.abs(p[:C]) > 1e-12, p[:C], np.nan)
        rr3 = ratio3[~np.isnan(ratio3)]
        print('  pool3/pool1 = %.5f (期望 ((sqrt(361)-14)^2)/100-0.1 = %.5f)'
              % (np.median(rr3), ((np.sqrt(361) - 14) ** 2) / 100 - 0.1))

print()
print('=== 参考输出 ===')
for k in ('out.policy.0', 'out.policy.1', 'out.policy.2', 'out.policy.3'):
    if k in D:
        v = D[k]
        print('  %-16s shape=%-18s rms=%.5f  [0,:5]=%s'
              % (k, v.shape, np.sqrt((v.astype(np.float64) ** 2).mean()),
                 np.round(v.reshape(v.shape[0], v.shape[1], -1)[0, :, 0][:5], 5).tolist()))
        if k == 'out.policy.1':
            print('       out.policy.1 全值:', np.round(v.reshape(-1), 6).tolist())
