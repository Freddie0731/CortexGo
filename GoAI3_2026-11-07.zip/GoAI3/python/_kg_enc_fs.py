# -*- coding: utf-8 -*-
"""用 fixscale 配置看具体着法：是否像会下棋。"""
import sys, os
import numpy as np
import torch
sys.stdout.reconfigure(encoding='utf-8', errors='replace')
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
os.environ.setdefault('TORCHDYNAMO_DISABLE', '1')

import _katago_v17_load as L
from _katago_official import load_official
from _kg_ref import build_state_dict
from _kg_enc import GoBoard, encode, BLACK, WHITE

COLS = 'ABCDEFGHJKLMNOPQRST'
M = L.load(sys.argv[1], verbose=False)
Model, mc = load_official()
sd = build_state_dict(M)


def build(cfgname):
    m = Model(mc.config_of_name[cfgname], 19).eval()
    m.initialize()
    t = {}
    for k, v in m.state_dict().items():
        if k in sd:
            a = np.array(sd[k], dtype=np.float32, copy=True)
            if tuple(a.shape) == tuple(v.shape):
                t[k] = torch.from_numpy(a).clone()
    m.load_state_dict(t, strict=False)
    return m


def run(m, board, hist, pla):
    sp, gl = encode(board, hist, pla)
    with torch.no_grad():
        r = m._forward_per_block_units(torch.from_numpy(sp), torch.from_numpy(gl))
    h = r[0]
    return h[0].numpy().reshape(6, 362)[0], h[1].numpy().reshape(3), h[4].numpy().reshape(-1)


def show(tag, m, board, hist, pla):
    p, v, own = run(m, board, hist, pla)
    print('--- %s ---' % tag)
    print('  value(win/loss/noresult) =', np.round(v, 3).tolist())
    print('  胜率(当前方, 经tanh) = %+.2f%%' % (np.tanh(v[0]) * 50 + 50))
    print('  归属图和 = %+.1f  (>0 表示当前方占优)' % own.sum())
    # softmax
    mx = p[:361].max()
    ex = np.exp(p[:361] - mx)
    prob = ex / ex.sum()
    order = np.argsort(-prob)
    print('  前 10 个着法:')
    for i in range(10):
        l = int(order[i])
        print('    %2d. %c%-2d  prob %5.2f%%  logit %+8.3f'
              % (i + 1, COLS[l % 19], 19 - l // 19, prob[l] * 100, p[l]))
    pp = np.exp(p[361] - mx) / ex.sum()
    print('    pass     prob %5.2f%%  logit %+8.3f' % (pp * 100, p[361]))


for cfg in ('b11c768h12nbt3tflrs-fs-silu', 'b11c768h12nbt3tflrs-fson-silu'):
    print('=' * 70)
    print('配置:', cfg)
    m = build(cfg)
    b = GoBoard()
    show('空盘 黑先', m, b, [], BLACK)
    b2 = GoBoard(); b2.play(3, 3, BLACK)
    show('黑 D4 后 白先', m, b2, [((3, 3), BLACK)], WHITE)
    b3 = GoBoard(); b3.play(3, 3, BLACK); b3.play(15, 15, WHITE); b3.play(15, 3, BLACK)
    show('黑D4 白Q16 黑Q4 后 白先', m, b3,
         [((3, 3), BLACK), ((15, 15), WHITE), ((15, 3), BLACK)], WHITE)
    print()
