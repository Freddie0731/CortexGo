# -*- coding: utf-8 -*-
"""权重映射验证：解析结果 vs 官方 model_pytorch 的 state_dict。

零成本强验证：419 个张量的形状逐一核对，并抽样比对数值（无需跑前向）。
想发现"顺序读错位"或"reshape/转置错"这类问题，这一步最敏感。

用法: python _katago_verify_map.py <file.bin.gz>
"""
import sys, os
import numpy as np
import torch

try:
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
except Exception:
    pass

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _katago_official import load_official          # noqa: E402
import _katago_v17_load as L                        # noqa: E402

MODEL_PATH = sys.argv[1] if len(sys.argv) > 1 else \
    r'C:\Users\小米\Downloads\kata1-tf3-b11c768-s11003M-d5973M-7gres.bin.gz'


def build_sd(M):
    """把解析结果映射成官方 state_dict（用 numpy 数组，键名与官方一致）。"""
    sd = {}
    tr = M['trunk']
    sd['conv_spatial.weight'] = tr['initialConv']['w']
    sd['linear_global.weight'] = tr['initialMatMul']['w']

    # --- trunk tip ---
    t = tr['trunkTipNorm']
    if not tr['trunkTipNormIsRMS']:
        sd['norm_trunkfinal.beta'] = t['bias'].reshape(1, -1, 1, 1)
        if t['scale'] is not None:
            sd['norm_trunkfinal.gamma'] = t['scale'].reshape(1, -1, 1, 1)
    sd['act_trunkfinal.weight'] = None   # 占位（激活无参数）

    # --- 每个 NormActConv ---
    def add_nac(prefix, nc, has_gamma):
        if nc['norm']['bias'] is not None:
            sd[prefix + '.norm.beta'] = nc['norm']['bias'].reshape(1, -1, 1, 1)
        if has_gamma and nc['norm']['scale'] is not None:
            sd[prefix + '.norm.gamma'] = nc['norm']['scale'].reshape(1, -1, 1, 1)
        if 'conv' in nc:
            sd[prefix + '.conv.weight'] = nc['conv']['w']

    for i, b in enumerate(tr['blocks']):
        pfx = 'blocks.%d' % i
        k = b['kind']
        if k == 'ordinary_block':
            add_nac(pfx + '.normactconv1', b['normactconv1'], True)
            add_nac(pfx + '.normactconv2', b['normactconv2'], True)
        elif k == 'gpool_block':
            add_nac(pfx + '.normactconv1', b['normactconv1'], True)
            add_nac(pfx + '.normactconv2', b['normactconv2'], True)
        elif k == 'nested_bottleneck_block':
            add_nac(pfx + '.normactconvp', b['p'], False)
            add_nac(pfx + '.normactconvq', b['q'], True)
            for j, sb in enumerate(b['stack']):
                sp = pfx + '.blockstack.%d' % j
                if sb['kind'] == 'transformer_attention_block':
                    sd[sp + '.norm1.weight'] = sb['preLN']['weight']
                    for kk, tg in (('qProj', 'q_proj'), ('kProj', 'k_proj'),
                                   ('vProj', 'v_proj'), ('outProj', 'out_proj')):
                        sd[sp + '.' + tg + '.weight'] = sb[kk]['w']
                    if 'ropeFreqs' in sb:
                        sd[sp + '.rope_freqs'] = sb['ropeFreqs'].reshape(
                            sb['ropeNumKVHeads'], sb['ropeNumPairs'], 2)
                elif sb['kind'] == 'transformer_ffn_block':
                    sd[sp + '.norm.weight'] = sb['preLN']['weight']
                    sd[sp + '.ffn_linear1.weight'] = sb['linear1']['w']
                    if 'linearGate' in sb:
                        sd[sp + '.ffn_linear_gate.weight'] = sb['linearGate']['w']
                    sd[sp + '.ffn_linear2.weight'] = sb['linear2']['w']
                elif sb['kind'] == 'ordinary_block':
                    add_nac(sp + '.normactconv1', sb['normactconv1'], True)
                    add_nac(sp + '.normactconv2', sb['normactconv2'], True)

    ph = M['policyHead']
    sd['policy_head.conv1p.weight'] = ph['p1Conv']['w']
    sd['policy_head.conv1g.weight'] = ph['g1Conv']['w']
    sd['policy_head.biasg.beta'] = ph['g1BN']['bias'].reshape(1, -1, 1, 1)
    sd['policy_head.linear_g.weight'] = ph['gpoolToBiasMul']['w']
    sd['policy_head.bias2.beta'] = ph['p1BN']['bias'].reshape(1, -1, 1, 1)
    sd['policy_head.conv2p.weight'] = ph['p2Conv']['w']
    sd['policy_head.linear_pass.weight'] = ph['gpoolToPassMul']['w']
    if 'gpoolToPassBias' in ph:
        sd['policy_head.linear_pass.bias'] = ph['gpoolToPassBias']['b']
    if 'gpoolToPassMul2' in ph:
        sd['policy_head.linear_pass2.weight'] = ph['gpoolToPassMul2']['w']

    vh = M['valueHead']
    sd['value_head.conv1.weight'] = vh['v1Conv']['w']
    sd['value_head.bias1.beta'] = vh['v1BN']['bias'].reshape(1, -1, 1, 1)
    sd['value_head.linear2.weight'] = vh['v2Mul']['w']
    sd['value_head.linear2.bias'] = vh['v2Bias']['b']
    sd['value_head.linear_valuehead.weight'] = vh['v3Mul']['w']
    sd['value_head.linear_valuehead.bias'] = vh['v3Bias']['b']
    sd['value_head.conv_ownership.weight'] = vh['vOwnershipConv']['w']
    return sd


def main():
    print('=== 1. 解析权重 ===')
    M = L.load(MODEL_PATH, verbose=False)
    print('   at_end=%s  bytes=%d/%d' % (M['at_end'], M['bytes_consumed'], M['file_size']))

    print('\n=== 2. 构建官方模型 ===')
    Model, mc = load_official()
    cfg = mc.config_of_name['b11c768h12nbt3tflrs']
    model = Model(cfg, 19)
    ref = model.state_dict()
    print('   官方 state_dict: %d 项' % len(ref))

    print('\n=== 3. 映射 ===')
    mine = build_sd(M)
    print('   我的映射产出: %d 项' % len(mine))

    # ---- 形状核对 ----
    print('\n=== 4. 形状核对 ===')
    ok, bad, missing = [], [], []
    for k, v in ref.items():
        if k not in mine:
            missing.append((k, tuple(v.shape)))
            continue
        mv = mine[k]
        if mv is None:
            continue
        if tuple(mv.shape) != tuple(v.shape):
            bad.append((k, tuple(v.shape), tuple(mv.shape)))
        else:
            ok.append(k)
    extra = [k for k in mine if k not in ref and mine[k] is not None]

    print('   形状一致 : %d' % len(ok))
    print('   形状不符 : %d' % len(bad))
    for k, a, b in bad[:25]:
        print('      %-56s 官方%-20s 我的%s' % (k, a, b))
    print('   官方有我没有 : %d' % len(missing))
    for k, s in missing[:25]:
        print('      %-56s %s' % (k, s))
    print('   我有官方没有 : %d' % len(extra))
    for k in extra[:25]:
        print('      %s' % k)

    # ---- 数值抽样核对（对有映射且形状一致的项比统计量）----
    print('\n=== 5. 数值抽样（前 8 个形状一致的项）===')
    for k in ok[:8]:
        a = np.asarray(ref[k].detach().numpy())
        b = np.asarray(mine[k])
        same = np.allclose(a, b, rtol=1e-4, atol=1e-6)
        print('   %-56s allclose=%-5s 官方[%+.4f,%+.4f] 我[%+.4f,%+.4f]'
              % (k, same, a.min(), a.max(), b.min(), b.max()))

    tot = len(ok) + len(bad) + len(missing)
    print('\n=== 结论 ===')
    print('   覆盖 %d/%d 项；形状一致 %d；不符 %d；缺失 %d'
          % (len(ok) + len(missing), tot, len(ok), len(bad), len(missing)))
    return 0


if __name__ == '__main__':
    sys.exit(main())
