# -*- coding: utf-8 -*-
"""数值拟合 q 分支：A 与 (k, scale) 的确切关系。

已知 p 分支 A = k = 1/sqrt(i+1)（常量，已实证）。
q 分支 A 逐通道变化，B = beta。这里收集 (A, k, scale) 并拟合 A = a + b*scale。
"""
import sys, os
import numpy as np
import torch
sys.stdout.reconfigure(encoding='utf-8', errors='replace')
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
os.environ.setdefault('TORCHDYNAMO_DISABLE', '1')

import _katago_v17_load as L
from _katago_official import load_official
from _kg_ref import build_state_dict
from _kg_enc import GoBoard, encode, BLACK, WHITE

M = L.load(sys.argv[1], verbose=False)
Model, mc = load_official()
m = Model(mc.config_of_name['b11c768h12nbt3tflrs-fs-silu'], 19).eval()
m.initialize()
sd = build_state_dict(M)
t = {}
for k, v in m.state_dict().items():
    if k in sd:
        a = np.array(sd[k], dtype=np.float32, copy=True)
        if tuple(a.shape) == tuple(v.shape):
            t[k] = torch.from_numpy(a).clone()
m.load_state_dict(t, strict=False)

cap = {}
tg = set('blocks.%d.normactconvq.norm' % i for i in range(11))
for name, mod in m.named_modules():
    if name in tg:
        def mk(nm):
            def pre(module, inp): cap.setdefault(nm, {})['in'] = inp[0].detach().clone()
            def post(module, inp, out): cap.setdefault(nm, {})['out'] = out.detach().clone()
            return pre, post
        p, q = mk(name)
        mod.register_forward_pre_hook(p)
        mod.register_forward_hook(q)

b = GoBoard()
b.play(3, 3, BLACK); b.play(15, 15, WHITE); b.play(3, 15, BLACK); b.play(15, 3, WHITE)
sp, gl = encode(b, [], BLACK)
with torch.no_grad():
    m._forward_per_block_units(torch.from_numpy(sp), torch.from_numpy(gl))

print('%-30s %-10s %-12s %-12s %-12s %s' % ('layer', 'k', 'A均值', 'A最小', 'A最大', 'A vs k,scale'))
for i in range(11):
    name = 'blocks.%d.normactconvq.norm' % i
    c = cap.get(name)
    if not c:
        continue
    x = c['in'].numpy().astype(np.float64)
    y = c['out'].numpy().astype(np.float64)
    xs = x.reshape(-1, x.shape[-1]); ys = y.reshape(-1, y.shape[-1])
    C = xs.shape[1]
    A = np.zeros(C); B = np.zeros(C)
    for ch in range(C):
        xc, yc = xs[:, ch], ys[:, ch]
        if np.ptp(xc) < 1e-12:
            A[ch] = np.nan; B[ch] = np.nan; continue
        A[ch], B[ch] = np.polyfit(xc, yc, 1)
    ok = ~np.isnan(A)
    k = 1.0 / np.sqrt(i + 1)
    sc = np.asarray(M['trunk']['blocks'][i]['q']['norm']['scale'], dtype=np.float64)
    # 拟合 A = a + b*scale
    Mx = np.c_[np.ones(ok.sum()), sc[ok]]
    sol, *_ = np.linalg.lstsq(Mx, A[ok], rcond=None)
    resid = A[ok] - Mx @ sol
    print('%-30s %-10.6f %-12.6f %-12.6f %-12.6f a=%.6f b=%.6f resid=%.2e'
          % (name, k, np.nanmean(A), np.nanmin(A), np.nanmax(A),
             sol[0], sol[1], np.abs(resid).max()))
    # 与候选公式对照
    cands = {
        'k': np.full_like(sc, k),
        'k*sc': k * sc,
        'k+(1-k)*sc': k + (1 - k) * sc,
        '(1-k)*sc+k*1': (1 - k) * sc + k,
        'sc': sc,
        '1+sc': 1 + sc,
    }
    best = None
    for cn, cv in cands.items():
        d = np.nanmax(np.abs(A[ok] - cv[ok]))
        if best is None or d < best[1]:
            best = (cn, d)
    print('     最佳候选: %-14s 差=%.3e   (k+(1-k)sc 差=%.3e)'
          % (best[0], best[1], np.nanmax(np.abs(A[ok] - (k + (1 - k) * sc)[ok]))))
