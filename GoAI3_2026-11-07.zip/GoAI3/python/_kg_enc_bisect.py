# -*- coding: utf-8 -*-
"""二分定位：哪个全局特征让网络在空盘上想 pass？

逐个把全局特征置零，看 pass logit 与 value 如何变化。
再用官方 PyTorch 模型跑，确认是编码问题而非实现问题。
"""
import sys, os
import numpy as np
import torch
sys.stdout.reconfigure(encoding='utf-8', errors='replace')
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
os.environ.setdefault('TORCHDYNAMO_DISABLE', '1')

import _katago_v17_load as L
from _katago_official import load_official
from _kg_ref import build_state_dict
from _kg_enc import GoBoard, encode, BLACK, WHITE

M = L.load(sys.argv[1], verbose=False)
Model, mc = load_official()
model = Model(mc.config_of_name['b11c768h12nbt3tflrs-silu'], 19).eval()
model.initialize()
sd = build_state_dict(M)
t = {}
for k, v in model.state_dict().items():
    if k in sd:
        a = np.array(sd[k], dtype=np.float32, copy=True)
        if tuple(a.shape) == tuple(v.shape):
            t[k] = torch.from_numpy(a).clone()
model.load_state_dict(t, strict=False)

b = GoBoard()
sp, gl = encode(b, [], BLACK)


def run(sp, gl):
    with torch.no_grad():
        r = model._forward_per_block_units(torch.from_numpy(sp.copy()),
                                           torch.from_numpy(gl.copy()))
    head = r[0]
    pol = head[0].numpy().reshape(6, 362)
    val = head[1].numpy().reshape(3)
    return pol[0], val


p0, v0 = run(sp, gl)
print('基线: pass logit = %+8.3f   value = [%.2f, %.2f, %.2f]'
      % (p0[361], v0[0], v0[1], v0[2]))
print('      board logit 最大 = %+8.3f' % p0[:361].max())
print()
print('逐项置零全局特征:')
names = {5: 'komi/20', 6: 'koRuleA', 7: 'koRuleB', 8: 'suicideLegal', 9: 'areaScoring',
         10: 'tax', 11: 'taxAll', 12: 'encore1', 13: 'encore2', 14: 'passEnds', 18: 'komiWave'}
for idx in sorted(names):
    g2 = gl.copy()
    g2[0, idx] = 0.0
    p, v = run(sp, g2)
    print('  置零 gl[%-2d] (%-14s): pass %+8.3f  boardMax %+8.3f  value[0] %+7.2f'
          % (idx, names[idx], p[361], p[:361].max(), v[0]))

print()
print('全部全局特征置零:')
g3 = np.zeros_like(gl)
p, v = run(sp, g3)
print('  pass %+8.3f  boardMax %+8.3f  value[0] %+7.2f' % (p[361], p[:361].max(), v[0]))

print()
print('只保留 gl[9]=1 (面积计分)，其余全局置零:')
g4 = np.zeros_like(gl); g4[0, 9] = 1.0
p, v = run(sp, g4)
print('  pass %+8.3f  boardMax %+8.3f  value[0] %+7.2f' % (p[361], p[:361].max(), v[0]))

print()
print('空间特征全部置零，只保留平面0:')
sp5 = np.zeros_like(sp); sp5[0, 0] = 1.0
p, v = run(sp5, gl)
print('  pass %+8.3f  boardMax %+8.3f  value[0] %+7.2f' % (p[361], p[:361].max(), v[0]))

print()
print('空间与全局全零（含平面0）:')
p, v = run(np.zeros_like(sp), np.zeros_like(gl))
print('  pass %+8.3f  boardMax %+8.3f  value[0] %+7.2f' % (p[361], p[:361].max(), v[0]))
