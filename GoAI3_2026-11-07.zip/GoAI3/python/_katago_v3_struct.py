# -*- coding: utf-8 -*-
"""KataGo v3 组件结构解析器（纯标准库，只读，带行号定位）。

v3 结构（已由 model.conv_spatial = 3x3x22->768 验证）:
    magic \\n magicSize \\n numComponents \\n
    <第一个组件: name \\n ndim \\n dims... \\n @BIN@ floats>   <- 组件本身自描述
    <后续组件 同上>
@BIN@ 之后紧跟 4*prod(dims) 字节 float32(小端)。

用法: python _katago_v3_struct.py <file.bin.gz> [--floats]
"""
import sys, gzip, struct, math

try:
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
except Exception:
    pass

NAME_CHARS = set('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_.-')


def looks_like_name(s):
    return bool(s) and all(c in NAME_CHARS for c in s) and ' ' not in s


def main():
    path = sys.argv[1]
    show_floats = '--floats' in sys.argv
    with gzip.open(path, 'rb') as g:
        data = g.read()

    pos = 0
    nl = data.index(b'\n', pos); magic = data[pos:nl].decode('utf-8'); pos = nl + 1
    nl = data.index(b'\n', pos); magic_size = int(data[pos:nl]); pos = nl + 1
    nl = data.index(b'\n', pos); num_components = int(data[pos:nl]); pos = nl + 1
    print('magic=%s  magicSize=%d  numComponents=%d' % (magic, magic_size, num_components))

    # 行号仅用于报告
    def line_no(off):
        return data[:off].count(b'\n')

    comps = []
    while len(comps) < 400:
        if pos >= len(data):
            break
        nl = data.find(b'\n', pos)
        if nl < 0:
            break
        name = data[pos:nl].decode('utf-8', 'replace')
        if not looks_like_name(name):
            print('\n!! stopping at line %d offset %d: %r is not a component name'
                  % (line_no(pos), pos, name[:50]))
            break
        start_line = line_no(pos)
        pos = nl + 1
        nl = data.find(b'\n', pos)
        try:
            ndim = int(data[pos:nl])
        except ValueError:
            print('!! bad ndim for %s' % name)
            break
        pos = nl + 1
        dims = []
        for _ in range(ndim):
            nl = data.find(b'\n', pos)
            dims.append(int(data[pos:nl]))
            pos = nl + 1
        if data[pos:pos + 5] != b'@BIN@':
            print('!! %s: no @BIN@ at offset %d (line %d), saw %r'
                  % (name, pos, line_no(pos), data[pos:pos + 16]))
            break
        pos += 5
        n = 1
        for d in dims:
            n *= d
        vals = struct.unpack_from('<%df' % n, data, pos) if show_floats and n else None
        pos += 4 * n
        comps.append((name, dims, n, start_line, vals))

    print('components parsed: %d' % len(comps))
    print('consumed %d / %d bytes, left %d\n' % (pos, len(data), len(data) - pos))

    print('%-4s %-9s %-36s %-22s %10s' % ('#', 'line', 'name', 'dims', 'floats'))
    print('-' * 90)
    for i, (name, dims, n, ln, _v) in enumerate(comps):
        print('%-4d %-9d %-36s %-22s %10d' % (i, ln, name, str(dims), n))

    total = sum(c[2] for c in comps)
    print('-' * 90)
    print('total floats: %d (%.1f MB of %d payload bytes before @BIN@ stripping)'
          % (total, total * 4 / 1048576.0, len(data)))

    if show_floats:
        print('\n--- stats ---')
        for name, dims, n, ln, vals in comps:
            if not vals:
                continue
            mn = min(vals); mx = max(vals)
            mean = sum(vals) / len(vals)
            print('  %-38s n=%-9d min=%+.4f max=%+.4f mean=%+.4f' % (name, n, mn, mx, mean))

    # 结构总结：找出卷积与残差块的模式
    print('\n--- architecture summary ---')
    convs = [c for c in comps if 'conv' in c[0].lower() and len(c[1]) == 4]
    print('  4-D conv tensors: %d' % len(convs))
    blocks = sorted(set(c[0].split('/')[0] for c in comps if '/' in c[0]))
    print('  block modules   : %d  %s' % (len(blocks), blocks[:20]))
    return 0


if __name__ == '__main__':
    sys.exit(main())
