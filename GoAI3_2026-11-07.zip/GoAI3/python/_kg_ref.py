# -*- coding: utf-8 -*-
"""用官方 PyTorch 模型导出参考激活，供 C++ 数值对齐。

做法：
  1. 用 gitcode 镜像拉到的官方 model_pytorch.py 构造 b11c768h12nbt3tflrs 模型
  2. 用 _katago_v17_load.py 解析出的权重灌进 state_dict（逐张量核对形状）
  3. 用固定种子的随机输入跑一次前向
  4. 把关键中间张量 dump 成 .bin（自描述头 + 原始 float32），C++ 侧读同一格式比对

dump 文件格式（小端）：
  magic   : b'KGREF001'
  nTensors: int32
  然后每个张量：
    nameLen : int32, name: bytes
    ndim    : int32, dims: int32[ndim]
    data    : float32[prod(dims)]

用法:
  python _kg_ref.py <weights.bin.gz> <out.bin> [--seed 1234]
"""
import sys, os, struct
import numpy as np
import torch

try:
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
except Exception:
    pass

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# 必须在 import torch 之前：本机 cl.exe 不在 PATH 上，torch.compile/inductor
# 会因此报 InvalidCxxCompiler。纯推理不需要编译加速，直接整体关掉。
os.environ.setdefault('TORCHDYNAMO_DISABLE', '1')
os.environ.setdefault('TORCH_COMPILE_DISABLE', '1')
os.environ.setdefault('TORCHINDUCTOR_DISABLE', '1')

from _katago_official import load_official
import _katago_v17_load as L


def build_state_dict(M):
    """把解析出的权重映射为官方 state_dict（numpy 数组）。"""
    sd = {}
    tr = M['trunk']
    sd['conv_spatial.weight'] = tr['initialConv']['w']
    sd['linear_global.weight'] = tr['initialMatMul']['w']

    def put_norm(prefix, n):
        if n.get('bias') is not None:
            sd[prefix + '.beta'] = np.asarray(n['bias']).reshape(1, -1, 1, 1)
        if n.get('scale') is not None:
            sd[prefix + '.gamma'] = np.asarray(n['scale']).reshape(1, -1, 1, 1)

    def put_nac(prefix, nc, has_gamma):
        put_norm(prefix + '.norm', nc['norm'])
        if not has_gamma and (prefix + '.norm.gamma') in sd:
            del sd[prefix + '.norm.gamma']
        sd[prefix + '.conv.weight'] = nc['conv']['w']

    def put_block(prefix, b):
        k = b['kind']
        if k in ('ordinary_block', 'gpool_block'):
            put_nac(prefix + '.normactconv1', b['normactconv1'], True)
            put_nac(prefix + '.normactconv2', b['normactconv2'], True)
        elif k == 'nested_bottleneck_block':
            put_nac(prefix + '.normactconvp', b['p'], False)
            put_nac(prefix + '.normactconvq', b['q'], True)
            for j, sb in enumerate(b['stack']):
                put_block(prefix + '.blockstack.%d' % j, sb)
        elif k == 'transformer_attention_block':
            sd[prefix + '.norm1.weight'] = b['preLN']['weight']
            for kk, tg in (('qProj', 'q_proj'), ('kProj', 'k_proj'),
                           ('vProj', 'v_proj'), ('outProj', 'out_proj')):
                sd[prefix + '.' + tg + '.weight'] = b[kk]['w']
            if 'ropeFreqs' in b:
                sd[prefix + '.rope_freqs'] = np.asarray(b['ropeFreqs']).reshape(
                    b['ropeNumKVHeads'], b['ropeNumPairs'], 2)
        elif k == 'transformer_ffn_block':
            sd[prefix + '.norm.weight'] = b['preLN']['weight']
            sd[prefix + '.ffn_linear1.weight'] = b['linear1']['w']
            if 'linearGate' in b:
                sd[prefix + '.ffn_linear_gate.weight'] = b['linearGate']['w']
            sd[prefix + '.ffn_linear2.weight'] = b['linear2']['w']

    for i, b in enumerate(tr['blocks']):
        put_block('blocks.%d' % i, b)

    if not tr['trunkTipNormIsRMS']:
        t = tr['trunkTipNorm']
        sd['norm_trunkfinal.beta'] = np.asarray(t['bias']).reshape(1, -1, 1, 1)
        if t['scale'] is not None:
            sd['norm_trunkfinal.gamma'] = np.asarray(t['scale']).reshape(1, -1, 1, 1)

    ph = M['policyHead']
    sd['policy_head.conv1p.weight'] = ph['p1Conv']['w']
    sd['policy_head.conv1g.weight'] = ph['g1Conv']['w']
    sd['policy_head.biasg.beta'] = np.asarray(ph['g1BN']['bias']).reshape(1, -1, 1, 1)
    sd['policy_head.linear_g.weight'] = ph['gpoolToBiasMul']['w']
    sd['policy_head.bias2.beta'] = np.asarray(ph['p1BN']['bias']).reshape(1, -1, 1, 1)
    # 文件只写 2 个策略通道；官方模型内部是 6（regular, optimistic, qwin, qloss, qscore, qnoresult）
    c6, c96 = ph['p2Conv']['w'].shape[0], ph['p2Conv']['w'].shape[1]
    full2 = np.zeros((6, c96, 1, 1), dtype=np.float32)
    full2[0] = ph['p2Conv']['w'][0]
    full2[5] = ph['p2Conv']['w'][1]
    sd['policy_head.conv2p.weight'] = full2
    sd['policy_head.linear_pass.weight'] = ph['gpoolToPassMul']['w']
    sd['policy_head.linear_pass.bias'] = np.asarray(ph['gpoolToPassBias']['b'])
    c_p1 = ph['gpoolToPassMul2']['w'].shape[1]
    full2b = np.zeros((6, c_p1), dtype=np.float32)
    full2b[0] = ph['gpoolToPassMul2']['w'][0]
    full2b[5] = ph['gpoolToPassMul2']['w'][1]
    sd['policy_head.linear_pass2.weight'] = full2b

    vh = M['valueHead']
    sd['value_head.conv1.weight'] = vh['v1Conv']['w']
    sd['value_head.bias1.beta'] = np.asarray(vh['v1BN']['bias']).reshape(1, -1, 1, 1)
    sd['value_head.linear2.weight'] = vh['v2Mul']['w']
    sd['value_head.linear2.bias'] = np.asarray(vh['v2Bias']['b'])
    sd['value_head.linear_valuehead.weight'] = vh['v3Mul']['w']
    sd['value_head.linear_valuehead.bias'] = np.asarray(vh['v3Bias']['b'])
    # 价值头映射（依据 value head 的 forward 与写侧关系）：
    #   conv1(x=trunk 输出 768) -> bias1 -> act1            (192 通道空间特征)
    #   gpool(act1) -> 576 维池化向量
    #   linear2: 576 -> 192, 再 act2                        (outv2)
    #   linear_valuehead(outv2)    : 192 -> 3   <-> 文件 v3Mul/v3Bias
    #   linear_miscvaluehead(outv2): 192 -> 10  <-> 文件 sv3Mul(6,192) 只存前 6
    #   注意：文件里的 v2Mul (192,576) 是 linear2，不是 misc 头。
    w = np.zeros((10, 192), dtype=np.float32)
    b = np.zeros((10,), dtype=np.float32)
    w[0:6] = np.asarray(vh['sv3Mul']['w'], dtype=np.float32)[0:6]
    b[0:6] = np.asarray(vh['sv3Bias']['b'], dtype=np.float32)[0:6]
    sd['value_head.linear_miscvaluehead.weight'] = w
    sd['value_head.linear_miscvaluehead.bias'] = b
    sd['value_head.conv_ownership.weight'] = vh['vOwnershipConv']['w']
    return sd


class Dumper(object):
    def __init__(self, path):
        self.f = open(path, 'wb')
        self.f.write(b'KGREF001')
        self.f.write(struct.pack('<i', 0))     # 张量个数占位
        self.n = 0

    def add(self, name, t):
        if torch.is_tensor(t):
            t = t.detach().cpu().numpy()
        t = np.ascontiguousarray(t, dtype=np.float32)
        nb = name.encode('utf-8')
        self.f.write(struct.pack('<i', len(nb)))
        self.f.write(nb)
        self.f.write(struct.pack('<i', t.ndim))
        for d in t.shape:
            self.f.write(struct.pack('<i', int(d)))
        self.f.write(t.tobytes())
        self.n += 1

    def close(self):
        self.f.seek(8)
        self.f.write(struct.pack('<i', self.n))
        self.f.close()
        return self.n


def main():
    wpath = sys.argv[1]
    outpath = sys.argv[2]
    seed = 1234
    if '--seed' in sys.argv:
        seed = int(sys.argv[sys.argv.index('--seed') + 1])

    print('=== 解析权重 ===')
    M = L.load(wpath, verbose=False)

    print('=== 构造官方模型 ===')
    Model, mc = load_official()
    # 注意：必须用 -silu 变体。b11c768h12nbt3tflrs 基础配置里没有 "activation" 键，
    # 官方 Model.__init__ 会取默认值 "relu"；而这份 checkpoint 是用 SiLU 训练的
    # （.bin.gz 里所有激活都写 ACTIVATION_SILU）。用错激活会导致第一层 norm 之后
    # 就发散（负数被 ReLU 归零 vs SiLU 给出负值）。
    cfgName = 'b11c768h12nbt3tflrs-fs-silu'
    if cfgName not in mc.config_of_name:
        raise SystemExit('config %s not found' % cfgName)
    cfg = mc.config_of_name[cfgName]
    pos_len = 19
    model = Model(cfg, pos_len).eval()
    model.initialize()
    print('  config=%s  activation=%s' % (cfgName, model.activation))

    print('=== 灌入权重 ===')
    sd = build_state_dict(M)
    ref = model.state_dict()
    loaded, skipped = 0, []
    target = {}
    for k, v in ref.items():
        if k in sd:
            # 关键：必须 copy。_katago_v17_load 读出的 numpy 数组是只读的，
            # torch.from_numpy 会包住它而不拷贝，后续可能行为未定义。
            a = np.array(sd[k], dtype=np.float32, copy=True, order='C')
            if tuple(a.shape) != tuple(v.shape):
                skipped.append((k, tuple(v.shape), tuple(a.shape)))
                continue
            target[k] = torch.from_numpy(a).clone()
            loaded += 1
        else:
            skipped.append((k, tuple(v.shape), None))
    missing, unexpected = model.load_state_dict(target, strict=False)
    print('  已加载 %d / 官方 %d 张量' % (loaded, len(ref)))
    if skipped:
        print('  未加载 %d 项（辅助头或形状不同，前向不影响）:' % len(skipped))
        for k, s, mine in skipped[:20]:
            print('    %-56s 官方%-18s 文件%s' % (k, s, mine))

    # ---- 输入 ----
    # Model 的 mask 取自 input_spatial[:,0:1]，所以第 0 平面必须是合法性掩码(全 1)。
    # 输入仍是 4 维 NCHW；transformer 序列布局由 _per_block_embed 内部转换。
    rng = np.random.RandomState(seed)
    B, H, W, C = 1, pos_len, pos_len, 22
    sp = (rng.randn(B, C, H, W).astype(np.float32) * 0.5)
    sp[:, 0, :, :] = 1.0
    inp_spatial = torch.from_numpy(sp).float()
    inp_global = torch.from_numpy(
        (rng.randn(B, 19).astype(np.float32) * 0.5)).float()
    mask = torch.ones(B, 1, H, W, dtype=torch.float32)

    d = Dumper(outpath)
    d.add('input.spatial', inp_spatial)
    d.add('input.global', inp_global)
    d.add('input.mask', mask)

    print('\n=== 注册 hook 并跑前向 ===')
    want_prefixes = (
        'blocks.0.', 'blocks.1.', 'norm_trunkfinal', 'act_trunkfinal',
        'policy_head.', 'value_head.',
    )
    hooks = []

    def mk_hook(nm):
        def hook(mod, inp, out):
            if isinstance(out, torch.Tensor):
                d.add(nm, out)
        return hook

    for name, mod in model.named_modules():
        if name and name.startswith(want_prefixes):
            hooks.append(mod.register_forward_hook(mk_hook(name)))

    # 额外：对 blocks.0 的 normactconvp / normactconvq 的 norm 子模块，
    # 同时抓取它的**输入**（pre-hook），这样可以确认残差累加后的真实输入。
    def mk_pre_hook(nm):
        def hook(mod, inp):
            if inp and torch.is_tensor(inp[0]):
                d.add(nm + '.input', inp[0])
        return hook

    pre_targets = [
        'blocks.0.normactconvp.norm',
        'blocks.0.normactconvq.norm',
        'blocks.0.blockstack.0.norm1',
        'blocks.0.blockstack.1.norm',
    ]
    for name, mod in model.named_modules():
        if name in pre_targets:
            hooks.append(mod.register_forward_pre_hook(mk_pre_hook(name)))

    # transformer 序列布局的模型走 _forward_per_block_units（输入是 3 维 (B,S,C)）；
    # 普通 NCHW 路径才用 model.forward。这里按布局自动选择。
    use_seq = bool(getattr(model, 'transformer_seq_layout', False))
    print('  transformer_seq_layout = %s -> 调用 %s' %
          (use_seq, '_forward_per_block_units' if use_seq else 'forward'))
    try:
        with torch.no_grad():
            if use_seq:
                res = model._forward_per_block_units(inp_spatial, inp_global)
            else:
                res = model(inp_spatial, inp_global, mask)
    except AssertionError as e:
        print('  序列布局路径断言失败（%s），回退到 forward' % e)
        with torch.no_grad():
            res = model(inp_spatial, inp_global, mask)

    for h in hooks:
        h.remove()

    print('\n=== 输出对象 ===')
    if isinstance(res, tuple):
        names = ('policy', 'value', 'miscvalue', 'moremiscvalue', 'ownership',
                 'scoring', 'futurepos', 'seki', 'scorebelief')
        for i, v in enumerate(res):
            nm = names[i] if i < len(names) else ('out%d' % i)
            if torch.is_tensor(v):
                d.add('out.' + nm, v)
                print('  out.%-14s %s' % (nm, tuple(v.shape)))
            elif isinstance(v, torch.Tensor):
                pass
            elif hasattr(v, 'shape'):
                d.add('out.' + nm, v)
                print('  out.%-14s %s' % (nm, tuple(v.shape)))
            elif isinstance(v, (tuple, list)):
                for j, vv in enumerate(v):
                    if torch.is_tensor(vv):
                        d.add('out.%s.%d' % (nm, j), vv)
                        print('  out.%s.%-9d %s' % (nm, j, tuple(vv.shape)))
                    else:
                        print('  out.%s.%-9d <%s>' % (nm, j, type(vv).__name__))
            else:
                print('  out.%-14s <%s>' % (nm, type(v).__name__))
    elif isinstance(res, dict):
        for k, v in res.items():
            if torch.is_tensor(v):
                d.add('out.' + k, v)
                print('  out.%-14s %s' % (k, tuple(v.shape)))
    elif torch.is_tensor(res):
        d.add('out.tensor', res)
        print('  out.tensor %s' % (tuple(res.shape),))
    else:
        print('  非预期返回类型: %s' % type(res))

    n = d.close()
    sz = os.path.getsize(outpath)
    print('\n写出 %s : %d 个张量, %.2f MB' % (outpath, n, sz / 1048576.0))


if __name__ == '__main__':
    main()
