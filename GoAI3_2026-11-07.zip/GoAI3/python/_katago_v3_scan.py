# -*- coding: utf-8 -*-
"""KataGo v3 结构正则搜索（二进制安全，纯标准库，只读）。

方法：直接在整个文件里搜索形如
    <ASCII名字>\n<十进制>\n<十进制>...\n@BIN@
的字节模式，枚举所有匹配及其在文件中的偏移。
名字集为 [A-Za-z0-9_.-]，且必须以非数字开头（排除数值行）。
这样不依赖"按行扫描"，不会被二进制数据里的 \\n 干扰。

用法: python _katago_v3_scan.py <file.bin.gz> [--max-shown N]
"""
import sys, gzip, re, struct

try:
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
except Exception:
    pass

# 名字行 + 至少一个整数行 + @BIN@
PAT = re.compile(rb'(?<![A-Za-z0-9_.\-])([A-Za-z_][A-Za-z0-9_.\-]{0,60})\n((?:[0-9]+\n){1,9})@BIN@')


def main():
    path = sys.argv[1]
    max_shown = 100
    if '--max-shown' in sys.argv:
        max_shown = int(sys.argv[sys.argv.index('--max-shown') + 1])
    with gzip.open(path, 'rb') as g:
        data = g.read()
    total = len(data)
    print('file size: %d bytes' % total)

    matches = list(PAT.finditer(data))
    print('raw @BIN@-terminated header-like matches: %d\n' % len(matches))

    print('%-4s %-11s %-44s %-24s %9s' % ('#', 'offset', 'name', 'dims', 'payload'))
    print('-' * 100)
    for i, m in enumerate(matches):
        name = m.group(1).decode('utf-8', 'replace')
        nums = [int(x) for x in m.group(2).split(b'\n') if x != b'']
        ndim = nums[0]
        dims = nums[1:1 + ndim]
        if len(dims) != ndim:
            continue
        n = 1
        for d in dims:
            n *= d
        payload_off = m.end()
        fits = payload_off + 4 * n <= total
        if i < max_shown:
            print('%-4d %-11d %-44s %-24s %9d %s'
                  % (i, m.start(), name[:44], str(dims), n,
                     '' if fits else 'OVERFLOW'))
    print('\n(total shown: %d of %d)' % (min(max_shown, len(matches)), len(matches)))

    # 是否恰好 numComponents+某数 个？
    print('\n--- counting consistency ---')
    pos = 0
    nl = data.index(b'\n', pos); magic = data[pos:nl].decode('utf-8'); pos = nl + 1
    nl = data.index(b'\n', pos); magic_size = int(data[pos:nl]); pos = nl + 1
    nl = data.index(b'\n', pos); num_components = int(data[pos:nl]); pos = nl + 1
    print('numComponents=%d' % num_components)
    print('matches=%d  (numComponents+? = %d)' % (len(matches), len(matches) - num_components))

    # 从第一个匹配开始，用"块链"前进，看能走多远
    print('\n--- block chain walk (choosing the match whose payload ends at/near next match) ---')
    by_off = {}
    for m in matches:
        nums = [int(x) for x in m.group(2).split(b'\n') if x != b'']
        ndim = nums[0]
        dims = nums[1:1 + ndim]
        if len(dims) != ndim:
            continue
        n = 1
        for d in dims:
            n *= d
        by_off[m.start()] = (m.group(1).decode('utf-8', 'replace'), dims, m.end() + 4 * n)

    offs = sorted(by_off)
    chain_start = None
    for o in offs:
        if by_off[o][0] not in ('trunk',):
            continue
        chain_start = o
        break
    if chain_start is None and offs:
        chain_start = offs[0]
    print('chain start chosen at offset %d' % (chain_start or -1))

    cur = chain_start
    steps = 0
    total_floats = 0
    while cur is not None and steps < 400:
        name, dims, endp = by_off[cur]
        n = 1
        for d in dims:
            n *= d
        total_floats += n
        steps += 1
        if steps <= 60:
            print('  [%3d] off %-11d %-40s %-22s floats=%d -> next %d'
                  % (steps, cur, name[:40], str(dims), n, endp))
        nxt = endp if endp in by_off else None
        if nxt is None:
            # 允许 endp 与下一个块首之间的差距（理论上应为 0）
            print('  [%3d] chain broke after %s: payload ends at %d, next match at %s'
                  % (steps, name[:40], endp,
                     str([o for o in offs if o > endp][:3])))
            break
        cur = nxt
    print('\nchain steps: %d, cumulative floats: %d (%.1f MB)'
          % (steps, total_floats, total_floats * 4 / 1048576.0))
    return 0


if __name__ == '__main__':
    sys.exit(main())
