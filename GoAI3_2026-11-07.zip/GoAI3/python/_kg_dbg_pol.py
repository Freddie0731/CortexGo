# -*- coding: utf-8 -*-
"""反推 policy 文件里的 2 个输出通道对应模型 6 通道中的哪两个。"""
import struct, sys
import numpy as np
sys.stdout.reconfigure(encoding='utf-8', errors='replace')
sys.path.insert(0, '.')
import _katago_v17_load as L


def read_ref(path):
    f = open(path, 'rb')
    assert f.read(8) == b'KGREF001'
    n = struct.unpack('<i', f.read(4))[0]
    D = {}
    for _ in range(n):
        nl = struct.unpack('<i', f.read(4))[0]
        name = f.read(nl).decode()
        nd = struct.unpack('<i', f.read(4))[0]
        dims = [struct.unpack('<i', f.read(4))[0] for _ in range(nd)]
        c = 1
        for d in dims:
            c *= d
        D[name] = np.frombuffer(f.read(4 * c), dtype='<f4').reshape(dims).copy()
    return D


M = L.load(sys.argv[1], verbose=False)
D = read_ref(sys.argv[2])
ph = M['policyHead']

conv2p = D['policy_head.conv2p']        # (1,6,19,19)
print('conv2p shape', conv2p.shape, ' 非零通道:',
      [i for i in range(conv2p.shape[1]) if np.abs(conv2p[0, i]).max() > 1e-9])
act2 = D['policy_head.act2'].reshape(96, 361)      # (1,96,19,19) -> (96, S)
lp2 = D['policy_head.linear_pass2'].reshape(-1)    # (6,)
print('linear_pass2 非零:', [i for i in range(lp2.size) if abs(lp2[i]) > 1e-9])

# 用文件权重算 conv2p 的两个通道，看对应模型哪两个
W = np.asarray(ph['p2Conv']['w'], dtype=np.float64)   # (2,96,1,1)
o = np.stack([W[k, :, 0, 0] @ act2 for k in range(2)])   # (2,S)
print()
for k in range(6):
    if np.abs(conv2p[0, k]).max() < 1e-9:
        continue
    ref = conv2p[0, k].reshape(361)
    for j in range(2):
        d = np.abs(o[j] - ref).max()
        if d < 1e-3:
            print('  模型 conv2p 通道 %d  <->  文件第 %d 个通道  (maxdiff=%.2e)' % (k, j, d))

# 同样反推 linear_pass2
Wp = np.asarray(ph['gpoolToPassMul2']['w'], dtype=np.float64)   # (2,96)
passv = D['policy_head.act_pass'].reshape(-1).astype(np.float64)  # (96,)
po = np.array([Wp[k] @ passv for k in range(2)])
print()
for k in range(6):
    d = np.abs(po - lp2[k]).min()
    if d < 1e-3:
        j = int(np.argmin(np.abs(po - lp2[k])))
        print('  模型 linear_pass2 通道 %d  <->  文件第 %d 个通道  (maxdiff=%.2e)'
              % (k, j, np.abs(po[j] - lp2[k]).max()))

# 出参：out.policy.0 的最后一列 = pass logits
op = D['out.policy.0']     # (1,6,362)
print()
print('out.policy.0[:, :, 361] (pass logits) =', np.round(op[0, :, 361], 6).tolist())
print('out.policy.0[:, :, 0] (board pos0)    =', np.round(op[0, :, 0], 6).tolist())
