# -*- coding: utf-8 -*-
"""用参考的 act_trunkfinal + 文件权重手算 value_head.conv1，与参考对照。"""
import struct, sys
import numpy as np
import torch
sys.stdout.reconfigure(encoding='utf-8', errors='replace')
sys.path.insert(0, '.')
import _katago_v17_load as L


def read_ref(path):
    f = open(path, 'rb')
    assert f.read(8) == b'KGREF001'
    n = struct.unpack('<i', f.read(4))[0]
    D = {}
    for _ in range(n):
        nl = struct.unpack('<i', f.read(4))[0]
        name = f.read(nl).decode()
        nd = struct.unpack('<i', f.read(4))[0]
        dims = [struct.unpack('<i', f.read(4))[0] for _ in range(nd)]
        c = 1
        for d in dims:
            c *= d
        D[name] = np.frombuffer(f.read(4 * c), dtype='<f4').reshape(dims).copy()
    return D


M = L.load(sys.argv[1], verbose=False)
D = read_ref(sys.argv[2])
a = torch.from_numpy(D['act_trunkfinal'].astype(np.float32).copy())   # (1,768,19,19)
W = torch.from_numpy(np.asarray(M['valueHead']['v1Conv']['w'], dtype=np.float32))
print('W shape', tuple(W.shape))
c = torch.nn.functional.conv2d(a, W)
ref = torch.from_numpy(D['value_head.conv1'].astype(np.float32).copy())
print('|手算 conv1 - 参考 conv1|max = %.6e' % (c - ref).abs().max().item())
print('手算[0,:4,0,0] =', np.round(c[0, :4, 0, 0].numpy(), 5).tolist())
print('参考[0,:4,0,0] =', np.round(ref[0, :4, 0, 0].numpy(), 5).tolist())
print()
print('=== 逐通道 diff ===')
d = (c - ref).abs()
per = d.amax(dim=(0, 2, 3))
print('  前 8 通道 maxdiff:', np.round(per[:8].numpy(), 5).tolist())
print('  非零通道数:', int((per > 1e-4).sum().item()), '/', per.numel())
print('  W[1,:4,0,0] =', np.round(W[1, :4, 0, 0].numpy(), 6).tolist())
