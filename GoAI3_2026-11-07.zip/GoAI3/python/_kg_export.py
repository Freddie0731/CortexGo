# -*- coding: utf-8 -*-
"""把 PyTorch 权重写回 KataGo v17 的 .bin.gz。

## 为什么不"重新生成" token 流

最先尝试的是记录读取时的 token 流再原样回写。结果是错的，而且错得很隐蔽：
`Tok.i()` 和 `Tok.f()` 内部都会调用 `self.s()`，所以覆写 `s/i/f` 会让每个
token 被记录两次（回写后形如 17 17 22 22）。更根本的问题是：重建 token 流
必须逐字节复刻空白、换行、以及 @BIN@ 标记与二进制块之间的边界，任何细节偏差
都会让读取器**静默错位** —— 不报错，只是网络变傻。

## 现在的做法：原地打补丁

.bin.gz 解压后是一整块字节，权重数组只是其中若干段连续的 float32。所以：
  1. 解压一次，拿到原始字节
  2. 读一遍（复用 _katago_v17_load 的读取器），记下每个权重块的
     **字节偏移与长度** —— 只记位置，不重写任何 token
  3. 导出时把原始字节整块复制，只在需要替换的权重段上写入新数据
  4. 重新 gzip

元数据（名字、维度、激活类型、epsilon、数字格式、空白）因此**逐字节保持原样**，
不存在错位的可能。可替换的自然单位就是"第 n 个权重块"。

用法:
  python _kg_export.py list      <in.bin.gz>
  python _kg_export.py roundtrip <in.bin.gz> <out.bin.gz>
  python _kg_export.py patch     <in.bin.gz> <out.bin.gz> <patch.pt>
"""
import gzip
import os
import sys

try:
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
except Exception:
    pass

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import _katago_v17_load as L

_BaseTok = L.Tok


class RecTok(_BaseTok):
    """只记权重块的字节位置。

    不要再覆写 i()/f()/s()：它们最终都会走到 s()，覆写两层会让每个 token
    被记录两次。这里只需要 w() 的位置。"""

    instances = []

    def __init__(self, data):
        _BaseTok.__init__(self, data)
        self.blocks = []
        RecTok.instances.append(self)

    def w(self, count):
        v = _BaseTok.w(self, count)
        off = self.p - 4 * count
        self.blocks.append((len(self.blocks), off, count))
        return v


def read_blocks(path):
    with gzip.open(path, 'rb') as f:
        raw = f.read()
    RecTok.instances = []
    saved = L.Tok
    L.Tok = RecTok
    try:
        M = L.load(path, verbose=False)
    finally:
        L.Tok = saved
    if not RecTok.instances:
        raise RuntimeError('没有录到权重块')
    return raw, RecTok.instances[0].blocks, M


def export(src, dst, patch=None, verbose=True):
    raw, blocks, M = read_blocks(src)
    if verbose:
        print('  decompressed %d bytes, %d weight blocks' % (len(raw), len(blocks)))

    total = 0
    prev_end = 0
    for idx, off, cnt in blocks:
        if off < prev_end:
            raise RuntimeError('block %d overlaps previous' % idx)
        if off + 4 * cnt > len(raw):
            raise RuntimeError('block %d out of range' % idx)
        prev_end = off + 4 * cnt
        total += cnt
    if verbose:
        print('  total floats %d' % total)

    out = bytearray(raw)
    n_patched = 0
    if patch:
        for idx, arr in patch.items():
            idx = int(idx)
            if idx < 0 or idx >= len(blocks):
                raise ValueError('block index %d out of range (%d blocks)' % (idx, len(blocks)))
            _, off, cnt = blocks[idx]
            a = np.ascontiguousarray(np.asarray(arr, dtype='<f4')).ravel()
            if a.size != cnt:
                raise ValueError('block %d wants %d floats, got %d' % (idx, cnt, a.size))
            out[off:off + 4 * cnt] = a.tobytes()
            n_patched += 1
        if verbose:
            print('  patched %d blocks' % n_patched)

    with gzip.GzipFile(dst, 'wb', compresslevel=6, mtime=0) as f:
        f.write(bytes(out))
    if verbose:
        print('  wrote %s (%.1f MB)' % (dst, os.path.getsize(dst) / 1e6))
    return blocks, n_patched


def main():
    if len(sys.argv) < 3:
        print(__doc__)
        return 2
    mode = sys.argv[1]
    src = sys.argv[2]

    if mode == 'list':
        raw, blocks, M = read_blocks(src)
        print('blocks=%d total_floats=%d' % (len(blocks), sum(b[2] for b in blocks)))
        for idx, off, cnt in blocks[:30]:
            print('  #%-4d off=%-12d count=%d' % (idx, off, cnt))
        if len(blocks) > 30:
            print('  ... %d more' % (len(blocks) - 30))
        return 0

    if len(sys.argv) < 4:
        print(__doc__)
        return 2
    dst = sys.argv[3]
    print('reading %s ...' % src)

    patch = None
    if mode == 'patch':
        if len(sys.argv) < 5:
            print('patch needs <patch.pt>')
            return 2
        import torch
        patch = torch.load(sys.argv[4], map_location='cpu')
        print('  loaded patch with %d entries' % len(patch))

    export(src, dst, patch)
    return 0


if __name__ == '__main__':
    sys.exit(main())
