# GitHub 下载通道说明（这台机器专用）

> 结论先行：**这台机器上"GitHub 下载不通/太慢"是三层问题叠加，不是网速问题。**
> 最终可用的一条命令（不需要任何第三方代理）：
>
> ```bat
> python tools\fetch_github.py get lightvector/KataGo v1.17.1 b10c384h6nbttflrs.bin.gz --out build_out\github\nets
> ```
>
> 实测 **38.25 MB / 约 16 MB/s / 3 秒**（对比 ghproxy.net 的 260 KB/s，快约 60 倍）。

---

## 一、三层结论（按诊断顺序）

### 第 1 层：curl.exe / PowerShell 的 HTTPS 是坏的 → 一切联网代码用 Python

现象：

```
curl: (35) schannel: AcquireCredentialsHandle failed: SEC_E_NO_CREDENTIALS
PowerShell / Invoke-WebRequest: "基础连接已经关闭: ..."
```

根因：进程拿不到 **Schannel 的 TLS 客户端凭证**（受限令牌/沙箱），**不是网络不通**。
所以：

* ❌ 不要用 `curl.exe`、`Invoke-WebRequest`、`Test-NetConnection`、`iwr` 判断"网络是否通"
* ✅ 所有联网代码走 **Python**（OpenSSL + 自带根证书，不依赖 Schannel）

这条结论对**任何**域名都成立——curl 连 baidu 也会失败，但它证明不了 baidu 不通。

### 第 2 层：`github.com` 本体不可达 → 不要直连，用 API 资产端点

实测（Python）：

| host | 结果 |
|---|---|
| `https://github.com/...` | ❌ TCP/443 超时（DNS 正常，IP 不可达） |
| `https://api.github.com` | ✅ 200 |
| `https://release-assets.githubusercontent.com` | ✅ 可达（关键！） |
| `https://objects.githubusercontent.com` | ✅ 可达 |
| `https://codeload.github.com` | ✅ 可达 |

**关键发现：GitHub REST API 的"下载 release 资产"端点会 302 到
`release-assets.githubusercontent.com`，而那个域名在这台机器上是通的。**
所以根本不需要第三方加速站：

```
GET https://api.github.com/repos/<owner>/<repo>/releases/assets/<asset_id>
Accept: application/octet-stream
→ 302 → https://release-assets.githubusercontent.com/github-production-release-asset/...
```

支持 `Range`（续传），但**资产 id 要用 API 查**：

```bat
python tools\fetch_github.py list lightvector/KataGo v1.17.1
```

`list` 会打印每个资产的 `name / size / id`。

> 注意：未认证的 API 有 60 次/小时限流；下载本身的流量走 CDN，不计入。

### 第 3 层：第三方代理大多不可用，gh-proxy.com 会"假活"

实测（每条都是 `Range: bytes=0-1048575` 真取 1 MiB，不是 HEAD）：

| 通道 | 实测结果 |
|---|---|
| **`api.github.com` asset 302（首选）** | ✅ 206，1 MiB / 1.4 s，完整文件 16 MB/s |
| `https://ghproxy.net/` | ✅ 206，1 MiB / 7.0 s（约 260 KB/s）；**可作第一备选** |
| `https://gh-proxy.org/` | ✅ 206，1 MiB / 1.8 s |
| `https://gh.ddlc.top/` | ✅ 206，1 MiB / 1.6 s |
| `https://gh-proxy.com/` | ⚠️ HEAD 200 但 GET 极慢（1 MiB 用了 38 s 超时；10 分钟 0 字节）——**别优先用** |
| `https://ghfast.top/` `gh.llkk.cc` `ghproxy.cc` `github.moeyy.xyz` | ❌ TLS handshake 超时（14–15 s） |
| `https://hub.gitmirror.com/` `gh.xxooo.cf` `ghproxy.cfd` | ❌ DNS 解析失败 |
| `https://gh.api.99988866.xyz/` | ❌ TLS alert handshake failure |
| `https://ghproxy.homeboyc.cn/` | ❌ 403 blocked |
| `https://ghps.cc/` | ❌ 302 到广告页（不是下载） |
| `https://cf.ghproxy.cc/` | ❌ 证书过期 |

镜像站域名换得很勤，`tools/fetch_github.py probe` 可以随时重新体检。

---

## 二、最终命令（可直接复制）

```bat
REM 0) 先体检：哪些通道现在真的能取字节
python tools\fetch_github.py probe

REM 1) 列出某个 release 的资产（名字 / 大小 / asset id）
python tools\fetch_github.py list lightvector/KataGo v1.17.1

REM 2) 下载（首选 api 通道，失败自动回退 ghproxy.net / gh-proxy.org / gh.ddlc.top）
python tools\fetch_github.py get lightvector/KataGo v1.17.1 b10c384h6nbttflrs.bin.gz --out build_out\github\nets

REM 3) 也可以用完整 release URL
python tools\fetch_github.py get-url https://github.com/lightvector/KataGo/releases/download/v1.17.1/b10c384h6nbttflrs.bin.gz --out build_out\github\nets

REM 4) 强制某条通道 / 调整超时重试
python tools\fetch_github.py get lightvector/KataGo v1.17.1 <asset> --channel api --timeout 30 --retries 6
python tools\fetch_github.py get lightvector/KataGo v1.17.1 <asset> --channel proxy:https://ghproxy.net
```

脚本行为：

* 每个通道先试 **api**，再按 `PROXIES` 顺序回退；`--channel` 可锁定单通道
* 每个请求 `--timeout`（默认 20 s）无字节即判失败 → 换下一个通道。
  **这是专门为 gh-proxy.com 那种"连上了但永远不吐字节"的假活代理准备的**
* `Range` 断点续传（`.part` 文件），每次失败保留已下载字节
* 每通道 `--retries`（默认 4）次尝试，无进展时退避 2–6 s
* 下载完做 **gzip 完整性校验**（解压 CRC/截断）并打印 **sha256**
* 全部通道失败时，会打印每条通道的失败原因后退出（非零码）

已知坑：`gh-proxy.com` 的 GET 会挂住，脚本把它放在回退列表**末尾**且从不首选。
如果你手动 curl/wget 之类的工具去试，**一定要加超时**，否则会像我们第一次那样
"10 分钟 0 字节"。

---

## 三、备选资源站（GitHub 全挂时）

这些站这台机器都能开（Python 实测 200），可用于找 KataGo 网络/权重：

* **HuggingFace 镜像**：`https://hf-mirror.com/api/models?search=katago`
  社区镜像上有 KataGo 网络，但基本都是**大网络**（实测：`Paolo626/KataGo` 里的
  kata1 是 b28c512 271 MB；`Jinqi-T/katago` 是 b40c768 863 MB）。
  resolve URL 形如 `https://hf-mirror.com/<repo>/resolve/main/<file>`。
* **ModelScope**：`https://www.modelscope.cn/`（可开，KataGo 网络资源少）
* **Gitee**：`https://gitee.com/`（可开，搜 katago 仓库，基本没有 release 权重）
* 官方源码也能拿：`/repos/lightvector/KataGo/contents/<path>?ref=v1.17.1`
  返回 base64 文件内容（本仓库 `build_out\github\ref\` 里的
  `model_pytorch.py` / `desc.cpp` / `eigenbackend.cpp` 就是这么取的）。
  整棵树：`/repos/lightvector/KataGo/git/trees/v1.17.1?recursive=1`。

---

## 四、本机已拉到的文件（2026-10，v1.17.1 release）

都放在 `build_out\github\nets\`，**没有覆盖仓库根的 `kata1*.bin.gz`**：

| 文件 | 大小 | sha256 | 解析结果 | C++ 引擎可用? |
|---|---:|---|---|---|
| `b10c384h6nbttflrs.bin.gz` | 38,245,488 | `0ba27eced5180b3e3d0b898b280c541112989765e789d1eb6cd0d31b2b2c1229` | v15 / 10 blocks / 384 ch / mid192 / normKind1 | ⚠️ 否：**fixup** 归一化，引擎只实现了 fixscale |
| `b10c512h8nbt3tflrs-fson-silu-rsnh.bin.gz` | 94,281,753 | `c04db4a503721d948bb720324f3cbdac6088cc9eb243632f020e4b6846f58995` | v17 / 10 / 512 / mid256 / normKind1(RMSNorm spatial) | ✅ 是（需 forward.h 的 RMSNorm 补丁） |
| `b11c768h12nbt3tflrs-fson-silu.bin.gz` | 211,660,960 | `1881600caab9e9d85a3dd6a019e9b8e7d2c237b5f984e13ed49a8645be3077c6` | v17 / 11 / 768 / mid384 / normKind0 | ⚠️ 否：`fson` 的 trunk 末端是 **batchnorm**（引擎按 fixscale 算） |

校验工具：

```bat
python tools\check_net.py build_out\github\nets\<net>.bin.gz
```

一步做完：sha256 + gzip 完整性 + Python 解析（`at_end` 必须 True）+
`bench_forward` 原生前向耗时 + `probe_encode --empty` 冒烟
（空盘策略必须落在四个星位，star pts 合计 > 0.15；否则就是"解析对了但算术错了"）。

另：`build_out\github\tools\katago_official\` 是官方 KataGo v1.17.1
eigen(CPU) Windows 版（5.2 MB，同样用上面的 api 通道下的），
可以用来做**数值基准**（`build_out\github\raw_nn2.py` 跑 `kata-raw-nn`
拿官方 policy/value）和**棋力代理指标**（`build_out\github\analysis_run.py`
跑 analysis 引擎，`eval_metrics.py` 算 top-1/top-5/AUC）。

---

## 五、给"另一个能上 GitHub 的网络"的准备

如果以后在别的机器上跑，把 `PROXIES` 和首选通道换一下即可：
在能直连 GitHub 的环境里 `--channel direct` 就是最快的（不加代理）。
脚本本身不依赖本机特性，只有"必须用 Python 而不是 curl"这一条是本机的约束。
