# HANDOFF —— GoAI3 棋力提升工作进展与交接

> 这份文档是给"下次继续做的人（或未来的我）"看的。目标是让任何人读完后，
> 不需要翻会话记录就能知道：**现在是什么状态、哪些已验证、哪些没做完、怎么接着做**。
>
> 最后更新：2026-10-17（工作被打断） / 2026-10-24 复核归档 + GPU 接线 + 全量价值头装机
> 工作目录：`D:\GoAI3\GoAI3\GoAI3`

---

## 0. 一句话现状

引擎**能编译、自检通过、数值回归全过、回归套件 9 项 0 FAIL 0 WARN**。
相对开工时：CPU 前向**快 4.56 倍**（1.0895s → 0.2389s），并且已经**接上 DirectML GPU**，
每手固定时间内的访问数从 ~12 涨到 **~130**（**10 倍以上**）；
搜索层修好了 PUCT 从不生效、FPU 符号反两个真 bug，编码器按官方 `fillRowV7` 重写，
死代码（随机 rollout 整条链，199 行）已清理。

**价值头重训已经收口**：v1（3,000 局面）之后又装上了全量版（7,560 局面），
空盘胜率 0.03% → 54.1%，引擎两条推理路径（DirectML GPU / 原生 CPU）逐局面
一致到 4e-6，代理指标 A/B 的"胜率校准 AUC"从 0.609 → 0.724（见 §7.5 / §7.6）。
搜索的价值项现在是真的胜率信号，不再是垃圾输入。

**还没做的**（收益从大到小）：更小更快的 KataGo 网络（§8）、云端全量重训 +
自对弈闭环（§8）、策略头监督微调（仓库还缺 train_policy.py）。

---

## 1. 已验证的数字（都是真机实测，机器空闲时测）

| 指标 | 开工前 | 现在 | 说明 |
|---|---:|---:|---|
| 单次前向（14 线程 CPU） | 1.0895 s (90.3 GFLOPS) | **0.2389 s (411.9 GFLOPS)** | `bench_forward.exe`，4.56 倍 |
| 单次前向（DirectML GPU） | — | **约 0.070 s** | ONNX Runtime + Arc 130T，约 14 倍于开工时 |
| `--time 10` 实际访问数 | 12 次 / 12.31 s | **134 次 / 10.19 s（GPU）**、36 次（纯 CPU） | GTP `genmove` |
| 搜索深度（空盘自检） | depth=0 | **depth=2~4** | 以前一次模拟只展开一个根子节点 |
| `--selftest` | PASSED | **PASSED** | 6 项全过 |
| `kg/test/test_ops`（算子逐项对齐 PyTorch） | ALL PASS | **ALL PASS** | 内核改动没破坏数值 |
| `kg/test/test_forward`（整网逐张量对齐） | ALL PASS | **ALL PASS** | 误差 ~1e-5 |
| 编码器 vs 官方 `fillRowV7` | 征子特征全错、global[9] 反、领地平面漏棋子 | **已修** | 见 §3.2 |
| 价值头是否可用 | **否**（空盘说行棋方胜率 0.03%，同行换轮次不翻号） | **是（全量版已装）**：空盘 54.1%、test AUC 0.665 / acc 0.605 / Brier 0.235 | 见 §7.5 / §7.6 |
| NPU 推理 | 未知 | **可用：196~285 ms** | 但比 CPU 优化后还慢，不建议 |
| GPU(DirectML) 推理 | 未知 | **76~81 ms**（13 倍） | 已验证，**未接线**，见 §4.2 |

**关键结论：现在这套（不接 GPU、不换价值头）就已经比开工时明显更强**，因为
① 每手能多搜 3 倍 ② 根节点先验不再是"每个合法点各试一次"的假搜索 ③ 网络看到的是真征子。

---

## 2. 怎么跑（立刻可验证）

```bat
:: 从仓库根目录跑（引擎按 cwd 找权重！）
x64\Release\GoAI3.exe --gui --time 30        :: 图形界面，每手 30 秒
x64\Release\GoAI3.exe --cli --time 30        :: GTP（Sabaki/GoGui）
x64\Release\GoAI3.exe --selftest             :: 自检
x64\Release\GoAI3.exe --benchmark            :: 速度与 nn/sim

:: 或双击 run.bat（默认 30 秒/手）
```

编译（本会话 pwsh 不存在，必须用 Windows PowerShell 或 cmd）：

```bat
powershell -NoProfile -ExecutionPolicy Bypass -File tools\build.ps1 -Target exe -OutDir build_out\integrate
```

或者直接：

```bat
cmd /c ""C:\Program Files\Microsoft Visual Studio\18\Community\VC\Auxiliary\Build\vcvars64.bat" >nul && cl /nologo /O2 /EHsc /std:c++20 /W3 /DNDEBUG /utf-8 /openmp /Fe:build_out\integrate\GoAI3.exe /Fo:build_out\integrate\ go_ai.cpp /link gdiplus.lib gdi32.lib user32.lib"
```

> 注：`/utf-8` 必须有（源码是 UTF-8，MSVC 默认按 GBK 解码会解坏中文注释并报语法错）；
> `/openmp` 必须有（kg/infer/ops.h 的多线程路径靠 `_OPENMP` 开启）。
> 主程序用 `/std:c++20`；kg/test/*.cpp 用 `/std:c++17`。

---

## 3. 已完成的工作

### 3.1 搜索层（`go_ai.cpp`，Lead 改的）

| # | 问题 | 后果 | 修法 |
|---|---|---|---|
| 1 | **PUCT 在选择里从不生效**：旧 `descend()` 先把根节点每个合法着法逐个建成子节点，**全部建完才开始用 PUCT**。19×19 根节点约 300 个合法着法，而那时一次前向 1 秒、每手 30 秒只够约 30 次模拟 → 搜索**永远没进入 PUCT 阶段**，等于"直接下网络第一选择"，每次模拟都浪费在一个再也不会被看的根子节点上 | 棋力 ≈ 纯策略网络，搜索完全白做 | 新增 `select_action()`：**未展开的合法着法带着先验和 FPU 估值一起参与 PUCT 竞争**，赢了才建子节点 |
| 2 | **FPU 符号反了**：`q = parent_q - reduction` 再取 `-q` 当子方视角，实际得到 `-parent_q + reduction` | 好局面里不敢探索、坏局面里乱逃 —— 正好反了 | 未访问动作的 Q 改用 `-(parent_q - reduction)` |
| 3 | 根节点先验有方向偏差（空盘四星位概率 0.38/0.27/0.16/0.15，本该接近均等） | 低访问数下**根先验几乎决定选点** | 新增 `--root-symmetries`：**只在根节点**做 8 对称平均（深层叶子仍只评 1 次）。默认 `0 = auto`，按预算自动取 `budget/5` 次，避免 `--time 5` 时把预算全花在根上 |
| 4 | `descend()` 提前返回时 virtual-loss 计数泄漏（节点池满/展开竞争失败） | 池满后选择永久偏向别的分支 | 新增 `descend_abort()` 释放 claim 并清空 path |
| 5 | GTP `genmove` 忽略颜色参数 | 空盘 `genmove w` 会给黑方生成并落子，客户端棋盘错乱 | 校验颜色，不符回 `? illegal move: it is black to move` |
| 6 | `--seed` 在 `--cli` 下无效，genmove 每手用时钟覆盖 seed | **A/B 对局无法复现** | `--seed` 对 `--cli` 生效，genmove 用 `seed ^ f(手数)` |
| 7 | 错误应答用 `=` 不是 `?` | 客户端无法按 GTP 规范判错 | 统一按 `is_error` 输出 `?`/`=` |
| 8 | `komi` 缺参时读未初始化 double（UB） | 贴目变成栈垃圾值且不报错 | 缺参回 `? syntax error`，保留原值 |
| 9 | genmove 出非法着法时静默改走 pass 但仍返回原坐标 | 客户端/引擎棋盘不同步 | 改为报错并保持棋盘同步 |
| 10 | 权重加载顺序 | 没有给"重训过价值头"的文件留位置 | 加载顺序变为 `kata1_value_fixed.bin.gz` → `kata1.bin.gz` → `nn_weights.bin.gz` → `nn_weights.bin` |

补丁脚本都留在 `tools/patch_*.py`（可重放、可审计）：
`patch_search.py`、`patch_root_symmetry.py`、`patch_root_sym_auto.py`、`patch_loader.py`、
`patch_gtp.py`、`patch_vloss_leak.py`、`fix_help_string.py`、`fix_loader_string.py`。

### 3.2 输入编码器（`kg/infer/encode.h` 重写 + `board.h`，encoder-fix 完成）

按官方 `_katago_src/nninputs.cpp` 的 `NNInputs::fillRowV7`（2302-2746 行）逐项对齐：

| 平面/特征 | 修前 | 修后 |
|---|---|---|
| 空间 14/15/16/17 | 「气≤2 的棋子」等近似，15/16 恒 0 | **真 `iterLadders` 征子搜索**（新增 `LadderSolver`）：14=被征子、17=工作点、15/16=前两手盘面 |
| 全局 9（计分规则位） | AREA 时置 1（**反**） | AREA=0 / TERRITORY=1 |
| 空间 18/19（领地） | 只填围空区，**漏掉所有棋子** | `board.h` 新增 `calculateArea()`，棋子算己色 + 单色围空赋值 |
| 全局 14 + 历史截断 | `hasLegalMove` 取反，永远 5 手历史 | `passWouldEndPhase` + friendly-pass 抑制 + `isGameFinished` 截断 |
| 空间 6（劫） | 只有 koLoc | koLoc（superko 未做，见 §4.3） |

证据：`build_out\enc\FINDINGS.md`（含 6 个可人工核对的征子局面 ASCII 平面、真实 139 手棋谱校验）。
性能：编码从 15~32µs 涨到 81~94µs（真实混沌局面），相对 0.24s 的前向可忽略。

### 3.3 CPU 前向内核（`kg/infer/ops.h` + `forward.h`，perf-kernels 改的）

**结果：1.0895s → 0.2389s（4.56 倍，90.3 → 411.9 GFLOPS）**，`test_ops`/`test_forward` 全过。
改法（细节以代码注释为准）：权重转置从"每次调用都转一遍"改成复用、内层循环向量化/分块、
并行粒度调整、掩码 fast path 等。
> ⚠️ 注意：perf-kernels 的**最终报告没来得及发**，所以"每一项贡献多少"没有记录；
> 但数值回归是干净的，可以放心用。若以后还要继续优化，见 §4.4。

### 3.4 评测裁判（`tools/match.py`、`tools/verify.py`，eval-harness 完成）

- `tools/match.py`：双引擎 GTP 对局驱动，固定 `--max-sims/--threads/--komi`、固定开局
  （可从 96k 棋谱取前 N 手）、黑白交换、双方连续 pass 后中国规则数子+贴目、
  Wilson95/精确二项/SPRT/功效分析、SGF、JSON、超时与非法着法容错。
- `tools/verify.py`：`--selftest` + `--benchmark` + GTP 协议探针 + A/B 的回归套件，
  支持 `verify.py compare before.json after.json` 做改前改后 diff。
- 用法与已知偏差：`tools/README_match.md`。

**量化结论（重要，决定"要不要相信小改动"）：**
检测 60% 胜率（≈+70 Elo）需 **158 局**；55% 需 620 局；53%(+20Elo) 需 1734 局。
所以**小改动在 CPU 上无法用对局证明**，评估要靠监督指标（策略 top-1、价值 AUC）＋大改动才做 A/B。

### 3.5 NPU / GPU 可行性（tools/README_npu.md + build_out\npu\，npu-accel 完成）

推翻了开工时的两个错误判断：
1. **网络不是完全断**：TCP 通、**HTTP 明文可用**、只有 HTTPS 被 RST；pip 装不上是
   临时目录被沙箱拒绝（`Errno 13`），不是网络。可用镜像命令见 `tools/README_npu.md`。
2. **机器上本来就装着 OpenVINO**（小米 MiService 2024.1 + MI AIService 2024.5），
   `available_devices=['NPU']`，已在 **Intel AI Boost NPU 上真跑通**完整 b11c768 前向。

实测（同一 ONNX 图、batch=1、有背景负载）：

| 路径 | 单次前向 | 相对原 1089ms |
|---|---:|---:|
| C++ 引擎（开工时） | 1089 ms | 1× |
| C++ 引擎（现在，内核优化后） | **239 ms** | 4.6× |
| ORT CPU EP（oneDNN） | 346.7 ms | 3.1× |
| **ORT DirectML GPU（Arc 130T）** | **76–81 ms** | **13–14×** |
| **NPU（Intel AI Boost，自带 OpenVINO 2024.1）** | 196–285 ms | 3.8–5.5× |

数值：DML policy max|Δlogp|=1.1e-5、top1 一致、value 3.8e-6；NPU(fp16) top-1 5/5 一致、
策略分布最大偏移 1.8%、value ≤0.16。NPU 的 batch=8 编译器直接拒绝，多流不提吞吐。

---

## 4. 没做完的工作（按性价比排序）

### 4.1 【已完成 v1；全量精修在跑】价值头重训

> 进度：**v1 已训练、已导出、已装进引擎（见 §7.5）**；后台正在用全量 7,560 局面
> 重训一版，完成后替换同名文件即可，步骤见 §7.5 的"重新导出 ONNX"。
> 下面保留当初的问题定性与管线说明，作为背景。

**问题定性（已定量证明）**：这个权重文件的价值头是坏的。
16680 个真实 pro 局面上，旧头给出的行棋方胜率**全部落在 [-1.0000, -0.870]**，
noresult 通道 logit ≈ **-65 ~ -80**（真实对局几乎无和棋，本该接近 0），
空盘说行棋方胜率 0.03%；同一盘面只换轮次/换黑白，胜率仍在 -0.5~-1.0 乱跳。
→ 它是个常数预测器（AUC 0.626 来自 ±0.03 抖动），**MCTS 的价值项等于不存在**。

**为什么这最值钱**：搜索的两个输入一个是策略（好）、一个是价值（坏）。修好价值 =
搜索终于有"这步之后我好还是坏"的信号，而不是只靠先验。

**已经做完的部分（`value-recal` 做的，全部可复用）：**
- 数据：96,121 局 SGF 已解压（`build_out\value\sgf\games`），筛出 **1,400 局**干净棋谱，
  采样 **16,680 个局面**（每局 12 个，ply 8..200，标签=最终胜者）。
- 一致性验证（最关键的一条 **PASS**）：C++ `dump_enc` 用 `kg/infer/encode.h` 编码 →
  PyTorch 官方模型吃同一份输入，**max|C++−PyTorch|：gpool 1.2e-5、value logits 4.6e-5、
  policy logits 3.8e-5**。（输入编码的唯一真源是 C++，不要在 Python 里重写编码器。）
- 导出通道 dry-run **验证可用**：只改 4 个张量（`v2Mul/v2Bias/v3Mul/v3Bias`），
  437,284 字节变化**全部落在这 4 个载荷区间内**，其余逐字节相同；重新解析 at_end=True；
  装回官方 PyTorch 模型与训练侧 numpy 计算 max diff 4.9e-7。
- 训练脚本已写好并跑通过小样本：**held-out AUC ≈ 0.94**（对比旧头的常数预测）。
- **踩过的坑（务必保留）**：`linear_valuehead` 三通道是 `0=win, 1=loss, 2=noresult`；
  把"是否获胜(1/0)"直接当类别索引会让新头 AUC 恰好变成 1−正确值（看起来像学反了）。
  正确写法：`类别 = 0 if 赢 else 1`。

**还差什么（照顺序做）：**
```bat
:: 1) 特征提取（当时跑到一半被打断，16,680 个局面 × PyTorch 前向）
set OMP_NUM_THREADS=6
python tools\value_features.py --help          :: 先看参数（有缓存/断点续跑）
python tools\value_features.py                  :: 产出 gpool(576维) 特征缓存
:: 2) 训练 + held-out 评估
python tools\value_train.py
:: 3) 导出（生成 kata1_value_fixed.bin.gz，不要覆盖 kata1.bin.gz）
python tools\value_export.py
:: 4) 验证
x64\Release\GoAI3.exe --selftest                   :: 引擎会自动优先加载 kata1_value_fixed.bin.gz
python tools\value_selfcheck.py                    :: 黑白互换一致性（输出应大致取反）
:: 5) 策略命中率基线（同一套数据管道）
python tools\value_policy_eval.py
```
**验收标准**：空盘（贴目 7.5）胜率应 ≈ 45~55%（不是 0.03%）；同一局面黑白互换后
value 大致取反；held-out AUC 明显高于旧头。

> 训练目标必须是**行棋方(pla)视角** —— 引擎 `nn_forward()` 把 value 当"当前行棋方视角"，
> 这样引擎侧不用改代码。

### 4.2 【次高价值】GPU(DirectML) 推理接线 —— 库已写好，没接进引擎

`kg/infer/ort_backend.h`（35 KB，ort-backend 写的）已经实现：运行时 `LoadLibrary` 加载
ONNX Runtime（不引入编译期依赖）、session 单例 + 前向互斥、失败可降级。
**还没做**：① 它的最终报告/数值验收（`kg/test/test_ort.cpp` 有没有跑通不清楚）②
`go_ai.cpp` 里 `forward_katago()` 的分支接线（ORT 可用时走 GPU，否则回退原生 C++）③
重训价值头之后要**重新导出 ONNX**（否则 GPU 路径用的还是旧价值头）。

**收益**：76ms vs 现在 239ms，约 3 倍；相对开工时 14 倍。每手 30 秒从约 125 访问 → 约 390 访问。
**代价**：要带 `onnxruntime.dll` + `DirectML.dll` + 292 MB ONNX；session 创建 6~8 秒；
iGPU 与桌面共享显存。

```bat
:: 建议的接线位置
::   go_ai.cpp : NeuralNet::forward_katago()   在调用 kg::kgBackendForward 之前先试 ort
:: 需要确认
::   kg/test/test_ort.cpp 的数值验收输出（policy maxΔ < 2e-3、value maxΔ < 0.2）
x64\Release\GoAI3.exe --backend ort --ort-model build_out\npu\models\kata1_b11_b1.onnx
```

> 如果重训了价值头：先 `python tools\export_onnx.py --weights kata1_value_fixed.bin.gz`
> 重新导出 ONNX，再让 ORT 与原生两条路径都吃同一份权重，否则数值对不上。

### 4.3 已知未修 / 近似（诚实清单）

1. **平面 6 的 superko 没做**：`kg::Board` 只有 `koLoc`，`go_ai.cpp` 只给 ≤8 手历史，
   长劫循环不可见。要修得先在引擎里维护 superko 历史（改 go_ai.cpp + board.h）。
2. **prevBoard/prevPrevBoard 的提子近似**：`Move` 里没有提子信息，只能反推；
   当前局面 `koLoc` 非空时能精确还原，否则"按没提子"处理。真实棋谱实测 0 误差，
   非劫提子手会少一颗子（只影响平面 15/16）。
3. **`area_score` 不清理死子**（`go_ai.cpp:356`）：只影响 pass-pass 终局判定与自对弈标签，
   对正常对局影响小；做自对弈训练数据前必须修。
4. **叶子批处理没做**：现在前向被一把互斥锁串行化，所以 `--threads` 大于 1 对吞吐几乎无益
   （建议 `--threads 1`）。要再提速只能做"一次前向算 B 个叶子"的异步 MCTS —— 那是大改。
5. **NPU batch>1 编译器限制**、pip OpenVINO 2026.4 的 NPU 插件要求更新驱动（32.0.100.3104 太旧）。
6. 训练/评估侧脚本（`train_alphazero.py`、`export_v3.py` 等）不在本仓库（在原训练机上）。

### 4.4 如果还想继续压 CPU 内核

现状 0.2389s / 411.9 GFLOPS，14 核 AVX2 峰值约 2 TFLOPS，理论还有 3-5 倍空间；
同图 ORT CPU EP 实测 346.7ms（也就是说我们**已经比 oneDNN 快约 30%**）。
下一步主要靠：叶子批处理（摊薄 280MB 权重读取）、attention 的 online-softmax 融合、
更细的 cache blocking。收益递减，优先级低于 §4.1 和 §4.2。

---

## 5. 文件地图（这次工作碰过/新增的）

```
go_ai.cpp                      引擎主程序（Lead 改了搜索层 + GTP + 加载顺序）
go_ai.cpp.bak / .bak2          改之前的快照（可用来 diff/回滚）
kg/infer/ops.h                 算子里程碑：1.0895s → 0.2389s
kg/infer/forward.h             前向（配合内核改动）
kg/infer/encode.h              输入编码器（重写：征子/global9/领地/历史截断）
kg/infer/board.h               新增 calculateArea()（领地平面用）
kg/infer/ort_backend.h         GPU 后端（已写，未接线）
kg/infer/ort/                  onnxruntime_c_api.h（从 pip 包复制）
kg/test/probe_encode.cpp       诊断探针：打印 value logits / 策略 topN / 星位概率 / ownership
kg/test/dump_enc.cpp           编码 dump（价值头重训的数据管道用）
kg/test/test_ort.cpp           ORT 数值验收（可能未跑通，见 §4.2）
tools/build.ps1                统一编译入口（-Target exe|bench|testfwd|testops|...）
tools/patch_*.py               我改 go_ai.cpp 的全部补丁（可重放）
tools/match.py / verify.py     A/B 对局 + 回归套件
tools/README_match.md          评测用法与量化结论
tools/value_*.py               价值头重训管线（manifest/features/train/export/selfcheck/policy_eval）
tools/export_onnx.py           PyTorch → ONNX（GPU/NPU 用）
tools/npu_bench.py / npu_setup.ps1 / README_npu.md   NPU/GPU 实测与安装
build_out\integrate\GoAI3.exe  当前工作树编出来的引擎（已验证 selftest + 数值回归）
build_out\perf|enc|value|ort|npu|match|probe|search|sgf   各条线的产物与证据
```

**注意**：`build_out/` 是产物目录（已加进 .gitignore），里面的证据文件（FINDINGS.md 等）
是这次工作的原始记录，删掉就没了 —— 想留证据请别删 `build_out/`。

---

## 6. 怎么"下次继续"

1. 打开这个项目，跟助手说：**"读 HANDOFF.md，继续做 §4.1 价值头重训"**（或 §4.2）。
2. 想验证现在的棋力：`x64\Release\GoAI3.exe --time 30 --gui` 自己下一盘；
   或 `python tools\verify.py --out build_out\integrate\verify.json` 跑全套回归。
3. 想知道改前改后差异：`python tools\verify.py compare A.json B.json`。
4. 如果只是想把现在的成果固定住：`git log` 里有本次提交，`go_ai.cpp.bak*` 是改前快照。

---

## 7. 2026-10-24 追加：GPU 接线 + 死代码清理 + GTP 完备化

### 7.1 DirectML GPU 后端已接线并默认启用（**这是本轮最大的一步**）

| | 纯 CPU（原生内核） | DirectML GPU（ORT） |
|---|---:|---:|
| 单次前向 | ~0.239 s | **~0.070 s** |
| `--time 10` 访问数 / 深度 | 36 / depth 3（空闲机） | **134 / depth 8** |
| `--selftest` 空盘搜索 | 4~6 访问 | **15 访问，depth 4，1.19 s** |
| 先验归一化 max | 0.4622 | 0.4622（**与 CPU 完全一致**） |
| 数值（对原生 fp32） | — | policy 概率 max\|Δ\| **1.2e-6**、value logits max\|Δ\| **3.1e-5**、top-1 **5/5** |

实现方式（关键点）：
* `kg/infer/ort_backend.h` 是 header-only、**运行时 `LoadLibrary`** 加载 ONNX Runtime，
  没有编译期/链接期依赖；session 单例（建一次 5.5~7 s），前向一把 mutex 串行化。
* 接线点在 `kg/infer/katago_backend.h` 的 `kgBackendForward()`：同一个 `encodeV7` 输入，
  只把前向搬到 GPU；**只有 `provider == "DirectML"` 才用** —— ORT 的 CPU EP（347 ms）
  比原生内核慢，误用会让引擎变慢。
* `go_ai.cpp` 启动时按 `kata1_value_fixed.onnx` → `kata1_b11.onnx` →
  `build_out/npu/models/kata1_b11_b1.onnx` 顺序找模型，找不到/DLL 缺失/provider 不是
  DirectML 都**静默回退原生 CPU**，不崩、不报错退出。新增 `--no-gpu`、`--ort-model P`。

**部署要求（缺一不可，否则自动回退 CPU）**：
1. `x64\Release\` 下放 `onnxruntime.dll`、`DirectML.dll`、`onnxruntime_providers_shared.dll`
   （来源 `build_out\npu\py\onnxruntime\capi\`，已复制好）；
2. 仓库根（= run.bat 的工作目录）放 `kata1_b11.onnx`（278 MB，已从
   `build_out\npu\models\kata1_b11_b1.onnx` 复制好）。

**代价（诚实记录）**：启动多花约 6 s（ONNX session 创建），进程内存 ~1.15 GB（峰值 1.47 GB），
iGPU 共享内存 ~668 MB。启动时会打印 `[gpu] provider : DirectML`，想确认是否真的走了 GPU 看这行。

> ⚠️ **价值头重训之后必须重新导出 ONNX**：`python tools\export_onnx.py`（从
> `kata1_value_fixed.bin.gz` 导出成 `kata1_value_fixed.onnx`），否则 GPU 路径用的还是旧价值头，
> 而原生路径用新价值头 —— 两条路会给出不同的棋。引擎的搜索顺序已经把
> `kata1_value_fixed.onnx` 排在第一位。

### 7.2 死代码清理（199 行）

`rollout()` 及其专属调用链（`tactical_move` / `atari_move` / `local_random_move` /
`influence_winner` / `rnd_int` / `rng_roll` / `is_own_eye`）以及早已没人用的
`gen_candidates()` —— 全部删除。证据：删前 grep 显示这些符号**零外部调用点**，
叶子评估自始至终是网络；`--benchmark` 的 `nn/sim ≈ 1.08` 也证明每次模拟只有一次网络前向。
保留 `is_tiger_mouth`（`move_prior` 还在用）、`move_prior`（无网络时的启发式先验）、
`area_winner`（自对弈判定）。补丁脚本：`tools/patch_remove_rollout.py`。

### 7.3 GTP 完备化（现在回归套件 **0 FAIL 0 WARN**）

新增 `final_score` / `compute_score`（用引擎自己的 `area_score`，与搜索的终局判定同源；
注意它按盘面数子、不清死子，未收完的棋会偏高），并把它登记进 `list_commands`。
上一轮修的 4 个协议 bug（错误用 `?`、`genmove` 校验颜色、`--seed` 生效、`komi` 缺参报错）
已由探针复验确认全部消失。

顺带修了 `tools/verify.py` 的一个**探针自身 bug**：它原来假设"错误也用 `=` 回"（旧引擎的
错误行为），于是引擎改对之后反而把 `play B D4` 被正确拒绝报成 FAIL。现在探针接受规范的
`?` 应答，并把"是否被拒绝"作为正确性判据。

### 7.4 本轮验证记录

```
x64\Release\GoAI3.exe --selftest        -> SELF TEST PASSED（6/6）
kg/test/test_ops.exe ops_ref.bin        -> ALL PASS
kg/test/test_forward.exe kata1.bin.gz ref.bin -> ALL PASS（max|Δ| ~2.6e-5）
python tools\verify.py --skip-benchmark -> RESULT: OK (9 checks, 0 FAIL, 0 WARN)
```

### 7.5 价值头重训 v1 已装进引擎（2026-10-24）

**这是本轮第二个大收益**：价值头从"常数噪声"变成"标定过的胜率"。

| 指标（同一 test 集：612 局面 / 51 局，按棋局划分） | 旧价值头 | **新价值头 v1** |
|---|---:|---:|
| AUC | 0.6557 | **0.7158** |
| 准确率 | 0.5000 | **0.6569** |
| Brier（越低越好） | 0.4795（比恒猜 50% 的 0.25 还差） | **0.2174** |
| 预测胜率均值 | 0.018（恒等于"行棋方必输"） | **0.5144**（已标定） |
| 空盘（贴目 7.5、黑先） | 0.03% | **45.1%** |
| 引擎 `--selftest` 空盘 wr | 65.8%（旧头当时的引擎） | **49.5%** |

分层 AUC（新/旧）：ply 8-40 0.496/0.602（早盘本就是掷硬币，样本小）、40-80 0.543/0.546、
80-120 **0.755**/0.691、120-160 **0.818**/0.740、160-201 **0.830**/0.764 —— **中后盘（搜索真正吃
价值的地方）提升 +0.06~0.08**。

产出的文件（都已放到仓库根，引擎会自动优先加载）：
* `kata1_value_fixed.bin.gz`（249.8 MB）—— 原生 CPU 路径用
* `kata1_value_fixed.onnx`（278.6 MB）—— DirectML GPU 路径用（必须同源，否则两条路棋力不同）
* 导出前做过字节校验：解压流只变了 437,247 字节，**全部落在 4 个目标张量区间内**，
  470 个数组里 466 个逐字节未变；重新解析 `at_end=True`。

**训练方式**（关键约束，决定了天花板）：**冻结 trunk 和价值头第一层**，只重训
`linear2`(576→192) 与 `linear_valuehead`(192→3)，输入是缓存好的 gpool 特征。
所以它只能在"192 维全局池化特征"的信息量里做标定，不能学到新的空间信息。
要再上一个台阶需要连 `v1Conv` 一起重训（要缓存 361×768 的空间特征，代价大得多）。

**视角**：确认是**行棋方(pla)视角**（与引擎 `nn_forward()` 的假设一致，所以 C++ 侧不用改）。
自检证据：黑大优 76 目且黑先 → +0.9427；同局面白先 → −0.9639；空盘黑先 −0.0979。
另外 `tests` 里做过"黑白互换 + 轮次互换 + 贴目取负 → 22 平面逐位相同、输出差异 0" 的
规范化自检（这也是 encode.h 正确性的强力证据）。

**全量版已续上**：覆盖 1,400 局、7,560 局面的重训版本已经装进引擎并重新导出 ONNX，
见下一节 §7.6（本节数字是 v1 的，保留作对照）。

**重新导出 ONNX 的命令**（价值头一变就必须做）：
```bat
tools\export_onnx_fixed.bat                :: = python tools\export_onnx.py --weights build_out\value\kata1_value_fixed.bin.gz
copy /y build_out\npu\models\kata1_b11_b1.onnx kata1_value_fixed.onnx
```
> 注意：`tools\export_onnx.py` 输出的文件名固定是 `kata1_b11_b1.onnx`，所以要手动改名成
> `kata1_value_fixed.onnx`（引擎按这个名字优先加载）。旧的 `kata1_b11.onnx` 属于
> `kata1.bin.gz` 那一对，别覆盖它。另外 onnx 包不在系统 Python 里，脚本里已经设好
> `PYTHONPATH=build_out\npu\py`。

**实测（GPU，`--benchmark`）**：13 visits/s，`nn/sim` 收敛到 **1.02**，前向约 0.077 s/次。
也就是每手 30 秒能搜 **约 390 次**（开工时是 12 次，**32 倍**）。

### 7.6 全量版价值头（7,560 局面）已装（2026-10-24）

v1 用 3,000 局面训练；这一轮把 **全量 7,560 局面**（1,400 局）的版本装进引擎并重新导出 ONNX。

| | 旧头 `kata1.bin.gz` | v1（3,000 局面） | **全量（7,560 局面，已装）** |
|---|---:|---:|---:|
| test AUC（1,660 局面 / 313 局） | 0.6146 | 0.6587 | **0.6652** |
| 准确率 | 0.5054 | 0.5982 | **0.6048** |
| Brier（越低越好） | 0.4764 | 0.2354 | **0.2353** |
| 预测胜率均值 | 0.0172 | 0.4976 | **0.4983** |
| 空盘原生网络 p_win（贴目 7.5、黑先） | 0.00% | 45.09% | **54.14%** |
| 引擎 `--selftest` 空盘 wr | 65.8%（旧头+旧引擎） | 49.5% | **53.4~53.8%** |

文件与同源校验：
* 权重：`build_out\value\kata1_value_fixed.bin.gz`（249.8 MB，md5 `79b81e85…`）拷到仓库根；
  v1 保留在 `build_out\value\kata1_value_fixed_v1.bin.gz`。
* ONNX 重导（**必须做，否则 GPU 路径还是旧头**）：`tools\export_onnx_fixed.bat`
  → `build_out\npu\models\kata1_b11_b1.onnx` → 改名为 `kata1_value_fixed.onnx`。
  292,166,343 B / 4,207 nodes / ir 8 / opset 17 —— **与 v1 导出同尺寸同图**（只有权重值变，
  所以文件大小不变是正常的），md5 由 `39f5dfe6…` 变为 `8da5aeb2…`。
  仓库根的 `kata1_b11.onnx` 属于 `kata1.bin.gz` 那一对，**没动**。
* 逐张量证明同源：新 ONNX 的 4 个价值头张量（`linear2.weight/bias`、`linear_valuehead.weight/bias`）
  与仓库根 `.bin.gz` **逐字节相同**（max|Δ|=0），与 v1 / 旧头都不同；
  trunk / policy 的全部 initializer 与旧导出**逐字节不变**。

引擎验收（`x64\Release\GoAI3.exe --threads 1`）：
```
--selftest            -> SELF TEST PASSED, 空盘 Q16 visits=15~16 wr=53.8% depth=2
--selftest --no-gpu   -> SELF TEST PASSED, 空盘 wr=53.8%（与 GPU 差 0.0pp，<2% 要求满足）
--benchmark           -> backend=KataGo-v17 (DirectML GPU), nn/sim 1.02@3s（收敛 1.0）, 14 visits/s
python tools\verify.py --skip-benchmark --out build_out\value_int\verify.json
                      -> RESULT: OK (9 checks, 0 FAIL, 0 WARN)
```

探针交叉验证（`build_out\value\probe_encode.exe`，原生 C++ 前向）：

| 局面 | value logits (win, loss, noresult) | p_win | winrate() |
|---|---|---:|---:|
| 空盘、黑先 | (3.170, 3.004, -8.828) | **54.14%** | +0.0828 |
| 黑大优≈76 目、黑先 | (3.624, -4.340, -10.735) | 99.97% | +0.9993 |
| 白大优（--swap）、白先 | (1.553, -2.703, -13.352) | 98.56% | +0.9720 |

> `winrate()` 是 **p_win − p_loss**（不是胜率），所以空盘 +0.0828 对应 p_win 54.14%。
> 空盘同局面三条路：GPU 引擎 value=0.0829448 / 原生引擎 0.0829459 / 探针 +0.0829；
> 另外 6 个职业局面上 GPU 与原生根节点价值 **max|Δ|=4e-6** ⇒ 两种后端同源。

代理指标 A/B（150 个固定职业局面：AJ1st 49 局，ply 40/69/100，`--max-sims 32 --threads 1`，
两边 visits 都是 32.0、耗时都是 ~2.8 s/局面）：

| 指标 | 旧头 `kata1.bin.gz` | 全量头 | 结论 |
|---|---:|---:|---|
| 搜索选中着法命中率（== 职业实战着法） | 50/150 = **33.3%** | 45/150 = **30.0%** | 配对 McNemar exact **p=0.332**，**代理指标看不出差异**（甚至略低 3.3pp，不显著） |
| 引擎根胜率对最终胜负的 AUC | 0.6092 | **0.7237** | 配对 bootstrap：ΔAUC=**+0.115**，95% CI [+0.023, +0.209]，P(Δ≤0)=**0.0064** |

分层 AUC（新/旧）：ply 40 0.568/0.468、ply 69 0.723/0.658、ply 100 **0.831**/0.739。
**结论**：32 模拟下选点基本由策略头先验决定，而策略头两版完全相同，所以着法命中率对
价值头不敏感（测不出差异是预期的，不是"变弱了"）；能证明这轮升级的是**胜率校准 AUC**。

**诚实记录的差异**：`--selftest` 空盘 wr 是 **53.4~53.8%**，不是上一轮交接里写的 50.7%。
原因是 selftest 报的是搜索根节点 Q（≈网络 p_win），网络级实测就是 54.14%；50.7% 应该是在
value-recal 自己的旧 exe（`build_out\value\GoAI3.exe`）上测的，那个 build 的搜索/对称平均
与现在的 `x64\Release\GoAI3.exe` 不同。判定"权重装对了"的依据以网络级 54.14% + 双后端一致为准。

**另外一个不影响引擎的细节**：ONNX 里未使用的 aux 价值头张量（`conv_scoring`、`conv_futurepos`、
`conv_seki`、`linear_s2/s3/smix`、`linear_moremiscvaluehead`）在 `_kg_ref.build_state_dict` 里
没有从权重文件映射，每次导出都是随机初值，所以新旧 ONNX 在这些张量上必然不同；
`ort_backend.h` 只请求 policy / value / ownership 三个输出，这三个头都是逐字节同源的，不受影响。

复现命令：`python build_out\value_int\ab\run_ab.py --which old|new --offset 0|75 --limit 75`
→ `python build_out\value_int\ab\analyze_ab.py`；GPU/原生交叉验证：`python build_out\value_int\crosscheck.py`。

---

## 8. 云端 GPU 训练（2026-10-24 追加）

`cloud/README_cloud.md` 是完整手册，结论一句话：
**云端只用来训练，不用来推理**（本地 DirectML 已经 0.077 s/前向，云端 RTT 会把收益抹平）。

能做的事（按性价比）：
1. **全量重训价值头**（~30 分钟、~¥3）：`bash cloud/run_value_full.sh`
   —— 本地 v1 只用了 3,000 局面，云端用全量 16,680（可扩到更多）。
2. **顺手下载更小更快的 KataGo 网络**（可能收益最大）：
   `bash cloud/fetch_stronger_nets.sh b10c128 b6c96`
   —— 固定每手时间下小网络通常比 b11c768 强；本机 HTTPS 被墙所以之前下不了。
3. **AlphaZero 自对弈闭环**（收益最大、最贵）：`bash cloud/run_selfplay_loop.sh`
   —— 复用 `_kg_pipeline.py`，策略目标必须来自搜索访问分布（`--mcts-visits 200+`）。
4. 策略头监督微调：需要新写 `train_policy.py`（仓库目前唯一缺的训练脚本）。

打包上传：`python tools\pack_cloud_bundle.py` → `build_out\cloud_bundle.tar.gz`（约 294 MB，
含 dump.bin / 96k 棋谱 / kata1.bin.gz / 全部训练脚本，已实测可打）。

为此补的一件事：`tools/value_features.py` 新增 `--device cuda`（默认 cpu，行为不变），
否则云端租了 GPU 也用不上（原来只会跑 CPU，1.9 局面/秒）。
`tools/patch_value_features_device.py` 是那次改动的补丁脚本。

**拿回本地后的固定流程**（与 §7.5 相同）：覆盖权重 → `tools\export_onnx_fixed.bat`
重导 ONNX → `--selftest`（空盘胜率必须 45~55%）→ 代理指标 A/B → 才提交。

---

## 9. 2026-10-24 第二轮：FTZ 提速 + 网络选型 + AI Studio 上传包

### 9.1 FTZ/DAZ：白捡 1.1~1.8 倍（已落地）

新一代 KataGo 网络会把大量激活压进 **denormal（次正规数，|x|<1.18e-38）** 区间，
x86 SIMD 处理它们有 10~100 倍惩罚。`go_ai.cpp` 的 `main()` 开头加两行：

```cpp
#include <float.h>
_controlfp_s(NULL, _DN_FLUSH, _MCW_DN);   // 进程级设置一次，线程继承
```

实测（`build_out\github\bench_ftz.exe`，同进程切换）：

| 网络 | 默认 | FTZ+DAZ | 收益 |
|---|---:|---:|---:|
| kata1 现网 | 0.2238 s | 0.2234 s | — |
| 38MB b10c384（fixup） | 0.0865 s | **0.0770 s** | 1.12× |
| 94MB b10c512（fixscale） | 0.3438 s | **0.2423 s** | 1.42× |
| 211MB b11c768（官方） | 0.8279 s | **0.4694 s** | 1.76× |

对现网 kata1 数值**零变化**（`test_ops` 复验 ALL PASS）。补丁脚本：`tools/patch_ftz.py`。

### 9.2 trunk 末端 RMSNorm 语义修复（为 v15+ 网络铺路，已落地）

`kg/infer/forward.h` 的 `trunkNormKind != 0` 分支原来是错的：官方是
`RMSNormMask(spatial)`（**整盘一个标量 RMS** + 每通道 `gamma` **和** `beta`），
我们写成了逐位置 RMS 且丢掉了 beta。用 dump 张量 + 官方公式复算，相对误差 **24.4%**；
修后 `max|d| = 0.0000`。对现网 v17（normKind=0）零影响。

### 9.3 三个官方网络的实际可用性（重要，别再踩）

| 网络 | 大小 | 格式 | 我们引擎能用吗 | FTZ 后前向 |
|---|---:|---|---|---:|
| kata1 现网（b11c768, 自制） | 250 MB | v17 fixscale | ✅ 已验证 | 0.224 s |
| `b10c384h6nbttflrs` | 38 MB | **v15 fixup** | ❌ 需要实现 fixup | 0.077 s |
| `b10c512h8nbt3tflrs-fson-silu-rsnh` | 94 MB | v17 fixscale（末端 RMSNorm） | ✅ **冒烟通过**（空盘星位合计 0.238） | 0.242 s |
| `b11c768h12nbt3tflrs-fson-silu` | 211 MB | v17 **fson（末端 batchnorm）** | ❌ 语义不符 | 0.469 s |

**命名规律**：基础 config 都是 `fixup`；**`-fs` / `-fson` 后缀才是 fixscale**。
我们现网名字里带 `-fs`，所以一直是对的；不带后缀的 38MB 那个是 fixup。

同口径棋力代理指标（800 局面、官方引擎原始 policy/value —— 与仓库 PyTorch 管线那套数字**不可直接比**，只比排序）：

| 网络 | top-1 | top-5 | value AUC |
|---|---:|---:|---:|
| kata1 现网 | 0.4587 | 0.7987 | 0.8289 |
| 94MB | **0.4850** | 0.8013 | 0.8288 |
| 38MB | 0.4725 | **0.8100** | 0.8252 |

结论与下一步：
* **38MB 是最优解**（2.9× 速度、质量不输），但需要实现 fixup —— 正在做（补丁放
  `build_out\github\`，用官方 KataGo 引擎做 oracle 验到 1e-3）。
* **94MB 可以今天就换**（质量 +2.6pp top-1、速度快持平、文件小 2.8×），只需 §9.2 的补丁。
* 211MB 不建议（慢一倍且要补 batchnorm 末端语义）。

### 9.4 一个还没定论的疑点

同一张网络我们引擎在空盘给出"星位合计 0.92、value logits(−6.1, 6.7)"，
官方引擎给"0.15 / 白胜率 0.656"，**所有网络都差这么多**。空盘上空间平面对称，
能造成差别的只有 19 个全局特征，范围很窄；已让 github-fetch 用"top-10 坐标是否相同"
一句话定性 —— 坐标相同就只是 prior 口径差异（不是 bug），坐标不同才是编码错。

### 9.5 AI Studio 上传包（已备好，差最后一步）

```bat
python aistudio\make_upload_bundle.py     :: -> aistudio\upload\goai3_code.zip (3.3 MB)
```

内容：训练/导出脚本 + 官方 PyTorch 模型定义(13 个 .py) + 价值头管线 + 云端一键脚本 +
`kg/infer/*.h` + `kg/test/dump_enc.cpp` + **`data/dump.bin`（16,680 局面编码+标签，24 MB）**。
带 dump.bin 的意义：**AI Studio 上不用编译 C++ 就能直接训价值头**。

数据集已建：`repo_id: caiqiyue2008/GOAI`（id 402034，私有）。
上传走「数据集文件 → 添加文件 → 上传文件 → 网页上传」；
**唯一卡点**：网页上传要弹 Windows 原生文件对话框，浏览器自动化驱动不了（`fill` 明确拒绝
`input[type=file]`），所以最后"选文件"这一步需要人工点一下。
替代方案：用已装好的 `aistudio-sdk` CLI（`tools/install_aistudio_sdk.py` 手工装，
没用 pip 因为沙箱报 Errno 13），命令：
`aistudio upload <本地路径> <远程路径> --repo-type dataset --token <我的控制台→令牌>`。
另：AI Studio 的机器**能直连 GitHub**，所以 250MB 权重其实可以让云端自己 `wget`，
本地只需传 3.3MB 的代码包。

---

## 10. 2026-10-24 第三个重大发现：**归一化语义错位 —— 之前整个网络前向都是错的**

### 10.1 结论先行

`kg/infer/model_load.h` 的归一化实现和官方导出格式有**结构性错位**，导致
**policy 和 value 两个头的共同输入（trunk 末端）一直是错的**。修好后我们的前向与
官方 KataGo v1.17.1 引擎（加载同一个 kata1.bin.gz）**对上了**：

| 空盘黑先 | 修前（我们） | 修后（我们） | 官方引擎 oracle |
|---|---:|---:|---:|
| 四个星位合计 | 0.9229 | **0.1535** | **0.1523** |
| 八个 komoku 合计 | 0.0168 | **~0.66** | **0.664** |
| 黑方胜率 | 0.0%（黑必胜/必败） | **34.4%** | **34.1~34.4%** |

4 手局面（B Q16 / W D4 / B D16 / W Q4）也与官方逐点吻合（top 值 0.237/0.236/0.168/0.155
对官方 0.245/0.227/0.164/0.162）。

### 10.2 根因（两处，都在 `model_load.h`）

官方导出器 `export_model_pytorch.py` 的 `write_bn()`（402-453 行）写进 `.bin.gz` 的是：

```
running_mean        = BN 的均值（非 BN 时为全 0）
running_var         = max(1e-20, running_std^2 - 1e-20)   （非 BN 时 1 - 1e-20）
"scale/gamma" 槽位   = scale*(gamma+1) / scale*gamma / scale   ← 已经把逐层 scale 乘进去了
beta
```

官方前向（`NormMask.forward` + `apply_gamma_beta_scale_mask`）可以统一成一条：

```
y = ((x - running_mean) / sqrt(running_var + eps)) * slot + beta      （eps 用文件里的 1e-20）
```

**错误 1**：`setScaleMul()` 硬编码 `scaleMul = 1/sqrt(block+1)`、`0.5*(1+gamma)`，
把 `running_mean/running_var` 读进来却**从来没用过**。

**错误 2**：两处 `gamma.clear()`（`readNormActConv` 里按 `useGamma` 清、以及 trunk 末端
`T.trunkTipNorm.gamma.clear()`）把文件里的**最终乘子**当成了"无用的 gamma"扔掉了。

对 kata1 的 p/q 分支，硬编码值恰好等于文件里的值（所以 `test_forward` 一直对得上、
一直没暴露），但 **trunk 末端那层真实 batchnorm 被整个跳过** —— 这就是"policy 分布
与官方不同 + value 完全错"的根因。

### 10.3 影响面（重要）

1. **"价值头坏了"是误判**：原始 `kata1.bin.gz` 的价值头在正确 trunk 下是健康的
   （空盘黑胜率 34.4%，与官方一致）。之前那两轮价值头重训（v1/全量）是在**错误的特征**上
   学的，属于"给错题打补丁"。
   → `kata1_value_fixed.bin.gz` 已移到 `build_out\disabled\`，引擎改回用原始 `kata1.bin.gz`。
2. **GPU(ONNX) 路径全部失效**：三个 ONNX 候选都是从错误的 PyTorch 图导出的
   （`_kg_ref.py` 用的 config `b11c768h12bnt3tflrs-fs-silu` 把 trunk 末端当成了非 BN 的
   fixscale）。已全部移到 `build_out\disabled\`，引擎暂时走**原生 CPU（0.24 s/前向）**。
   → 要恢复 GPU，必须用**修好图的 PyTorch** 重新导出 ONNX（config 要用 `-fson-` 语义：
   `norm_kind=fixscaleonenorm` + `bnorm_use_gamma=True`，末端是 batchnorm，
   需要把文件里的 `running_mean/running_std` 和"槽位/scale"拆回 gamma 与 scale）。
3. **编码器的工作不受影响**：encode.h 对齐 `fillRowV7` 是另一条独立的线，结论仍然成立。
4. **搜索层的修复也不受影响**（PUCT/FPU/根对称/vloss 都是纯搜索逻辑）。

### 10.4 修后实测

```
x64\Release\GoAI3.exe --selftest        -> PASSED；空盘 priors max 0.4622 -> 0.2385，genmove R4、wr 35%
python tools\verify.py --skip-benchmark -> RESULT: OK (9 checks, 0 FAIL, 0 WARN)
```

对比很有说服力：同一个 `verify` 里
* 新引擎（修正后）：`empty genmove=R4 visits=5 wr=35.1%`
* 旧引擎（错图）：  `empty genmove=Q16 visits=4 wr=73.0%` / `wr=98.6%`

### 10.5 下一步

1. **重导 ONNX（恢复 GPU 路径）**：修 `_kg_ref.build_state_dict` + 用 `-fson` 语义的 config，
   导出后用官方引擎 oracle 验同一局面的 policy/value（1e-3 内），再放回仓库根。
2. **重评价值头**：在正确特征下测原始头的 AUC/Brier（预期显著优于之前"重训头 0.6652"），
   确认不需要再训。
3. **重新标定搜索参数**：之前所有调参都是在一个错 policy 上做的（policy_temp/裁判口径等），
   修复后要复核 `--benchmark`、代理指标。
4. 补丁脚本：`tools/patch_norm_semantics.py`（可重放；改前快照 `model_load.h.bak`/`.bak2`）。

---

## 11. 2026-10-24 收尾：ONNX 恢复 + 38MB 网络打通 + 编码器残余差异（唯一已知缺口）

### 11.1 GPU 路径已恢复（用**修好图**的 PyTorch 重导 ONNX）

* 产物：仓库根 `kata1_b11.onnx`（292,208,272 B），脚本 `tools/export_onnx_fson.py`，
  说明 `build_out\github\ONNX_FSON_NOTES.md`
* 关键：config 必须是 **`b11c768h12nbt3tflrs-fson-silu`**（`norm_kind="fixscaleonenorm"` +
  `bnorm_use_gamma=True`），state dict 按 `write_bn()` 语义反拆：
  `gamma = slot/module.scale - 1`、`running_std = sqrt(file_var + 1e-20)`
* 数值：PyTorch(fson) vs 我们 native C++ → policy **2.8e-7**、value logit 5.7e-6；
  ORT(CPU) vs PyTorch → policy 1.8e-7。**三者同图，1e-6 级一致。**
* vs 官方 oracle：空盘 policy max diff **3.1e-4**、whiteWin **0.6559 完全一致**
* 实机：`--benchmark` 13 visits/s、`--time 10` = **137 访问**、空盘 R4 / wr 34.9%

### 11.2 38MB 网络（b10c384h6nbttflrs）现在**不需要 fixup 补丁**了

`setScaleMul` 改成统一公式后，fixup 语义天然成立（文件槽位就是 `write_bn` 折好的
`gamma+1`/`1`）。实测（新引擎、无补丁）：**空盘黑方胜率 0.3704 vs 官方 0.3704**，
star orbit 0.1995 vs 0.1956，top-4 一致；3 个中盘里 2 个 top-1 一致。
→ `model_load_fixup.patch` 作废（`build_out\github\` 里仅作历史记录）。

**要不要把它设成默认网络**：它 FTZ 后 0.077 s（现网 0.224 s，2.9×），每访问质量代理指标
不输现网。但它的价值头是官方训练的另一套，切网前建议先跑一次代理指标 A/B（搜索选中
职业着法命中率），确认整体不退化再切。

### 11.3 唯一已知缺口：**编码器残余差异**（影响所有非空局面）

证据：同一输入下 ORT≡C++(1e-6)、C++≡PyTorch(1e-7)，但中盘 vs 官方 oracle 的
policy **max diff 0.04~0.13**（mean <1e-3），个别局面 top-1 不一致。
空盘（只有全局特征起作用）差 3.1e-4 —— 所以问题在**只有中盘才会用到的平面**：

按可能性排序：
1. 征子平面 **14/15/16/17**（`iterLadders` 的重复局面、劫禁、workingMoves 语义）
2. 领地平面 **18/19**（官方 `calculateArea` 的 pass-alive / 大领地分支）
3. 历史平面 **9..13** 的截断与交替规则
4. 全局 **14**（passWouldEndPhase）
5. 超劫平面 **6**（我们只有 `koLoc`，没有 superko 列表）

排查方法（已交给 encoder-fix）：用 Python 按 `nninputs.cpp::fillRowV7` 复刻官方编码器 →
与 `build_out\github\normfix\dump_io.exe` 导出的我们的平面逐平面 diff →
用官方引擎 `kata-raw-nn N` 做端到端验收（目标：中盘 policy max diff <2e-3）。

### 11.4 这一轮的教训（写给后来人）

* **"PyTorch 与 C++ 对得上" 不能证明实现正确**：两边可能用的是同一张**错的图**。
  唯一可信的参照是**官方引擎**（`katago.exe` 加载同一个 .bin.gz，`kata-raw-nn` 取原始输出）。
* 验证网络实现的正确顺序：① 空盘（只测全局特征 + 图）→ ② 中盘（加历史/征子/领地）
  → ③ 与 oracle 逐点对数。空盘对上不代表中盘对。
* 网络权重文件里的 `running_mean/running_var` 一旦不是默认值，说明那一层是 **batchnorm**，
  必须真的做归一化 —— 只是"乘个常数"会让整条 trunk 输出偏移，而且不会报任何错。

### 11.5 AI Studio 上传：已完成（2026-10-24 12:32）

数据集：**`repo_id: caiqiyue2008/GOAI`**（id `402034`，私有）
已上传：**`goai3_code.zip` 3.23 MB**（第 5 个 commit `add goai3 code bundle + encoded data`）
核对：commit 列表 + 文件列表 + 大小（3.23 MiB ↔ 本地 3,390,xxx 字节）一致。

* 网页上传路径（可复用）：数据集详情 →「数据集文件」→「添加文件」→ 悬停展开 →「上传文件」
  →「网页上传」→ 点「点击或拖拽文件到此处」选文件 → 填 commit →「确定」
  （单次 ≤10 个文件、总量 ≤500 MB）
* 命令行路径（更适合 250 MB 权重）：`python tools/aistudio_upload.py [文件]`，
  令牌三选一（`AISTUDIO_TOKEN` 环境变量 / `aistudio/.token` 文件 / `--token`），
  已 `--dry-run` 验证；SDK 装法见 `tools/install_aistudio_sdk.py`
  （不用 pip：本机沙箱 pip 解包 Errno 13；py3.14 的 psutil 用 cp37-abi3 轮子，
  pycryptodome 无普通 cp314 轮子 → 写了 `Crypto` 占位 shim，上传路径不需要 AES）。
* 本地包已升级到 **v2**（多了 `export_onnx_fson.py` / `check_net.py` /
  `patch_norm_semantics.py`，并含 `HANDOFF.md §10/§11`）。AI Studio 上目前是 v1，
  内容差异仅这 3 个开发脚本；要更新就用上面任一路径重传一次。
* **还没传的**：250 MB 权重（`kata1.bin.gz`）。云端其实不一定需要它：
  AI Studio 的机器能直连 GitHub，可以直接
  `wget https://github.com/lightvector/KataGo/releases/download/v1.17.1/b11c768h12nbt3tflrs-fson-silu.bin.gz`
  但注意**必须带 `-fson` 后缀的 fixscale 版本**（我们引擎现在也支持不了的 fson 末端
  batchnorm 已在 §10 修好，两种都能读，但 `-fson` 是我们验过与官方逐点一致的那条）。

---

## 12. 2026-10-24 编码器第二轮：与官方**逐平面完全一致**

### 12.1 结果（`build_out\enc2\REPORT_ROUND2.md`）

用**独立复刻官方 `fillRowV7` 的 Python 实现**（`build_out\enc2\official_encoder.py`）做 ground truth，
对 10 个中盘局面（ply 40/72/104/136/168/200×2，komi 5.5~7.5，tromp-taylor）逐平面比对：

```
planes_wrong = []      globals wrong = []      （10/10 局面）
```
修前：plane 14/15/16/17 在 5/10 局面错、plane 6 在 5/10 局面漏点。

这轮修的三处（都在 `kg/infer/encode.h`）：
1. **征子求解器重写成官方 `board.cpp` 的逐行移植**：补上防守方 `findLibertyGainingCaptures`
   （提子长气逃出——以前完全没考虑）、根节点清劫、防守方遇劫直接判逃、25000 节点/542 栈深、
   双劫死、剪枝与上下界早退、ko 成立条件。
2. **平面 6 补上 superko**：官方 `getPosHashAfterMove` 会把"自杀掉的整串"一起 XOR 掉，
   所以"自杀但盘面不变"的一手会命中当前局面哈希 → 判 superko 禁着。用官方引擎吐的
   `policy=-1` 掩码逐点验证，10/10 一致。
3. `Rules::friendlyPassOk = false`（= 官方 tromp-taylor 预设 = 本引擎两 pass 终局规则）。

验收：`--selftest` PASSED（空盘 R4 / wr 35.0%，先验 max **0.1741**）；
空盘四星位合计 **0.1535**（官方 0.1523）；`tools\verify.py` **9 项 0 FAIL 0 WARN**。

### 12.2 【重要】oracle 方法必须改：analysis 模式不是 symmetry 0

「中盘 policy max diff 0.04~0.13」的**主因是对比方法，不是编码器**：

* 最差局面 p08：`analysis` 说 top-1=J5、maxdiff 0.166；
  而同局面的 GTP **`kata-raw-nn 0`** 说 **top-1=H4（与我们一致）、maxdiff 0.0086**。
* 官方**自己 8 个 symmetry 之间就差 0.02~0.05**（把 8 个 symmetry 全换算回棋盘坐标后比）。

→ **以后所有 oracle 对比一律用 `kata-raw-nn 0`（或显式固定 symmetry），
analysis 那套做不到 1e-3 判据。** §11.3 里"H16 vs G4"的 top-1 不一致就是这个现象。

### 12.3 修好 oracle 之后真正的残余：**policy head**

symmetry 0 下 p00：value **0.523782 vs 官方 0.523780（1e-6 级，完全一致）**，
但 policy 还差 **0.0198**（p08 是 0.0086）。

价值是 trunk → v1Conv → gpool 出来的，value 既已 1e-6 一致 ⇒ **trunk 是对的**，
policy 的差只能在 **policy head**：gating/global-pool 路径、最后 1x1 conv 的 bias、
或激活/注意力的数值实现。下一步排查顺序（交给 encoder-fix）：
① 用 `kata-raw-nn 0` 做 20~30 局面 oracle，确认残差稳定在 1e-2 量级；
② 逐层对齐 policy head 的中间张量（gating 乘子、最后 1x1 conv logits），定位分叉层。

### 12.4 新增可复用工具（`build_out\enc2\`，均可重跑）

`official_encoder.py`（官方编码器独立复刻）、`compare_mid.py`（逐平面 diff + oracle + 端到端）、
`diff_one.py`、`run_in.exe`（任意 .in.bin → 我们的 forward，隔离编码器与网络）、
`raw_nn3.py`/`raw_nn_multi.py`（kata-raw-nn 单/多 symmetry）、`dbg_search.py`/`ltr.exe`（征子逐节点 trace）。

官方 v1.17.1 源码（`board.cpp / search*.cpp / rules.cpp / analysis.cpp / boardhistory.cpp /
desc.cpp / nninputs.cpp` 等）已拉到 `_katago_src/` —— **以后查官方语义不必再猜**。
