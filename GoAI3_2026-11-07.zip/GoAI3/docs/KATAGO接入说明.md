# KataGo v17 神经网络接入说明

原来的 `go_ai.cpp`（32 通道小 CNN + MCTS）现在可以直接使用 KataGo 官方发布的
70M 参数 transformer 网络。**MCTS、rollout、prior 分配、GUI、GTP 全部沿用原逻辑**，
只换掉了网络后端。

---

## 一、接入点

整个改动集中在 `NeuralNet` 的两个方法，接口契约完全不变：

```cpp
bool NeuralNet::load(const std::string& path);        // 多一条 KataGo 分支
bool NeuralNet::forward(const Board& b,
                        const std::vector<const Board*>& history,
                        std::vector<float>& policy,   // 362 维，已 softmax，[361]=pass
                        float& value);                // [-1,1]，当前方视角
```

搜索侧一行未改，因为它只检查 `g_nn.loaded` 与 `params.use_nn`：

- `expand_node()` 第 1841 行：`net_ok = params.use_nn && g_nn.loaded`
- `run_simulation()` 第 2085 行：同样只判断 `loaded`

### 新增文件

| 文件 | 作用 |
|---|---|
| `kg/infer/katago_backend.h` | 适配层：加载 + 前向 + 互斥保护，不依赖 `go_ai.cpp` 的类型 |
| `kg/infer/*.h`（原有） | 推理栈：gzip 解压、v17 解析器、算子、前向、V7 编码 |
| `kg/test/*.cpp` | 推理栈的自检（与官方 PyTorch 逐层对齐） |

### 关键实现细节

**1. 格式识别**：认 gzip 魔数 `1f 8b`，不认扩展名，所以 `kata1.bin.gz` 改名成
`nn_weights.bin` 也能正确走 KataGo 分支。加载顺序：
`kata1.bin.gz` → `nn_weights.bin.gz` → `nn_weights.bin`。

**2. 历史还原**：`collect_history()` 给的是"新→旧"的连续局面，而 KataGo 的
V7 编码器要"旧→新"的落子序列。适配层用相邻两局做差分还原每一手 ——
落子点就是唯一一个"由空变有子"的点；一个都没有就是 pass。

**3. 线程安全**：`expand_node()` 的注释明确说网络推理发生在锁外、会被多线程
并发调用。原来的小网络 `forward()` 用局部缓冲所以安全，但 `kg::Forward` 持有
复用的激活缓冲，**不是线程安全的**，所以适配层用一把互斥锁把前向串行化。
单次前向约 2 秒，串行化的损失可以忽略。

**4. 对称平均**：`params.symmetries` 是给原来那个小网络的廉价增强。对 KataGo
一次前向 2 秒，ns=8 就是 16 秒/节点，搜索完全跑不动，所以对 KataGo 强制压到
1 次（`nn_forward()` 里判断 `g_nn.is_katago`）。

**5. 时间预算**：默认 `max_time = 5.0` 秒对 KataGo 只够 2 次访问。所以没显式
给过 `--time` 时，加载到 KataGo 会自动抬到 60 秒。用 `--time N` 自己指定。

**6. 工程配置**：`GoAI3.vcxproj` 四个配置都加了
`<OpenMPSupport>true</OpenMPSupport>` 和 `/utf-8`。
- `/openmp`：多线程让前向从 3.3 秒降到 2 秒
- `/utf-8`：源码是 UTF-8，而 MSVC 默认按系统代码页(936/GBK)解码，
  会把中文注释解坏并引发语法错误

---

## 二、用法

### 双击就能下

```
run.bat               AI 每手思考 30 秒
run.bat 120           AI 每手思考 120 秒（更强）
run.bat 20 gtp        GTP 模式（接 Sabaki / GoGui），不开窗口
```

**为什么必须有这个脚本**：引擎是按**工作目录**找权重的，不是按 exe 位置。
直接双击 `x64\Release\GoAI3.exe` 时工作目录就是 `x64\Release\`，那里没有
`kata1.bin.gz`，引擎会**静默退回启发式 AI（根本没用上 KataGo）**。
`run.bat` 先 `cd` 到项目根目录，所以网络一定找得到。

### 命令行

```bat
:: 构建（Release x64）
msbuild GoAI3.vcxproj /p:Configuration=Release /p:Platform=x64

:: 自检（加载网络 + 空盘搜索）
x64\Release\GoAI3.exe --selftest

:: 指定思考时间
x64\Release\GoAI3.exe --time 300

:: 调试：打印网络对每个叶子的原始价值
x64\Release\GoAI3.exe --cli --debug-value
```

权重放在**工作目录**，文件名 `kata1.bin.gz`。
加载顺序：`kata1.bin.gz` → `nn_weights.bin.gz` → `nn_weights.bin`。

### 验证结果

```
GoAI++ build 2026-10-11-katago-v17-backend-1
Neural net loaded: KataGo v17 (.bin.gz), 22 input planes + 19 global features.
  [ok] network I/O contract: policy=362 (want 362) backend=KataGo-v17
  [ok] priors normalise (n=360 sum=1.000000 min=5.56e-05 max=0.5112)
  [ok] empty-board search: move=Q16 nn=yes
        top: Q16/1 R16/1 D16/1 E16/1 Q4/1
SELF TEST PASSED
```

GTP 实测：

```
genmove b          -> Q16     （空盘，正确星位）
play w D4
genmove b          -> Q4      （正确挂角）
```

GUI 实测：窗口正常打开，标题显示 `White (AI) to play. B=0 W=0 ...`。

**搜索确实在用 KataGo 网络**（`nn=yes`），走出的着法与真实 KataGo 一致。

---

## 三、已修的一个真实 Bug

`kg/infer/forward.h` 的 `winrate()` 原来写成：

```cpp
double d = w + l + n;
if (d <= 1e-9) return 0.0f;        // ← 把三个通道当概率，但它们其实是 logit
double r = (w - l) / d;
```

空盘时 `d = -3.76 + 4.42 - 85.02 = -84.36`，负数让 `d <= 1e-9` 无条件成立，
于是 `value` **恒等于 0**，搜索拿到一个恒定的"五五开"，价值信号整条丢失。

现在改成正确的做法：三通道是 `linear_valuehead` 的裸 logit，先 softmax 再取
`p_win - p_loss`。

---

## 四、已知问题：value head 过饱和（未解决）

修复上面那个 bug 之后，value 不再恒为 0，但暴露出更本质的问题：

| 局面 | win | loss | noresult | 胜率 |
|---|---|---|---|---|
| 空盘（黑先） | -3.76 | +4.42 | -85.0 | -0.9994 |
| 黑占左上1/4（白先） | -9.74 | +9.38 | -74.7 | -1.0000 |
| 黑占3/4（白先） | -16.98 | +15.74 | -75.4 | -1.0000 |
| 白占3/4（黑先） | -16.94 | +15.64 | -74.5 | -1.0000 |
| 黑一子被打吃（白先） | -2.80 | +3.42 | -67.3 | -0.9960 |

**好的部分**：value 随局面单调变化（白方越来越差：-3.76 → -9.74 → -16.98），
方向是对的，不是随机噪声。

**问题**：空盘上 win/loss 的 logit 差就有 **8.18**，等于说"黑输 99.97%"。
对一个训练好的网络，空盘应当接近 50%。这个量级的 logit 差不可能。

**已排除**：
- trunk 正确 —— 策略头在空盘给出四个星位共 95% 概率，与真实 KataGo 一致
- `gpoolValueApply()` 正确 —— 三路系数 `1.0 / 0.5 / 0.15` 与官方
  `KataValueHeadGPool` 逐项吻合
- 数值实现正确 —— 整网 45 个中间张量 + policy + value + ownership 与官方
  PyTorch 逐层对齐（误差 1e-5）

**剩余嫌疑**：value head 最后两层（`linear2` 576→192、`linear_valuehead` 192→3）
与文件里 `v2Mul/v2Bias`、`v3Mul/v3Bias` 的关联可能错位。文件里还有
`sv3Mul/sv3Bias`(6→`linear_miscvaluehead[0:6]`)，三者容易串位。

**影响**：MCTS 的叶子价值近乎恒定（都是"当前方输"），所以搜索实际上退化成
**由策略先验驱动**。这不会让它下坏棋（策略是已验证正确的强信号），但价值项
贡献不了信息。GUI/GTP 显示的胜率也会失真（恒显示 ~100%）。

**下一步**：核对 `model_pytorch.py` 里 `ValueHead` 的参数注册顺序与
`desc.cpp` 读取 `v2*`/`v3*`/`sv3*` 的顺序，确认哪一组对应 `linear2`。

---

## 五、性能

| 项目 | 数值 |
|---|---|
| 加载权重（解压 250 MB + 解析） | 约 3.3 秒 |
| 单次前向（14 线程） | 约 2 秒 |
| 搜索速度 | 约 0.4 visits/秒 |

对比原来的 32 通道小网络（约 320–360 visits/秒），**慢约 800 倍**。
这是 CPU 跑 70M transformer 的硬限制，不是代码问题。

### 已修：时间预算失控

`search_worker` 原来每 **8 次**模拟才看一次表：

```cpp
if ((done & 7) == 0) {  /* 检查 max_time */ }
```

对原来那个小网络，8 次模拟约 25 毫秒，无所谓。但 KataGo 一次前向 2.6 秒，
8 次就是 21 秒，再乘上线程数 —— 实测 `--time 8` 跑了 **175 秒**，
AI 看起来像"思考到天荒地老"。现在改成每次都看表（读时钟是纳秒级，
相对 2.6 秒完全可以忽略）。实测 `--time 10` → **14.9 秒**。

仍有约 1.5 倍超出（线程在途的那次前向无法中断），可以接受。

### 实用建议：换小网络

`b11c768` 是 KataGo 里**最大的一档**。如果每手 30 秒太慢，最有效的办法是
换一个小网络 —— KataGo 官方还发布 b6c96 / b10c128 / b15c192 / b18c256 等：

| 网络 | 相对速度 | 相对棋力 |
|---|---|---|
| b6c96 | 约 50 倍快 | 仍远超原来的 32 通道 CNN |
| b10c128 | 约 25 倍快 | 同上 |
| b11c768（当前） | 1× | 最强 |

换网络只需替换 `kata1.bin.gz`，代码不用改（解析器按文件里的块数/通道数自适应）。
但要确认目标网络也是 **v17 格式**，且归一化是 **fixscale**（当前实现按 fixscale
解析，fixup 的公式不同）。

---

## 六、本次删除的内容

按"只保留库、删掉独立程序"的要求删除了：

- `kg/kgai.cpp`（独立命令行 AI）、`kg/play.cpp`（独立交互对弈）
- `kg/build/*.exe`、`kg/README.md`
- `下棋.bat`、`构建kg引擎.bat`、`构建kg测试.bat`、`编译验证.bat`

**保留**：`kg/infer/*.h`（接入必需的推理栈）、`kg/test/*.cpp`（数值验证）、
`kg/build/ref.bin` 与 `ops_ref.bin`（自检参考数据）、`_katago_src/`（官方源码对照）。
