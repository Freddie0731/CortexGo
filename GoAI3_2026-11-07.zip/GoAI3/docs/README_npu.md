# NPU / GPU 推理加速：结论、证据、脚本（KataGo v17 b11c768 实测）

> 目标机器：Intel Core Ultra 5 225H（Arrow Lake-H，14 逻辑核）+ Intel Arc 130T（共享显存）
> + Intel AI Boost NPU（驱动 32.0.100.3104，Status=Started）。
> 网络模型：`kata1.bin.gz`（KataGo v17，config `b11c768h12nbt3tflrs-fs-silu`，SiLU）。
> 所有数字均为 **batch=1、同一局面、19×19、fp32/fp16 对比** 的**单次完整前向**（9 个输出头全算），
> 测试时机器上还有 4 个 agent 在跑（CPU 有背景负载），`OMP_NUM_THREADS=4`。

---

## 0. 一句话结论

**NPU 能用**——机器上本来就装着能驱动这颗 NPU 的 OpenVINO 2024.1（小米 MiService 自带），
用 ctypes 直调 `openvino_c.dll` 即可在 NPU 上真实执行网络，**不需要 pip、不需要联网、不需要管理员**；
但**单次前向 196–285 ms，只比同样图的 ONNX Runtime CPU（346.7 ms）快 1.2–1.8 倍**，
单独用它扛不起延迟目标。**真正值得落地的是 DirectML GPU：76–81 ms/次**（比现在 C++ 引擎 1089 ms 快 13–14 倍，
数值与 fp32 完全一致）。另外**只把 CPU 侧的卷积换成 oneDNN/ORT，就能从 1089 ms 降到 346.7 ms**（3.1×），
这是不需要任何新硬件、也不需要改棋力逻辑的确定性收益。

---

## 1. 环境盘点（全部为实测原始输出）

### 1.1 NPU 硬件 / 驱动在

```
pnputil /enum-devices /class ComputeAccelerator
  Device Description: Intel(R) AI Boost
  Status:             Started
  Driver Name:        oem28.inf          (npu.inf, Intel Corporation)
  Driver Version:     10/25/2024 32.0.100.3104

C:\Windows\System32\DriverStore\FileRepository\npu.inf_amd64_834dea82912b5189\
  npu_driver_compiler.dll   (81 MB, NPU 编译器)
  npu_level_zero_umd.dll    (Level Zero 用户态驱动)
  npu_dml_compiler.dll      (127 MB, DirectML/计算编译器)
  npu_kmd.sys / npu_d3d12_umd.dll / ze_loader.dll
```

### 1.2 系统 ONNX Runtime（决定 GPU/NPU 能否"白嫖"）

`C:\Windows\System32\onnxruntime.dll` = **1.17.1**（Windows ML 精简版，10.5 MB）。
`OrtGetAvailableProviders` **没有被导出**（它是 `OrtApi` 结构体成员，不是全局符号），
所以直接看它导出了哪些符号——这 5 个就是它的全部：

```
OrtGetApiBase
OrtGetWinMLAdapter
OrtSessionOptionsAppendExecutionProvider_CPU
OrtSessionOptionsAppendExecutionProvider_DML
OrtSessionOptionsAppendExecutionProviderEx_DML
```

并 **delay-import `DirectML.dll` / `d3d12.dll` / `dxgi.dll`** → **系统 ORT 自带 DML EP（GPU）**，
但没有 OpenVINO/QNN/NPU EP。`onnxruntime.dll` 文件版本 1.17.260613-0100.1。

用 pip 装的 ORT（1.24.4，`onnxruntime-directml`）原始输出：

```
onnxruntime 1.24.4
ORT available providers: ['DmlExecutionProvider', 'CPUExecutionProvider']
```

### 1.3 机器上其实有两套 OpenVINO（关键发现）

| 路径 | 版本 | 组件 |
|---|---|---|
| `C:\Program Files\MI\AIService\1.3.0.179\` | **2024.5.0.17288** | openvino.dll + intel_npu_plugin + gpu/cpu plugin（无 openvino_c.dll） |
| `C:\Program Files (x86)\Timi Personal Computing\MiService\4.0.0.32\MiDeviceService\` | **2024.1.0.15008** | 同上，**并且有 `openvino_c.dll`**（C API，可 ctypes 直调） |

用 ctypes 调 2024.1 的 `openvino_c.dll`：

```
ov_core_create status: 0
ov_core_get_available_devices() = ['NPU']
```

### 1.4 pip 版 OpenVINO 2026.4：能编译 NPU，但不能执行

```
openvino 2026.4.1  available_devices: ['CPU', 'GPU']      # NPU 不在列表里
c.get_property("NPU", "NPU_PLATFORM") = AUTO_DETECT
c.compile_model(tiny, "NPU")                 # AUTO_DETECT 失败
c.compile_model(tiny, "NPU", {"NPU_PLATFORM":"3720"})  # 编译成功（4000/5010 也可）
cm.create_infer_request()                    # 失败：No available devices
```

结论：2026.4 的 NPU 插件要求比 32.0.100.3104 更新的驱动；
**模型转换用 2026.4（它的 ONNX/PyTorch frontend 齐），执行用 2024.1（它的 NPU 插件能开设备）**，
两者用 IR 文件对接（IR v11 两边都认）。

### 1.5 网络：不是"完全离线"，是 **HTTPS 被阻断、HTTP 明文可用**

```
TCP pypi.org:443 CONNECTED / baidu.com:443 CONNECTED / update.microsoft.com:443 CONNECTED
HTTPS https://pypi.org/simple/      -> ERROR 基础连接已经关闭: 接收时发生错误   (TLS 被 RST)
HTTPS https://github.com/           -> 同上
HTTP  http://mirrors.aliyun.com/pypi/simple/ -> 200      <- 可用
HTTP  http://www.baidu.com/                  -> 200
无代理（netsh winhttp show proxy = Direct access；HKCU Internet Settings ProxyEnable=0）
```

pip 第一次失败的真实原因**不是网络**，而是它把解包临时文件写到受限的 `%TEMP%\dsh-*` 被判 `Errno 13`；
把 `TMP/TEMP` 指到工程内目录即可（见 §4 的行命令）。

---

## 2. 实测数字（同一张图、同一局面）

| 路径 | 单次前向 (ms) | leaves/s (@361 点/次) | 初始化/编译 | 与 PyTorch fp32 误差 |
|---|---:|---:|---:|---|
| 我们 C++ 引擎现状（参考值，14 核） | **1089** | 0.9 | - | - |
| 官方 PyTorch CPU（参考值，14 核） | 190 | 1.9 | - | - |
| PyTorch CPU，本机 4 线程（有背景负载） | 2084（min 1411 / max 6614） | 0.48 | - | 基准 |
| **ORT CPU EP，4 线程，同图** | **346.7** | **1041** | session 1.1 s | policy max\|d\| 4.4e-5 |
| **ORT DirectML（Arc 130T GPU）b1** | **75.6–80.9** | **4461–4777** | session 5.7–8.3 s | policy max\|d\| 1.1e-5，top1 一致 |
| ORT DirectML b8 | 605.1 | 4773 | session 6.6 s | - |
| **NPU b1（2024.1 ctypes，同步）** | **285.3**（n=10，271.6–294.9） | **1266** | 编译 49.7 s | top1 5/5 一致，prob max\|d\| 0.018 |
| **NPU b1（2024.1 ctypes，async 1 流）** | 195.8–207.6 | 1739–1844 | 编译 47–52 s | 同上 |
| NPU async 2 流 / 4 流 | 406.7 / 816.2（墙钟） | 1775 / 1769 | - | - |
| OpenVINO 2026.4 GPU | **编译失败**（`ProgramBuilder build failed!`） | - | - | - |
| OpenVINO 2026.4 NPU | 编译 OK（NPU_PLATFORM=3720）但无法创建 infer request | - | - | - |
| NPU batch=8 | **编译失败**：`Got non broadcastable dimensions pair: '6144' and 8'`（2024.1 vpux 编译器的 batch 广播 bug） | - | - | - |

要点：

* **NPU 是"能跑但不算快"**：285 ms 和我们给 CPU 定的 300–400 ms 目标同一档，
  1 路请求就把 NPU 打满（2/4 路并发吞吐不涨：1775/1769 vs 1739 leaves/s），
  所以它没有"靠批处理翻盘"的空间。
* **DirectML GPU 是压倒性赢家**：80.9 ms，而且是 fp32 近似精确（policy 最大误差 1e-5）。
  batch8 只有 7% 吞吐提升 → 单 batch 的低延迟已经够用，不需要为了 GPU 改搜索层。
* **CPU 的确定性收益被低估了**：同一张图，ORT CPU（oneDNN）346.7 ms，
  是当前 C++ 内核 1089 ms 的 1/3.1。这不依赖任何新硬件。

### 2.1 NPU 数值误差（fp16 执行 vs PyTorch fp32，5 个随机合法局面）

```
board  policy top1        pol max|d|  prob max|d|  value max|d|  own max|d|
0      319/319 MATCH      1.0608      0.00679      0.1635       0.02683
1      315/315 MATCH      0.3382      0.00386      0.0249       0.01948
2      290/290 MATCH      0.6828      0.00551      0.0816       0.01045
3      269/269 MATCH      0.4043      0.00682      0.0154       0.01358
4      244/244 MATCH      0.5633      0.01793      0.0083       0.00960

top-1 agreement: 5/5      policy prob max|d| worst: 0.018
```

* **best move 5/5 完全相同**；policy 概率分布最大只移动 1.8% 的绝对概率质量。
* value 头误差 ≤0.16（这 3 个是 value 的 logits，参考值量级 ±40，相对 <0.4%）。
* 这些差异来自 NPU 的 fp16 计算 + 权重转换，属于"可接受"量级；但如果要做 INT8 量化，
  建议先跑一版 policy KL / top-1 一致率再决定（本仓库还没有 INT8 数据）。

---

### 2.2 fp16 / INT8 量化对棋力的影响（以及为什么"批处理"在 NPU 上才划算）

* **fp16（NPU 默认执行精度）实测**：best move 5/5 一致，policy 概率分布最大偏移 1.8%，
  value 头差 ≤0.16（±40 量级），ownership ≤0.027。以 KataGo 的经验，这种量级的扰动
  通常只影响极少数势均力敌的选点，**大概率不改变棋力**；但本仓库没有做对局级 A/B，
  不能给"棋力不掉"的结论，只能说"数值层面风险很低"。
* **INT8 不建议直接上**：policy 头是 log-softmax 输出、value 头对尺度敏感，
  per-tensor INT8 很容易把低概率但正确的着法压掉。若要做，至少：
  ① 只量化 conv（trunk），policy/value 头保持 fp16；
  ② 用 300–1000 个真实局面做 per-channel 校准；
  ③ 验收标准用 **policy top-1 一致率 ≥99% + policy KL < 1e-3**，而不是只看均方误差。
* **批处理的账**：NPU 的算力只有在张量足够大时才喂得饱。b11c768 在 19×19、batch=1 时
  空间只有 361 个点，NPU 实测 196–285 ms/次（约 1.3–1.8k leaves/s）；而 2/4 路并发
  **吞吐不涨**（1775/1769），说明单请求已经把流水线打满——这颗 NPU 的瓶颈不在批大小，
  在算子形状与驱动效率。更糟的是 2024.1 的 vpux 编译器对这张网的 **batch=8 直接编译失败**，
  所以"靠叶子批处理把 NPU 利用率拉起来"在这台机器上走不通（要等新版 NPU 驱动 + 新版
  OpenVINO，才能重新评估）。换句话说：**NPU 的批处理故事在这里是空的，GPU 的批处理
  也只有 7% 收益，不值得为它改搜索层。**

---

## 3. 判断：值不值得把引擎接到 GPU/NPU

**结论：先接 DirectML GPU（值得，13–14×），NPU 暂不接（能跑但收益不足），
同时把 CPU 内核换成 oneDNN/ORT（最稳的 3.1×）。**

1. **GPU (DirectML) 76–81 ms**：对比 1089 ms 是 **13–14×**；对比官方 PyTorch CPU 190 ms 是 2.4×。
   数值与 fp32 一致，不需要量化妥协。代价是：初始化 5.7–8.3 s（进程级一次）、
   292 MB 模型（fp32 ONNX），以及一次性的 ORT C API 集成工作。
   **推荐路线**：引擎里常驻一个 ORT session（`DmlExecutionProvider`），
   `go_ai.cpp` 只换前向调用点；叶子批处理可以先不做（b1 就够了）。
2. **NPU 196–285 ms**：和 CPU 优化目标（300–400 ms）同档，比 GPU 慢 2.6–3.5×；
   而且 vpux 编译器对 batch>1 直接报错（本网络），要靠多请求并发来提吞吐——
   但 1 路已经打满，并发也提不上去。**除非有功耗/占用 CPU 的硬约束，否则不值得接**。
   若要保留，路线已验证：`openvino_c.dll` (2024.1) + IR，全套 ctypes 在 `build_out\npu\`。
3. **异构并行**：GPU 76–81 ms 已远低于搜索层单次开销，NPU 再快也不会改变总耗时量级；
   若将来要"GPU+NPU 同时算不同叶子"，理论上可再叠 1/3 吞吐，但工程复杂度高，收益有限。
4. **风险**：DML 走的是 iGPU（共享内存），与桌面/显示争用；NPU 走驱动 32.0.100.3104，
   升级驱动后 2026.x 路线才"官方支持"。两者都需要**常驻 session / 常驻编译缓存**，
   不能每次前向重新初始化（8.3 s / 49.7 s 无法接受）。

---

## 4. 用户需要执行的确切命令

### 4.1 （推荐）装 Python 推理栈到工程内，不污染系统

在**普通 PowerShell**（不要管理员；需要能访问 HTTP 镜像）里，于仓库根目录执行：

```bat
set TMP=D:\GoAI3\GoAI3\GoAI3\build_out\npu\tmp
set TEMP=%TMP%
python -m pip install --disable-pip-version-check --no-cache-dir ^
  --target build_out\npu\py ^
  -i http://mirrors.aliyun.com/pypi/simple/ --trusted-host mirrors.aliyun.com ^
  onnx protobuf ml_dtypes typing_extensions openvino onnxruntime-directml
```

（本机 HTTPS 被阻断，**必须**用 `-i http://...` + `--trusted-host`；这行已封装进
`tools\npu_setup.ps1 -Mode install`。）

### 4.2 只跑 NPU：不需要装任何东西

NPU 路径复用机器自带的 OpenVINO 2024.1，只需要已生成的 IR：

```bat
python build_out\npu\convert_ir.py --onnx build_out\npu\models\kata1_b11_b1.onnx ^
       --out build_out\npu\models\kata1_b11_b1.xml
set PYTHONPATH=D:\GoAI3\GoAI3\GoAI3\build_out\npu\py;D:\GoAI3\GoAI3\GoAI3\build_out\npu
python tools\npu_bench.py --backend openvino-ctypes ^
       --ir build_out\npu\models\kata1_b11_b1.xml ^
       --ref build_out\npu\models\ref_b1.npz --streams 1 2 4
```

### 4.3 想用 pip 版 OpenVINO 2026.x 直接吃 NPU（需要更新驱动、需要管理员）

当前 NPU 驱动 32.0.100.3104 对 2026.4 太旧（能编译、不能建 infer request）。执行：

1. 从小米/Intel 官网或 Windows Update 安装 **新版 Intel NPU 驱动**（`npu.inf`，管理员）。
2. 重跑 `tools\npu_setup.ps1 -Mode detect`，确认驱动版本高于 32.0.100.3104。
3. `python -c "import openvino as ov; print(ov.Core().available_devices)"` 应包含 `NPU`。

### 4.4 想用 ONNX Runtime 的原生 NPU EP（可选）

```bat
python -m pip install --target build_out\npu\py onnxruntime-openvino ^
  -i http://mirrors.aliyun.com/pypi/simple/ --trusted-host mirrors.aliyun.com
```

### 4.5 完全断网的机器

在能联网的机器上执行 4.1，然后把整个 `build_out\npu\py` 目录拷过来，`PYTHONPATH` 指过去即可。
模型文件（ONNX/IR/ref npz）也可以用同样方式拷。

---

## 5. 复现步骤（从 280 MB 权重到数字）

```bat
:: 0) 依赖（4.1 或 tools\npu_setup.ps1 -Mode install）
set PYTHONPATH=D:\GoAI3\GoAI3\GoAI3\build_out\npu\py;D:\GoAI3\GoAI3\GoAI3\build_out\npu
set OMP_NUM_THREADS=4
set KATAGO_FLEX_ATTENTION=0

:: 1) 官方 PyTorch 模型 -> ONNX（约 4 分钟；需要 onnx 包）
python tools\export_onnx.py --out build_out\npu\models

:: 2) ONNX -> IR（batch 1 和 8 各一份）
python build_out\npu\make_ir.py

:: 3) 三个后端基准
python tools\npu_bench.py --backend onnxruntime --device DmlExecutionProvider --batches 1 8 ^
       --onnx build_out\npu\models\kata1_b11_b1.onnx --ref build_out\npu\models\ref_b1.npz
python tools\npu_bench.py --backend onnxruntime --device CPUExecutionProvider --batches 1 ^
       --onnx build_out\npu\models\kata1_b11_b1.onnx --ref build_out\npu\models\ref_b1.npz
python tools\npu_bench.py --backend openvino-ctypes --streams 1 2 4 ^
       --ir build_out\npu\models\kata1_b11_b1.xml --ref build_out\npu\models\ref_b1.npz

:: 4) NPU fp16 在 5 个局面上的数值误差
python build_out\npu\acc_compare.py --onnx build_out\npu\models\kata1_b11_b1.onnx ^
       --ir build_out\npu\models\kata1_b11_b1.xml --boards 5
```

---

## 6. 文件清单

| 文件 | 作用 |
|---|---|
| `tools\export_onnx.py` | 官方 PyTorch 模型 → ONNX（含 SDPA / RMSNorm 的导出替换、`KATAGO_FLEX_ATTENTION=0`、固定 batch） |
| `tools\npu_bench.py` | 三后端基准：`openvino`（2026.x CPU/GPU）、`openvino-ctypes`（**NPU**）、`onnxruntime`（DML/CPU），输出 ms、leaves/s、数值误差 |
| `tools\npu_setup.ps1` | 检测（NPU 驱动、磁盘上的 OpenVINO、系统 ORT 符号、pip 包）/ 安装（HTTP 镜像 + 工程内 TMP）/ 冒烟 |
| `build_out\npu\ov_c.py` | **OpenVINO 2024.1 C API 的 ctypes 绑定**（NPU 执行的关键；`ov_shape_t` 的 `dims` 是**指针**不是内联数组，这是最容易踩的 ABI 坑） |
| `build_out\npu\convert_ir.py` / `make_ir.py` | ONNX / PyTorch → IR（用 pip OpenVINO 2026.4） |
| `build_out\npu\bench_npu_ctypes.py` / `bench_npu_streams.py` | NPU 单请求延迟 / 多请求吞吐 |
| `build_out\npu\acc_compare.py` | NPU(fp16) vs fp32 多局面数值误差 |
| `build_out\npu\pe_info.py` / `ort_probe.py` / `ov_probe.py` | PE 导出表、系统 ORT 探测、OpenVINO 设备探测 |
| `build_out\npu\dl.py` / `extract.py` | 受限环境下的 HTTP 分块下载 + wheel 手工解包（不依赖 pip 临时目录） |
| `build_out\npu\models\` | `kata1_b11_b1.onnx`（292 MB）、`kata1_b11_b1.xml/.bin`、`kata1_b11_b8.*`、`ref_b1.npz`、`ref_b8.npz` |
| `build_out\npu\py\` | 装好的 Python 包（onnx/openvino/onnxruntime-directml/…），`PYTHONPATH` 指过去 |

---

## 7. 坑与限制（都真实踩过）

1. **HTTPS 全被 RST**：pip 默认源不可用；镜像必须写 `http://` 且 `--trusted-host`。
2. **pip 临时目录被限制（Errno 13）**：把 `TMP/TEMP` 指到 `build_out\npu\tmp`；
   再不行就用 `dl.py`（HTTP Range 4 MB 分块下载）+ `extract.py`（zip 解包），完全绕开 pip。
3. **legacy ONNX 导出**：torch 2.14 的 `torch.onnx.export(dynamo=False)` 需要 `onnx` 包；
   `aten::rms_norm`（opset<23）和 `scaled_dot_product_attention` 不可导出，
   `export_onnx.py` 里已把它们替换成等价基本算子（数值一致，见误差表）。
4. **静态 reshape 陷阱**：batch=1 导出的 ONNX 里 `Reshape` 常量写死了 `[1,768,361]`，
   直接把图 reshape 成 batch=8 会报 `incompatible with input shape` —— batch=8 必须**重新导出**。
5. **NPU 2024.1 编译器不支持本网络 batch>1**（vpux `Got non broadcastable dimensions pair`），
   提吞吐只能多请求并发；但 1 路已打满，并发无收益。
6. **`ov_shape_t` ABI**：`{int64 rank; int64* dims;}`，dims 是**指针**；按内联数组写会
   `access violation reading 0x0000000000000001`。
7. **OpenVINO 2024.1 的 `plugins.xml` 是老的**（指向 MKLDNNPlugin/clDNNPlugin），
   所以这套运行时只能跑 NPU；CPU/GPU 请用 pip 版 2026.4。
8. **2026.4 的 GPU 插件编不了这张图**（`ProgramBuilder build failed!`）——GPU 请走 ORT DirectML。
9. **常驻 session**：DML session 创建 8.3 s、NPU 编译 49.7 s，集成时必须进程级复用，
   否则每次前向都重编译。
