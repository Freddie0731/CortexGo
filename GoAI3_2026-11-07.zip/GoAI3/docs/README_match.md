# GoAI3 A/B 对局驱动与回归验证套件

**这就是"棋力提升"的裁判。** 没有它，内核加速/编码器修复/价值头重训/搜索层调整都只是
"看起来更快"，而不是"下得更强"。

两份脚本（都在 `tools/`，只用标准库，Python 3.14 实测通过）：

| 文件 | 作用 |
|---|---|
| `tools/match.py` | A/B 对局驱动：两个 `--cli` 引擎互下，记录每手、终局数子、Wilson/SPRT 统计、SGF/JSON |
| `tools/verify.py` | 回归套件：产物指纹、`--selftest`、`--benchmark`、GTP 协议探针、A/B 复用；支持改前/改后 diff |
| `tools/README_match.md` | 本文档：用法、假设、已知偏差、耗时、发现的引擎 bug |

---

## 0. 运行前提（**必须从仓库根运行**）

```powershell
cd /d D:\GoAI3\GoAI3\GoAI3
python tools\match.py ...
```

`go_ai.cpp` 的 `load_network_or_report()` 按**当前工作目录**找 `kata1.bin.gz`，不是按 exe
所在目录；在别处运行会**静默退回启发式搜索**（不报错，只是变弱）。两个脚本因此：
- 总是把子进程的 `cwd` 设成仓库根；
- 读引擎 stderr，若看到 heuristic fallback 会写进 `notes`；
- 校准/GT P探针会显示 `[no-nn heuristic search]`。

---

## 1. `tools/match.py` —— A/B 对局驱动

### 1.1 最快自测（不碰神经网络，验证驱动本身）

```powershell
python tools\match.py --a x64\Release\GoAI3.exe --b x64\Release\GoAI3.exe `
    --games 6 --max-sims 1 --max-moves 60 --no-nn `
    --sgf-dir build_out\sgf --sgf-limit 3 --sgf-moves 6 `
    --out build_out\match\control_non_nn.json
```

- 同一个 exe 打自己 = 对称对照，A 胜率应 ≈ 50%（实测 6 局 3:3，见 §6）。
- `--no-nn` 让双方都走启发式，**驱动逻辑毫秒级/手**，适合 CI 式回归。
- `--sgf-dir` 用真实棋谱前 N 手当固定开局（同一开局分别让 A 执黑/执白各下一局）。

固定开局也可以手写：

```powershell
python tools\match.py --opening "Q16 D4 Q4 D16" --opening "R16 D4 P4 D16" ...
```

开局文件（每行一串 GTP 坐标，`#` 注释）：

```powershell
python tools\match.py --opening-file tools\openings.txt ...
```

从 96k 局棋谱里解压一批：

```powershell
cmd /c "tar -xf kg\build\sgf\games.7z -C build_out\match\sgf --include=games/AJ1st/01/*"
python tools\match.py --sgf-dir build_out\match\sgf --sgf-limit 8 --sgf-moves 8 ...
```

### 1.2 真实 A/B（神经网络，小预算）

```powershell
python tools\match.py `
    --a x64\Release\GoAI3.exe --b build_out\GoAI3_test.exe `
    --games 20 --max-sims 4 --threads 2 --max-moves 200 --komi 7.5 --seed 1 `
    --sgf-dir build_out\sgf --sgf-limit 4 --sgf-moves 8 `
    --out build_out\match\ab_001.json
```

也可以只在一边加参数（`--a-args` / `--b-args`，用 `=` 形式避免 argparse 把值当选项）：

```powershell
python tools\match.py --a-args=--no-nn ...        # 只让 A 走启发式
python tools\match.py --b-args="--cpuct 1.4" ...  # 给 B 换搜索参数
```

### 1.3 主要参数

| 参数 | 默认 | 说明 |
|---|---|---|
| `--a/--b` | `x64\Release\GoAI3.exe` / `build_out\GoAI3_test.exe` | 两个引擎 exe |
| `--games` | 10 | 局数 |
| `--max-sims` | 16 | **每个线程每手**的模拟数；总访问 ≈ `threads × max_sims`；单次前向约 `fwd` 秒，则单手提时间 ≈ `max_sims × fwd` |
| `--threads` | 2 | 引擎搜索线程（同时跑多个 agent 时保持 2） |
| `--komi` | 7.5 | 双方引擎及判分都用它 |
| `--max-moves` | 200 | 到这么多手（**含开局手**）仍未双方连续 pass，就按盘面数子结束；`termination=max_moves` |
| `--opening` / `--opening-file` / `--sgf-dir` | 空 | 固定开局；多个开局按 `游戏序号 % 开局数` 轮流用 |
| `--seed` | 1 | 记录并传给引擎；**但当前引擎 GTP 不用它**（见 §5 bug 2） |
| `--engine-args` / `--a-args` / `--b-args` | 空 | 额外引擎参数，如 `--no-nn`、`--cpuct 1.4` |
| `--move-timeout` | 自动 | 单次 genmove 超时；自动 = `max(180, fwd_est × max_sims × 10 + 60)` |
| `--max-total-minutes` | 90 | 按校准的 forward 时间估算总耗时，超了就拒绝启动（`--force` 强制） |
| `--estimate-only` | | 启动引擎+校准+打印耗时计划后退出（不实际下棋） |
| `--plan-only` | | 不启动引擎，只打印统计功效表（要多少局） |
| `--out` | `build_out/match/last_match.json` | 结果 JSON |
| `--no-sgf` | | 不写 SGF |
| `--verbose` | | 打印每一手（默认只打印每局结果，避免 200 手刷屏） |
| `--json` | | 把完整 JSON 打到 stdout |

颜色分配：`A` 在第 1、3、5… 局执黑，第 2、4、6… 局执白（`b` 相反），保证双方黑白各半。
`--games` 为奇数时黑白不平衡，汇总里只有 `a_wins/b_wins`，不做额外修正（脚本不隐藏这一点）。

### 1.4 输出

每次运行的产物都在 `build_out/match/`（这是本任务允许写入的目录）：

```
build_out/match/
├─ last_match.json          # 或 --out 指定的文件
├─ sgf/<run_id>/game_001.sgf ...   # 每局终局盘面 + 全部着法（人工抽查死活用）
└─ logs/engine_a_<run_id>.log      # 原始 GTP 命令/应答 + 引擎 stderr（复现 bug 用）
```

`last_match.json`（schema `goai3-match/1`）关键字段：

```text
config            # 全部参数（含开局、引擎额外参数）
engines.a/b       # exe 路径/size/mtime/sha256/build tag、启动耗时、stderr 摘要、
                  # 校准（空盘 genmove）坐标/访问数/胜率/forward 时间估计
estimate          # 校准后的耗时计划（每手秒数、总分钟）
games[i].moves    # 每手：ply/color/coord/by(A|B|opening)/stats(visits,winrate,depth,
                  # seconds,no_nn)/wall_s
games[i].termination  # double_pass | max_moves | resign | illegal_genmove | ...
games[i].winner / winner_color / score_black_area / score_margin
games[i].stones   # 终局黑白子数
games[i].errors   # 引擎非法着法/协议错误详情（游戏被标记 invalid 并剔出胜率）
summary           # a_winrate、Wilson95、elo、二项检验 p、SPRT、功效分析、终止类型统计
```

### 1.5 统计口径

- **胜率** = A 胜 / (A 胜 + B 胜)，平局（仅整数贴目可能出现）单列，`invalid` 局剔出。
- **Wilson 95% 置信区间**（小样本比正态近似稳）：`summary.wilson95_low/high`。
- **ELO 差**：由胜率换算 `-400·log10(1/p−1)`，并给出 Wilson 区间换算值。
- **显著性**：单侧精确二项检验 `P(X ≥ a_wins | p=0.5)`；`a_significantly_stronger_95` 仅在
  `p ≤ 0.05 且胜率 > 50%` 时为真。
- **SPRT**：`elo0=0, elo1=20`，`alpha=beta=0.05`（可 `--elo0/--elo1` 调）。LLR 在对数似然比
  上下界之间就继续下；到边界给出 H0/H1 结论。和棋忽略（贴目 7.5 不会出现）。
- **功效（要多少局）**：`summary.power_analysis` 用**精确二项分布**搜索最小局数；
  `sprt_monte_carlo` 用固定随机种子模拟该 SPRT，给平均局数、H1/H0 接受概率。

---

## 2. `tools/verify.py` —— 回归/证明套件

### 2.1 一条命令跑全套

```powershell
# 默认：两个仓库自带 exe；artifact + selftest + benchmark + GTP 探针（A/B 默认跳过）
python tools\verify.py

# 完整版：附带一次快速 A/B（启发式，几秒）
python tools\verify.py --match-games 6 --match-sims 1 --match-max-moves 40 `
    --match-args=--no-nn --match-sgf-dir build_out\sgf --match-sgf-limit 2 `
    --match-sgf-moves 4 --out build_out\match\last_verify.json

# 真实 NN 的 A/B（最小预算，仍要几分钟）
python tools\verify.py --match-games 2 --match-sims 1 --match-max-moves 8 `
    --skip-benchmark --out build_out\match\last_verify_nn.json
```

检查项（一张表输出，状态 PASS/WARN/FAIL/SKIP）：

1. `artifact:<label>`：存在性、size、mtime、sha256、build tag（`exe --help`，不加载权重）。
2. `selftest:<label>`：`exe --selftest` 退出码 + `SELF TEST PASSED`，并抽取对称变换、合法着法
   枚举数、prior 归一化、空盘搜索的 move/visits/winrate/depth/policy_sum。
3. `benchmark:<label>`：`exe --benchmark --time T --threads N`；解析每个预算档的
   visits、visits/s、depth、`nn/sim`、`forward_s`。判定：
   - `nn/sim > 2.0` → FAIL（同一局面被评估两次的经典回归）；
   - `nn/sim ∈ (1.75, 2.0]` → WARN；
   - 访问数 < 8 时 `nn/sim` 必然 ≥1.25（根节点扩展那次前向），此时只 WARN 并注明**不可作为
     回归依据**（机器太慢/太忙）；
   - visits 不随预算增长 → WARN（搜索卡死或机器饱和）。
4. `gtp:<label>`：起一个 `--cli --max-sims 1 --threads 1` 进程，检查 `protocol_version == "2"`、
   空盘 genmove 坐标合法、错色 `play` 被拒、错误应答前缀、`final_score` 是否存在、
   `genmove` 是否忽略颜色参数、`komi` 缺参是否被静默接受。已知的 4 个 GTP 问题会记在
   `values.protocol_findings` 里，状态为 WARN（**是记录，不是本次改动引入的失败**）。
5. `match:<store-vs-current>`：复用 `match.py` 跑一小局 A/B（`--match-games 0` 时 SKIP）。
   有 invalid 局或 engine error → FAIL。

常用开关：`--skip-selftest`、`--skip-benchmark`（机器忙时最慢的一项，~1-2 分钟/exe）、
`--skip-gtp`、`--benchmark-time`、`--exe`（可重复）、`--json`、`--out`。

### 2.2 改前 vs 改后对比

```powershell
python tools\verify.py --out build_out\match\verify_before.json      # 改前（旧 exe）
python tools\verify.py --out build_out\match\verify_after.json       # 改后（新 exe）
python tools\verify.py compare build_out\match\verify_before.json `
    build_out\match\verify_after.json
```

`compare` 会摊平两份 JSON（所有检查项状态 + 数值、A/B 汇总），打印 OLD/NEW/DELTA 表并给结论：

- `PASS/WARN -> FAIL`、`nn/sim` 变差 >10%、`visits/s` 下降 >10% → **REGRESSION**（退出码 1）；
- 反之 → IMPROVED；无变化 → NO_CHANGE。

也支持直接 diff 两份 `match.py` 的结果 JSON（schema 不同会自动识别，只比 summary）。

---

## 3. 终局判定与已知偏差（**先读这一节再用结果**）

### 3.1 判定规则：双方连续 pass 后按中国规则数子 + 贴目

- 驱动自己维护一个与 `go_ai.cpp` **逐条一致**的棋盘副本（`Board`：捕获、禁着点=简单劫、
  自杀非法、pass 切换手番、pass 计数），每手 `genmove` 的坐标都先在这上面验合法性，
  `play` 被对方引擎接受后再落子。
- 双方**连续 pass**（`--passes-to-end`，默认 2）即终局：`area_score = 黑子+黑空 − 白子−白空 − komi`。
  与引擎内部 `area_score()` 完全同式，保证"裁判和选手用同一把尺"。
- 到 `--max-moves` 仍未终局：对当前盘面同样数子，`termination=max_moves`。
  **此时棋未下完，结果只反映"封盘时谁实地多"，这是最大噪声来源。**
- 引擎 GTP **没有** `final_score`/`showboard`（`list_commands` 里就没有），所以数子只能由驱动做。

### 3.2 死子问题（重要）

引擎的 `area_score()` 是**最朴素的数子**：盘上白子就算白方，哪怕它已经是死子/被打吃状态。
本裁判沿用同一公式，因此：

- 当棋**真的下到双方连续 pass** 时，双方都认同终局，影响通常可接受；
- 当被 `--max-moves` 截断、或低模拟预算下双方乱下时，**盘面上的死子会被算活**，偏差
  可能很大，而且**对双方不完全对称**（谁的死子多谁占便宜）。
- 缓解手段（脚本已提供）：
  - `summary.double_pass_rate` —— 若明显低于 1，说明大量对局是截断的，胜率可信度下降；
  - `games[i].stones` 与 SGF（`build_out/match/sgf/<run>/`）—— 每局终局盘面都在，可人工抽查；
  - 想要严格终局：把 `--max-moves` 放大（≥250），并接受更长耗时；低预算下引擎本来就不太会 pass。
- 引擎若返回 **非法 genmove**（例如已被占的点、自杀点、劫点），驱动不会崩：记录到
  `summary.engine_errors` 与 `games[i].errors`，该局标 `invalid` 并从胜率中剔除；同时保留
  原始 GTP 应答行（`games[i].raw_genmove_lines`）方便报 bug。

### 3.3 其他偏差

- **贴目固定 7.5**：不会出现和棋；若 `--komi` 用整数可能出现 jigo（单列 draws）。
- **开局**来自 SGF 时取其主线前 N 手；让子局（首手是白）会被跳过并 warning。
  开局手计入 `--max-moves`。
- **`--seed` 不能复现对局**：见 §5 bug 2。可复现的是"配置 + 完整着法记录"，
  想复现某个局面可以用 `play` 重放 `games[i].moves`。
- **no-nn 模式**（`--no-nn`）下引擎叶子价值恒定 50%，`winrate` 字段没有意义，只适合测驱动。
- 引擎注释里的小样本 `winrate=100.0%`、`depth=0` 是网络在 1-4 次访问下的退化输出
  （本机实测所有位置都是 100%），**不要**拿它当棋力信号。

---

## 4. 耗时实测与建议局数

### 4.1 单手提耗时模型

`genmove` 的模拟预算 `--max-sims N` 是**每线程**的：总访问 ≈ `threads × N`，
墙钟时间 ≈ `N × forward`（两个线程并行）。每局第一手额外多一次根节点前向。

| 配置 | 单手时间（前向 1.1 s，空闲机） | 200 手一局 | 10 局 |
|---|---|---|---|
| `--max-sims 1` | ~1.1 s | ~4 分钟 | ~40 分钟 |
| `--max-sims 4` | ~4.4 s | ~15 分钟 | ~2.5 小时 |
| `--max-sims 16` | ~18 s | ~1 小时 | ~10 小时 |
| `--max-sims 32` | ~35 s | ~2 小时 | ~20 小时 |

本机实测（2026-10-17，机器上同时有 PyTorch 训练/内核基准/编码器修复 3 个 agent）：
权重加载 5–10 s，`forward` 实测 **1.8–6 s**（干净时按用户给的 1.1 s），
`--max-sims 1`、12 手一局实测 44–95 s（含波动）。**所有估算都以校准值为准**：
`match.py` 启动后先各跑一次空盘 genmove，用 `seconds/(visits+1)` 得到真实 forward，
再打印 `time plan`，超过 `--max-total-minutes`（默认 90）直接拒绝启动。

### 4.2 "要看 60% 胜率需要多少局" —— 量化答案

`python tools\match.py --plan-only` 会给出精确二项检验（对 p=0.5，80% 功效）的最小局数：

| 真实胜率 | 对应 ELO 差 | 单侧 α=0.05 | 双侧 α=0.05 |
|---|---|---|---|
| 53% | +21 | **1734 局** | 2189 局 |
| 55% | +35 | **620 局** | 786 局 |
| **60%** | **+70** | **158 局** | 199 局 |
| 65% | +108 | 69 局 | 90 局 |

SPRT(`elo0=0, elo1=20, α=β=0.05`) 的蒙特卡洛（1500 次，cap 1200）：

| 真实胜率 | 平均局数 | P(接受 H1 "更强") |
|---|---|---|
| 50% | ~1000（大量跑满 cap） | 0.03 |
| 52.9%（= +20 Elo） | ~990 | 0.44 |
| 55% | ~670 | 0.91 |
| 60% | ~300 | 1.00 |

**结论/建议：**

1. **先跑 `verify.py`（十几秒到几分钟）+ 10~20 局小预算 A/B 看方向**，不要一上来就几十局 × 16 sims。
2. 目标若只是"确认 +60 Elo 级提升"：理论 158 局；按 4 sims、200 手、空闲机 15 min/局 ≈ **40 小时**，
   所以必须**先靠内核加速把 forward 降下来**（forward 从 1.1 s 降到 0.2 s，同样局数只需 1/5 时间）；
   在此之前，用 `--max-sims 2~4` + 少局数只做**方向性**判断（Wilson 区间会非常宽，脚本会直说"不显著"）。
3. 想检测 +20 Elo（53%）需要 ~1700 局，在 CPU 上不现实；SPRT 也会跑上千局。**报告时应明确写：
   当前算力只能可靠证明 ≥60% 级别的大改动，小改动请用更快的内核后再测。**
4. 机器忙时 `--threads 2`（默认）即可；`verify.py --skip-benchmark` 可省掉最慢的一项。

---

## 5. 在 GTP 里发现的引擎问题（**未修改 go_ai.cpp，交给 lead**）

1. **`genmove` 忽略颜色参数**（`go_ai.cpp` `run_gtp` 中读取 `color` 后从未使用）。
   在空盘上发 `genmove w`，引擎会为**黑方**生成并落子，返回黑方着法。
   本驱动永远按 `board.to_move` 请求，所以不会踩到；`verify.py` 的 GTP 探针会自动检测到
   `genmove_ignores_colour=true`。
2. **`--seed` 在 `--cli` 下无效、对局不可复现**：`--seed` 只在 `--selfplay` 分支被解析；
   `run_gtp` 的 `genmove` 里 `gp.seed = 时钟`，每手覆盖。因此同一个 `--seed` 无法逐局复现。
   （`match.py` 仍把 seed 传给引擎以便将来修复后生效；当前请用记录下来的着法回放。）
3. **GTP 错误用 `=` 而不是 `?`**：`play` 非法、未知命令都回 `= illegal move` / `= unknown command`
   （带 id 时是 `=9 illegal move`）。GTP 客户端无法靠第一个字符区分成功/失败，必须自己校验应答
   内容与棋盘。本驱动正是这么做的。
4. **`komi` 缺参数时用未初始化的 double**：源码 `double k; iss >> k; komi = k;`，提取失败时
   `komi` 变成栈上垃圾值（UB），而且不报错。探针记录 `komi_missing_arg_rejected=false`。
5. **没有 `final_score` / `showboard` / `compute_score`**：裁判只能自己数子（见 §3）。
6. **双方连续 pass 后引擎不知道终局**：GTP 循环不做 game-over 判定，继续 genmove 也不会拒绝；
   终局由 `match.py` 判定。
7. **genmove 应答带空格注释**：`= Q16  (visits=.. winrate=..% depth=.. ..s)`；客户端必须只取
   第一个 token。注释里 `winrate=100.0% depth=0` 在极小访问数下是退化输出（见 §3.3）。
8. **内部非法着法兜底会静默 pass**：`genmove` 里若 `play_move` 失败会改走 `play_move(PASS)`，
   但仍把原坐标返回给客户端（`run_gtp`），会造成客户端/引擎棋盘不同步。本驱动若发现
   genmove 返回非法坐标，会记录 `illegal_genmove` 并作废该局，不会崩溃。
9. **工作目录依赖**：权重相对 cwd 找，找不到只在 stderr 提示并**静默退回启发式**。
   这是本任务里真实踩过的坑，`match.py`/`verify.py` 都会检查 stderr 并记录 `nn_fallback`。

---

## 6. 自测证据（2026-10-17，本机原始输出摘录）

同一 exe（`x64\Release\GoAI3.exe`）对自身、无神经网络、6 局、60 手上限：

```
[match] engine A: ...\x64\Release\GoAI3.exe  build=2026-10-11-katago-v17-backend-1  netfile=yes  startup=8.4s
[match] calibration A: D16   visits=2 wr=50.0%0.02s wall  [no-nn heuristic search]
[match] game 1 done: B  W+15.5  moves=60  0.2s
...
valid=6  invalid=0  A wins=3  B wins=3  draws=0
A winrate = 50.0%  (Wilson95 18.8% .. 81.2%)
one-sided binomial p(A>=3 | 50%) = 0.656  -> not significant yet
total wall = 18.4s
```

真实 NN 路径（`x64\Release\GoAI3.exe` = A，`build_out\GoAI3_test.exe` = B，同版本 2 局，每手 1 sim）：

```
[match] calibration A: Q16   visits=2 wr=100.0% 11.72s wall
[match] calibration B: Q16   visits=2 wr=100.0% 11.26s wall
[match] time plan: 2 games x ~12 moves x 4.52s/move = ~2.3 min (forward est 3.75s from calibration)
[match] game 1 done: B  W+7.5  moves=12  95.1s
[match] game 2 done: A  W+7.5  moves=12  43.6s
valid=2  invalid=0  A wins=1  B wins=1  draws=0
A winrate = 50.0%  (Wilson95 9.4% .. 90.5%)
total wall = 180.6s
```

说明：2 局 / 12 手 / 每手 2 访问只能证明"驱动 + 真实 NN 路径正确、黑白交换正确、统计正确"，
**不能**当棋力结论。真实 A/B 请按 §4.2 的局数规划。

`verify.py` 的 GTP 探针（两个 exe 一致）：

```
proto=2  empty=Q16 visits=1 wr=100.0% wall=4.09s  quirks=4
  protocol_findings:
    - GTP errors are sent with '=' not '?' (spec violation)
    - no final_score command: the harness must score the board itself
    - genmove ignores its colour argument (it generates for board.to_move)
    - 'komi' with no argument is silently accepted (should be an error)
```

鲁棒性自测：用一个故意出 bug 的假引擎（`build_out/match/fake_engine.py`，第 3 次 genmove
返回已占点）对真实引擎，驱动没有崩溃，而是记录并作废该局：

```
[match] game 1 ABORTED: illegal_genmove: {'kind': 'illegal_genmove', 'engine': 'A',
         'coord': 'B19', 'index': 1, 'ply': 5, 'board_to_move': 'B', ...}
valid=0  invalid=2  A wins=0  B wins=0  draws=0
ENGINE PROBLEMS (see json .summary.engine_errors):
  - {"kind": "illegal_genmove", ...}
```

规则副本与引擎一致性：用 GTP 重放一个"打劫"序列，引擎对立即提回返回 `illegal move`，
驱动的 `Board` 副本同样拒绝；简单提子、自杀非法、pass 计数、空盘 `area_score=-komi` 均单测通过。

---

## 7. 文件与权限

本任务只写：`tools/match.py`、`tools/verify.py`、`tools/README_match.md`、
`build_out/match/`（JSON/SGF/log/verify 结果）。**未修改** `go_ai.cpp` / `kg/` / 其他 tools。
