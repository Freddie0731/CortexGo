// ============================================================================
//  search.h -- PUCT MCTS 搜索（用神经网络的策略先验与价值）
//
//  简化版 AlphaZero/KataGo 搜索：
//    * 先验来自网络 policy（softmax 后按合法着法归一）
//    * 叶子价值来自网络 value；回传时按层交替取负
//    * 终局（双方 pass）直接用面积点目，不调网络
//    * 每个叶子只做一次网络前向（价值缓存在节点上）
//    * 填自己真眼的着法降低先验（不置零，避免无子可下）
//
//  关于 value 的视角：实测本网络 value 的 win 输出是**白方视角**
//  （空盘给黑方约 5.6%，而空盘黑贴 7.5 本就略差，符合白方视角）。
//  因此转成"当前方视角"时，黑方取负、白方取正。
// ============================================================================
#ifndef KG_SEARCH_H
#define KG_SEARCH_H

#include "board.h"
#include "encode.h"
#include "forward.h"

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <vector>

namespace kg {

// 面积点目：黑减白。用于终局估值与自我对弈判定。
inline int areaScoreBlackMinusWhite(const Board& b) {
    const int N = b.N, S = N * N;
    std::vector<uint8_t> visited((size_t)S, 0);
    int score = 0;
    int nb[4];
    for (int l = 0; l < S; ++l) {
        Color c = b.at(l);
        if (c == BLACK) { ++score; continue; }
        if (c == WHITE) { --score; continue; }
        if (visited[l]) continue;
        std::vector<int> region;
        int stack[19 * 19], sp = 0;
        stack[sp++] = l;
        visited[l] = 1;
        bool tb = false, tw = false;
        while (sp > 0) {
            int cur = stack[--sp];
            region.push_back(cur);
            int n = b.neighbors(cur, nb);
            for (int i = 0; i < n; ++i) {
                int q = nb[i];
                Color cq = b.at(q);
                if (cq == EMPTY) {
                    if (!visited[q]) { visited[q] = 1; stack[sp++] = q; }
                } else if (cq == BLACK) tb = true;
                else tw = true;
            }
        }
        if (tb && !tw) score += (int)region.size();
        else if (tw && !tb) score -= (int)region.size();
    }
    return score;
}

struct Node {
    int loc;
    Color toMove;
    float prior;
    float valueSum;
    int visits;
    bool expanded;
    bool terminal;
    float leafValue;               // 网络评出的价值（当前方视角，[-1,1]）
    std::vector<int> children;

    Node() : loc(-1), toMove(BLACK), prior(0.0f), valueSum(0.0f), visits(0),
             expanded(false), terminal(false), leafValue(0.0f) {}
};

class Search {
public:
    Search(const Forward& nn, int posLen, float cpuct = 1.10f, float fpu = 0.20f)
        : nn_(nn), N_(posLen), cpuct_(cpuct), fpu_(fpu) {}

    // 搜索 maxVisits 次，返回最佳着法；outMoves 回传各候选的访问次数
    int run(const Position& root, int maxVisits,
            std::vector<std::pair<int, int> >* outMoves, float* outWinProb) {
        nodes_.clear();
        nodes_.resize(1);
        expand(0, root);

        for (int it = 0; it < maxVisits; ++it) {
            Position p = root;
            int node = 0;
            std::vector<int> path;
            path.push_back(0);
            // ---- 选择 ----
            while (nodes_[node].expanded && !nodes_[node].terminal) {
                const Node& nd = nodes_[node];
                float parentQ = (nd.visits > 0) ? (nd.valueSum / nd.visits) : 1.0f;
                float fpuVal = parentQ - fpu_;
                float sqrtN = std::sqrt((float)(nd.visits > 0 ? nd.visits : 1));
                int best = -1;
                float bestScore = -1e30f;
                for (size_t i = 0; i < nd.children.size(); ++i) {
                    const Node& ch = nodes_[nd.children[i]];
                    float q = (ch.visits > 0) ? (ch.valueSum / ch.visits) : fpuVal;
                    float u = cpuct_ * ch.prior * sqrtN / (1.0f + ch.visits);
                    float sc = -q + u;      // 子节点价值是对手视角
                    if (sc > bestScore) { bestScore = sc; best = nd.children[i]; }
                }
                if (best < 0) break;
                node = best;
                path.push_back(node);
                p.play(nodes_[node].loc);
                if (p.gameOver()) { nodes_[node].terminal = true; break; }
            }

            // ---- 评估叶子（每叶子一次网络前向） ----
            if (!nodes_[node].expanded) expand(node, p);
            float leafValue = nodes_[node].leafValue;

            // ---- 回传（交替取负） ----
            for (int i = (int)path.size() - 1; i >= 0; --i) {
                Node& nd = nodes_[path[i]];
                nd.visits++;
                nd.valueSum += leafValue;
                leafValue = -leafValue;
            }
        }

        int bestMove = Board::PASS;
        int bestVisits = -1;
        if (outMoves) outMoves->clear();
        const Node& rootN = nodes_[0];
        for (size_t i = 0; i < rootN.children.size(); ++i) {
            const Node& ch = nodes_[rootN.children[i]];
            if (outMoves) outMoves->push_back(std::make_pair(ch.loc, ch.visits));
            if (ch.visits > bestVisits) { bestVisits = ch.visits; bestMove = ch.loc; }
        }
        if (outWinProb)
            *outWinProb = (rootN.visits > 0) ? (rootN.valueSum / rootN.visits) : 0.0f;
        return bestMove;
    }

    size_t nodeCount() const { return nodes_.size(); }

private:
    const Forward& nn_;
    int N_;
    float cpuct_, fpu_;
    std::vector<Node> nodes_;

    // 是否填自己的真眼
    bool isSelfEye(const Board& b, int l, Color pla) const {
        int x = b.xOf(l), y = b.yOf(l);
        int nb[4];
        int n = b.neighbors(l, nb);
        if (n < 4) return false;
        for (int i = 0; i < n; ++i)
            if (b.at(nb[i]) != pla) return false;
        const int ddx[4] = {-1, 1, -1, 1}, ddy[4] = {-1, -1, 1, 1};
        for (int k = 0; k < 4; ++k) {
            int cx = x + ddx[k], cy = y + ddy[k];
            if (!b.onBoard(cx, cy)) continue;
            if (b.at(b.loc(cx, cy)) == other(pla)) return false;
        }
        return true;
    }

    void expand(int idx, const Position& p) {
        Node& nd = nodes_[idx];
        if (nd.expanded) return;
        nd.expanded = true;
        nd.toMove = p.toMove;

        if (p.gameOver()) {
            nd.terminal = true;
            int sc = areaScoreBlackMinusWhite(p.board);
            // 从当前方视角的最终得分：黑方要减去贴目，白方加贴目
            float selfScore = (p.toMove == BLACK) ? ((float)sc - p.rules.komi)
                                                  : (-(float)sc + p.rules.komi);
            nd.leafValue = (selfScore > 0.0f) ? 1.0f : -1.0f;
            return;
        }

        EncodedInput in;
        encodeV7(p.board, p.history, p.toMove, p.rules, in);
        ForwardResult r;
        nn_.run(in.spatial, in.global, std::vector<float>(), r);

        const int S = N_ * N_;

        // 价值：网络 win 为白方视角 → 转当前方视角
        {
            float whiteWin = r.value[0];
            float selfWin = (p.toMove == WHITE) ? whiteWin : -whiteWin;
            float v = std::tanh(selfWin * 0.5f);
            nd.leafValue = (v > 1.0f) ? 1.0f : ((v < -1.0f) ? -1.0f : v);
        }

        // 先验：策略通道 0，仅合法着法
        std::vector<std::pair<float, int> > cand;
        float mx = -1e30f;
        for (int l = 0; l < S; ++l) {
            if (!p.board.isLegal(l, p.toMove)) continue;
            float v = r.policy[(size_t)l];
            if (isSelfEye(p.board, l, p.toMove)) v -= 10.0f;
            if (v > mx) mx = v;
            cand.push_back(std::make_pair(v, l));
        }
        {
            float v = r.policy[(size_t)S];
            if (v > mx) mx = v;
            cand.push_back(std::make_pair(v, Board::PASS));
        }
        if (cand.empty()) { nd.terminal = true; nd.leafValue = -1.0f; return; }

        double sum = 0.0;
        for (size_t i = 0; i < cand.size(); ++i) {
            cand[i].first = std::exp((double)cand[i].first - mx);
            sum += cand[i].first;
        }
        nd.children.clear();
        for (size_t i = 0; i < cand.size(); ++i) {
            Node ch;
            ch.loc = cand[i].second;
            ch.toMove = other(p.toMove);
            ch.prior = (float)(cand[i].first / sum);
            nodes_.push_back(ch);
            nd.children.push_back((int)nodes_.size() - 1);
        }
    }
};

}  // namespace kg

#endif  // KG_SEARCH_H
