// ============================================================================
//  encode.h -- KataGo V7 输入特征编码（22 空间平面 + 19 全局特征）
//
//  严格对照官方 cpp/neuralnet/nninputs.cpp 的 NNInputs::fillRowV7（2302-2746）。
//  假定棋规组合 = KataGo 的 "chinese" 预设：
//    area scoring / no tax / positional ko(带 superko 规则) / multi-stone suicide
//    legal / friendlyPassOk = false / komi = 7.5
//  无 button、无 playoutDoublingAdvantage、无 encore（相关特征恒 0）。
//
//  空间平面（19x19，行优先 pos = y*19 + x）：
//    0      在盘上（恒 1，官方即用它作 mask）
//    1/2    轮到的一方的棋子 / 对手的棋子
//    3/4/5  该棋子的气数 == 1 / == 2 / == 3
//    6      劫禁着点（= board.koLoc；见下方"未修复项"说明 superko）
//    7/8    官方用于 encore 阶段，本实现（无 encore）恒 0
//    9..13  最近 5 手（由新到旧，交替 pla/opp；pass 记到全局 0..4）
//    14     征子(ladder)标记：官方 iterLadders() 判定"逃不掉"的棋串
//    15/16  上一手 / 上上手棋盘上的平面 14（官方 prevBoard / prevPrevBoard）
//    17     被征棋串的"逃出工作点"(workingMoves)：只有 2 气、且属于 opp 的
//           棋串才会写（官方 addLadderFeature 的 `colors[loc]==opp && libs>1`）
//    18/19  当前领地（pla / opp），官方 = calculateArea(全开参数)：棋子算自己
//           的颜色，只挨一种颜色的空旷区算那种颜色，两色都挨着判中立
//    20/21  官方用于 second encore 起始色，本实现恒 0
//
//  全局特征（19 个）：
//    0..4   最近 5 手是否为 pass（由新到旧）
//    5      自身视角贴目 / 20
//    6/7    劫规则（positional: 1.0 / 0.5；situational: 1.0 / -0.5）
//    8      是否允许多子自杀
//    9      计分规则：**AREA -> 0，TERRITORY -> 1**（nninputs.cpp:2643-2648）
//    10/11  税务规则（本实现 0）
//    12/13  encore 阶段（本实现 0）
//    14     passWouldEndPhase：现在 pass 会不会结束本阶段（nninputs.cpp:2666-2668），
//           并在"friendly pass 抑制"生效时强制 0
//    15/16  playoutDoublingAdvantage（本实现 0）
//    17     button（0）
//    18     贴目奇偶三角波
//
//  与官方仍然存在的差异（本文件无法单独修掉，见任务报告）：
//    * 平面 6 的 superko 部分：官方是 `board.ko_loc ∪ hist.superKoBanned`。
//      本引擎的 Board 只有 koLoc、没有 superko 列表，且 go_ai.cpp 只给编码器
//      最多 8 手历史窗口 —— 长劫循环所需要的重复局面不可见，所以这里只有 koLoc。
//    * prevBoard / prevPrevBoard：官方从 BoardHistory 的 recentBoards 直接取。
//      这里只能从当前棋盘 + 最后一手反推（Move 里没有提子信息）。当当前局面的
//      koLoc 非空时可以精确还原最后一口提的子（koLoc 就是被提点）；否则按
//      "最后一手没有提子"处理 —— 绝大多数手都成立，但提子手会略有偏差。
//    * 平面 18/19 的 pass-alive/Benson 细节：官方传的三个 flag 全为 true，
//      此时语义等价于上面写的"能算的都算"，不需要 Benson 判定。
// ============================================================================
#ifndef KG_ENCODE_H
#define KG_ENCODE_H

#include "board.h"

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <vector>
#ifdef KG_LADDER_TRACE
#include <cstdio>
#endif

namespace kg {

struct EncodedInput {
    std::vector<float> spatial;  // (22, N*N) 行优先 (C,H,W)
    std::vector<float> global;   // (19,)
};

// 棋规参数（本实现支持的组合）
struct Rules {
    float komi = 7.5f;                 // 白方所得贴目（黑方视角为 -komi）
    bool positionalKo = true;          // true = positional；false = situational
    bool multiStoneSuicideLegal = true;
    bool areaScoring = true;
    bool taxSeki = false, taxAll = false;
    bool hasButton = false;
    // friendlyPassOk：官方 tromp-taylor 预设、以及本引擎（go_ai.cpp 两个 pass 即
    // 结束对局）都是 false —— 此时 passWouldEndPhase 直接写进全局 14、历史照常显示。
    // 只有 KataGo 的 "chinese"/"chinese-ogs" 预设才是 true（搜索里"友好让过"：
    // 已有 1 个 pass 时第 2 个 pass 不结束对局，输入要隐藏历史并把全局 14 置 0，
    // 见 nninputs.cpp:2478-2497）。要和官方引擎 analysis 对比就必须用 false。
    bool friendlyPassOk = false;
    int encorePhase = 0;
};

// 对局状态：棋盘 + 历史 + 轮次（编码器与搜索共用）
struct Position {
    Board board;
    std::vector<Move> history;
    Color toMove;
    Rules rules;
    int consecutivePasses;

    Position() : toMove(BLACK), consecutivePasses(0) {}

    bool play(int loc) {
        if (loc != Board::PASS && !board.isLegal(loc, toMove)) return false;
        int cap = board.playMove(loc, toMove);
        if (cap < 0) return false;
        Move m; m.loc = loc; m.pla = toMove;
        history.push_back(m);
        if (loc == Board::PASS) ++consecutivePasses; else consecutivePasses = 0;
        toMove = other(toMove);
        return true;
    }

    bool gameOver() const {
        return consecutivePasses >= 2 || !board.hasLegalMove(toMove);
    }
};

// ===========================================================================
//  征子(ladder)求解器 —— 官方 cpp/game/board.cpp 的精确移植（v1.17.1）
//
//  对应官方函数（行号指 _katago_src/board.cpp）：
//    Board::searchIsLadderCaptured(loc, defenderFirst, buf)                 1628
//    Board::searchIsLadderCapturedAttackerFirst2Libs(loc, buf, workingMoves) 1581
//    findLiberties 1489 / findLibertyGainingCaptures 1522 / hasLibertyGainingCaptures 1562
//    getBoundNumLibertiesAfterPlay 307 / getNumLibertiesAfterPlay 344
//    wouldBeKoCapture 518 / countHeuristicConnectionLibertiesX2 1156
//    由 nninputs.cpp:815-866 的 iterLadders() 驱动。
//
//  上一版（2026-10-17）是"凭语义重写"的近似，和官方有三处实质差异，已按源码修正：
//   * 防守方的走法不只是"唯一一口气"，还包括 **findLibertyGainingCaptures**
//     （提掉周围只剩 1 气的对方串来长气）—— 这是征子逃出的常见手段；
//   * 根节点 defenderFirst 时官方把 ko_loc 清空（"假设所有劫都成立"）；
//     防守方轮次时如果 ko_loc 非空，官方**直接判逃脱**（不承认靠劫活的征子）；
//   * 节点预算 25000 / 栈深 542（官方 MAX_LADDER_SEARCH_NODE_BUDGET / stackSize）、
//     双劫死特例、两口外气不相邻时的剪枝、按启发式排序走法。
//
//  与官方唯一的有意差异：额外加了"单次 encodeV7 总节点预算"（TOTAL_NODE_BUDGET），
//  防止病态局面把编码时间拖爆；触发时该棋串当作"未解"（不写平面 14），
//  正常局面下不会触发（实测 10 个中盘局面总节点数 < 2000）。
// ===========================================================================

// 19x19 邻居表：热点（征子搜索）里每个节点要算几遍邻居，避免做 % 与 / 除法。
struct NbTable19 {
    int16_t count[19 * 19];
    int16_t nb[19 * 19][4];
    NbTable19() {
        for (int y = 0; y < 19; ++y) {
            for (int x = 0; x < 19; ++x) {
                int l = y * 19 + x, k = 0;
                if (x > 0) nb[l][k++] = (int16_t)(l - 1);
                if (x < 18) nb[l][k++] = (int16_t)(l + 1);
                if (y > 0) nb[l][k++] = (int16_t)(l - 19);
                if (y < 18) nb[l][k++] = (int16_t)(l + 19);
                count[l] = (int16_t)k;
            }
        }
    }
};
inline const NbTable19& nbTable19() { static NbTable19 t; return t; }

class LadderSolver {
public:
    static const int MAX_LOCS = 19 * 19;
    static const int OFFICIAL_NODE_BUDGET = 25000;         // 官方 MAX_LADDER_SEARCH_NODE_BUDGET
    static const int STACK_SIZE = MAX_LOCS * 3 / 2 + 1;    // 官方 stackSize = 542
    static const int TOTAL_NODE_BUDGET = 200000;           // 本实现的安全阀（见头部说明）

    void init(const Board& b) {
        N_ = b.N;
        S_ = b.N * b.N;
        if (S_ > MAX_LOCS) S_ = MAX_LOCS;
        for (int i = 0; i < S_; ++i) col_[i] = b.colors[(size_t)i];
        ko_ = b.koLoc;
        capTop_ = 0;
        nodes_ = 0;
        totalNodes_ = 0;
        budgetHit_ = false;
        totalBudgetHit_ = false;
        gen_ = 0;
        gen2_ = 0;
        std::memset(seenStone_, 0, sizeof(seenStone_));
        std::memset(seenEmpty_, 0, sizeof(seenEmpty_));
        std::memset(grpSeen_, 0, sizeof(grpSeen_));
    }

    int nodes() const { return nodes_; }
    int totalNodes() const { return totalNodes_; }

    // 官方 Board::searchIsLadderCaptured(loc, defenderFirst=true)
    bool searchIsLadderCaptured(int loc, bool defenderFirst) {
        if (totalBudgetHit_) return false;
        if (loc < 0 || loc >= S_) return false;
        if (col_[loc] == EMPTY) return false;
        int libs = groupLibs_(loc, 0, 0);
        if (libs > 2 || (defenderFirst && libs > 1)) return false;
        Color pla = col_[loc];
        Color opp = other(pla);
        nodes_ = 0;
        budgetHit_ = false;
        int koSaved = ko_;
        if (defenderFirst) ko_ = Board::NULL_LOC;   // 官方：根节点假设所有劫都成立
        bool r = node_(loc, pla, opp, defenderFirst, 0);
        ko_ = koSaved;
        totalNodes_ += nodes_;
        if (totalNodes_ > TOTAL_NODE_BUDGET) totalBudgetHit_ = true;
        return r;
    }

    // 官方 Board::searchIsLadderCapturedAttackerFirst2Libs(loc, buf, workingMoves)
    bool attackerFirst2Libs(int loc, std::vector<int>& workingMoves) {
        workingMoves.clear();
        if (totalBudgetHit_) return false;
        if (loc < 0 || loc >= S_) return false;
        if (col_[loc] == EMPTY) return false;
        if (groupLibs_(loc, 0, 0) != 2) return false;
        Color pla = col_[loc];
        Color opp = other(pla);
        int libs[4];
        int nlib = groupLibs_(loc, libs, 4);
        if (nlib != 2) return false;
        int move0 = libs[0], move1 = libs[1];
        bool works[2] = { false, false };
        int mv[2] = { move0, move1 };
        for (int k = 0; k < 2; ++k) {
            if (!isLegal_(mv[k], opp, false)) continue;
            int saveKo = ko_, saveCap = capTop_;
            play_(mv[k], opp);
            works[k] = searchIsLadderCaptured(loc, true);
            undoPlay_(mv[k], opp, saveKo, saveCap);
        }
        if (works[0] || works[1]) {
            if (works[0]) workingMoves.push_back(move0);
            if (works[1]) workingMoves.push_back(move1);
            return true;
        }
        return false;
    }

private:
    int N_, S_;
    Color col_[MAX_LOCS];
    int ko_;
    int nodes_;          // 当前这次 searchIsLadderCaptured 的节点数
    int totalNodes_;     // 本次 init 后的累计节点数（安全阀）
    bool budgetHit_;
    bool totalBudgetHit_;
    int capTop_;
    int capStones_[MAX_LOCS];
    int gen_, gen2_;
    int seenStone_[MAX_LOCS];
    int seenEmpty_[MAX_LOCS];
    int grpSeen_[MAX_LOCS];

    int nbOf_(int l, int out[4]) {
        if (N_ == 19) {
            const NbTable19& t = nbTable19();
            out[0] = t.nb[l][0]; out[1] = t.nb[l][1];
            out[2] = t.nb[l][2]; out[3] = t.nb[l][3];
            return t.count[l];
        }
        int x = l % N_, y = l / N_, n = 0;
        if (x > 0) out[n++] = l - 1;
        if (x < N_ - 1) out[n++] = l + 1;
        if (y > 0) out[n++] = l - N_;
        if (y < N_ - 1) out[n++] = l + N_;
        return n;
    }

    void bumpGen_() {
        ++gen_;
        if (gen_ <= 0 || gen_ > 1000000000) {
            std::memset(seenStone_, 0, sizeof(seenStone_));
            std::memset(seenEmpty_, 0, sizeof(seenEmpty_));
            gen_ = 1;
        }
    }

    static bool adjacent_(int a, int b) {
        const NbTable19& t = nbTable19();
        int n = t.count[a];
        for (int i = 0; i < n; ++i)
            if (t.nb[a][i] == b) return true;
        return false;
    }

    // 棋串气数 + 气位（一次 flood fill；out 可为 0）
    int groupLibs_(int l, int* out, int maxOut) {
        Color c = col_[l];
        if (c == EMPTY) return 0;
        bumpGen_();
        int nlib = 0;
        int stack[MAX_LOCS], sp = 0;
        stack[sp++] = l;
        seenStone_[l] = gen_;
        int nb[4];
        while (sp > 0) {
            int cur = stack[--sp];
            int n = nbOf_(cur, nb);
            for (int i = 0; i < n; ++i) {
                int q = nb[i];
                Color cq = col_[q];
                if (cq == EMPTY) {
                    if (seenEmpty_[q] != gen_) {
                        seenEmpty_[q] = gen_;
                        if (out != 0 && nlib < maxOut) out[nlib] = q;
                        ++nlib;
                    }
                } else if (cq == c && seenStone_[q] != gen_) {
                    seenStone_[q] = gen_;
                    stack[sp++] = q;
                }
            }
        }
        return nlib;
    }

    int groupStones_(int l, int* out, int maxOut) {
        Color c = col_[l];
        if (c == EMPTY) return 0;
        bumpGen_();
        int n = 0;
        int stack[MAX_LOCS], sp = 0;
        stack[sp++] = l;
        seenStone_[l] = gen_;
        int nb[4];
        while (sp > 0) {
            int cur = stack[--sp];
            if (out != 0 && n < maxOut) out[n] = cur;
            ++n;
            int nn = nbOf_(cur, nb);
            for (int i = 0; i < nn; ++i) {
                int q = nb[i];
                if (col_[q] == c && seenStone_[q] != gen_) {
                    seenStone_[q] = gen_;
                    stack[sp++] = q;
                }
            }
        }
        return n;
    }

    int groupSize_(int l) {
        Color c = col_[l];
        if (c == EMPTY) return 0;
        bumpGen_();
        int n = 0;
        int stack[MAX_LOCS], sp = 0;
        stack[sp++] = l;
        seenStone_[l] = gen_;
        int nb[4];
        while (sp > 0) {
            int cur = stack[--sp];
            ++n;
            int nn = nbOf_(cur, nb);
            for (int i = 0; i < nn; ++i) {
                int q = nb[i];
                if (col_[q] == c && seenStone_[q] != gen_) {
                    seenStone_[q] = gen_;
                    stack[sp++] = q;
                }
            }
        }
        return n;
    }

    int groupHead_(int l) {
        int stones[MAX_LOCS];
        int n = groupStones_(l, stones, MAX_LOCS);
        int h = l;
        for (int i = 0; i < n; ++i)
            if (stones[i] < h) h = stones[i];
        return h;
    }

    // 官方 Board::findLiberties（bufStart..bufIdx+numFound 之间去重）
    int findLiberties_(int loc, int* buf, int bufStart, int bufIdx) {
        int stones[MAX_LOCS];
        int ns = groupStones_(loc, stones, MAX_LOCS);
        int numFound = 0;
        int nb[4];
        for (int k = 0; k < ns; ++k) {
            int cur = stones[k];
            int n = nbOf_(cur, nb);
            for (int i = 0; i < n; ++i) {
                int lib = nb[i];
                if (col_[lib] != EMPTY) continue;
                bool dup = false;
                for (int j = bufStart; j < bufIdx + numFound; ++j)
                    if (buf[j] == lib) { dup = true; break; }
                if (!dup) buf[bufIdx + numFound++] = lib;
            }
        }
        return numFound;
    }

    // 官方 Board::findLibertyGainingCaptures
    int findLibertyGainingCaptures_(int loc, int* buf, int bufStart, int bufIdx) {
        Color opp = other(col_[loc]);
        int stones[MAX_LOCS];
        int ns = groupStones_(loc, stones, MAX_LOCS);
        int checked[8];
        int nChecked = 0;
        int numFound = 0;
        int nb[4];
        for (int k = 0; k < ns; ++k) {
            int cur = stones[k];
            int n = nbOf_(cur, nb);
            for (int i = 0; i < n; ++i) {
                int adj = nb[i];
                if (col_[adj] != opp) continue;
                if (groupLibs_(adj, 0, 0) != 1) continue;
                int head = groupHead_(adj);
                bool already = false;
                for (int j = 0; j < nChecked; ++j)
                    if (checked[j] == head) { already = true; break; }
                if (already) continue;
                numFound += findLiberties_(adj, buf, bufStart, bufIdx + numFound);
                if (nChecked < 8) checked[nChecked++] = head;
            }
        }
        return numFound;
    }

    bool hasLibertyGainingCaptures_(int loc) {
        Color opp = other(col_[loc]);
        int stones[MAX_LOCS];
        int ns = groupStones_(loc, stones, MAX_LOCS);
        int nb[4];
        for (int k = 0; k < ns; ++k) {
            int cur = stones[k];
            int n = nbOf_(cur, nb);
            for (int i = 0; i < n; ++i) {
                int adj = nb[i];
                if (col_[adj] == opp && groupLibs_(adj, 0, 0) == 1) return true;
            }
        }
        return false;
    }

    int getNumImmediateLiberties_(int loc) {
        int nb[4];
        int n = nbOf_(loc, nb);
        int c = 0;
        for (int i = 0; i < n; ++i)
            if (col_[nb[i]] == EMPTY) ++c;
        return c;
    }

    // 官方 Board::wouldBeKoCapture
    bool wouldBeKoCapture_(int loc, Color pla) {
        if (col_[loc] != EMPTY) return false;
        Color opp = other(pla);
        int oppCapturable = Board::NULL_LOC;
        int nb[4];
        int n = nbOf_(loc, nb);
        for (int i = 0; i < n; ++i) {
            int adj = nb[i];
            if (col_[adj] != opp) return false;      // 官方：非 wall 且非 opp 就 false
            if (groupLibs_(adj, 0, 0) == 1) {
                if (oppCapturable != Board::NULL_LOC) return false;
                oppCapturable = adj;
            }
        }
        if (oppCapturable == Board::NULL_LOC) return false;
        if (groupSize_(oppCapturable) != 1) return false;
        return true;
    }

    // 官方 Board::getBoundNumLibertiesAfterPlay
    void getBoundNumLibertiesAfterPlay_(int loc, Color pla, int& lowerBound, int& upperBound) {
        Color opp = other(pla);
        int numImmediate = 0, numCaps = 0, potential = 0;
        int numConnection = 0, maxConnection = 0;
        int nb[4];
        int n = nbOf_(loc, nb);
        for (int i = 0; i < n; ++i) {
            int adj = nb[i];
            if (col_[adj] == EMPTY) ++numImmediate;
            else if (col_[adj] == opp) {
                int libs = groupLibs_(adj, 0, 0);
                if (libs == 1) { ++numCaps; potential += groupSize_(adj); }
            } else if (col_[adj] == pla) {
                int conn = groupLibs_(adj, 0, 0) - 1;
                numConnection += conn;
                if (conn > maxConnection) maxConnection = conn;
            }
        }
        lowerBound = numCaps + (maxConnection > numImmediate ? maxConnection : numImmediate);
        upperBound = numImmediate + potential + numConnection;
    }

    // 官方 Board::getNumLibertiesAfterPlay：落子后该串气数，>=maxv 返回 maxv
    int getNumLibertiesAfterPlay_(int loc, Color pla, int maxv) {
        Color opp = other(pla);
        int libs[16];
        int numLibs = 0;
        int capturedHeads[4];
        int numCaptured = 0;
        int nb[4];
        int n = nbOf_(loc, nb);
        for (int i = 0; i < n; ++i) {
            int adj = nb[i];
            if (col_[adj] == EMPTY) {
                if (numLibs < 16) libs[numLibs] = adj;
                ++numLibs;
                if (numLibs >= maxv) return maxv;
            } else if (col_[adj] == opp && groupLibs_(adj, 0, 0) == 1) {
                if (numLibs < 16) libs[numLibs] = adj;
                ++numLibs;
                if (numLibs >= maxv) return maxv;
                int head = groupHead_(adj);
                bool found = false;
                for (int j = 0; j < numCaptured; ++j)
                    if (capturedHeads[j] == head) { found = true; break; }
                if (!found && numCaptured < 4) capturedHeads[numCaptured++] = head;
            }
        }
        // 官方 wouldBeEmpty(lc)
        auto wouldBeEmpty = [&](int lc) -> bool {
            if (col_[lc] == EMPTY) return true;
            if (col_[lc] == opp) {
                int h = groupHead_(lc);
                for (int j = 0; j < numCaptured; ++j)
                    if (capturedHeads[j] == h) return true;
            }
            return false;
        };
        int connecting[4];
        int numConnecting = 0;
        for (int i = 0; i < n; ++i) {
            int adj = nb[i];
            if (col_[adj] != pla) continue;
            int head = groupHead_(adj);
            bool found = false;
            for (int j = 0; j < numConnecting; ++j)
                if (connecting[j] == head) { found = true; break; }
            if (found) continue;
            if (numConnecting < 4) connecting[numConnecting++] = head;
            int stones[MAX_LOCS];
            int ns = groupStones_(adj, stones, MAX_LOCS);
            for (int k = 0; k < ns; ++k) {
                int cur = stones[k];
                int nb2[4];
                int n2 = nbOf_(cur, nb2);
                for (int m = 0; m < n2; ++m) {
                    int possibleLib = nb2[m];
                    if (possibleLib == loc) continue;
                    if (!wouldBeEmpty(possibleLib)) continue;
                    bool counted = false;
                    for (int j = 0; j < numLibs; ++j)
                        if (libs[j] == possibleLib) { counted = true; break; }
                    if (counted) continue;
                    if (numLibs < 16) libs[numLibs] = possibleLib;
                    ++numLibs;
                    if (numLibs >= maxv) return maxv;
                }
            }
        }
        return numLibs < maxv ? numLibs : maxv;
    }

    int countHeuristicConnectionLibertiesX2_(int loc, Color pla) {
        int n2 = 0;
        int nb[4];
        int n = nbOf_(loc, nb);
        for (int i = 0; i < n; ++i) {
            int adj = nb[i];
            if (col_[adj] == pla) {
                int libs = groupLibs_(adj, 0, 0);
                if (libs > 1) n2 += libs * 2 - 3;
            }
        }
        return n2;
    }

    // 落子（假设合法）。返回提子数；-1 = 自杀（suicide 非法时当作不可走）。
    int play_(int l, Color pla) {
        col_[l] = pla;
        Color opp = other(pla);
        int nb[4];
        int n = nbOf_(l, nb);
        int captured = 0;
        int possibleKo = Board::NULL_LOC;
        int capStart = capTop_;
        ++gen2_;
        if (gen2_ <= 0) { std::memset(grpSeen_, 0, sizeof(grpSeen_)); gen2_ = 1; }
        for (int i = 0; i < n; ++i) {
            int q = nb[i];
            if (col_[q] != opp) continue;
            if (groupLibs_(q, 0, 0) != 0) continue;
            int st[MAX_LOCS], sp = 0;
            st[sp++] = q;
            grpSeen_[q] = gen2_;
            while (sp > 0) {
                int cur = st[--sp];
                col_[cur] = EMPTY;
                if (capTop_ < MAX_LOCS) capStones_[capTop_++] = cur;
                ++captured;
                int nb2[4];
                int n2 = nbOf_(cur, nb2);
                for (int j = 0; j < n2; ++j) {
                    int r = nb2[j];
                    if (col_[r] == opp && grpSeen_[r] != gen2_) {
                        grpSeen_[r] = gen2_;
                        st[sp++] = r;
                    }
                }
            }
            possibleKo = q;
        }
        int libsAfter = groupLibs_(l, 0, 0);
        if (captured == 0 && libsAfter == 0) {   // 自杀（ladder 里 suicide 非法）
            col_[l] = EMPTY;
            capTop_ = capStart;
            return -1;
        }
        int locsAfter = groupSize_(l);
        // 官方：ko 的条件 = 提 1 子 && 落子后这串只有 1 颗子 && 该串 1 气
        ko_ = (captured == 1 && locsAfter == 1 && libsAfter == 1) ? possibleKo
                                                                : Board::NULL_LOC;
        return captured;
    }

    void undoPlay_(int l, Color pla, int saveKo, int saveCap) {
        Color opp = other(pla);
        while (capTop_ > saveCap) {
            int q = capStones_[--capTop_];
            col_[q] = opp;
        }
        col_[l] = EMPTY;
        ko_ = saveKo;
    }

    bool isLegal_(int loc, Color pla, bool suicideLegal) {
        if (loc < 0 || loc >= S_) return false;
        if (col_[loc] != EMPTY) return false;
        if (loc == ko_) return false;
        int saveKo = ko_, saveCap = capTop_;
        int cap = play_(loc, pla);
        undoPlay_(loc, pla, saveKo, saveCap);
        if (cap < 0) return suicideLegal;   // 自杀：suicideLegal 时才合法
        return true;
    }

    // 官方 searchIsLadderCaptured 的搜索主体（迭代栈机的等价递归实现）
    bool node_(int loc, Color pla, Color opp, bool isDefender, int depth) {
#ifdef KG_LADDER_TRACE
        {
            int lb2[4];
            int nl2 = groupLibs_(loc, lb2, 4);
            std::printf("%*s%s loc=%d libs=%d", depth * 2, "",
                        isDefender ? "DEF" : "ATT", loc, nl2);
            if (isDefender) {
                int mv2[16];
                int nn = 0;
                nn += findLibertyGainingCaptures_(loc, mv2, 0, nn);
                nn += findLiberties_(loc, mv2, 0, nn);
                std::printf(" def_moves:");
                for (int i = 0; i < nn; ++i) std::printf(" %d", mv2[i]);
                int lo = 0, hi = 0;
                getBoundNumLibertiesAfterPlay_(mv2[nn - 1], pla, lo, hi);
                std::printf("  lone=%d bounds=(%d,%d)", mv2[nn - 1], lo, hi);
            } else {
                int mv2[16];
                int nn = findLiberties_(loc, mv2, 0, 0);
                std::printf(" att_moves:");
                for (int i = 0; i < nn; ++i) std::printf(" %d", mv2[i]);
            }
            std::printf(" ko=%d\n", ko_);
        }
#endif
        if (budgetHit_) return false;
        if (nodes_ >= OFFICIAL_NODE_BUDGET) { budgetHit_ = true; return false; }
        if (depth >= STACK_SIZE - 1) return true;    // 官方：栈满 -> 当作征子成立
        int libBuf[4];
        int libs = groupLibs_(loc, libBuf, 4);
        if (!isDefender && libs <= 1) return true;
        if (!isDefender && libs >= 3) return false;
        if (isDefender && libs >= 2) return false;
        if (isDefender && ko_ != Board::NULL_LOC) return false;  // 官方：不认靠劫活的征子

        int moves[16];
        int n = 0;
        if (isDefender) {
            n += findLibertyGainingCaptures_(loc, moves, 0, n);
            n += findLiberties_(loc, moves, 0, n);
            if (n <= 0) return true;
            int lone = moves[n - 1];
            int lo = 0, hi = 0;
            getBoundNumLibertiesAfterPlay_(lone, pla, lo, hi);
            if (lo >= 3) return false;
            if (n == 1 && hi <= 1) return true;
        } else {
            n = findLiberties_(loc, moves, 0, 0);
            if (n < 2) return true;
            int libs0 = getNumImmediateLiberties_(moves[0]);
            int libs1 = getNumImmediateLiberties_(moves[1]);
            // 双劫死：官方假设攻击方赢
            if (libs0 == 0 && libs1 == 0 &&
                wouldBeKoCapture_(moves[0], opp) && wouldBeKoCapture_(moves[1], opp)) {
                if (getNumLibertiesAfterPlay_(moves[0], pla, 3) <= 2 &&
                    getNumLibertiesAfterPlay_(moves[1], pla, 3) <= 2) {
                    if (!hasLibertyGainingCaptures_(loc)) return true;
                }
            }
            if (!adjacent_(moves[0], moves[1])) {
                if (libs0 >= 3 && libs1 >= 3) return false;
                else if (libs0 >= 3) n = 1;
                else if (libs1 >= 3) { moves[0] = moves[1]; n = 1; }
            }
            if (n > 1) {
                int h0 = libs0 * 2 + countHeuristicConnectionLibertiesX2_(moves[0], pla);
                int h1 = libs1 * 2 + countHeuristicConnectionLibertiesX2_(moves[1], pla);
                if (h1 > h0) { int t = moves[0]; moves[0] = moves[1]; moves[1] = t; }
            }
        }
        for (int i = 0; i < n; ++i) {
            int m = moves[i];
            Color p = isDefender ? pla : opp;
            if (!isLegal_(m, p, false)) continue;
            int saveKo = ko_, saveCap = capTop_;
            play_(m, p);
            ++nodes_;
            bool v = node_(loc, pla, opp, !isDefender, depth + 1);
            undoPlay_(m, p, saveKo, saveCap);
            if (budgetHit_) return false;
            if (isDefender && !v) return false;
            if (!isDefender && v) return true;
        }
        return isDefender;
    }
};


// ---------------------------------------------------------------------------
//  一次计算某张棋盘上的征子标记（平面 14）与工作点（平面 17）。
//
//  opp / marks17 只对"当前棋盘"有意义：官方 plane17 只写
//  `board.colors[loc] == opp && board.getNumLiberties(loc) > 1` 的棋串。
//  历史棋盘（prevBoard/prevPrevBoard）只用来填平面 15/16，所以传 marks17=0。
// ---------------------------------------------------------------------------
inline void ladderFeatures(const Board& b, Color opp,
                           std::vector<uint8_t>& marks14,
                           std::vector<uint8_t>* marks17) {
    const int S = b.N * b.N;
    marks14.assign((size_t)S, 0);
    if (marks17) marks17->assign((size_t)S, 0);

    // 1) 每点的棋串头（用最小 loc 代表整串）+ 每个头的气数
    std::vector<int> headOf((size_t)S, -1);
    std::vector<int> headLibs((size_t)S, 0);
    std::vector<int> heads;
    {
        std::vector<uint8_t> vis((size_t)S, 0);
        std::vector<int> libStamp((size_t)S, 0);
        std::vector<int> stack, members;
        int stamp = 0;
        int nb[4];
        for (int l = 0; l < S; ++l) {
            if (b.at(l) == EMPTY || vis[l]) continue;
            Color c = b.at(l);
            ++stamp;
            vis[l] = 1;
            stack.clear();
            stack.push_back(l);
            members.clear();
            int libs = 0;
            while (!stack.empty()) {
                int cur = stack.back();
                stack.pop_back();
                members.push_back(cur);
                int n = (S == 19 * 19) ? (int)nbTable19().count[cur] : b.neighbors(cur, nb);
                if (S != 19 * 19) {
                    /* fallback: nb[] 已由 b.neighbors 填好 */
                } else {
                    nb[0] = nbTable19().nb[cur][0]; nb[1] = nbTable19().nb[cur][1];
                    nb[2] = nbTable19().nb[cur][2]; nb[3] = nbTable19().nb[cur][3];
                }
                for (int i = 0; i < n; ++i) {
                    int q = nb[i];
                    Color cq = b.at(q);
                    if (cq == EMPTY) {
                        if (libStamp[q] != stamp) { libStamp[q] = stamp; ++libs; }
                    }
                    else if (cq == c && !vis[q]) {
                        vis[q] = 1;
                        stack.push_back(q);
                    }
                }
            }
            int head = members[0];
            for (size_t i = 1; i < members.size(); ++i)
                if (members[i] < head) head = members[i];
            headLibs[head] = libs;
            for (size_t i = 0; i < members.size(); ++i) headOf[members[i]] = head;
            heads.push_back(head);
        }
    }

    // 2) 只对"气数 1 或 2"的棋串跑求解器（与官方 iterLadders 的触发条件一致）
    std::vector<uint8_t> captured((size_t)S, 0);
    {
        LadderSolver solver;
        solver.init(b);
        std::vector<int> working;
        for (size_t i = 0; i < heads.size(); ++i) {
            int h = heads[i];
            int libs = headLibs[h];
            if (libs != 1 && libs != 2) continue;
            bool cap = (libs == 1) ? solver.searchIsLadderCaptured(h, true)
                                   : solver.attackerFirst2Libs(h, working);
#ifdef KG_LADDER_TRACE
            std::printf("[ladder] head=%d libs=%d captured=%d work=%d\n",
                        h, libs, (int)cap, (int)working.size());
#endif
            if (!cap) continue;
            captured[h] = 1;
            if (marks17 && libs == 2 && b.at(h) == opp) {
                for (size_t j = 0; j < working.size(); ++j) {
                    int m = working[j];
                    if (m >= 0 && m < S) (*marks17)[m] = 1;
                }
            }
        }
    }

    for (int l = 0; l < S; ++l) {
        int h = headOf[l];
        if (h >= 0 && captured[h]) marks14[l] = 1;
    }
}

// ---------------------------------------------------------------------------
//  从"当前棋盘 + 最后一手"反推上一个局面（官方这里用 hist.getRecentBoard(1)）。
//  Move 里没有提子信息：当前局面的 koLoc 非空时它必然等于最后一手提掉的那一子，
//  可以精确还原；否则按"没有提子"处理（见文件头"与官方仍然存在的差异"）。
// ---------------------------------------------------------------------------
inline void undoLastMove(Board& b, const Move& mv) {
    int prevKo = b.koLoc;
    if (mv.loc == Board::PASS || mv.loc == Board::NULL_LOC) { b.koLoc = Board::NULL_LOC; return; }
    if (mv.loc < 0 || mv.loc >= b.N * b.N) { b.koLoc = Board::NULL_LOC; return; }
    b.colors[(size_t)mv.loc] = EMPTY;
    if (prevKo != Board::NULL_LOC && prevKo != mv.loc)
        b.colors[(size_t)prevKo] = other(mv.pla);   // 还原被提的那一子
    b.koLoc = Board::NULL_LOC;
}

// 编码一侧（nextPlayer 视角）的输入。
inline void encodeV7(const Board& board, const std::vector<Move>& history,
                     Color nextPlayer, const Rules& rules, EncodedInput& out) {
    const int N = board.N;
    const int S = N * N;
    const int NF = 22;
    out.spatial.assign((size_t)NF * S, 0.0f);
    out.global.assign(19, 0.0f);

    const Color pla = nextPlayer;
    const Color opp = other(pla);
    float* sp = out.spatial.data();
    float* gl = out.global.data();
    auto set = [&](int p, int l, float v) { sp[(size_t)p * S + l] = v; };

    // ---- 平面 0..5 ----
    for (int l = 0; l < S; ++l) set(0, l, 1.0f);   // 平面 0：在盘上
    int nb[4];
    for (int l = 0; l < S; ++l) {
        Color c = board.at(l);
        if (c == pla) set(1, l, 1.0f);
        else if (c == opp) set(2, l, 1.0f);
        if (c != EMPTY) {
            int libs = board.liberties(l);
            if (libs == 1) set(3, l, 1.0f);
            else if (libs == 2) set(4, l, 1.0f);
            else if (libs == 3) set(5, l, 1.0f);
        }
    }

    // ---- 平面 6：劫禁着点 + superko 禁着（nninputs.cpp:2356-2371） ----
    // 官方写的是 board.ko_loc ∪ hist.superKoBanned。superKoBanned 由
    // boardhistory.cpp:1081-1103 增量维护，判据是
    //   "这一手走完后的局面(pos_hash)在 koHashHistory 里出现过"
    // 其中有一步能从当前盘面精确算出来、而且实战里经常出现：
    //   * 自杀手（多子自杀合法时）—— 官方 Board::getPosHashAfterMove（board.cpp:970）
    //     会把"要落的子 + 被自杀掉的整串"一起 XOR 掉；如果这一手自杀后盘面
    //     和现在完全一样（即落子点四周没有己方子、没有空点、也没有能提的对方
    //     1 气串），那么新局面的哈希就正好等于"当前局面"，而当前局面本来就在
    //     koHashHistory 里 -> 判为 superko 禁着。
    //   官方只在 isIllegalSuicide(...)==false（即自杀合法）时才走这条分支。
    // 真实的长劫循环重复还会产生其它 superKoBanned 点，但本引擎每次只把最近
    // <=8 手交给编码器（Board 里也没有 superko 历史），那部分没法算 —— 见文件头。
    if (rules.encorePhase == 0) {
        if (board.koLoc != Board::NULL_LOC) set(6, board.koLoc, 1.0f);
        if (rules.multiStoneSuicideLegal) {
            for (int l = 0; l < S; ++l) {
                if (board.at(l) != EMPTY) continue;
                if (l == board.koLoc) continue;
                Color opp = other(pla);
                bool noEmptyNbr = true, hasFriendly = false, canCapture = false;
                int nbn = board.neighbors(l, nb);
                for (int i = 0; i < nbn; ++i) {
                    Color cq = board.at(nb[i]);
                    if (cq == EMPTY) noEmptyNbr = false;
                    else if (cq == pla) hasFriendly = true;
                    else if (board.liberties(nb[i]) == 1) canCapture = true;
                }
                if (noEmptyNbr && !hasFriendly && !canCapture) set(6, l, 1.0f);
            }
        }
    }

    // ---- 平面 18/19：当前领地（nninputs.cpp:2387-2397） ----
    // 只在 AREA + TAX_NONE 时有这张特征（其他组合本实现没有用到）。
    if (rules.areaScoring && !rules.taxSeki && !rules.taxAll) {
        std::vector<Color> area((size_t)S, EMPTY);
        board.calculateArea(area.data(), true, true, true,
                            rules.multiStoneSuicideLegal);
        for (int l = 0; l < S; ++l) {
            if (area[l] == pla) set(18, l, 1.0f);
            else if (area[l] == opp) set(19, l, 1.0f);
        }
    }

    // ---- 历史截断（nninputs.cpp:2478-2497） ----
    // 1) 尾部连续 pass 数
    int trailingPasses = 0;
    for (int i = (int)history.size() - 1; i >= 0 && trailingPasses < 2; --i) {
        if (history[(size_t)i].loc == Board::PASS) ++trailingPasses;
        else break;
    }
    // 2) passWouldEndPhase / passWouldEndGame（boardhistory.cpp:894-907）
    bool passWouldEndPhase = (trailingPasses >= 1);
    bool passWouldEndGame = passWouldEndPhase &&
        (rules.areaScoring || (rules.encorePhase >= 2));
    // 3) shouldSuppressEndGameFromFriendlyPass（boardhistory.cpp:909-914）：
    //    friendlyPassOk + AREA + 正好第 2 个 pass => 搜索里故意不让它结束对局
    bool suppressPassEnd = passWouldEndGame && rules.friendlyPassOk &&
        rules.areaScoring && trailingPasses == 1;
    int maxTurns = 5;
    if (suppressPassEnd) maxTurns = 0;
    else if (trailingPasses >= 2) maxTurns = 1;   // isGameFinished 近似

    // ---- 平面 9..13 + 全局 0..4（nninputs.cpp:2502-2561） ----
    int numTurnsIncluded = 0;
    if (maxTurns > 0) {
        int idx = (int)history.size() - 1;
        Color want = opp;
        int amount = std::min(maxTurns, (int)history.size());
        for (int k = 0; k < amount; ++k) {
            if (history[(size_t)idx].pla != want) break;
            int loc = history[(size_t)idx].loc;
            if (loc == Board::PASS) gl[k] = 1.0f;
            else if (loc >= 0) set(9 + k, loc, 1.0f);
            numTurnsIncluded = k + 1;
            --idx;
            want = other(want);
        }
    }

    // ---- 平面 14/15/16/17：征子特征（nninputs.cpp:2563-2596） ----
    {
        std::vector<uint8_t> m14, m17, m15, m16;
        ladderFeatures(board, opp, m14, &m17);
        for (int l = 0; l < S; ++l) {
            if (m14[l]) set(14, l, 1.0f);
            if (m17[l]) set(17, l, 1.0f);
        }
        // 官方：numTurnsOfHistoryIncluded < 1 时 prevBoard = board，< 2 时
        // prevPrevBoard = prevBoard —— 这两种情况直接复用上面的结果，不重算。
        Board prevBoard = board, prevPrevBoard;
        bool havePrev = (numTurnsIncluded >= 1 && !history.empty());
        if (havePrev) undoLastMove(prevBoard, history.back());
        bool havePrevPrev = (numTurnsIncluded >= 2 && history.size() >= 2);
        if (havePrevPrev) {
            prevPrevBoard = prevBoard;
            undoLastMove(prevPrevBoard, history[history.size() - 2]);
        }
        else prevPrevBoard = prevBoard;
        if (!havePrev) m15 = m14;
        else ladderFeatures(prevBoard, opp, m15, 0);
        for (int l = 0; l < S; ++l) if (m15[l]) set(15, l, 1.0f);
        if (!havePrevPrev) {
            for (int l = 0; l < S; ++l) if (m15[l]) set(16, l, 1.0f);
        } else {
            ladderFeatures(prevPrevBoard, opp, m16, 0);
            for (int l = 0; l < S; ++l) if (m16[l]) set(16, l, 1.0f);
        }
    }

    // ---- 全局特征 ----
    float selfKomi = (pla == BLACK) ? -rules.komi : rules.komi;
    float bArea = (float)S;
    const float KOMI_CLIP_RADIUS = 20.0f;
    if (selfKomi > bArea + KOMI_CLIP_RADIUS) selfKomi = bArea + KOMI_CLIP_RADIUS;
    if (selfKomi < -bArea - KOMI_CLIP_RADIUS) selfKomi = -bArea - KOMI_CLIP_RADIUS;
    gl[5] = selfKomi / 20.0f;

    // 劫规则（nninputs.cpp:2626-2637）
    if (rules.positionalKo) { gl[6] = 1.0f; gl[7] = 0.5f; }
    else { gl[6] = 1.0f; gl[7] = -0.5f; }

    if (rules.multiStoneSuicideLegal) gl[8] = 1.0f;
    // 计分规则（nninputs.cpp:2643-2648）：AREA -> 0，TERRITORY -> 1
    if (rules.areaScoring) gl[9] = 0.0f;
    else gl[9] = 1.0f;
    if (rules.taxSeki) gl[10] = 1.0f;
    else if (rules.taxAll) { gl[10] = 1.0f; gl[11] = 1.0f; }
    if (rules.encorePhase > 0) gl[12] = 1.0f;
    if (rules.encorePhase > 1) gl[13] = 1.0f;

    // pass 会不会结束本阶段（nninputs.cpp:2666-2668）
    gl[14] = (!suppressPassEnd && passWouldEndPhase) ? 1.0f : 0.0f;
    if (rules.hasButton) gl[17] = 1.0f;

    if (rules.areaScoring || rules.encorePhase >= 2) {
        bool boardAreaIsEven = (S % 2) == 0;
        float komiFloor;
        if (boardAreaIsEven) komiFloor = std::floor(selfKomi / 2.0f) * 2.0f;
        else komiFloor = std::floor((selfKomi - 1.0f) / 2.0f) * 2.0f + 1.0f;
        float delta = selfKomi - komiFloor;
        if (delta < 0.0f) delta = 0.0f;
        if (delta > 2.0f) delta = 2.0f;
        float wave;
        if (delta < 0.5f) wave = delta;
        else if (delta < 1.5f) wave = 1.0f - delta;
        else wave = delta - 2.0f;
        gl[18] = wave;
    }
}

}  // namespace kg

#endif  // KG_ENCODE_H
