// ============================================================================
//  model_load.h -- KataGo v17 .bin.gz 权重解析器（C++）
//
//  严格镜像官方 cpp/neuralnet/desc.cpp 的读取顺序，且与已通过验证的 Python
//  实现 _katago_v17_load.py 一一对应（该实现精确消耗全部 281905904 字节）。
//
//  格式本质（这是理解全部代码的关键）：
//    元数据是**空白分隔的 token 流**（对应 C++ 的 operator>>），
//    每个层名也是一个 token，**没有任何按名字查找**。
//    权重是 "@BIN@" 之后紧跟 4*N 字节小端 float32。
//    因此只要按与官方完全相同的顺序读，就必然正确。
//
//  已通过自校验：解析后 bytesConsumed 必须恰好等于 totalBytes。
// ============================================================================
#ifndef KG_MODEL_LOAD_H
#define KG_MODEL_LOAD_H

#include "weights.h"
#include "minigzip.h"

#include <cmath>
#include <cstdint>
#include <cstring>
#include <stdexcept>
#include <string>
#include <vector>

namespace kg {

class ParseError : public std::runtime_error {
public:
    explicit ParseError(const std::string& m) : std::runtime_error(m) {}
};

// ---------------------------------------------------------------- token 读取器
class TokenReader {
public:
    TokenReader(const uint8_t* d, size_t n) : d_(d), n_(n), p_(0) {}

    size_t pos() const { return p_; }
    size_t size() const { return n_; }

    inline void skipWs() {
        while (p_ < n_) {
            uint8_t c = d_[p_];
            if (c == ' ' || c == '\t' || c == '\n' || c == '\r' || c == '\v' || c == '\f')
                ++p_;
            else
                break;
        }
    }

    std::string token() {
        skipWs();
        if (p_ >= n_) throw ParseError("unexpected end of stream while reading a token");
        size_t s = p_;
        while (p_ < n_) {
            uint8_t c = d_[p_];
            if (c == ' ' || c == '\t' || c == '\n' || c == '\r' || c == '\v' || c == '\f')
                break;
            ++p_;
        }
        return std::string((const char*)d_ + s, p_ - s);
    }

    int i32() {
        std::string t = token();
        try {
            size_t used = 0;
            int v = std::stoi(t, &used);
            if (used == t.size()) return v;
        } catch (...) {
        }
        // 官方先用 int 读，失败再按 float 截断，这里保持一致
        return (int)std::strtof(t.c_str(), nullptr);
    }

    float f32() { return std::strtof(token().c_str(), nullptr); }

    // 读 "@BIN@" 之后的 count 个 float32
    void floats(size_t count, std::vector<float>& out) {
        skipWs();
        int guard = 0;
        while (p_ < n_ && d_[p_] != '@') {
            ++p_;
            if (++guard > 100)
                throw ParseError("did not find '@' within 100 bytes (corrupt or .txt.gz?)");
        }
        if (p_ + 5 > n_ || std::memcmp(d_ + p_, "@BIN@", 5) != 0)
            throw ParseError("expected '@BIN@' marker for a binary float block");
        p_ += 5;
        size_t need = 4 * count;
        if (p_ + need > n_)
            throw ParseError("binary float block is truncated");
        out.resize(count);
        if (count > 0) {
            // 文件为小端 float32；x86 上直接拷贝即可
#if defined(__BYTE_ORDER__) && (__BYTE_ORDER__ == __ORDER_BIG_ENDIAN__)
            const uint8_t* src = d_ + p_;
            for (size_t i = 0; i < count; ++i) {
                uint8_t b[4] = {src[4 * i + 3], src[4 * i + 2], src[4 * i + 1], src[4 * i]};
                std::memcpy(&out[i], b, 4);
            }
#else
            std::memcpy(out.data(), d_ + p_, need);
#endif
        }
        p_ += need;
    }

    bool atEnd() {
        skipWs();
        return p_ >= n_;
    }

private:
    const uint8_t* d_;
    size_t n_;
    size_t p_;
};

// ---------------------------------------------------------------- 各层读取
struct LoadStats {
    size_t floats = 0;
    int convs = 0, matmuls = 0, norms = 0, acts = 0;
    int nestedBlocks = 0, tfBlocks = 0, ordinaryBlocks = 0, gpoolBlocks = 0;
};

inline void readConv(TokenReader& r, ConvLayer& c, LoadStats& st) {
    c.name = r.token();
    c.ky = r.i32();
    c.kx = r.i32();
    c.ic = r.i32();
    c.oc = r.i32();
    c.dky = r.i32();
    c.dkx = r.i32();
    if (c.ky <= 0 || c.kx <= 0 || c.ic <= 0 || c.oc <= 0)
        throw ParseError(c.name + ": conv has non-positive dimensions");
    if ((c.ky & 1) == 0 || (c.kx & 1) == 0)
        throw ParseError(c.name + ": conv kernel must be odd-sized");
    size_t n = (size_t)c.ky * c.kx * c.ic * c.oc;
    std::vector<float> raw;
    r.floats(n, raw);
    // 文件顺序 (ky,kx,ic,oc) -> 内部 (oc,ic,ky,kx)
    c.w.resize(n);
    for (int o = 0; o < c.oc; ++o) {
        for (int i = 0; i < c.ic; ++i) {
            for (int y = 0; y < c.ky; ++y) {
                for (int x = 0; x < c.kx; ++x) {
                    size_t src = ((size_t)((y * c.kx + x) * c.ic + i) * c.oc) + o;
                    size_t dst = ((size_t)((o * c.ic + i) * c.ky + y) * c.kx) + x;
                    c.w[dst] = raw[src];
                }
            }
        }
    }
    std::vector<float>().swap(raw);   // 立即归还临时内存，避免峰值翻倍
    st.floats += n;
    st.convs++;
}

inline void readNorm(TokenReader& r, NormLayer& b, LoadStats& st) {
    b.name = r.token();
    b.c = r.i32();
    b.epsilon = r.f32();
    b.hasScale = (r.i32() != 0);
    b.hasBias = (r.i32() != 0);
    if (b.c <= 0) throw ParseError(b.name + ": norm numChannels must be positive");
    r.floats((size_t)b.c, b.runningMean);
    r.floats((size_t)b.c, b.runningVar);
    // 文件 has_scale 槽位里放的是逐通道 gamma。是否真的使用由调用方决定
    // （见 readNormActConv 的 useGamma 参数）。
    std::vector<float> scale;
    if (b.hasScale) r.floats((size_t)b.c, scale);
    if (b.hasBias) r.floats((size_t)b.c, b.bias);
    b.gamma.swap(scale);
    b.fixScale = 1.0f;   // 默认；由 readResidualBlockStack 按块序号覆盖
    st.floats += (size_t)b.c * (2 + (b.hasScale ? 1 : 0) + (b.hasBias ? 1 : 0));
    st.norms++;
}

inline void readActivation(TokenReader& r, ActivationLayer& a, int modelVersion, LoadStats& st) {
    a.name = r.token();
    if (modelVersion >= 11) {
        a.kind = r.token();
    } else {
        a.kind = "ACTIVATION_RELU";
    }
    st.acts++;
}

inline void readMatMul(TokenReader& r, MatMulLayer& m, LoadStats& st) {
    m.name = r.token();
    m.ic = r.i32();
    m.oc = r.i32();
    if (m.ic <= 0 || m.oc <= 0) throw ParseError(m.name + ": matmul channels must be positive");
    size_t n = (size_t)m.ic * m.oc;
    std::vector<float> raw;
    r.floats(n, raw);
    // 文件顺序 (ic,oc) -> 内部 (oc,ic)
    m.w.resize(n);
    for (int o = 0; o < m.oc; ++o)
        for (int i = 0; i < m.ic; ++i) m.w[(size_t)o * m.ic + i] = raw[(size_t)i * m.oc + o];
    st.floats += n;
    st.matmuls++;
}

inline void readMatBias(TokenReader& r, MatBiasLayer& m, LoadStats& st) {
    m.name = r.token();
    m.c = r.i32();
    if (m.c <= 0) throw ParseError(m.name + ": matbias channels must be positive");
    r.floats((size_t)m.c, m.b);
    st.floats += (size_t)m.c;
}

inline void readRmsNorm(TokenReader& r, RmsNormLayer& m, LoadStats& st) {
    m.name = r.token();
    m.c = r.i32();
    m.epsilon = r.f32();
    m.spatial = (r.i32() != 0);
    m.cgroupSize = r.i32();
    if (m.cgroupSize != 0)
        throw ParseError(m.name + ": grouped spatial RMSNorm is not supported");
    r.floats((size_t)m.c, m.gamma);
    r.floats((size_t)m.c, m.beta);
    st.floats += (size_t)m.c * 2;
    st.norms++;
}

inline void readTransformerNorm(TokenReader& r, TransformerNormLayer& m, LoadStats& st) {
    m.name = r.token();
    m.c = r.i32();
    m.epsilon = r.f32();
    r.floats((size_t)m.c, m.weight);
    st.floats += (size_t)m.c;
    st.norms++;
}

// 按分支把乘性系数写进 scaleMul。实测（PyTorch 反解）结论：
//   p 分支（fixup_use_gamma=False）: y = x * (1/sqrt(i+1)) + beta
//   q 分支（fixup_use_gamma=True） : y = x * (0.5*(1+scale)) + beta   （scale 即文件里的 gamma）
// 两个分支用同一个接口表达，避免分支判断散落到算子层。
inline void setScaleMul(NormLayer& n, bool useGamma, float k) {
    // 官方导出器（export_model_pytorch.py write_bn）写进 .bin.gz 的四组数：
    //   running_mean       : BN 的均值（非 BN 时为全 0）
    //   running_var        : max(1e-20, std^2 - 1e-20)（非 BN 时为 1-1e-20）
    //   "scale/gamma" 槽位  : scale*(gamma+1) / scale*gamma / scale
    //                        —— **已经把逐层 scale 乘进去了**
    //   beta
    // 所以正确的前向只有一条公式：
    //     y = ((x - running_mean) / sqrt(running_var + eps)) * slot + beta
    // eps 用文件里的值（1e-20）：var 是按 std^2-eps 写的，加回去正好还原 std。
    // 非 BN 时 mean=0、sqrt(1-eps+eps)=1，自动退化成 y = x*slot + beta。
    //
    // 老实现硬编码 k=1/sqrt(block+1) 与 0.5*(1+gamma)，并把 mean/var 完全丢掉：
    // 对 kata1 的 p/q 分支恰好等值（所以一直没暴露），但 trunk 末端那层真实
    // batchnorm 被整个跳过 —— policy/value 两个头喂进去的 trunk 输出因此是错的。
    (void)useGamma;
    (void)k;
    n.fixScale = 1.0f;
    n.scaleMul.assign((size_t)n.c, 1.0f);
    const bool hasSlot = (n.gamma.size() == (size_t)n.c);
    const bool hasBeta = (n.bias.size() == (size_t)n.c);
    std::vector<float> newBias((size_t)n.c, 0.0f);
    for (int c = 0; c < n.c; ++c) {
        const float inv = 1.0f / std::sqrt(n.runningVar[c] + n.epsilon);
        const float slot = hasSlot ? n.gamma[c] : 1.0f;
        n.scaleMul[c] = slot * inv;
        newBias[c] = (hasBeta ? n.bias[c] : 0.0f) - n.runningMean[c] * n.scaleMul[c];
    }
    n.bias.swap(newBias);
}

inline void readNormActConv(TokenReader& r, NormActConv& n, int modelVersion, LoadStats& st,
                            bool useGamma, float fixScale) {
    readNorm(r, n.norm, st);
    setScaleMul(n.norm, useGamma, fixScale);
    readActivation(r, n.act, modelVersion, st);
    readConv(r, n.conv, st);
    n.name = n.norm.name;
}

// 前向声明（块是递归结构）
inline void readBlock(TokenReader& r, Block& b, int modelVersion, LoadStats& st);

inline void readResidualBlockStack(TokenReader& r, std::vector<Block>& out, int count,
                                   int modelVersion, LoadStats& st) {
    out.resize(count);
    for (int i = 0; i < count; ++i) readBlock(r, out[i], modelVersion, st);
}

inline void readBlock(TokenReader& r, Block& b, int modelVersion, LoadStats& st) {
    std::string kind = r.token();
    if (kind == "ordinary_block") {
        b.kind = BLK_ORDINARY;
        b.name = r.token();
        // 普通残差块（ResBlock）：官方 normactconv1/2 都是 fixup_use_gamma=True。
        // fixscale 下逐块常量由 blockIndex 决定（本网络不含 ordinary_block，保留兼容）。
        readNormActConv(r, b.ordinary.nc1, modelVersion, st, true, 1.0f);
        readNormActConv(r, b.ordinary.nc2, modelVersion, st, true, 1.0f);
        st.ordinaryBlocks++;
    } else if (kind == "gpool_block") {
        b.kind = BLK_GPOOL;
        b.name = r.token();
        GPoolBlock& g = b.gpool;
        // KataConvAndGPool: norm, act, conv1r, conv1g, normg, actg, linear_g
        readNorm(r, g.nc1.norm, st);
        readActivation(r, g.nc1.act, modelVersion, st);
        readConv(r, g.conv1r, st);
        readConv(r, g.conv1g, st);
        readNorm(r, g.normg, st);
        readActivation(r, g.actg, modelVersion, st);
        readMatMul(r, g.linear_g, st);
        g.nc1.name = g.conv1r.name;
        g.nc1.conv = g.conv1r;
        readNorm(r, g.nc2.norm, st);
        readActivation(r, g.nc2.act, modelVersion, st);
        readConv(r, g.nc2.conv, st);
        g.nc2.name = g.nc2.conv.name;
        st.gpoolBlocks++;
    } else if (kind == "nested_bottleneck_block") {
        b.kind = BLK_NESTED_BOTTLENECK;
        b.name = r.token();
        b.internalLength = r.i32();
        if (b.internalLength < 1)
            throw ParseError(b.name + ": nested block internal length must be >= 1");
        // fixscale 的逐块常量：第 i 块为 1/sqrt(i+1)（官方 Model.initialize 中
        // fixscale 分支：block.initialize(fixup_scale = 1/sqrt(i+1))）。
        // 实测（PyTorch 反解）确认：blocks.i.normactconvp.norm 的 A 恰为 1/sqrt(i+1)。
        const float k = 1.0f / std::sqrt((float)(st.nestedBlocks + 1));
        // normactconvp：官方 fixup_use_gamma=False → 不使用 gamma
        readNormActConv(r, b.p, modelVersion, st, false, k);
        readResidualBlockStack(r, b.stack, b.internalLength, modelVersion, st);
        // normactconvq：官方 fixup_use_gamma=True → 使用 gamma
        readNormActConv(r, b.q, modelVersion, st, true, k);
        st.nestedBlocks++;
    } else if (kind == "transformer_attention_block") {
        b.kind = BLK_TF_ATTENTION;
        TfAttentionBlock& a = b.attn;
        a.name = r.token();
        a.numHeads = r.i32();
        a.numKVHeads = r.i32();
        a.qHeadDim = r.i32();
        a.vHeadDim = r.i32();
        a.useRope = (r.i32() != 0);
        a.learnableRope = (r.i32() != 0);
        readTransformerNorm(r, a.preLN, st);
        readMatMul(r, a.qProj, st);
        readMatMul(r, a.kProj, st);
        readMatMul(r, a.vProj, st);
        readMatMul(r, a.outProj, st);
        if (a.useRope) {
            if (a.learnableRope) {
                /*std::string ropeName =*/ r.token();
                a.ropeNumKVHeads = r.i32();
                a.ropeNumPairs = r.i32();
                int dim2 = r.i32();
                if (dim2 != 2) throw ParseError(a.name + ": rope freq dim2 must be 2");
                r.floats((size_t)a.ropeNumKVHeads * a.ropeNumPairs * 2, a.ropeFreqs);
                st.floats += a.ropeFreqs.size();
            } else {
                /*std::string thetaName =*/ r.token();
                a.ropeTheta = r.f32();
            }
        }
        b.name = a.name;
        st.tfBlocks++;
    } else if (kind == "transformer_ffn_block") {
        b.kind = BLK_TF_FFN;
        TfFFNBlock& f = b.ffn;
        f.name = r.token();
        f.numChannels = r.i32();
        f.ffnChannels = r.i32();
        f.useSwiGLU = (r.i32() != 0);
        readTransformerNorm(r, f.preLN, st);
        readMatMul(r, f.linear1, st);
        if (f.useSwiGLU) readMatMul(r, f.linearGate, st);
        readMatMul(r, f.linear2, st);
        b.name = f.name;
        st.tfBlocks++;
    } else {
        throw ParseError("unsupported block kind '" + kind + "' at offset " +
                         std::to_string(r.pos()));
    }
}

// ---------------------------------------------------------------- 顶层解析
// 从已解压的内存缓冲解析模型。
inline void parseModel(const uint8_t* data, size_t size, Model& M) {
    TokenReader r(data, size);
    LoadStats st;
    M.totalBytes = size;

    // ---- ModelDesc ----
    M.name = r.token();
    M.modelVersion = r.i32();
    M.numInputChannels = r.i32();
    M.numInputGlobalChannels = r.i32();
    if (M.modelVersion < 3 || M.modelVersion > 17)
        throw ParseError("unsupported model version " + std::to_string(M.modelVersion));
    if (M.modelVersion >= 13) {
        M.tdScoreMultiplier = r.f32();
        M.scoreMeanMultiplier = r.f32();
        M.scoreStdevMultiplier = r.f32();
        M.leadMultiplier = r.f32();
        M.varianceTimeMultiplier = r.f32();
        M.shorttermValueErrorMultiplier = r.f32();
        M.shorttermScoreErrorMultiplier = r.f32();
    }
    if (M.modelVersion >= 15) {
        M.metaEncoderVersion = r.i32();
        M.preferPassAliveUnderSuicideRules = (r.i32() != 0);
        M.preferExcludeTerritoryAdjacentToAtari = (r.i32() != 0);
        for (int i = 0; i < 5; ++i) {
            int unused = r.i32();
            if (unused != 0)
                throw ParseError("nonzero reserved model option " + std::to_string(i));
        }
    }

    // ---- TrunkDesc ----
    Trunk& T = M.trunk;
    T.name = r.token();
    T.numBlocks = r.i32();
    T.trunkNumChannels = r.i32();
    T.midNumChannels = r.i32();
    T.regularNumChannels = r.i32();
    T.dilatedNumChannels = r.i32();
    T.gpoolNumChannels = r.i32();
    if (M.modelVersion >= 15) {
        T.trunkNormKind = r.i32();
        for (int i = 0; i < 5; ++i) {
            int unused = r.i32();
            if (unused != 0)
                throw ParseError("nonzero reserved trunk option " + std::to_string(i));
        }
    }
    M.trunkNormKind = T.trunkNormKind;
    if (T.numBlocks < 1) throw ParseError("trunk numBlocks must be >= 1");

    readConv(r, T.initialConv, st);
    readMatMul(r, T.initialMatMul, st);
    if (T.initialConv.oc != T.trunkNumChannels)
        throw ParseError("initialConv.outChannels != trunkNumChannels");
    if (T.initialMatMul.oc != T.trunkNumChannels)
        throw ParseError("initialMatMul.outChannels != trunkNumChannels");
    if (M.metaEncoderVersion > 0)
        throw ParseError("SGF metadata encoder (metaEncoderVersion>0) is not implemented yet");

    readResidualBlockStack(r, T.blocks, T.numBlocks, M.modelVersion, st);

    if (T.trunkNormKind == 0) {
        readNorm(r, T.trunkTipNorm, st);
        // fixscale 下末端常量 = 1/sqrt(numTotalBlocks+1)，实测确认为 1/sqrt(12)。
        setScaleMul(T.trunkTipNorm, false, 1.0f / std::sqrt((float)(T.numBlocks + 1)));
    } else {
        readRmsNorm(r, T.trunkTipRmsNorm, st);
    }
    readActivation(r, T.trunkTipAct, M.modelVersion, st);

    // ---- PolicyHead ----
    PolicyHead& P = M.policyHead;
    P.name = r.token();
    if (M.modelVersion >= 17) {
        P.policyOutChannels = r.i32();
        for (int i = 0; i < 3; ++i) {
            int unused = r.i32();
            if (unused != 0)
                throw ParseError("nonzero reserved policy option " + std::to_string(i));
        }
    } else {
        P.policyOutChannels = (M.modelVersion >= 12 && M.modelVersion <= 15) ? 2 : 1;
    }
    readConv(r, P.p1Conv, st);
    readConv(r, P.g1Conv, st);
    readNorm(r, P.g1BN, st);
    // 官方 biasg 是 BiasMask（不是 BatchNorm）： y = (x + beta) * mask，无 gamma/常量
    P.g1BN.gamma.clear();
    setScaleMul(P.g1BN, false, 1.0f);
    readActivation(r, P.g1Activation, M.modelVersion, st);
    readMatMul(r, P.gpoolToBiasMul, st);
    readNorm(r, P.p1BN, st);
    P.p1BN.gamma.clear();
    setScaleMul(P.p1BN, false, 1.0f);
    readActivation(r, P.p1Activation, M.modelVersion, st);
    readConv(r, P.p2Conv, st);
    readMatMul(r, P.gpoolToPassMul, st);
    if (M.modelVersion >= 15) {
        readMatBias(r, P.gpoolToPassBias, st);
        readActivation(r, P.passActivation, M.modelVersion, st);
        readMatMul(r, P.gpoolToPassMul2, st);
    }

    // ---- ValueHead ----
    ValueHead& V = M.valueHead;
    V.name = r.token();
    if (M.modelVersion >= 17) {
        for (int i = 0; i < 3; ++i) {
            int unused = r.i32();
            if (unused != 0)
                throw ParseError("nonzero reserved value option " + std::to_string(i));
        }
    }
    readConv(r, V.v1Conv, st);
    readNorm(r, V.v1BN, st);
    // 官方 bias1 是 BiasMask： y = (x + beta) * mask
    V.v1BN.gamma.clear();
    setScaleMul(V.v1BN, false, 1.0f);
    readActivation(r, V.v1Activation, M.modelVersion, st);
    readMatMul(r, V.v2Mul, st);
    readMatBias(r, V.v2Bias, st);
    readActivation(r, V.v2Activation, M.modelVersion, st);
    readMatMul(r, V.v3Mul, st);
    readMatBias(r, V.v3Bias, st);
    readMatMul(r, V.sv3Mul, st);
    readMatBias(r, V.sv3Bias, st);
    readConv(r, V.vOwnershipConv, st);

    M.bytesConsumed = r.pos();
    M.atEndFlag = r.atEnd();   // 剩余应只有空白（最后一个 @BIN@ 块后有一个 '\n'）
    M.numFloats = st.floats;
    M.numConvs = st.convs;
    M.numMatMuls = st.matmuls;
    M.numNorms = st.norms;
    M.numNestedBlocks = st.nestedBlocks;
    M.numTfBlocks = st.tfBlocks;
}

// 从 .bin.gz 文件加载（解压 + 解析）
inline bool loadModelFromFile(const std::string& path, Model& M, std::string* errMsg) {
    std::vector<uint8_t> raw;
    if (!minigzip::readFile(path, raw, errMsg)) return false;
    std::vector<uint8_t> plain;
    std::string gerr;
    if (!minigzip::gzipDecompress(raw.data(), raw.size(), plain,
                                  300u * 1024u * 1024u, &gerr)) {
        if (errMsg) *errMsg = gerr;
        return false;
    }
    raw.clear();
    raw.shrink_to_fit();
    try {
        parseModel(plain.data(), plain.size(), M);
    } catch (const std::exception& e) {
        if (errMsg) *errMsg = e.what();
        return false;
    }
    return true;
}

}  // namespace kg

#endif  // KG_MODEL_LOAD_H
