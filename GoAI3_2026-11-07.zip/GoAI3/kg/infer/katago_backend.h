// ============================================================================
//  katago_backend.h -- 把 KataGo v17 神经网络接进 go_ai.cpp 的适配层
//
//  设计目标：go_ai.cpp 只需要认识两个函数，就能把原来的小 CNN 换成
//  70M 参数的 KataGo 网络，而 MCTS / rollout / GUI 一行都不用改。
//
//      bool kgBackendLoad(const std::string& path, std::string* err);
//      bool kgBackendForward(const Board& b, Color toMove,
//                            const std::vector<Move>& hist, const Rules& rules,
//                            std::vector<float>& policy, float& value);
//
//  接口约定与 go_ai.cpp 的 NeuralNet::forward 完全一致：
//      policy : 大小 NN+1 = 362，**已 softmax 归一化**，[361] 是 pass
//      value  : [-1, 1]，**当前行棋方视角**（+1 = 当前方必胜）
//
//  线程安全：kg::Forward 内部持有复用的激活缓冲，不是线程安全的；而
//  go_ai.cpp 的 expand_node 是在锁外并发调用网络推理的，所以这里用一把
//  互斥锁把前向串行化。单次前向约 2 秒，串行化的损失可以忽略。
// ============================================================================
#ifndef KG_KATAGO_BACKEND_H
#define KG_KATAGO_BACKEND_H

#include "model_load.h"
#include "forward.h"
// Optional GPU backend (ONNX Runtime + DirectML). Header-only and
// runtime-loaded; if it is not configured this is a no-op.
#include "ort_backend.h"
#include "encode.h"
#include "board.h"
#include "ops.h"

#include <cmath>
#include <mutex>
#include <string>
#include <vector>

namespace kg {

namespace backend_detail {
    // 模型与复用缓冲。Model 只读；Forward 持有可变缓冲，需锁保护。
    inline Model& modelRef() { static Model m; return m; }
    inline Forward*& forwardPtr() { static Forward* f = NULL; return f; }
    inline bool& readyFlag() { static bool r = false; return r; }
    inline std::string& errRef() { static std::string e; return e; }
    inline std::mutex& mtx() { static std::mutex m; return m; }
    // 300 次前向后打印一次耗时统计，便于判断"是不是慢得离谱"
    inline long long& callCount() { static long long n = 0; return n; }
    inline double& totalSeconds() { static double t = 0.0; return t; }
}

// 是否已成功加载
inline bool kgBackendReady() { return backend_detail::readyFlag(); }

// 最近一次加载失败的原因
inline const std::string& kgBackendError() { return backend_detail::errRef(); }

// 前向调用次数与累计耗时（秒）
inline void kgBackendStats(long long* calls, double* seconds) {
    if (calls) *calls = backend_detail::callCount();
    if (seconds) *seconds = backend_detail::totalSeconds();
}

// 加载 .bin.gz 权重。成功返回 true。
inline bool kgBackendLoad(const std::string& path, std::string* err) {
    std::lock_guard<std::mutex> lk(backend_detail::mtx());
    backend_detail::readyFlag() = false;
    backend_detail::errRef().clear();

    Model& M = backend_detail::modelRef();
    std::string why;
    if (!loadModelFromFile(path, M, &why)) {
        backend_detail::errRef() = why;
        if (err) *err = why;
        return false;
    }
    // 必须是"零第三方依赖"这份解析器支持的结构（嵌套瓶颈 + transformer）
    if (M.trunk.blocks.empty()) {
        backend_detail::errRef() = "model has no trunk blocks";
        if (err) *err = backend_detail::errRef();
        return false;
    }
    // 释放旧的 Forward，重建（指向新的 Model）
    delete backend_detail::forwardPtr();
    backend_detail::forwardPtr() = new Forward(M, 19);
    backend_detail::readyFlag() = true;
    backend_detail::callCount() = 0;
    backend_detail::totalSeconds() = 0.0;
    return true;
}

// 一次前向。b 是当前局面，toMove 是行棋方，hist 是**按时间顺序**（旧→新）的
// 落子历史（loc = -1 表示 pass）。失败时返回 false 并保持 policy 为空。
inline bool kgBackendForward(const Board& b, Color toMove,
                             const std::vector<Move>& hist, const Rules& rules,
                             std::vector<float>& policy, float& value) {
    policy.clear();
    value = 0.0f;
    if (!backend_detail::readyFlag()) return false;
    if (b.N != 19) return false;

    EncodedInput in;
    encodeV7(b, hist, toMove, rules, in);

    // ---- forward pass: GPU when it really is the GPU -------------------
    // Same encoder, same post-processing below; only the forward moves.
    // Deliberately gated on provider == "DirectML": the ORT CPU EP is
    // slower than the native kernels (347 ms vs 239 ms), so silently using
    // it would make the engine slower, not faster. See README_ort.md.
    ForwardResult r;
    bool haveLogits = false;
    if (ortBackendReady() && ortBackendProvider() == "DirectML") {
        std::vector<float> ownership;
        if (ortBackendForward(in.spatial, in.global, r.policy, r.value,
                              ownership)) {
            r.S = b.N * b.N;
            r.numPolicyOut = 6;
            haveLogits = true;
        }
    }
    if (!haveLogits) {
        std::lock_guard<std::mutex> lk(backend_detail::mtx());
        backend_detail::forwardPtr()->run(in.spatial, in.global,
                                          std::vector<float>(), r);
    }
    if (r.policy.empty()) return false;

    const int S = 19 * 19;
    const int numOut = r.numPolicyOut > 0 ? r.numPolicyOut : 1;

    // 取策略通道 0（regular policy）。KataGo v17 的策略头有 6 个通道，
    // 官方对局只用通道 0；通道 5 是"短期乐观"策略，用于训练辅助。
    // 文件里只写了 2 个通道，其中文件 ch1 对应模型 ch5。
    const size_t base = 0;
    float mx = -1e30f;
    for (int i = 0; i <= S; ++i) {
        float v = r.policy[base + (size_t)i];
        if (v > mx) mx = v;
    }
    policy.resize((size_t)S + 1);
    double sum = 0.0;
    for (int i = 0; i <= S; ++i) {
        double e = std::exp((double)r.policy[base + (size_t)i] - mx);
        policy[(size_t)i] = (float)e;
        sum += e;
    }
    if (sum <= 1e-30) return false;
    for (int i = 0; i <= S; ++i) policy[(size_t)i] = (float)(policy[(size_t)i] / sum);
    (void)numOut;

    // 价值：官方口径 (win - loss) / (win + loss + noresult)，已是当前方视角
    value = r.winrate();
    if (!(value == value)) value = 0.0f;          // NaN 保护
    if (value > 1.0f) value = 1.0f;
    if (value < -1.0f) value = -1.0f;
    return true;
}

}  // namespace kg

#endif  // KG_KATAGO_BACKEND_H
