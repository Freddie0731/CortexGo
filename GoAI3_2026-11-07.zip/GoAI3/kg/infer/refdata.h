// ============================================================================
//  refdata.h -- 读取 Python 侧导出的参考张量（用于数值对齐）
//
//  文件格式（小端），由 _kg_ref.py 写出：
//    magic    : 'KGREF001'   (8 字节)
//    nTensors : int32
//    每个张量:
//      nameLen : int32, name: bytes
//      ndim    : int32, dims: int32[ndim]
//      data    : float32[prod(dims)]
// ============================================================================
#ifndef KG_REFDATA_H
#define KG_REFDATA_H

#include <cstdint>
#include <cstdio>
#include <cstring>
#include <map>
#include <string>
#include <vector>

namespace kg {

struct RefTensor {
    std::vector<int> dims;
    std::vector<float> data;
    size_t size() const { return data.size(); }
    int dim(int i) const { return (i < (int)dims.size()) ? dims[i] : 0; }
};

class RefData {
public:
    bool load(const std::string& path, std::string* errMsg) {
        auto fail = [&](const char* m) { if (errMsg) *errMsg = m; return false; };
        FILE* f = nullptr;
#if defined(_MSC_VER)
        if (fopen_s(&f, path.c_str(), "rb") != 0) f = nullptr;
#else
        f = std::fopen(path.c_str(), "rb");
#endif
        if (!f) return fail("cannot open reference file");
        char magic[8];
        if (std::fread(magic, 1, 8, f) != 8 || std::memcmp(magic, "KGREF001", 8) != 0) {
            std::fclose(f);
            return fail("bad reference magic");
        }
        int32_t n = 0;
        if (std::fread(&n, 4, 1, f) != 1) { std::fclose(f); return fail("cannot read count"); }
        for (int i = 0; i < n; ++i) {
            int32_t nameLen = 0;
            if (std::fread(&nameLen, 4, 1, f) != 1 || nameLen < 0 || nameLen > 4096) {
                std::fclose(f);
                return fail("bad name length");
            }
            std::string name((size_t)nameLen, '\0');
            if (nameLen > 0 && std::fread(&name[0], 1, (size_t)nameLen, f) != (size_t)nameLen) {
                std::fclose(f);
                return fail("short read on name");
            }
            int32_t ndim = 0;
            if (std::fread(&ndim, 4, 1, f) != 1 || ndim < 0 || ndim > 8) {
                std::fclose(f);
                return fail("bad ndim");
            }
            RefTensor t;
            t.dims.resize((size_t)ndim);
            if (ndim > 0 && std::fread(t.dims.data(), 4, (size_t)ndim, f) != (size_t)ndim) {
                std::fclose(f);
                return fail("short read on dims");
            }
            size_t count = 1;
            for (int d = 0; d < ndim; ++d) count *= (size_t)t.dims[(size_t)d];
            t.data.resize(count);
            if (count > 0 && std::fread(t.data.data(), 4, count, f) != count) {
                std::fclose(f);
                return fail("short read on data");
            }
            tensors_[name] = std::move(t);
        }
        std::fclose(f);
        return true;
    }

    bool has(const std::string& k) const { return tensors_.find(k) != tensors_.end(); }
    const RefTensor* get(const std::string& k) const {
        std::map<std::string, RefTensor>::const_iterator it = tensors_.find(k);
        return (it == tensors_.end()) ? nullptr : &it->second;
    }
    size_t count() const { return tensors_.size(); }
    const std::map<std::string, RefTensor>& all() const { return tensors_; }

private:
    std::map<std::string, RefTensor> tensors_;
};

// 比较两个数组，返回最大绝对/相对误差。返回 false 表示形状不一致。
inline bool compareArrays(const std::vector<float>& a, const std::vector<float>& b,
                          double& maxAbs, double& maxRel, size_t& argMax) {
    if (a.size() != b.size()) return false;
    maxAbs = 0.0;
    maxRel = 0.0;
    argMax = 0;
    for (size_t i = 0; i < a.size(); ++i) {
        double d = std::fabs((double)a[i] - (double)b[i]);
        double denom = std::fmax(1e-6, std::fabs((double)b[i]));
        double r = d / denom;
        if (d > maxAbs) { maxAbs = d; argMax = i; }
        if (r > maxRel) maxRel = r;
    }
    return true;
}

}  // namespace kg

#endif  // KG_REFDATA_H
