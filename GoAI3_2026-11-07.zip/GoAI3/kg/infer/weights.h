// ============================================================================
//  weights.h -- KataGo v17 权重容器
//
//  设计取舍：Python 侧用 numpy 的 (oc,ic,y,x) 视图表达卷积核；C++ 侧要能直接
//  做推理，所以这里统一存成"紧凑 float 数组 + 形状元信息"，并提供按索引取值的
//  辅助函数。张量一律以 torch 语义的维度顺序描述（conv 为 oc,ic,ky,kx）。
//
//  约定（与官方 export_model_pytorch.py 的写出顺序对应）：
//    * 卷积：文件里是 (ky,kx,ic,oc)，解析时重排为 (oc,ic,ky,kx)
//    * MatMul：文件里是 (ic,oc)，解析时转置为 (oc,ic)
//    * BatchNorm：文件里的第二个数组是 running_std^2 - eps（不是 variance）
// ============================================================================
#ifndef KG_WEIGHTS_H
#define KG_WEIGHTS_H

#include <cstdint>
#include <string>
#include <vector>

namespace kg {

// 卷积层。kernel 按 (oc, ic, ky, kx) 排布，长度 = oc*ic*ky*kx。
struct ConvLayer {
    std::string name;
    int ky = 0, kx = 0, ic = 0, oc = 0, dky = 1, dkx = 1;
    std::vector<float> w;
    size_t size() const { return w.size(); }
    // 取 conv[oc][ic][y][x]
    inline float at(int o, int i, int y, int x) const {
        return w[((size_t)((o * ic + i) * ky + y) * kx) + x];
    }
};

// 归一化层。
//
// 这份 checkpoint 用的是 **fixscale** 归一化（不是 fixup，也不是 batchnorm）。
// 官方 NormActConv.initialize 在 fixscale 下会调用 norm.set_scale(norm_scale)，
// 令 NormMask 走 apply_gamma_beta_scale_mask 的 scale 分支：
//
//     y = x * (gamma * scale) + beta        （有 gamma）
//     y = x * scale            + beta        （无 gamma）
//
// 其中 scale 是**逐块常量** = 1/sqrt(i+1)（i 为块序号），由 initialize() 算出，
// **.bin.gz 里并不保存**。已用 PyTorch 反解实测确认：
//     blocks.i.normactconvp.norm   A = 1/sqrt(i+1)   （常量，resid ~3e-7）
//     norm_trunkfinal             A = 1/sqrt(B+1)    （B = 块数）
//     blocks.i.normactconvq.norm   A = 逐通道（gamma 参与）
//
// 因此这里显式保存 fixScale（块常量）与 gamma（逐通道，可为空），
// 前向按 y = x * fixScale * (gamma?gamma:1) + beta 计算。
struct NormLayer {
    std::string name;
    int c = 0;
    float epsilon = 0.0f;
    bool hasScale = false, hasBias = false;
    // fixscale 的逐块常量 1/sqrt(i+1)；fixup 时为 1.0
    float fixScale = 1.0f;
    // 逐通道 gamma（文件 has_scale 槽位）。为空表示该分支不用它。
    std::vector<float> gamma;
    // 逐通道乘性系数：实际计算为 y = x * scaleMul[c] + beta[c]。
    // 解析器按分支填好，前向直接使用（避免把分支判断散落在算子层）。
    std::vector<float> scaleMul;
    std::vector<float> runningMean;   // batchnorm 情形才有；本网络为空
    std::vector<float> runningVar;
    std::vector<float> bias;          // beta

    inline float affine(int cIdx, float x) const {
        float b = (bias.size() == (size_t)c) ? bias[cIdx] : 0.0f;
        float g = (gamma.size() == (size_t)c) ? gamma[cIdx] : 1.0f;
        return x * (fixScale * g) + b;
    }
};

// 全连接层。kernel 按 (oc, ic) 排布。
struct MatMulLayer {
    std::string name;
    int ic = 0, oc = 0;
    std::vector<float> w;
    inline float at(int o, int i) const { return w[(size_t)o * ic + i]; }
};

// 偏置层。
struct MatBiasLayer {
    std::string name;
    int c = 0;
    std::vector<float> b;
};

// 激活（只记类型）
struct ActivationLayer {
    std::string name;
    std::string kind;   // "ACTIVATION_SILU" 等
};

// Transformer 用的内联 RMSNorm：只有 weight，无 bias/spatial
struct TransformerNormLayer {
    std::string name;
    int c = 0;
    float epsilon = 0.0f;
    std::vector<float> weight;
};

// 主干最终 RMSNorm（spatial 模式，有 gamma/beta）
struct RmsNormLayer {
    std::string name;
    int c = 0;
    float epsilon = 0.0f;
    bool spatial = false;
    int cgroupSize = 0;
    std::vector<float> gamma;
    std::vector<float> beta;
};

// NormActConv：norm -> act -> conv（p/q 分支）
struct NormActConv {
    std::string name;
    NormLayer norm;
    ActivationLayer act;
    ConvLayer conv;
};

// 普通残差块： normactconv1 + normactconv2
struct OrdinaryBlock {
    std::string name;
    NormActConv nc1, nc2;
};

// 全局池化残差块
struct GPoolBlock {
    std::string name;
    NormActConv nc1;      // 其内部用 convpool 的 7 个子层
    NormActConv nc2;
    ConvLayer conv1r, conv1g;
    NormLayer normg;
    ActivationLayer actg;
    MatMulLayer linear_g;
    bool hasConvPool = true;
};

// transformer attention 块
struct TfAttentionBlock {
    std::string name;
    int numHeads = 0, numKVHeads = 0, qHeadDim = 0, vHeadDim = 0;
    bool useRope = false, learnableRope = false;
    TransformerNormLayer preLN;
    MatMulLayer qProj, kProj, vProj, outProj;
    std::vector<float> ropeFreqs;     // learnable 时为 (numKVHeads, numPairs, 2)
    int ropeNumKVHeads = 0, ropeNumPairs = 0;
    float ropeTheta = 0.0f;
};

// transformer FFN 块
struct TfFFNBlock {
    std::string name;
    int numChannels = 0, ffnChannels = 0;
    bool useSwiGLU = false;
    TransformerNormLayer preLN;
    MatMulLayer linear1, linearGate, linear2;
};

// 块类型枚举（与官方 desc.h 的常量对应）
enum BlockKind {
    BLK_ORDINARY = 0,
    BLK_GPOOL = 2,
    BLK_NESTED_BOTTLENECK = 3,
    BLK_TF_ATTENTION = 4,
    BLK_TF_FFN = 5,
};

// 块：用具体成员而非多态，避免虚函数与内存碎片
struct Block {
    BlockKind kind = BLK_ORDINARY;
    std::string name;

    OrdinaryBlock ordinary;         // kind == BLK_ORDINARY
    GPoolBlock gpool;               // kind == BLK_GPOOL
    TfAttentionBlock attn;          // kind == BLK_TF_ATTENTION
    TfFFNBlock ffn;                 // kind == BLK_TF_FFN
    // kind == BLK_NESTED_BOTTLENECK
    int internalLength = 0;
    NormActConv p, q;               // normactconvp / normactconvq
    std::vector<Block> stack;
};

// 主干
struct Trunk {
    std::string name;
    int numBlocks = 0;
    int trunkNumChannels = 0, midNumChannels = 0, regularNumChannels = 0;
    int dilatedNumChannels = 0, gpoolNumChannels = 0;
    int trunkNormKind = 0;              // 0 = STANDARD, 1 = RMSNORM
    ConvLayer initialConv;              // model.conv_spatial
    MatMulLayer initialMatMul;          // model.linear_global
    std::vector<Block> blocks;
    NormLayer trunkTipNorm;             // trunkNormKind == 0
    RmsNormLayer trunkTipRmsNorm;       // trunkNormKind == 1
    ActivationLayer trunkTipAct;
};

// 策略头
struct PolicyHead {
    std::string name;
    int policyOutChannels = 0;
    ConvLayer p1Conv, g1Conv;
    NormLayer g1BN;
    ActivationLayer g1Activation;
    MatMulLayer gpoolToBiasMul;
    NormLayer p1BN;
    ActivationLayer p1Activation;
    ConvLayer p2Conv;
    MatMulLayer gpoolToPassMul;
    MatBiasLayer gpoolToPassBias;
    ActivationLayer passActivation;
    MatMulLayer gpoolToPassMul2;
};

// 价值头
struct ValueHead {
    std::string name;
    ConvLayer v1Conv;
    NormLayer v1BN;
    ActivationLayer v1Activation;
    MatMulLayer v2Mul;
    MatBiasLayer v2Bias;
    ActivationLayer v2Activation;
    MatMulLayer v3Mul;
    MatBiasLayer v3Bias;
    MatMulLayer sv3Mul;
    MatBiasLayer sv3Bias;
    ConvLayer vOwnershipConv;
};

// 整个模型
struct Model {
    std::string name;
    int modelVersion = 0;
    int numInputChannels = 0;        // 空间平面
    int numInputGlobalChannels = 0;  // 全局特征
    // 后处理缩放（v>=13）
    float tdScoreMultiplier = 20.0f;
    float scoreMeanMultiplier = 20.0f;
    float scoreStdevMultiplier = 20.0f;
    float leadMultiplier = 20.0f;
    float varianceTimeMultiplier = 40.0f;
    float shorttermValueErrorMultiplier = 0.25f;
    float shorttermScoreErrorMultiplier = 150.0f;
    // v>=15
    int metaEncoderVersion = 0;
    bool preferPassAliveUnderSuicideRules = false;
    bool preferExcludeTerritoryAdjacentToAtari = false;
    int trunkNormKind = 0;

    Trunk trunk;
    PolicyHead policyHead;
    ValueHead valueHead;

    // 解析统计（用于自校验）
    size_t bytesConsumed = 0;
    size_t totalBytes = 0;
    size_t numFloats = 0;
    int numConvs = 0, numMatMuls = 0, numNorms = 0, numNestedBlocks = 0, numTfBlocks = 0;
    // 解析结束后流里是否只剩空白。因为最后一个 @BIN@ 数据块之后还有一个 '\n'，
    // 所以不能要求 bytesConsumed == totalBytes，而应要求"剩余全为空白"。
    bool atEndFlag = false;

    // 精确闭合：数据已全部消费，且剩余字节都是空白。
    bool atEnd() const { return atEndFlag; }
};

}  // namespace kg

#endif  // KG_WEIGHTS_H
