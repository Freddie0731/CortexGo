// ============================================================================
//  board.h -- 19x19 围棋规则与状态（供编码器与搜索使用）
//
//  坐标：loc = y * N + x；x 向右，y 向下（与官方 Board 一致）。
//  规则：area scoring / no tax / positional ko / multi-stone suicide legal。
//
//  说明：本实现每次现算气数，代码简单、不易出错。若要做到更高 visits/秒，
//  可改为增量维护棋串头与气数（搜索热点）。
// ============================================================================
#ifndef KG_BOARD_H
#define KG_BOARD_H

#include <cstdint>
#include <cstring>
#include <vector>

namespace kg {

typedef int8_t Color;
const Color EMPTY = 0;
const Color BLACK = 1;
const Color WHITE = 2;

inline Color other(Color c) { return (Color)(3 - c); }

struct Move {
    int loc;      // 落子位置；PASS 用 Board::PASS 表示
    Color pla;    // 谁下的
};

class Board {
public:
    static const int PASS = -1;
    static const int NULL_LOC = -2;

    int N;
    std::vector<Color> colors;
    int koLoc;

    Board() { reset(19); }

    void reset(int n) {
        N = n;
        colors.assign((size_t)N * N, EMPTY);
        koLoc = NULL_LOC;
    }

    inline int area() const { return N * N; }
    inline bool onBoard(int x, int y) const { return x >= 0 && x < N && y >= 0 && y < N; }
    inline int loc(int x, int y) const { return y * N + x; }
    inline int xOf(int l) const { return l % N; }
    inline int yOf(int l) const { return l / N; }
    inline Color at(int l) const { return colors[(size_t)l]; }

    int neighbors(int l, int out[4]) const {
        int x = xOf(l), y = yOf(l), n = 0;
        if (x > 0) out[n++] = loc(x - 1, y);
        if (x < N - 1) out[n++] = loc(x + 1, y);
        if (y > 0) out[n++] = loc(x, y - 1);
        if (y < N - 1) out[n++] = loc(x, y + 1);
        return n;
    }

    int liberties(int l) const {
        Color c = colors[(size_t)l];
        if (c == EMPTY) return 0;
        uint8_t seen[19 * 19];
        std::memset(seen, 0, sizeof(seen));
        uint8_t visited[19 * 19];
        std::memset(visited, 0, sizeof(visited));
        int stack[19 * 19], sp = 0;
        stack[sp++] = l;
        visited[l] = 1;
        int libs = 0;
        int nb[4];
        while (sp > 0) {
            int cur = stack[--sp];
            int n = neighbors(cur, nb);
            for (int i = 0; i < n; ++i) {
                int q = nb[i];
                if (seen[q]) continue;
                Color cq = colors[(size_t)q];
                if (cq == EMPTY) { seen[q] = 1; ++libs; }
                else if (cq == c && !visited[q]) { visited[q] = 1; stack[sp++] = q; }
            }
        }
        return libs;
    }

    void groupOf(int l, std::vector<int>& out) const {
        out.clear();
        Color c = colors[(size_t)l];
        if (c == EMPTY) return;
        std::vector<uint8_t> visited((size_t)N * N, 0);
        int stack[19 * 19], sp = 0;
        stack[sp++] = l;
        visited[l] = 1;
        int nb[4];
        while (sp > 0) {
            int cur = stack[--sp];
            out.push_back(cur);
            int n = neighbors(cur, nb);
            for (int i = 0; i < n; ++i) {
                int q = nb[i];
                if (!visited[q] && colors[(size_t)q] == c) { visited[q] = 1; stack[sp++] = q; }
            }
        }
    }

    bool isLegal(int l, Color pla) const {
        if (l == PASS) return true;
        if (l < 0 || l >= N * N) return false;
        if (colors[(size_t)l] != EMPTY) return false;
        if (l == koLoc) return false;
        Board tmp = *this;
        return tmp.playMove(l, pla) >= 0;
    }

    // 落子。返回提子数；返回 -1 表示非法（自杀）。
    int playMove(int l, Color pla) {
        if (l == PASS) { koLoc = NULL_LOC; return 0; }
        colors[(size_t)l] = pla;
        int captured = 0;
        int nb[4];
        int n = neighbors(l, nb);
        Color opp = other(pla);
        int capturedAt = NULL_LOC;
        for (int i = 0; i < n; ++i) {
            int q = nb[i];
            if (colors[(size_t)q] == opp && liberties(q) == 0) {
                std::vector<int> g;
                groupOf(q, g);
                for (size_t j = 0; j < g.size(); ++j) colors[(size_t)g[j]] = EMPTY;
                captured += (int)g.size();
                if (g.size() == 1) capturedAt = q;
            }
        }
        if (captured == 0 && liberties(l) == 0) {
            colors[(size_t)l] = EMPTY;   // 非法：自杀，撤销
            return -1;
        }
        koLoc = (captured == 1 && liberties(l) == 1) ? capturedAt : NULL_LOC;
        return captured;
    }

    bool hasLegalMove(Color pla) const {
        for (int l = 0; l < N * N; ++l)
            if (colors[(size_t)l] == EMPTY && isLegal(l, pla)) return true;
        return false;
    }

    // ------------------------------------------------------------------
    //  calculateArea -- 对应官方 cpp/game/board.cpp 的 Board::calculateArea。
    //
    //  fillRowV7（nninputs.cpp:2391-2397）用的就是全开的那一组参数：
    //      nonPassAliveStones = true, safeBigTerritories = true,
    //      unsafeBigTerritories = true, suicideLegal = rules.multiStoneSuicideLegal
    //
    //  这三个 flag 全为 true 时，语义正好是"能算的都算，算不了的判中立"：
    //    * 每颗棋子都算自己颜色的面积（nonPassAliveStones=true 即如此：死子也算
    //      自己的，死活是搜索/终局裁决的事，不是这张特征平面的事）；
    //    * 一个空旷连通区若只挨着一种颜色的棋子，就整块算那种颜色
    //      （safe/unsafeBigTerritories 全 true = 安全大块与不安全大块都算）；
    //    * 同时挨着两色的空旷区（还没定型的公共地带）判为中立 EMPTY。
    //  suicideLegal 只影响 pass-alive 的算法（Benson），在"全开"组合下不影响结果。
    //  当某个 flag 为 false 时本实现没有做额外区分（本引擎只用到全开组合）。
    // ------------------------------------------------------------------
    void calculateArea(Color* area, bool nonPassAliveStones,
                       bool safeBigTerritories, bool unsafeBigTerritories,
                       bool suicideLegal) const {
        (void)nonPassAliveStones;
        (void)safeBigTerritories;
        (void)unsafeBigTerritories;
        (void)suicideLegal;
        const int S = N * N;
        for (int i = 0; i < S; ++i) area[i] = colors[(size_t)i];
        std::vector<uint8_t> visited((size_t)S, 0);
        std::vector<int> stack, region;
        int nb[4];
        for (int l = 0; l < S; ++l) {
            if (colors[(size_t)l] != EMPTY || visited[l]) continue;
            visited[l] = 1;
            stack.clear();
            stack.push_back(l);
            region.clear();
            bool touchBlack = false, touchWhite = false;
            while (!stack.empty()) {
                int cur = stack.back();
                stack.pop_back();
                region.push_back(cur);
                int n = neighbors(cur, nb);
                for (int i = 0; i < n; ++i) {
                    int q = nb[i];
                    Color cq = colors[(size_t)q];
                    if (cq == EMPTY) {
                        if (!visited[q]) { visited[q] = 1; stack.push_back(q); }
                    }
                    else if (cq == BLACK) touchBlack = true;
                    else touchWhite = true;
                }
            }
            // 两色都挨着、或谁都不挨（空盘）=> 中立
            if (touchBlack == touchWhite) continue;
            Color owner = touchBlack ? BLACK : WHITE;
            for (size_t i = 0; i < region.size(); ++i) area[region[i]] = owner;
        }
    }
};

}  // namespace kg

#endif  // KG_BOARD_H
