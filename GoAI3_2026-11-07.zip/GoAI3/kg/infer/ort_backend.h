// ============================================================================
//  ort_backend.h -- 可选 GPU 推理后端：ONNX Runtime + DirectML
//
//  背景：本引擎原生的 KataGo v17 前向在 CPU 上约 1089 ms/次（14 核标量内核）。
//  同一个网络导出成 ONNX 后，用 ONNX Runtime 的 DirectML EP 在 Intel Arc 130T
//  上单次前向 76-81 ms（13-14 倍），数值与 fp32 参考的 policy 最大差 ~1e-5。
//  这个头文件把那条路封装成引擎能直接调的两个函数，**不引入任何编译期链接依赖**：
//  onnxruntime.dll 在运行时用 LoadLibrary 加载，头文件只 include 一份 ORT 官方
//  C API 头（kg/infer/ort/onnxruntime_c_api.h，MIT，原样复制）。
//
//  ---------------------------------------------------------------------------
//  给 go_ai.cpp 的接线方式（只要 include 这个头 + 调两个函数）：
//
//      #include "kg/infer/ort_backend.h"
//
//      // 1) 进程启动时调一次（也可以在加载 kata1.bin.gz 成功后调）。
//      //    session 创建/图编译约 5-9 秒，**绝不能每次前向重建**。
//      std::string err;
//      if (!kg::ortBackendLoad("build_out/npu/models/kata1_b11_b1.onnx", &err)) {
//          std::cerr << "[ort] disabled: " << err << "\n";   // 退回原生 CPU 路径
//      }
//
//      // 2) 每次叶子前向：把 encodeV7() 的输入直接喂进来。
//      kg::EncodedInput in;
//      kg::encodeV7(kb, kh, toMove, rules, in);
//      std::vector<float> policyLogits, valueLogits, ownership;
//      if (kg::ortBackendForward(in.spatial, in.global,
//                                policyLogits, valueLogits, ownership)) {
//          // policyLogits: 6*362（通道 0 = 常规 policy，[..., 361] 是 pass）
//          // valueLogits:  3    （win/loss/noresult 的 **logits**，行棋方视角）
//          // ownership:    361  （逐点归属，+1 黑 / -1 白，行棋方？见 README）
//      } else {
//          // 任意一步失败：**必须**退回原生 CPU 前向（kg::kgBackendForward），
//          // 引擎不能因此崩溃或静默变慢。失败原因可用 ortBackendError() 取。
//      }
//
//  ---------------------------------------------------------------------------
//  设计要点（踩过的坑都写在这里）：
//   * 单例 + 互斥锁：OrtSession 创建一次；前向用一把 std::mutex 串行化
//     （与 kg/infer/katago_backend.h 的做法一致——go_ai.cpp 的 expand_node 会在
//     锁外并发调用网络，而 ORT session 的 Run 本身线程安全、但 DML 设备串行）.
//   * DLL 加载顺序：先把 DLL 同目录的 DirectML.dll 用绝对路径 + 
//     LOAD_WITH_ALTERED_SEARCH_PATH 加载起来，再同样方式加载 onnxruntime.dll，
//     否则延迟加载的 DirectML 会去 System32 找/或解析失败。
//   * DLL 搜索顺序：① 环境变量 GOAI3_ORT_DLL（完整路径，换机器用）
//                    ② exe 同目录 onnxruntime.dll
//                    ③ 当前目录下 build_out\npu\py\onnxruntime\capi\onnxruntime.dll
//                    ④ 当前目录下 onnxruntime.dll
//                    ⑤ C:\Windows\System32\onnxruntime.dll（系统 1.17 精简版，
//                       只有 API<=17，对本头文件要求的 OrtApi v24 会失败→优雅报错）
//   * 输入/输出名字与形状**从 graph 读**（SessionGetInputName/OutputName +
//     TypeInfo），不硬编码；只按"元素个数 + rank + 名字关键字"识别语义。
//     识别后把形状断言成预期值（spatial 22x19x19、global 19、policy 6x362、
//     value 3、ownership 361），不符就报错返回 false。
//   * 执行提供者：优先新的 EP device 模型
//     （GetEpDevices + SessionOptionsAppendExecutionProvider_V2），失败再试旧的
//     generic SessionOptionsAppendExecutionProvider("DmlExecutionProvider")；
//     两者都失败则**降级到 ORT CPU EP**（约 347 ms/次，仍比原生 1089 ms 快），
//     并往 stderr 打一行警告，provider 变成 "CPU"。这样没有 GPU/DirectML 的
//     机器上依然能拿到 3 倍加速；真想完全停用就删掉 DLL/不调 ortBackendLoad。
//   * 任何失败都返回 false + 可读错误字符串，绝不抛异常出边界、绝不崩溃。
//
//  已知限制：fp32 模型 292 MB；DML 首次 session 创建 5.4-8.3 s（一次性）；
//  DML 走 iGPU 共享内存，和桌面/显示争用；并发前向被本头文件的互斥锁串行化。
// ============================================================================
#ifndef KG_ORT_BACKEND_H
#define KG_ORT_BACKEND_H

#include "ort/onnxruntime_c_api.h"

#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>

#include <atomic>
#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <mutex>
#include <string>
#include <vector>

namespace kg {

// ===========================================================================
//  实现细节（外部只用下面 4 个公开函数 + 诊断 getter）
// ===========================================================================
namespace ort_detail {

// ---- 小工具 ---------------------------------------------------------------
inline std::string toLower(const std::string& s) {
    std::string r = s;
    for (size_t i = 0; i < r.size(); ++i) {
        char c = r[i];
        if (c >= 'A' && c <= 'Z') r[i] = (char)(c - 'A' + 'a');
    }
    return r;
}

inline bool contains(const std::string& hay, const char* needle) {
    return hay.find(needle) != std::string::npos;
}

inline bool fileExistsA(const std::string& p) {
    if (p.empty()) return false;
    DWORD a = GetFileAttributesA(p.c_str());
    return a != INVALID_FILE_ATTRIBUTES && (a & FILE_ATTRIBUTE_DIRECTORY) == 0;
}

inline std::string dirName(const std::string& p) {
    size_t k = p.find_last_of("\\/");
    if (k == std::string::npos) return std::string(".");
    if (k == 0) return p.substr(0, 1);
    return p.substr(0, k);
}

inline std::string absolutePath(const std::string& p) {
    if (p.empty()) return p;
    // 已经是绝对路径（"C:\..." / "\\server\..." / "/x"）
    if (p.size() >= 2 && p[1] == ':') return p;
    if (p.size() >= 1 && (p[0] == '\\' || p[0] == '/')) return p;
    char buf[MAX_PATH * 2];
    DWORD n = GetFullPathNameA(p.c_str(), (DWORD)sizeof(buf), buf, NULL);
    if (n == 0 || n >= sizeof(buf)) return p;
    return std::string(buf, n);
}

inline std::string exeDir() {
    char buf[MAX_PATH * 2];
    DWORD n = GetModuleFileNameA(NULL, buf, (DWORD)sizeof(buf));
    if (n == 0 || n >= sizeof(buf)) return std::string();
    std::string p(buf, n);
    size_t k = p.find_last_of("\\/");
    return (k == std::string::npos) ? std::string(".") : p.substr(0, k);
}

inline std::wstring widenPath(const std::string& p) {
    std::wstring w;
    if (p.empty()) return w;
    int n = MultiByteToWideChar(CP_UTF8, MB_ERR_INVALID_CHARS, p.c_str(), -1, NULL, 0);
    if (n > 0) {
        w.resize((size_t)n - 1);
        MultiByteToWideChar(CP_UTF8, MB_ERR_INVALID_CHARS, p.c_str(), -1, &w[0], n);
        return w;
    }
    n = MultiByteToWideChar(CP_ACP, 0, p.c_str(), -1, NULL, 0);
    if (n > 0) {
        w.resize((size_t)n - 1);
        MultiByteToWideChar(CP_ACP, 0, p.c_str(), -1, &w[0], n);
    }
    return w;
}

inline double nowSeconds() {
    return (double)GetTickCount64() / 1000.0;
}

// 读环境变量（MSVC 上用 _dupenv_s 避免 C4996 警告；其它平台退回 getenv）
inline std::string envString(const char* name) {
#ifdef _MSC_VER
    char* buf = NULL;
    size_t n = 0;
    if (_dupenv_s(&buf, &n, name) == 0 && buf) {
        std::string s(buf);
        std::free(buf);
        return s;
    }
    return std::string();
#else
    const char* v = std::getenv(name);
    return v ? std::string(v) : std::string();
#endif
}

// 把 OrtStatus* 转成可读字符串并释放。成功（nullptr）返回空串。
inline std::string takeStatus(const OrtApi* api, OrtStatus* st) {
    if (!st) return std::string();
    std::string msg;
    if (api) {
        const char* m = api->GetErrorMessage(st);
        if (m) msg = m;
        api->ReleaseStatus(st);
    }
    return msg;
}

// 一个 tensor 的元信息（从 graph 读出来）
struct TensorMeta {
    std::string name;
    std::vector<int64_t> dims;
    size_t count;
    int rank;
    ONNXTensorElementDataType elemType;
    TensorMeta() : count(0), rank(0), elemType(ONNX_TENSOR_ELEMENT_DATA_TYPE_UNDEFINED) {}
};

// 运行时状态（函数内 static 单例；进程内唯一）
struct State {
    HMODULE hDirectML;
    HMODULE hProvidersShared;
    HMODULE hOrt;
    const OrtApi* api;
    OrtEnv* env;
    OrtSessionOptions* options;
    OrtSession* session;
    OrtMemoryInfo* memInfo;
    OrtAllocator* allocator;  // ORT 拥有，不释放

    std::string dllPath;
    std::string modelPath;
    std::string provider;   // "DirectML" / "CPU"
    std::string error;      // 最近一次失败原因
    std::string ortVersion;

    // 输入（0=spatial, 1=global），名字/形状从 graph 读
    std::string inName[2];
    std::vector<int64_t> inShape[2];
    // 输出（0=policy, 1=value, 2=ownership）
    std::string outName[3];

    long long calls;
    double seconds;

    State()
        : hDirectML(NULL), hProvidersShared(NULL), hOrt(NULL), api(NULL), env(NULL),
          options(NULL), session(NULL), memInfo(NULL), allocator(NULL), calls(0),
          seconds(0.0) {}
};

inline State& state() { static State s; return s; }
inline std::mutex& mtx() { static std::mutex m; return m; }
inline std::atomic<bool>& readyFlag() { static std::atomic<bool> r(false); return r; }

inline void setError(const std::string& msg) { state().error = msg; }

// 清空当前后端对象（调用方需持有 mtx）。不 FreeLibrary，由 release 统一处理。
inline void clearObjectsLocked() {
    State& S = state();
    if (S.api) {
        if (S.session) { S.api->ReleaseSession(S.session); S.session = NULL; }
        if (S.options) { S.api->ReleaseSessionOptions(S.options); S.options = NULL; }
        if (S.memInfo) { S.api->ReleaseMemoryInfo(S.memInfo); S.memInfo = NULL; }
        if (S.env) { S.api->ReleaseEnv(S.env); S.env = NULL; }
    }
    S.api = NULL;
    S.allocator = NULL;
    for (int i = 0; i < 2; ++i) { S.inName[i].clear(); S.inShape[i].clear(); }
    for (int i = 0; i < 3; ++i) S.outName[i].clear();
    S.provider.clear();
    S.ortVersion.clear();
    S.calls = 0;
    S.seconds = 0.0;
    readyFlag().store(false, std::memory_order_release);
}

// 释放 DLL（调用方需持有 mtx）。顺序与加载相反。
inline void unloadDllsLocked() {
    State& S = state();
    if (S.hOrt) { FreeLibrary(S.hOrt); S.hOrt = NULL; }
    if (S.hProvidersShared) { FreeLibrary(S.hProvidersShared); S.hProvidersShared = NULL; }
    if (S.hDirectML) { FreeLibrary(S.hDirectML); S.hDirectML = NULL; }
    S.dllPath.clear();
}

// ---- DLL 候选路径 ---------------------------------------------------------
inline std::vector<std::string> dllCandidates() {
    std::vector<std::string> out;
    std::string env = envString("GOAI3_ORT_DLL");
    if (!env.empty()) out.push_back(absolutePath(env));

    std::string exe = exeDir();
    if (!exe.empty()) out.push_back(exe + "\\onnxruntime.dll");

    out.push_back(absolutePath("build_out\\npu\\py\\onnxruntime\\capi\\onnxruntime.dll"));
    out.push_back(absolutePath("onnxruntime.dll"));
    out.push_back("C:\\Windows\\System32\\onnxruntime.dll");
    return out;
}

// 加载 onnxruntime.dll 并拿到 OrtApi（调用方需持有 mtx）。
// 成功返回 true；失败返回 false，why 里累积每个候选的失败原因。
inline bool loadOrtLocked(const std::string& ortDllPath, std::string* why) {
    State& S = state();
    std::string dir = dirName(ortDllPath);

    // 1) 先把同目录的 DirectML.dll 用绝对路径拉起来（延迟加载依赖解析的关键）
    std::string dml = dir + "\\DirectML.dll";
    if (fileExistsA(dml)) {
        S.hDirectML = LoadLibraryExA(dml.c_str(), NULL, LOAD_WITH_ALTERED_SEARCH_PATH);
        if (!S.hDirectML) {
            *why += "LoadLibrary(DirectML.dll) failed err=" + std::to_string((long long)GetLastError()) + "; ";
        }
    }
    // onnxruntime_providers_shared.dll 是部分 EP 的辅助库，存在就先装（DML 内置，可不需要）
    std::string shared = dir + "\\onnxruntime_providers_shared.dll";
    if (fileExistsA(shared)) {
        S.hProvidersShared = LoadLibraryExA(shared.c_str(), NULL, LOAD_WITH_ALTERED_SEARCH_PATH);
    }

    // 2) 再加载 onnxruntime.dll（LOAD_WITH_ALTERED_SEARCH_PATH 让它优先在自身目录找依赖）
    S.hOrt = LoadLibraryExA(ortDllPath.c_str(), NULL, LOAD_WITH_ALTERED_SEARCH_PATH);
    if (!S.hOrt) {
        *why += "LoadLibrary(onnxruntime.dll) failed at '" + ortDllPath +
                "' err=" + std::to_string((long long)GetLastError()) + "; ";
        unloadDllsLocked();
        return false;
    }

    typedef const OrtApiBase*(ORT_API_CALL * GetApiBaseFn)(void);
    GetApiBaseFn getBase =
        reinterpret_cast<GetApiBaseFn>(reinterpret_cast<void*>(GetProcAddress(S.hOrt, "OrtGetApiBase")));
    if (!getBase) {
        *why += "OrtGetApiBase not exported by '" + ortDllPath + "'; ";
        unloadDllsLocked();
        return false;
    }
    const OrtApiBase* base = getBase();
    const char* vs = base ? base->GetVersionString() : NULL;
    S.ortVersion = vs ? vs : "?";
    const OrtApi* api = base ? base->GetApi(ORT_API_VERSION) : NULL;
    if (!api) {
        *why += "ORT " + S.ortVersion + " does not support OrtApi v" +
                std::to_string((long long)ORT_API_VERSION) +
                " (header/DLL mismatch; upgrade the DLL); ";
        S.ortVersion.clear();
        unloadDllsLocked();
        return false;
    }
    S.api = api;
    S.dllPath = ortDllPath;
    return true;
}

// 选执行提供者（调用方需持有 mtx）。优先 DirectML，失败降级 CPU EP。
// 返回 true；provider 一定被设置。DML 失败时会往 stderr 打一行警告。
inline bool selectProviderLocked(std::string* warn) {
    State& S = state();
    const OrtApi* api = S.api;
    std::string dmlErr;

    // 调试/对照开关：GOAI3_ORT_FORCE_CPU=1 时不加 DML，直接走 ORT CPU EP。
    // 这也正是"机器上没有可用 GPU/DirectML"时走的那条降级代码路径。
    {
        std::string forceCpu = envString("GOAI3_ORT_FORCE_CPU");
        if (!forceCpu.empty() && forceCpu != "0") {
            S.provider = "CPU";
            if (warn) *warn = "GOAI3_ORT_FORCE_CPU is set (debug switch); skipping DirectML; ";
            if (api->SetIntraOpNumThreads) api->SetIntraOpNumThreads(S.options, 4);
            return true;
        }
    }

    // ---- 路线 A：新的 EP device 模型（ORT >= 1.22）----
    bool appended = false;
    if (api->GetEpDevices && api->EpDevice_EpName && api->SessionOptionsAppendExecutionProvider_V2) {
        const OrtEpDevice* const* devs = NULL;
        size_t ndev = 0;
        std::string st = takeStatus(api, api->GetEpDevices(S.env, &devs, &ndev));
        if (st.empty()) {
            const OrtEpDevice* pick = NULL;
            for (size_t i = 0; i < ndev; ++i) {
                const char* nm = api->EpDevice_EpName(devs[i]);
                if (!nm) continue;
                std::string l = toLower(nm);
                if (l.find("dml") != std::string::npos || l.find("directml") != std::string::npos) {
                    pick = devs[i];
                    break;
                }
            }
            if (pick) {
                const OrtEpDevice* one = pick;
                st = takeStatus(api, api->SessionOptionsAppendExecutionProvider_V2(
                                        S.options, S.env, &one, 1, NULL, NULL, 0));
                if (st.empty()) {
                    appended = true;
                    S.provider = "DirectML";
                } else {
                    dmlErr += "EP_V2(DML): " + st + "; ";
                }
            } else {
                dmlErr += "no DmlExecutionProvider among EP devices; ";
            }
        } else {
            dmlErr += "GetEpDevices: " + st + "; ";
        }
    } else {
        dmlErr += "OrtApi has no EP-device API; ";
    }

    // ---- 路线 B：旧的 generic append（ORT >= 1.12）----
    if (!appended && api->SessionOptionsAppendExecutionProvider) {
        std::string st = takeStatus(api, api->SessionOptionsAppendExecutionProvider(
                                            S.options, "DmlExecutionProvider", NULL, NULL, 0));
        if (st.empty()) {
            appended = true;
            S.provider = "DirectML";
        } else {
            dmlErr += "generic append(DmlExecutionProvider): " + st + "; ";
        }
    }

    if (!appended) {
        // ---- 降级：ORT CPU EP（不 append，ORT 默认就会用 CPU EP）----
        S.provider = "CPU";
        if (warn) *warn = dmlErr;
        // 让 CPU fallback 不至于太慢：限制 4 线程（机器上还有别的 agent/进程）
        if (api->SetIntraOpNumThreads) api->SetIntraOpNumThreads(S.options, 4);
        return true;
    }
    // DML 路径下 intra_op 线程只影响 CPU 上的少量节点，保持默认即可。
    return true;
}

// 读输入/输出名字 + 形状并识别语义（调用方需持有 mtx）。
inline bool bindIoLocked(std::string* why) {
    State& S = state();
    const OrtApi* api = S.api;

    size_t nin = 0, nout = 0;
    std::string st = takeStatus(api, api->SessionGetInputCount(S.session, &nin));
    if (!st.empty()) { *why = "SessionGetInputCount: " + st; return false; }
    st = takeStatus(api, api->SessionGetOutputCount(S.session, &nout));
    if (!st.empty()) { *why = "SessionGetOutputCount: " + st; return false; }
    if (nin != 2) {
        *why = "expected 2 inputs (spatial, global), graph has " + std::to_string((long long)nin);
        return false;
    }

    std::vector<TensorMeta> inputs;
    for (size_t i = 0; i < nin; ++i) {
        TensorMeta m;
        char* nm = NULL;
        st = takeStatus(api, api->SessionGetInputName(S.session, i, S.allocator, &nm));
        if (!st.empty()) { *why = "SessionGetInputName: " + st; return false; }
        m.name = nm ? nm : "";
        api->AllocatorFree(S.allocator, nm);
        OrtTypeInfo* ti = NULL;
        st = takeStatus(api, api->SessionGetInputTypeInfo(S.session, i, &ti));
        if (!st.empty()) { *why = "SessionGetInputTypeInfo(" + m.name + "): " + st; return false; }
        const OrtTensorTypeAndShapeInfo* tsi = NULL;
        st = takeStatus(api, api->CastTypeInfoToTensorInfo(ti, &tsi));
        if (!st.empty() || !tsi) {
            api->ReleaseTypeInfo(ti);
            *why = "input '" + m.name + "' is not a tensor";
            return false;
        }
        size_t nd = 0;
        api->GetDimensionsCount(tsi, &nd);
        m.dims.resize(nd, 0);
        if (nd > 0) api->GetDimensions(tsi, &m.dims[0], nd);
        api->GetTensorElementType(tsi, &m.elemType);
        api->GetTensorShapeElementCount(tsi, &m.count);
        m.rank = (int)nd;
        api->ReleaseTypeInfo(ti);
        if (m.elemType != ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT) {
            *why = "input '" + m.name + "' is not float32";
            return false;
        }
        inputs.push_back(m);
    }

    // spatial: 7942 个元素、rank 4 [1,22,19,19]（也接受 rank 3 [22,19,19]）
    int iSpatial = -1, iGlobal = -1;
    for (size_t i = 0; i < inputs.size(); ++i) {
        if (inputs[i].count == 22 * 361 && inputs[i].rank >= 3) iSpatial = (int)i;
        else if (inputs[i].count == 19 && inputs[i].rank <= 2) iGlobal = (int)i;
    }
    if (iSpatial < 0 || iGlobal < 0) {
        *why = "cannot identify spatial(22x19x19)/global(19) inputs; graph inputs=";
        for (size_t i = 0; i < inputs.size(); ++i)
            *why += inputs[i].name + "(" + std::to_string((long long)inputs[i].count) + ") ";
        return false;
    }
    {
        const TensorMeta& a = inputs[(size_t)iSpatial];
        // 断言形状：统一成 batch=1
        if (!(a.rank == 4 && a.dims[0] == 1 && a.dims[1] == 22 && a.dims[2] == 19 && a.dims[3] == 19) &&
            !(a.rank == 3 && a.dims[0] == 22 && a.dims[1] == 19 && a.dims[2] == 19)) {
            *why = "spatial input '" + a.name + "' has unexpected shape";
            return false;
        }
        S.inName[0] = a.name;
        S.inShape[0] = a.dims;
    }
    {
        const TensorMeta& b = inputs[(size_t)iGlobal];
        if (!(b.rank == 2 && b.dims[0] == 1 && b.dims[1] == 19) &&
            !(b.rank == 1 && b.dims[0] == 19)) {
            *why = "global input '" + b.name + "' has unexpected shape";
            return false;
        }
        S.inName[1] = b.name;
        S.inShape[1] = b.dims;
    }

    // ---- 输出：按 count/rank/名字识别 policy/value/ownership ----
    std::vector<TensorMeta> outs;
    for (size_t i = 0; i < nout; ++i) {
        TensorMeta m;
        char* nm = NULL;
        st = takeStatus(api, api->SessionGetOutputName(S.session, i, S.allocator, &nm));
        if (!st.empty()) { *why = "SessionGetOutputName: " + st; return false; }
        m.name = nm ? nm : "";
        api->AllocatorFree(S.allocator, nm);
        OrtTypeInfo* ti = NULL;
        st = takeStatus(api, api->SessionGetOutputTypeInfo(S.session, i, &ti));
        if (!st.empty()) { *why = "SessionGetOutputTypeInfo: " + st; return false; }
        const OrtTensorTypeAndShapeInfo* tsi = NULL;
        st = takeStatus(api, api->CastTypeInfoToTensorInfo(ti, &tsi));
        if (!st.empty() || !tsi) { api->ReleaseTypeInfo(ti); continue; }
        size_t nd = 0;
        api->GetDimensionsCount(tsi, &nd);
        m.dims.resize(nd, 0);
        if (nd > 0) api->GetDimensions(tsi, &m.dims[0], nd);
        api->GetTensorElementType(tsi, &m.elemType);
        api->GetTensorShapeElementCount(tsi, &m.count);
        m.rank = (int)nd;
        api->ReleaseTypeInfo(ti);
        if (m.elemType != ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT) continue;
        outs.push_back(m);
    }

    // policy: count==6*362 且最后一维==362
    int iPolicy = -1;
    for (size_t i = 0; i < outs.size(); ++i) {
        const TensorMeta& m = outs[i];
        bool shapeOk = (m.count == 6u * 362u) && m.rank >= 2 &&
                       m.dims[(size_t)m.rank - 1] == 362;
        if (!shapeOk) continue;
        bool named = contains(toLower(m.name), "policy");
        if (named) { iPolicy = (int)i; break; }
        if (iPolicy < 0) iPolicy = (int)i;
    }
    // value: count==3
    int iValue = -1;
    for (size_t i = 0; i < outs.size(); ++i) {
        const TensorMeta& m = outs[i];
        if (m.count != 3) continue;
        if (contains(toLower(m.name), "value")) { iValue = (int)i; break; }
        if (iValue < 0) iValue = (int)i;
    }
    // ownership: count==361 且 shape 含 19x19；优先名字带 own
    int iOwn = -1;
    for (size_t i = 0; i < outs.size(); ++i) {
        const TensorMeta& m = outs[i];
        if (m.count != 361) continue;
        bool shapeOk = (m.rank >= 2 && m.dims[(size_t)m.rank - 1] == 19 &&
                        m.dims[(size_t)m.rank - 2] == 19);
        if (!shapeOk) continue;
        if (contains(toLower(m.name), "own")) { iOwn = (int)i; break; }
        if (iOwn < 0) iOwn = (int)i;
    }
    if (iPolicy < 0 || iValue < 0 || iOwn < 0) {
        *why = "cannot identify policy(6x362)/value(3)/ownership(19x19) outputs; graph outputs=";
        for (size_t i = 0; i < outs.size(); ++i)
            *why += outs[i].name + "(" + std::to_string((long long)outs[i].count) + ") ";
        return false;
    }
    S.outName[0] = outs[(size_t)iPolicy].name;
    S.outName[1] = outs[(size_t)iValue].name;
    S.outName[2] = outs[(size_t)iOwn].name;
    return true;
}

// 一次前向（调用方需持有 mtx）。失败写 error 并返回 false。
inline bool forwardLocked(const std::vector<float>& spatial,
                          const std::vector<float>& global,
                          std::vector<float>& policyLogits,
                          std::vector<float>& valueLogits,
                          std::vector<float>& ownership) {
    State& S = state();
    if (!S.api || !S.session || !S.memInfo) {
        setError("ORT backend is not loaded");
        return false;
    }
    if (spatial.size() != 22u * 361u) {
        setError("spatial size must be 22*361=" + std::to_string((long long)(22u * 361u)) +
                 ", got " + std::to_string((long long)spatial.size()));
        return false;
    }
    if (global.size() != 19) {
        setError("global size must be 19, got " + std::to_string((long long)global.size()));
        return false;
    }

    const OrtApi* api = S.api;
    // 输入 shape：graph 里的形状可能带动态 batch(-1)，统一成 1
    int64_t sDims[4] = {1, 22, 19, 19};
    int64_t gDims[2] = {1, 19};
    size_t sRank = 4, gRank = 2;
    if (!S.inShape[0].empty()) {
        sRank = S.inShape[0].size();
        for (size_t i = 0; i < sRank && i < 4; ++i)
            sDims[i] = S.inShape[0][i] > 0 ? S.inShape[0][i] : 1;
    }
    if (!S.inShape[1].empty()) {
        gRank = S.inShape[1].size();
        for (size_t i = 0; i < gRank && i < 2; ++i)
            gDims[i] = S.inShape[1][i] > 0 ? S.inShape[1][i] : 1;
    }

    OrtValue* vSpatial = NULL;
    OrtValue* vGlobal = NULL;
    OrtValue* vOut[3] = {NULL, NULL, NULL};
    OrtTensorTypeAndShapeInfo* outInfo[3] = {NULL, NULL, NULL};
    bool ok = false;
    std::string why;

    do {
        std::string st = takeStatus(api, api->CreateTensorWithDataAsOrtValue(
                                            S.memInfo, const_cast<float*>(spatial.data()),
                                            spatial.size() * sizeof(float), sDims, sRank,
                                            ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT, &vSpatial));
        if (!st.empty() || !vSpatial) { why = "CreateTensor(spatial): " + st; break; }
        st = takeStatus(api, api->CreateTensorWithDataAsOrtValue(
                                 S.memInfo, const_cast<float*>(global.data()),
                                 global.size() * sizeof(float), gDims, gRank,
                                 ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT, &vGlobal));
        if (!st.empty() || !vGlobal) { why = "CreateTensor(global): " + st; break; }

        const char* inNames[2] = {S.inName[0].c_str(), S.inName[1].c_str()};
        const OrtValue* inVals[2] = {vSpatial, vGlobal};
        const char* outNames[3] = {S.outName[0].c_str(), S.outName[1].c_str(), S.outName[2].c_str()};

        double t0 = nowSeconds();
        st = takeStatus(api, api->Run(S.session, NULL, inNames, inVals, 2, outNames, 3, vOut));
        double dt = nowSeconds() - t0;
        if (!st.empty()) { why = "Run: " + st; break; }
        S.calls += 1;
        S.seconds += dt;

        // 校验 + 拷贝三个输出
        const size_t want[3] = {6u * 362u, 3u, 361u};
        std::vector<float>* dst[3] = {&policyLogits, &valueLogits, &ownership};
        for (int k = 0; k < 3; ++k) {
            if (!vOut[k]) { why = "Run returned null output for '" + S.outName[k] + "'"; break; }
            st = takeStatus(api, api->GetTensorTypeAndShape(vOut[k], &outInfo[k]));
            if (!st.empty() || !outInfo[k]) { why = "GetTensorTypeAndShape(" + S.outName[k] + "): " + st; break; }
            size_t cnt = 0;
            api->GetTensorShapeElementCount(outInfo[k], &cnt);
            if (cnt != want[k]) {
                why = "output '" + S.outName[k] + "' has " + std::to_string((long long)cnt) +
                      " elements, expected " + std::to_string((long long)want[k]);
                break;
            }
            void* raw = NULL;
            st = takeStatus(api, api->GetTensorMutableData(vOut[k], &raw));
            if (!st.empty() || !raw) { why = "GetTensorMutableData(" + S.outName[k] + "): " + st; break; }
            dst[k]->assign((const float*)raw, (const float*)raw + cnt);
        }
        if (!why.empty()) break;
        ok = true;
    } while (0);

    if (vSpatial) api->ReleaseValue(vSpatial);
    if (vGlobal) api->ReleaseValue(vGlobal);
    for (int k = 0; k < 3; ++k) {
        if (outInfo[k]) api->ReleaseTensorTypeAndShapeInfo(outInfo[k]);
        if (vOut[k]) api->ReleaseValue(vOut[k]);
    }
    if (!ok) {
        policyLogits.clear();
        valueLogits.clear();
        ownership.clear();
        setError(why.empty() ? "ORT forward failed" : why);
        return false;
    }
    return true;
}

}  // namespace ort_detail

// ===========================================================================
//  公开接口（go_ai.cpp 只需要这 4 个 + 诊断 getter）
// ===========================================================================

// 加载 ONNX 模型并创建 ORT session（进程内只做一次；重复调用同路径会直接返回）。
// onnxPath：ONNX 文件路径（UTF-8；相对路径按当前工作目录解析）。
// err：失败原因（可为 NULL）。成功返回 true。
// 失败时**不会**留下半初始化状态，后端保持未就绪，调用方应退回原生 CPU 前向。
inline bool ortBackendLoad(const std::string& onnxPath, std::string* err) {
    using namespace ort_detail;
    if (err) err->clear();
    if (onnxPath.empty()) {
        setError("onnxPath is empty");
        if (err) *err = state().error;
        return false;
    }
    std::string absModel = absolutePath(onnxPath);
    if (!fileExistsA(absModel)) {
        setError("ONNX model not found: '" + absModel + "'");
        if (err) *err = state().error;
        return false;
    }

    std::lock_guard<std::mutex> lk(mtx());
    State& S = state();
    // 已就绪且是同一个模型 → 直接成功（避免重复花 5-9 秒建 session）
    if (readyFlag().load(std::memory_order_acquire) && S.modelPath == absModel) return true;

    clearObjectsLocked();
    S.modelPath.clear();
    setError(std::string());
    double tBeg = nowSeconds();

    // 1) 找并加载 onnxruntime.dll
    std::vector<std::string> cands = dllCandidates();
    std::string loadWhy;
    bool dllOk = false;
    for (size_t i = 0; i < cands.size() && !dllOk; ++i) {
        std::string p = cands[i];
        if (!fileExistsA(p)) {
            loadWhy += "'" + p + "' (not found); ";
            continue;
        }
        loadWhy += "'" + p + "': ";
        std::string why;
        dllOk = loadOrtLocked(p, &why);
        if (!dllOk) loadWhy += why;
        else loadWhy.clear();
    }
    if (!dllOk) {
        setError("cannot load a usable onnxruntime.dll with OrtApi v" +
                 std::to_string((long long)ORT_API_VERSION) + " -- tried: " + loadWhy);
        if (err) *err = S.error;
        unloadDllsLocked();
        return false;
    }

    const OrtApi* api = S.api;
    std::string st;

    // 2) Env
    st = takeStatus(api, api->CreateEnv(ORT_LOGGING_LEVEL_WARNING, "goai3", &S.env));
    if (!st.empty()) {
        setError("CreateEnv: " + st);
        if (err) *err = S.error;
        unloadDllsLocked();
        return false;
    }

    // 3) SessionOptions + 执行提供者
    st = takeStatus(api, api->CreateSessionOptions(&S.options));
    if (!st.empty()) {
        setError("CreateSessionOptions: " + st);
        if (err) *err = S.error;
        clearObjectsLocked();
        unloadDllsLocked();
        return false;
    }
    if (api->SetSessionGraphOptimizationLevel)
        api->SetSessionGraphOptimizationLevel(S.options, ORT_ENABLE_ALL);
    std::string dmlWarn;
    selectProviderLocked(&dmlWarn);
    if (!dmlWarn.empty()) {
        std::fprintf(stderr, "[ort_backend] DirectML unavailable, falling back to ORT CPU EP: %s\n",
                     dmlWarn.c_str());
    }

    // 4) CreateSession（DML 要 5-9 秒编译整张图）
    std::wstring wpath = widenPath(absModel);
    st = takeStatus(api, api->CreateSession(S.env, wpath.c_str(), S.options, &S.session));
    if (!st.empty() || !S.session) {
        setError("CreateSession('" + absModel + "') provider=" + S.provider + ": " + st);
        if (err) *err = S.error;
        S.session = NULL;
        clearObjectsLocked();
        unloadDllsLocked();
        return false;
    }

    // 5) allocator + 输入输出绑定
    st = takeStatus(api, api->GetAllocatorWithDefaultOptions(&S.allocator));
    if (!st.empty()) {
        setError("GetAllocatorWithDefaultOptions: " + st);
        if (err) *err = S.error;
        clearObjectsLocked();
        unloadDllsLocked();
        return false;
    }
    st = takeStatus(api, api->CreateCpuMemoryInfo(OrtArenaAllocator, OrtMemTypeDefault, &S.memInfo));
    if (!st.empty()) {
        setError("CreateCpuMemoryInfo: " + st);
        if (err) *err = S.error;
        clearObjectsLocked();
        unloadDllsLocked();
        return false;
    }
    std::string ioWhy;
    if (!bindIoLocked(&ioWhy)) {
        setError("graph I/O mismatch: " + ioWhy);
        if (err) *err = S.error;
        clearObjectsLocked();
        unloadDllsLocked();
        return false;
    }

    S.modelPath = absModel;
    readyFlag().store(true, std::memory_order_release);
    std::fprintf(stderr,
                 "[ort_backend] ready: provider=%s ort=%s model=%s session=%.1fs dll=%s\n",
                 S.provider.c_str(), S.ortVersion.c_str(), S.modelPath.c_str(),
                 nowSeconds() - tBeg, S.dllPath.c_str());
    return true;
}

// 是否已成功加载（线程安全，可无锁调用）
inline bool ortBackendReady() { return ort_detail::readyFlag().load(std::memory_order_acquire); }

// 最近一次失败/加载原因（不含锁；建议在 Ready()==false 时单线程读取）
inline const std::string& ortBackendError() { return ort_detail::state().error; }

// 当前执行提供者："DirectML" / "CPU" / ""（未加载）。返回拷贝，避免悬垂引用。
inline std::string ortBackendProvider() {
    using namespace ort_detail;
    std::lock_guard<std::mutex> lk(mtx());
    return state().provider;
}

// 诊断：实际加载的 onnxruntime.dll 版本（如 "1.24.4"）；未加载时为空。
inline std::string ortBackendOrtVersion() {
    using namespace ort_detail;
    std::lock_guard<std::mutex> lk(mtx());
    return state().ortVersion;
}

// 诊断：实际加载的 onnxruntime.dll 完整路径（DLL 摆放排查用）；未加载时为空。
inline std::string ortBackendDllPath() {
    using namespace ort_detail;
    std::lock_guard<std::mutex> lk(mtx());
    return state().dllPath;
}

// 诊断：前向调用次数与累计耗时（秒）。指针可为 NULL。
inline void ortBackendStats(long long* calls, double* seconds) {
    using namespace ort_detail;
    std::lock_guard<std::mutex> lk(mtx());
    if (calls) *calls = state().calls;
    if (seconds) *seconds = state().seconds;
}

// 一次完整前向（串行化；失败返回 false 并写可读错误，输出 vector 清空）。
// spatial : (22,19,19) 行优先，即 encodeV7().spatial，长度 22*361=7942
// global  : (19,)，即 encodeV7().global
// policyLogits：6*362，[c*362 + loc]；通道 0 是常规 policy，loc==361 是 pass
// valueLogits ：3，win/loss/noresult 的 logits（当前行棋方视角）
// ownership   ：361，逐点归属（+1 黑 / -1 白，白方视角，按 KataGo 官方约定）
inline bool ortBackendForward(const std::vector<float>& spatial,
                              const std::vector<float>& global,
                              std::vector<float>& policyLogits,
                              std::vector<float>& valueLogits,
                              std::vector<float>& ownership) {
    using namespace ort_detail;
    if (!readyFlag().load(std::memory_order_acquire)) {
        policyLogits.clear();
        valueLogits.clear();
        ownership.clear();
        setError("ORT backend is not ready (call ortBackendLoad first)");
        return false;
    }
    try {
        std::lock_guard<std::mutex> lk(mtx());
        if (!readyFlag().load(std::memory_order_acquire)) {
            policyLogits.clear();
            valueLogits.clear();
            ownership.clear();
            setError("ORT backend was released concurrently");
            return false;
        }
        return forwardLocked(spatial, global, policyLogits, valueLogits, ownership);
    } catch (const std::exception& e) {
        setError(std::string("exception in ortBackendForward: ") + e.what());
    } catch (...) {
        setError("unknown exception in ortBackendForward");
    }
    policyLogits.clear();
    valueLogits.clear();
    ownership.clear();
    return false;
}

// 释放 session / env / DLL（进程退出或切换后端时调；可重复调用）。
inline void ortBackendRelease() {
    using namespace ort_detail;
    std::lock_guard<std::mutex> lk(mtx());
    clearObjectsLocked();
    unloadDllsLocked();
    state().modelPath.clear();
}

}  // namespace kg

#endif  // KG_ORT_BACKEND_H
