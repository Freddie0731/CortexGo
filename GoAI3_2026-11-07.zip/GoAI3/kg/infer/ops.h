// ============================================================================
//  ops.h -- 推理算子（纯 CPU，单精度）
//
//  布局约定（与官方 model_pytorch.py 的 transformer 序列布局一致）：
//    主干全程用 (S, C)：S = H*W = 361 个棋盘点（行优先，行= y，列= x），C = 通道。
//    只有在最外层做 3x3 卷积时才转成 (C, H, W)。
//  这样所有 1x1 卷积都是纯矩阵乘法，既简单又快。
//
//  数值约定：
//    * ConvLayer.w 已按 (oc, ic, ky, kx) 排布
//    * MatMulLayer.w 已按 (oc, ic) 排布
//    * NormLayer 在 fixup 情形下只用 scale/bias（即 gamma/beta），逐通道仿射
//    * 掩码在盘的合法点为 1，盘外为 0
//
//  ---------------------------------------------------------------------------
//  SIMD / 性能说明（2026-10 优化）
//  ---------------------------------------------------------------------------
//  * 本文件里的热循环全部改成 AVX2 + FMA 手写微内核（4 行 x 16 列输出寄存器
//    分块）。MSVC 在 x64 上允许直接使用 AVX2 intrinsic，**不要求 /arch:AVX2**，
//    因此这里用 __cpuid 做运行时探测：支持 AVX2+FMA 的机器走 SIMD 路径，老 CPU
//    自动退回原来的标量实现。这样既不牺牲兼容性，也不需要改编译参数。
//  * 1x1 卷积的权重是 (oc, ic) 布局，做 GEMM 时需要 (ic, oc) 转置副本。
//    以前每次调用都重新转置一遍（几百次/前向，纯浪费）；现在用 LinearWeightCache
//    按权重地址缓存转置结果（Forward 持有，模型重载时随 Forward 一起重建）。
//    S==1 的线性层（全局池化/价值头等）不需要转置，直接走 GEMV 路径。
//  * 注意力：QK 前把每个 head 的 K 转置成 (qDim, S) 以便按 j 向量化；softmax 与
//    PV 融合在同一个任务里（PV 按输出通道分块，v 的块留在 L1）。
//  * RoPE：角度的 cos/sin 只和 (s, head, pair) 有关，按 (S,H,P) 预算成表缓存，
//    省掉每次调用 9M 次 std::cos/std::sin。
//  * 逐点算子（SiLU/NormMask/RMSNorm/残差加）向量化，SiLU 用多项式 exp。
//
//  数值：所有点的累加顺序与标量版本一致（仅 FMA 合并舍入），实测与 PyTorch
//  参考的最大绝对误差仍在 1e-4 以内（见 test_ops / test_forward）。
// ============================================================================
#ifndef KG_OPS_H
#define KG_OPS_H

#include "weights.h"

#include <algorithm>
#include <atomic>
#include <cmath>
#include <cstddef>
#include <cstring>
#include <mutex>
#include <stdexcept>
#include <string>
#include <thread>
#include <unordered_map>
#include <vector>

// 多线程开关：MSVC 下用 /openmp 启用；也可在编译时定义 KG_NO_THREADS 关闭。
#if defined(_OPENMP) && !defined(KG_NO_THREADS)
#define KG_OMP 1
#include <omp.h>
#else
#define KG_OMP 0
#endif

// AVX2 手写内核：只在 x86-64 + MSVC 上启用（其余平台走标量回退）。
#if defined(_MSC_VER) && (defined(_M_X64) || defined(_M_AMD64)) && !defined(KG_NO_AVX2)
#include <immintrin.h>
#include <intrin.h>
#define KG_X64_SIMD 1
#else
#define KG_X64_SIMD 0
#endif

namespace kg {

// 线程数（0 = 自动）。搜索与算子共用。
inline int& threadCount() { static int n = 0; return n; }
inline int effectiveThreads() {
    if (!KG_OMP) return 1;
    int n = threadCount();
    if (n <= 0) {
#if KG_OMP
        n = omp_get_max_threads();
#endif
    }
    if (n < 1) n = 1;
    return n;
}

// 运行时探测 AVX2 + FMA（并确认 OS 保存了 YMM 状态）。
inline bool cpuHasAvx2() {
#if KG_X64_SIMD
    static const bool ok = []() -> bool {
        int r[4] = {0, 0, 0, 0};
        __cpuid(r, 0);
        if (r[0] < 7) return false;
        __cpuid(r, 1);
        const bool osxsave = (r[2] & (1 << 27)) != 0;
        const bool avx = (r[2] & (1 << 28)) != 0;
        const bool fma = (r[2] & (1 << 12)) != 0;   // CPUID.01H:ECX.FMA
        if (!osxsave || !avx || !fma) return false;
        const unsigned long long xcr0 = _xgetbv(0);
        if ((xcr0 & 0x6ULL) != 0x6ULL) return false;   // XMM + YMM 状态已开启
        __cpuidex(r, 7, 0);
        const bool avx2 = (r[1] & (1 << 5)) != 0;      // CPUID.(EAX=7,ECX=0):EBX.AVX2
        return avx2;
    }();
    return ok;
#else
    return false;
#endif
}

// ---------------------------------------------------------------- 基础工具
inline void zeroFill(std::vector<float>& v, size_t n) {
    v.assign(n, 0.0f);
}

// ---------------------------------------------------------------- 向量 exp
// exp(x) 的 8 路向量版本：x = n*ln2 + r, |r| <= ln2/2，多项式近似 exp(r)，
// 再乘 2^n。相对误差约 1e-7（够 SiLU 与 softmax 用，远小于 1e-4 容差）。
#if KG_X64_SIMD
inline __m256 exp256_ps(__m256 x) {
    const __m256 ln2_hi = _mm256_set1_ps(0.693145751953125f);
    const __m256 ln2_lo = _mm256_set1_ps(1.428606765330187045e-06f);
    const __m256 inv_ln2 = _mm256_set1_ps(1.44269504088896341f);
    // 夹到 [-87, 87]，避免 2^n 的指数位溢出（更极端的输入在 SiLU 里结果就是 0/x）
    x = _mm256_min_ps(x, _mm256_set1_ps(87.0f));
    x = _mm256_max_ps(x, _mm256_set1_ps(-87.0f));
    __m256 fn = _mm256_round_ps(_mm256_mul_ps(x, inv_ln2),
                                _MM_FROUND_TO_NEAREST_INT | _MM_FROUND_NO_EXC);
    __m256 r = _mm256_fnmadd_ps(fn, ln2_hi, x);
    r = _mm256_fnmadd_ps(fn, ln2_lo, r);
    __m256 p = _mm256_set1_ps(1.0f / 720.0f);
    p = _mm256_fmadd_ps(p, r, _mm256_set1_ps(1.0f / 120.0f));
    p = _mm256_fmadd_ps(p, r, _mm256_set1_ps(1.0f / 24.0f));
    p = _mm256_fmadd_ps(p, r, _mm256_set1_ps(1.0f / 6.0f));
    p = _mm256_fmadd_ps(p, r, _mm256_set1_ps(0.5f));
    p = _mm256_fmadd_ps(p, r, _mm256_set1_ps(1.0f));
    p = _mm256_fmadd_ps(p, r, _mm256_set1_ps(1.0f));
    __m256i e = _mm256_slli_epi32(
        _mm256_add_epi32(_mm256_cvtps_epi32(fn), _mm256_set1_epi32(127)), 23);
    return _mm256_mul_ps(p, _mm256_castsi256_ps(e));
}
#endif

// 一段 SiLU（标量/向量由宏决定），不负责线程切分
inline void siluRange(float* __restrict x, size_t n) {
#if KG_X64_SIMD
    size_t i = 0;
    if (cpuHasAvx2()) {
        const __m256 one = _mm256_set1_ps(1.0f);
        const __m256 zero = _mm256_setzero_ps();
        for (; i + 7 < n; i += 8) {
            __m256 v = _mm256_loadu_ps(x + i);
            __m256 e = exp256_ps(_mm256_sub_ps(zero, v));  // exp(-v)
            __m256 den = _mm256_add_ps(one, e);
            _mm256_storeu_ps(x + i, _mm256_div_ps(v, den));
        }
    }
#endif
    for (; i < n; ++i) {
        float v = x[i];
        x[i] = v / (1.0f + std::exp(-v));
    }
}

// 逐点 SiLU（原地）；大数组按块并行
inline void siluInPlace(float* x, size_t n) {
    const size_t CH = 16384;
    const size_t ntasks = (n + CH - 1) / CH;
#if KG_OMP
    const int nt = effectiveThreads();
    if (nt > 1 && ntasks > 1) {
#pragma omp parallel for schedule(static) num_threads(nt)
        for (long long t = 0; t < (long long)ntasks; ++t) {
            const size_t b = (size_t)t * CH;
            const size_t e = (b + CH < n) ? (b + CH) : n;
            siluRange(x + b, e - b);
        }
        return;
    }
#endif
    siluRange(x, n);
}

// SwiGLU 使用的融合算子：a[i] = silu(a[i]) * b[i]
inline void siluMulRange(float* __restrict a, const float* __restrict b, size_t n) {
    size_t i = 0;
#if KG_X64_SIMD
    if (cpuHasAvx2()) {
        const __m256 one = _mm256_set1_ps(1.0f);
        const __m256 zero = _mm256_setzero_ps();
        for (; i + 7 < n; i += 8) {
            __m256 v = _mm256_loadu_ps(a + i);
            __m256 e = exp256_ps(_mm256_sub_ps(zero, v));
            __m256 r = _mm256_div_ps(v, _mm256_add_ps(one, e));
            _mm256_storeu_ps(a + i, _mm256_mul_ps(r, _mm256_loadu_ps(b + i)));
        }
    }
#endif
    for (; i < n; ++i) {
        float v = a[i];
        a[i] = (v / (1.0f + std::exp(-v))) * b[i];
    }
}

inline void siluMulInPlace(float* __restrict a, const float* __restrict b, size_t n) {
    const size_t CH = 16384;
    const size_t ntasks = (n + CH - 1) / CH;
#if KG_OMP
    const int nt = effectiveThreads();
    if (nt > 1 && ntasks > 1) {
#pragma omp parallel for schedule(static) num_threads(nt)
        for (long long t = 0; t < (long long)ntasks; ++t) {
            const size_t bb = (size_t)t * CH;
            const size_t ee = (bb + CH < n) ? (bb + CH) : n;
            siluMulRange(a + bb, b + bb, ee - bb);
        }
        return;
    }
#endif
    siluMulRange(a, b, n);
}

// 逐点 SiLU（官方用 torch.nn.SiLU）
inline void applyActivation(std::vector<float>& v, const std::string& kind) {
    if (kind == "ACTIVATION_SILU") {
        siluInPlace(v.data(), v.size());
    } else if (kind == "ACTIVATION_IDENTITY") {
        // 什么都不做
    } else if (kind == "ACTIVATION_RELU") {
        for (size_t i = 0; i < v.size(); ++i)
            if (v[i] < 0.0f) v[i] = 0.0f;
    } else if (kind == "ACTIVATION_MISH") {
        for (size_t i = 0; i < v.size(); ++i) {
            float v0 = v[i];
            float sp = std::log1p(std::exp(v0));   // softplus
            v[i] = v0 * std::tanh(sp);
        }
    } else if (kind.empty()) {
        // 无激活
    } else {
        throw std::runtime_error("unsupported activation: " + kind);
    }
}

// dst[i] += src[i]（残差累加用；原地，n 可达几十万）
inline void addInPlace(float* __restrict dst, const float* __restrict src, size_t n) {
    size_t i = 0;
#if KG_X64_SIMD
    if (cpuHasAvx2()) {
        for (; i + 7 < n; i += 8) {
            __m256 a = _mm256_loadu_ps(dst + i);
            __m256 b = _mm256_loadu_ps(src + i);
            _mm256_storeu_ps(dst + i, _mm256_add_ps(a, b));
        }
    }
#endif
    for (; i < n; ++i) dst[i] += src[i];
}

// 通道数
inline int channelsOf(const std::vector<float>& v, int S) {
    return (S > 0) ? (int)(v.size() / (size_t)S) : 0;
}

// ---------------------------------------------------------------- 归一化
// fixscale 归一化： y = x * (fixScale * gamma) + beta ，再乘掩码。
//   fixScale：逐块常量 1/sqrt(i+1)（由 load 阶段按块序号设置，文件里没有）
//   gamma   ：逐通道参数；为空表示该分支不使用 gamma（如 normactconvp）
// x 布局 (S, C)，mask 长度 S。
inline void normMaskApply(const std::vector<float>& x, int S, int C, const NormLayer& n,
                          const std::vector<float>& mask, std::vector<float>& out) {
    out.resize(x.size());
    if (S <= 0 || C <= 0) return;
    const bool hasBias = (n.bias.size() == (size_t)C);
    const bool hasMul = (n.scaleMul.size() == (size_t)C);
    const bool hasMask = !mask.empty();
    for (int s = 0; s < S; ++s) {
        const float m = hasMask ? mask[s] : 1.0f;
        const float* src = &x[(size_t)s * C];
        float* dst = &out[(size_t)s * C];
        if (hasMul) {
            if (hasBias) {
                int c = 0;
#if KG_X64_SIMD
                if (cpuHasAvx2()) {
                    const __m256 vm = _mm256_set1_ps(m);
                    for (; c + 7 < C; c += 8) {
                        __m256 v = _mm256_loadu_ps(src + c);
                        __m256 g = _mm256_loadu_ps(n.scaleMul.data() + c);
                        __m256 b = _mm256_loadu_ps(n.bias.data() + c);
                        _mm256_storeu_ps(dst + c,
                                         _mm256_mul_ps(_mm256_fmadd_ps(v, g, b), vm));
                    }
                }
#endif
                for (; c < C; ++c) dst[c] = (src[c] * n.scaleMul[c] + n.bias[c]) * m;
            } else {
                for (int c = 0; c < C; ++c) dst[c] = (src[c] * n.scaleMul[c]) * m;
            }
        } else if (hasBias) {
            for (int c = 0; c < C; ++c) dst[c] = (src[c] + n.bias[c]) * m;
        } else {
            if (m == 1.0f) {
                std::memcpy(dst, src, sizeof(float) * (size_t)C);
            } else {
                for (int c = 0; c < C; ++c) dst[c] = src[c] * m;
            }
        }
    }
}

// RMSNorm（非 spatial）：对每个位置的通道求 RMS 后归一化，再乘 weight
inline void rmsNormApply(const std::vector<float>& x, int S, int C,
                         const std::vector<float>& weight, float eps,
                         std::vector<float>& out) {
    out.resize(x.size());
    if (S <= 0 || C <= 0) return;
    for (int s = 0; s < S; ++s) {
        const float* src = &x[(size_t)s * C];
        float* dst = &out[(size_t)s * C];
        float ss = 0.0f;
        int c = 0;
#if KG_X64_SIMD
        if (cpuHasAvx2()) {
            __m256 a0 = _mm256_setzero_ps(), a1 = _mm256_setzero_ps();
            for (; c + 15 < C; c += 16) {
                __m256 v0 = _mm256_loadu_ps(src + c);
                __m256 v1 = _mm256_loadu_ps(src + c + 8);
                a0 = _mm256_fmadd_ps(v0, v0, a0);
                a1 = _mm256_fmadd_ps(v1, v1, a1);
            }
            __m256 a = _mm256_add_ps(a0, a1);
            __m128 lo = _mm256_castps256_ps128(a);
            __m128 hi = _mm256_extractf128_ps(a, 1);
            lo = _mm_add_ps(lo, hi);
            lo = _mm_hadd_ps(lo, lo);
            lo = _mm_hadd_ps(lo, lo);
            ss = _mm_cvtss_f32(lo);
        }
#endif
        for (; c < C; ++c) ss += src[c] * src[c];
        const float inv = 1.0f / std::sqrt(ss / (float)C + eps);
        c = 0;
#if KG_X64_SIMD
        if (cpuHasAvx2()) {
            const __m256 vi = _mm256_set1_ps(inv);
            for (; c + 7 < C; c += 8) {
                __m256 v = _mm256_loadu_ps(src + c);
                __m256 w = _mm256_loadu_ps(weight.data() + c);
                _mm256_storeu_ps(dst + c, _mm256_mul_ps(_mm256_mul_ps(v, vi), w));
            }
        }
#endif
        for (; c < C; ++c) dst[c] = src[c] * inv * weight[c];
    }
}

// ---------------------------------------------------------------- 矩阵乘
// out(S, OC) = x(S, IC) * W^T，Wt 为 (IC, OC) 预转置布局。
//
// 性能要点（都是被 bench_forward 量出来的，不是猜的）：
//
//   最朴素的写法是 "for s { for i { for k: out[s][k] += x[s][i]*w[i][k] } }"，
//   它对每个局面都要把整个权重矩阵读一遍 —— 流量 S*IC*OC*4 字节。实测
//   q_proj（IC=OC=384, S=361）要 7.92 ms，合 213 MB / 7.92 ms = 26.9 GB/s，
//   完全是内存带宽瓶颈，算力只用到 13 GFLOPS（这台机器能到 500 上下）。
//
//   解法是经典三重分块：输出按 (SB 行 × KB 列) 切块，让"输出块 + 权重块"
//   都留在 L1 里。这样权重流量从 S*IC*OC 降到 (S/SB)*IC*OC，约 S/SB 倍。
//
//   2026-10 再进一步：改用 AVX2 4x16 寄存器分块微内核（8 个 ymm 累加器），
//   每个 (4 行 x 16 列) 输出块在寄存器里完成整个 IC 归约，权重与 x 都只从
//   L1/L2 读一遍，实测单核从 ~6 GFLOPS 提到 ~45 GFLOPS。
//   S <= 3 的线性层（全局池化/价值头）走 GEMV 路径，连转置都不需要。

// 点积（GEMV 用）
inline float dotProduct(const float* __restrict a, const float* __restrict b, int n) {
    float s = 0.0f;
    int i = 0;
#if KG_X64_SIMD
    if (cpuHasAvx2()) {
        __m256 a0 = _mm256_setzero_ps(), a1 = _mm256_setzero_ps();
        for (; i + 15 < n; i += 16) {
            __m256 v0 = _mm256_loadu_ps(a + i);
            __m256 w0 = _mm256_loadu_ps(b + i);
            __m256 v1 = _mm256_loadu_ps(a + i + 8);
            __m256 w1 = _mm256_loadu_ps(b + i + 8);
            a0 = _mm256_fmadd_ps(v0, w0, a0);
            a1 = _mm256_fmadd_ps(v1, w1, a1);
        }
        __m256 t = _mm256_add_ps(a0, a1);
        __m128 lo = _mm256_castps256_ps128(t);
        __m128 hi = _mm256_extractf128_ps(t, 1);
        lo = _mm_add_ps(lo, hi);
        lo = _mm_hadd_ps(lo, lo);
        lo = _mm_hadd_ps(lo, lo);
        s = _mm_cvtss_f32(lo);
    }
#endif
    for (; i < n; ++i) s += a[i] * b[i];
    return s;
}

#if KG_X64_SIMD
namespace gemm_detail {

// 4 行 x 16 列输出微内核：8 个 ymm 累加器，完成整个 IC 归约。
// 每个 i：2 次权重向量加载 + 4 次 broadcast + 8 次 FMA（负载/算力基本平衡）。
inline void micro4x16(const float* __restrict a0, const float* __restrict a1,
                      const float* __restrict a2, const float* __restrict a3,
                      const float* __restrict W, int IC, int OC, int k0,
                      __m256 bias0, __m256 bias1, float* __restrict c0,
                      float* __restrict c1, float* __restrict c2,
                      float* __restrict c3) {
    __m256 c00 = bias0, c01 = bias1;
    __m256 c10 = bias0, c11 = bias1;
    __m256 c20 = bias0, c21 = bias1;
    __m256 c30 = bias0, c31 = bias1;
    const float* b = W + (size_t)k0;
    for (int i = 0; i < IC; ++i) {
        __m256 w0 = _mm256_loadu_ps(b);
        __m256 w1 = _mm256_loadu_ps(b + 8);
        __m256 va = _mm256_broadcast_ss(a0 + i);
        __m256 vb = _mm256_broadcast_ss(a1 + i);
        __m256 vc = _mm256_broadcast_ss(a2 + i);
        __m256 vd = _mm256_broadcast_ss(a3 + i);
        c00 = _mm256_fmadd_ps(va, w0, c00);
        c01 = _mm256_fmadd_ps(va, w1, c01);
        c10 = _mm256_fmadd_ps(vb, w0, c10);
        c11 = _mm256_fmadd_ps(vb, w1, c11);
        c20 = _mm256_fmadd_ps(vc, w0, c20);
        c21 = _mm256_fmadd_ps(vc, w1, c21);
        c30 = _mm256_fmadd_ps(vd, w0, c30);
        c31 = _mm256_fmadd_ps(vd, w1, c31);
        b += OC;
    }
    _mm256_storeu_ps(c0, c00);
    _mm256_storeu_ps(c0 + 8, c01);
    _mm256_storeu_ps(c1, c10);
    _mm256_storeu_ps(c1 + 8, c11);
    _mm256_storeu_ps(c2, c20);
    _mm256_storeu_ps(c2 + 8, c21);
    _mm256_storeu_ps(c3, c30);
    _mm256_storeu_ps(c3 + 8, c31);
}

// 4 行（整行，OC 任意）的标量兜底：尾部行 / 尾部列 / OC<16 时用
inline void rowsScalar(const float* __restrict x, const float* __restrict W, int IC,
                       int OC, const float* bias, float* __restrict o, int s0, int s1,
                       int k0, int k1) {
    for (int s = s0; s < s1; ++s) {
        const float* a = x + (size_t)s * IC;
        float* c = o + (size_t)s * OC;
        for (int k = k0; k < k1; ++k) {
            float acc = 0.0f;
            for (int i = 0; i < IC; ++i) acc += a[i] * W[(size_t)i * OC + k];
            c[k] = bias ? (acc + bias[k]) : acc;
        }
    }
}

// AVX2 主路径。
//
// 任务划分：(行组 SB=32 行) x (列块 KCH=64 列)，一个任务内部按 16 列一列的
// 权重条带顺序遍历，使 (IC x 16) 的权重条带在 L1 里被该行组的 8 个 4 行微内核
// 反复复用。这样整个权重矩阵每个行组只从 L2 读一遍（S/32 遍），而不是每个 4 行
// 块都读一遍（S/4 遍）—— 权重流量降到 1/8，384x384 的 GEMM 从 L2 带宽瓶颈
// 变回计算瓶颈。
// dynamic 调度：这台机器 P/E 核速度不一致，且常有其它进程抢占 CPU。
inline void linearApplyTAvx2(const float* __restrict x, int S, int IC, int OC,
                             const float* __restrict W, const float* bias,
                             float* __restrict o) {
    const int nRB = S / 4;              // 整 4 行块数
    const int kFull = (OC / 16) * 16;   // 16 列对齐部分
    const int nt = effectiveThreads();
    const int SB = 64;                  // 行组大小（16 个 4 行块）
    const int KCH = 32;                 // 列块大小（2 个 16 列块）
    const int nRowGroups = (nRB + SB / 4 - 1) / (SB / 4);
    const int nKCh = (kFull + KCH - 1) / KCH;
    const int ntasks = nRowGroups * nKCh;

    auto doTask = [&](int task) {
        const int rg = task / nKCh;
        const int kc = task % nKCh;
        const int s0 = rg * SB;
        const int s1 = (s0 + SB < nRB * 4) ? (s0 + SB) : (nRB * 4);
        const int k0 = kc * KCH;
        const int k1 = (k0 + KCH < kFull) ? (k0 + KCH) : kFull;
        for (int kk = k0; kk < k1; kk += 16) {
            __m256 bv0 = bias ? _mm256_loadu_ps(bias + kk) : _mm256_setzero_ps();
            __m256 bv1 = bias ? _mm256_loadu_ps(bias + kk + 8) : _mm256_setzero_ps();
            for (int s = s0; s < s1; s += 4) {
                const float* a0 = x + (size_t)s * IC;
                float* c0 = o + (size_t)s * OC;
                micro4x16(a0, a0 + IC, a0 + 2 * IC, a0 + 3 * IC, W, IC, OC, kk, bv0, bv1,
                          c0 + kk, c0 + OC + kk, c0 + 2 * OC + kk, c0 + 3 * OC + kk);
            }
        }
    };

#if KG_OMP
    if (nt > 1 && ntasks >= 4) {
#pragma omp parallel for schedule(dynamic, 1) num_threads(nt)
        for (int task = 0; task < ntasks; ++task) doTask(task);
    } else
#endif
    {
        for (int task = 0; task < ntasks; ++task) doTask(task);
    }
    // 尾部列（OC % 16）与尾部行（S % 4）：标量兜底，量很小
    if (kFull < OC) {
        for (int s = 0; s < nRB * 4; ++s)
            rowsScalar(x, W, IC, OC, bias, o, s, s + 1, kFull, OC);
    }
    if (nRB * 4 < S) rowsScalar(x, W, IC, OC, bias, o, nRB * 4, S, 0, OC);
}

}  // namespace gemm_detail
#endif  // KG_X64_SIMD

inline void linearApplyT(const std::vector<float>& x, int S, int IC, int OC,
                         const std::vector<float>& Wt,  // (IC, OC)
                         const float* bias, std::vector<float>& out) {
    if (S <= 0 || IC <= 0 || OC <= 0 || (size_t)Wt.size() < (size_t)IC * OC ||
        (size_t)x.size() < (size_t)S * IC) {
        out.assign((size_t)(S > 0 ? S : 0) * (size_t)(OC > 0 ? OC : 0), 0.0f);
        return;
    }
    out.resize((size_t)S * OC);   // 下面会写满每个元素，无需清零
    const float* xp = x.data();
    const float* w = Wt.data();
    float* o = out.data();
#if KG_X64_SIMD
    if (cpuHasAvx2()) {
        gemm_detail::linearApplyTAvx2(xp, S, IC, OC, w, bias, o);
        return;
    }
#endif
    // ---- 标量回退（保持原实现的分块，供无 AVX2 的老机器）----
    if (bias) {
        for (int s = 0; s < S; ++s) {
            float* orow = o + (size_t)s * OC;
            for (int k = 0; k < OC; ++k) orow[k] = bias[k];
        }
    } else {
        std::memset(o, 0, sizeof(float) * (size_t)S * OC);
    }
    const int SB = 32, KB = 128;
    const int nS = (S + SB - 1) / SB;
    const int nK = (OC + KB - 1) / KB;
    const int nt = effectiveThreads();
#if KG_OMP
    if (nt > 1 && nS >= 2) {
#pragma omp parallel for schedule(static) num_threads(nt)
        for (int bs = 0; bs < nS; ++bs) {
            const int s0 = bs * SB;
            const int s1 = (s0 + SB < S) ? (s0 + SB) : S;
            for (int bk = 0; bk < nK; ++bk) {
                const int k0 = bk * KB;
                const int k1 = (k0 + KB < OC) ? (k0 + KB) : OC;
                const int kb = k1 - k0;
                for (int i = 0; i < IC; ++i) {
                    const float* wrow = w + (size_t)i * OC + k0;
                    for (int s = s0; s < s1; ++s) {
                        const float xi = xp[(size_t)s * IC + i];
                        if (xi == 0.0f) continue;
                        float* orow = o + (size_t)s * OC + k0;
                        for (int k = 0; k < kb; ++k) orow[k] += xi * wrow[k];
                    }
                }
            }
        }
        return;
    }
#endif
    for (int bs = 0; bs < nS; ++bs) {
        const int s0 = bs * SB;
        const int s1 = (s0 + SB < S) ? (s0 + SB) : S;
        for (int bk = 0; bk < nK; ++bk) {
            const int k0 = bk * KB;
            const int k1 = (k0 + KB < OC) ? (k0 + KB) : OC;
            const int kb = k1 - k0;
            for (int i = 0; i < IC; ++i) {
                const float* wrow = w + (size_t)i * OC + k0;
                for (int s = s0; s < s1; ++s) {
                    const float xi = xp[(size_t)s * IC + i];
                    if (xi == 0.0f) continue;
                    float* orow = o + (size_t)s * OC + k0;
                    for (int k = 0; k < kb; ++k) orow[k] += xi * wrow[k];
                }
            }
        }
    }
}

// GEMV：S 很小（1~3）时直接按 W(oc,ic) 行做点积，不需要转置。
inline void gemvApply(const std::vector<float>& x, int S, int IC, int OC,
                      const std::vector<float>& W, const float* bias,
                      std::vector<float>& out) {
    out.resize((size_t)S * OC);
    const float* w = W.data();
    const float* xp = x.data();
    for (int k = 0; k < OC; ++k) {
        const float* wrow = w + (size_t)k * IC;
        const float b = bias ? bias[k] : 0.0f;
        for (int s = 0; s < S; ++s) {
            out[(size_t)s * OC + k] = dotProduct(xp + (size_t)s * IC, wrow, IC) + b;
        }
    }
}

// 兼容接口：内部先转置（单次调用；热路径请用 linearApplyCached）
inline void linearApply(const std::vector<float>& x, int S, int IC, int OC,
                        const std::vector<float>& W, const float* bias,
                        std::vector<float>& out) {
    if (W.empty() || (int)W.size() < IC * OC) { out.assign((size_t)S * OC, 0.0f); return; }
    if (S <= 3) {   // 小 S 走 GEMV，省掉整个权重矩阵的转置
        gemvApply(x, S, IC, OC, W, bias, out);
        return;
    }
    std::vector<float> Wt((size_t)IC * OC);
    for (int o = 0; o < OC; ++o) {
        const float* src = &W[(size_t)o * IC];
        float* dst = &Wt[(size_t)o];
        for (int i = 0; i < IC; ++i) dst[(size_t)i * OC] = src[i];
    }
    linearApplyT(x, S, IC, OC, Wt, bias, out);
}

// ------------------------------------------------------- 权重转置缓存
// 按权重数据地址缓存 (ic, oc) 转置副本。Forward 持有本对象：模型权重在
// Forward 生命周期内不变，所以缓存永远命中；模型重载会重建 Forward，缓存随之重建。
class LinearWeightCache {
public:
    // 返回 W (oc,ic) 的 (ic,oc) 转置副本；尺寸不合法时返回空数组。
    const std::vector<float>& getTransposed(const std::vector<float>& W, int IC, int OC) const {
        if (IC <= 0 || OC <= 0 || W.size() < (size_t)IC * OC) return empty_;
        if (map_.empty() && !built_) {
            map_.reserve(512);
            built_ = true;
        }
        std::lock_guard<std::mutex> lk(mtx_);
        Entry& e = map_[W.data()];
        if (e.ic == IC && e.oc == OC && e.wt.size() == (size_t)IC * OC) return e.wt;
        e.wt.resize((size_t)IC * OC);
        transposeInto(W.data(), IC, OC, e.wt.data());
        e.ic = IC;
        e.oc = OC;
        return e.wt;
    }
    size_t totalBytes() const {
        std::lock_guard<std::mutex> lk(mtx_);
        size_t n = 0;
        for (std::unordered_map<const float*, Entry>::const_iterator it = map_.begin();
             it != map_.end(); ++it)
            n += it->second.wt.size() * sizeof(float);
        return n;
    }
    void clear() {
        std::lock_guard<std::mutex> lk(mtx_);
        map_.clear();
    }

private:
    struct Entry {
        int ic = 0, oc = 0;
        std::vector<float> wt;
    };
    static void transposeInto(const float* __restrict src, int IC, int OC,
                              float* __restrict dst) {
        for (int o = 0; o < OC; ++o) {
            const float* s = src + (size_t)o * IC;
            float* d = dst + o;
            for (int i = 0; i < IC; ++i) d[(size_t)i * OC] = s[i];
        }
    }
    mutable std::mutex mtx_;
    mutable std::unordered_map<const float*, Entry> map_;
    mutable bool built_ = false;
    mutable std::vector<float> empty_;
};

// 带转置缓存的线性层
inline void linearApplyCached(const std::vector<float>& x, int S, int IC, int OC,
                              const std::vector<float>& W, const float* bias,
                              std::vector<float>& out, const LinearWeightCache& cache) {
    if (W.size() < (size_t)IC * OC || IC <= 0 || OC <= 0) {
        out.assign((size_t)S * OC, 0.0f);
        return;
    }
    if (S <= 3) {   // 价值头/全局池化等 S==1 的层：GEMV，无需转置
        gemvApply(x, S, IC, OC, W, bias, out);
        return;
    }
    const std::vector<float>& wt = cache.getTransposed(W, IC, OC);
    linearApplyT(x, S, IC, OC, wt, bias, out);
}

// ---------------------------------------------------------------- 卷积
// 1x1 卷积 = 逐点线性映射（等价于在 (S,C) 上做矩阵乘）
inline void conv1x1Apply(const std::vector<float>& x, int S,
                         const ConvLayer& c, std::vector<float>& out) {
    linearApply(x, S, c.ic, c.oc, c.w, nullptr, out);
}

inline void conv1x1ApplyCached(const std::vector<float>& x, int S, const ConvLayer& c,
                               std::vector<float>& out, const LinearWeightCache& cache) {
    linearApplyCached(x, S, c.ic, c.oc, c.w, nullptr, out, cache);
}

// 3x3（或任意奇数核）卷积，same padding，输入 (C,H,W) 输出 (OC,H,W)。
// 直接卷积：对每个核位置做一次矩阵乘累加。SIMD 友好（最内层是 ic 连续）。
inline void convSpatialApply(const std::vector<float>& x, int C, int H, int W,
                             const ConvLayer& c, std::vector<float>& out) {
    const int OC = c.oc;
    const int ky = c.ky, kx = c.kx;
    const int py = ky / 2, px = kx / 2;
    const size_t HW = (size_t)H * W;
    out.assign((size_t)OC * HW, 0.0f);

    // 逐核位置：把 pad 后的 (H,W) 上偏移 (dy,dx) 的输入，与核片段做矩阵乘
    for (int dy = 0; dy < ky; ++dy) {
        const int oy0 = dy - py;                 // 输出行 y 对应的输入行 = y + oy0
        const int yLo = (oy0 < 0) ? -oy0 : 0;
        const int yHi = (oy0 > 0) ? (H - oy0) : H;
        if (yLo >= yHi) continue;
        for (int dx = 0; dx < kx; ++dx) {
            const int ox0 = dx - px;
            const int xLo = (ox0 < 0) ? -ox0 : 0;
            const int xHi = (ox0 > 0) ? (W - ox0) : W;
            if (xLo >= xHi) continue;
            const int nOut = xHi - xLo;          // 这一行有效输出点数
            const int kstride = ky * kx;
            (void)nOut;
#if KG_OMP
            // 按输出通道并行（每个通道独立累加，无竞争）
            const int nt = effectiveThreads();
#pragma omp parallel for schedule(static) num_threads(nt)
            for (int o = 0; o < OC; ++o) {
                for (int y = yLo; y < yHi; ++y) {
                    const int iy = y + oy0;
                    for (int xl = xLo; xl < xHi; ++xl) {
                        const int ix = xl + ox0;
                        const size_t oIdx = (size_t)y * W + xl;
                        const size_t iIdx = (size_t)iy * W + ix;
                        const float* xp = &x[iIdx];
                        const float* wp = &c.w[(size_t)(o * c.ic) * kstride + dy * kx + dx];
                        float acc = 0.0f;
                        for (int i = 0; i < c.ic; ++i)
                            acc += xp[(size_t)i * HW] * wp[(size_t)i * kstride];
                        out[(size_t)o * HW + oIdx] += acc;
                    }
                }
            }
#else
            for (int y = yLo; y < yHi; ++y) {
                const int iy = y + oy0;
                for (int xl = xLo; xl < xHi; ++xl) {
                    const int ix = xl + ox0;
                    const size_t oIdx = (size_t)y * W + xl;
                    const size_t iIdx = (size_t)iy * W + ix;
                    // 对每个输出通道累加：核元素按 (ic, ky, kx) 排布
                    const float* xp = &x[iIdx];
                    for (int o = 0; o < OC; ++o) {
                        const float* wp = &c.w[(size_t)(o * c.ic) * kstride + dy * kx + dx];
                        float acc = 0.0f;
                        for (int i = 0; i < c.ic; ++i)
                            acc += xp[(size_t)i * HW] * wp[(size_t)i * kstride];
                        out[(size_t)o * HW + oIdx] += acc;
                    }
                }
            }
#endif
        }
    }
}

// ---------------------------------------------------------------- 全局池化
// 官方有两个不同的 gpool，第三路不相同：
//
//   KataGPool（策略头用）：
//       pool1 = mean, pool2 = mean*((sqrt(maskSum)-14)/10), pool3 = max(x + (mask-1))
//   KataValueHeadGPool（价值头用）：
//       pool1 = mean, pool2 = mean*((sqrt(maskSum)-14)/10),
//       pool3 = mean * (((sqrt(maskSum)-14)^2)/100 - 0.1)
//
// 两者前两路相同，只有第三路不同。用 idx1 标志区分。
// x 布局 (S, C)，mask 长度 S。输出 (3*C,)。
inline void gpoolApplyEx(const std::vector<float>& x, int S, int C,
                         const std::vector<float>& mask, float maskSum,
                         bool valueMode, std::vector<float>& out) {
    out.assign((size_t)3 * C, 0.0f);
    if (S <= 0 || maskSum <= 0.0f) return;
    const float off = std::sqrt(maskSum) - 14.0f;
    const float scale2 = off / 10.0f;
    const float scale3 = (off * off) / 100.0f - 0.1f;

    for (int c = 0; c < C; ++c) {
        float sum = 0.0f, mx = -1e30f;
        for (int s = 0; s < S; ++s) {
            float v = x[(size_t)s * C + c];
            float m = mask.empty() ? 1.0f : mask[s];
            sum += v * m;
            // 官方：max(x + (mask-1))，即盘外当 -1
            float vm = v + (m - 1.0f);
            if (vm > mx) mx = vm;
        }
        float mean = sum / maskSum;
        out[c] = mean;
        out[C + c] = mean * scale2;
        out[2 * C + c] = valueMode ? (mean * scale3) : mx;
    }
}

// 策略头版（第三路取 max）
inline void gpoolApply(const std::vector<float>& x, int S, int C,
                       const std::vector<float>& mask, float maskSum,
                       std::vector<float>& out) {
    gpoolApplyEx(x, S, C, mask, maskSum, false, out);
}

// 价值头版（第三路取 mean 的二次式）
inline void gpoolValueApply(const std::vector<float>& x, int S, int C,
                            const std::vector<float>& mask, float maskSum,
                            std::vector<float>& out) {
    gpoolApplyEx(x, S, C, mask, maskSum, true, out);
}

// ---------------------------------------------------------------- RoPE
// 可学习 2D RoPE（官方 compute_learnable_rope_cos_sin + apply_learnable_rotary_emb）
//   angle[s][h][p] = freqs[h][p][0] * x(s) + freqs[h][p][1] * y(s)
//   对每个 2 元组 (x0,x1): (x0*cos - x1*sin, x0*sin + x1*cos)
// x 布局 (S, H*D)，D 为 head dim（必须偶数）；freqs 布局 (H, P, 2)，P = D/2。
//
// 关键优化：angle 只和 (s, h, p) 有关，与输入 x 无关。每个前向会调用几十次
// （q 和 k 各一次/注意力块），原来每次都要算 9M 次 std::cos/std::sin。
// 这里把 cos/sin 预算成表按 (S,H,P) 缓存（freqs 内容变了会自动重建）。
struct RopeTable {
    std::mutex mtx;
    std::vector<float> cosv;   // (S*H*P)
    std::vector<float> sinv;   // (S*H*P)
    std::vector<float> freqCopy;
    int S = 0, H = 0, D = 0, posLen = 0;
};

inline RopeTable& ropeTableRef() {
    static RopeTable t;
    return t;
}

inline void ropeApply(std::vector<float>& x, int S, int H, int D,
                      const std::vector<float>& freqs, int posLen) {
    const int P = D / 2;
    if (P <= 0 || S <= 0 || H <= 0 || posLen <= 0) return;
    if ((size_t)x.size() < (size_t)S * H * D) return;
    if (freqs.size() < (size_t)H * P * 2) return;

    RopeTable& T = ropeTableRef();
    std::lock_guard<std::mutex> lk(T.mtx);
    const size_t n = (size_t)S * H * P;
    bool needBuild = (T.S != S || T.H != H || T.D != D || T.posLen != posLen ||
                      T.freqCopy.size() != freqs.size() ||
                      T.cosv.size() != n ||
                      !std::equal(freqs.begin(), freqs.end(), T.freqCopy.begin()));
    if (needBuild) {
        T.cosv.resize(n);
        T.sinv.resize(n);
        T.freqCopy = freqs;
        T.S = S; T.H = H; T.D = D; T.posLen = posLen;
        float* cv = T.cosv.data();
        float* sv = T.sinv.data();
        for (int s = 0; s < S; ++s) {
            const float sy = (float)(s / posLen);
            const float sx = (float)(s % posLen);
            for (int h = 0; h < H; ++h) {
                const float* f = &freqs[(size_t)h * P * 2];
                float* cbase = cv + ((size_t)s * H + h) * P;
                float* sbase = sv + ((size_t)s * H + h) * P;
                for (int p = 0; p < P; ++p) {
                    const float ang = f[(size_t)p * 2 + 0] * sx + f[(size_t)p * 2 + 1] * sy;
                    cbase[p] = std::cos(ang);
                    sbase[p] = std::sin(ang);
                }
            }
        }
    }
    const float* cv = T.cosv.data();
    const float* sv = T.sinv.data();
    const size_t rowLen = (size_t)H * D;
#if KG_OMP
    const int nt = effectiveThreads();
    if (nt > 1 && S >= 4 * nt) {
#pragma omp parallel for schedule(static) num_threads(nt)
        for (int s = 0; s < S; ++s) {
            float* base = x.data() + (size_t)s * rowLen;
            const float* cbase = cv + (size_t)s * H * P;
            const float* sbase = sv + (size_t)s * H * P;
            for (int h = 0; h < H; ++h) {
                float* bp = base + (size_t)h * D;
                const float* cp = cbase + (size_t)h * P;
                const float* sp = sbase + (size_t)h * P;
                for (int p = 0; p < P; ++p) {
                    const float co = cp[p], si = sp[p];
                    const float x0 = bp[2 * p], x1 = bp[2 * p + 1];
                    bp[2 * p] = x0 * co - x1 * si;
                    bp[2 * p + 1] = x0 * si + x1 * co;
                }
            }
        }
        return;
    }
#endif
    for (int s = 0; s < S; ++s) {
        float* base = x.data() + (size_t)s * rowLen;
        const float* cbase = cv + (size_t)s * H * P;
        const float* sbase = sv + (size_t)s * H * P;
        for (int h = 0; h < H; ++h) {
            float* bp = base + (size_t)h * D;
            const float* cp = cbase + (size_t)h * P;
            const float* sp = sbase + (size_t)h * P;
            for (int p = 0; p < P; ++p) {
                const float co = cp[p], si = sp[p];
                const float x0 = bp[2 * p], x1 = bp[2 * p + 1];
                bp[2 * p] = x0 * co - x1 * si;
                bp[2 * p + 1] = x0 * si + x1 * co;
            }
        }
    }
}

// ---------------------------------------------------------------- 注意力
// 标准多头注意力（numHeads == numKVHeads，无 GQA/QK-norm/GAB/TAB）：
//   logits = scale * (q · k)，盘外**key** 置 -inf，softmax，再对 v 加权
// 注意：官方只屏蔽非法 key，**不跳过非法的 query**（被屏蔽的 query 仍会算出结果）。
// q/k/v 布局均为 (S, H, D)，输出布局 (S, H*vDim)
//
// SIMD 路径（AVX2 + qDim%8==0 + vDim%16==0）：
//   1) 每个 head 把 K 转成 (qDim, S_pad)，这样 QK 的内层可按 j 连续向量化；
//   2) 每个任务算 (head, 半边 i) 的 QK + softmax，P 存进共享缓冲；
//   3) 同一任务里做 PV：按 16 个输出通道分块，v 的块（约 23 KB）留在 L1。
struct AttentionScratch {
    std::vector<float> kt;     // H * qDim * S_pad
    std::vector<float> pmat;   // H * S * S
    std::vector<float> logits; // nt * 4 * S_pad（线程私有 4 行 logits）
};

namespace attn_detail {

// 原始标量实现（无 AVX2 / 形状不规整时使用）
inline void attentionScalar(const std::vector<float>& q, const std::vector<float>& k,
                            const std::vector<float>& v, int S, int H, int qDim,
                            int vDim, const std::vector<float>& mask,
                            std::vector<float>& out) {
    const float scale = 1.0f / std::sqrt((float)qDim);
#if KG_OMP
    const int nt = effectiveThreads();
    if (nt > 1 && H >= 2) {
#pragma omp parallel for schedule(static) num_threads(nt)
        for (int h = 0; h < H; ++h) {
            std::vector<float> logits(S);
            for (int i = 0; i < S; ++i) {
                const float* qi = &q[((size_t)i * H + h) * qDim];
                float mx = -1e30f;
                for (int j = 0; j < S; ++j) {
                    if (!mask.empty() && mask[j] <= 0.0f) { logits[j] = -1e30f; continue; }
                    const float* kj = &k[((size_t)j * H + h) * qDim];
                    float acc = 0.0f;
                    for (int d = 0; d < qDim; ++d) acc += qi[d] * kj[d];
                    acc *= scale;
                    logits[j] = acc;
                    if (acc > mx) mx = acc;
                }
                float sum = 0.0f;
                for (int j = 0; j < S; ++j) {
                    float e = std::exp(logits[j] - mx);
                    logits[j] = e;
                    sum += e;
                }
                float inv = (sum > 0.0f) ? (1.0f / sum) : 0.0f;
                float* oi = &out[((size_t)i * H + h) * vDim];
                for (int j = 0; j < S; ++j) {
                    float w = logits[j] * inv;
                    if (w == 0.0f) continue;
                    const float* vj = &v[((size_t)j * H + h) * vDim];
                    for (int d = 0; d < vDim; ++d) oi[d] += w * vj[d];
                }
            }
        }
        return;
    }
#endif
    std::vector<float> logits(S);
    for (int h = 0; h < H; ++h) {
        for (int i = 0; i < S; ++i) {
            const float* qi = &q[((size_t)i * H + h) * qDim];
            float mx = -1e30f;
            for (int j = 0; j < S; ++j) {
                if (!mask.empty() && mask[j] <= 0.0f) { logits[j] = -1e30f; continue; }
                const float* kj = &k[((size_t)j * H + h) * qDim];
                float acc = 0.0f;
                for (int d = 0; d < qDim; ++d) acc += qi[d] * kj[d];
                acc *= scale;
                logits[j] = acc;
                if (acc > mx) mx = acc;
            }
            float sum = 0.0f;
            for (int j = 0; j < S; ++j) {
                float e = std::exp(logits[j] - mx);
                logits[j] = e;
                sum += e;
            }
            float inv = (sum > 0.0f) ? (1.0f / sum) : 0.0f;
            float* oi = &out[((size_t)i * H + h) * vDim];
            for (int j = 0; j < S; ++j) {
                float w = logits[j] * inv;
                if (w == 0.0f) continue;
                const float* vj = &v[((size_t)j * H + h) * vDim];
                for (int d = 0; d < vDim; ++d) oi[d] += w * vj[d];
            }
        }
    }
}

#if KG_X64_SIMD
inline void attentionAvx2(const std::vector<float>& q, const std::vector<float>& k,
                          const std::vector<float>& v, int S, int H, int qDim,
                          int vDim, const std::vector<float>& mask,
                          std::vector<float>& out, AttentionScratch& sc) {
    const float scale = 1.0f / std::sqrt((float)qDim);
    const int S_pad = (S + 15) & ~15;
    const int nt = effectiveThreads();
    const float* qp = q.data();
    const float* kp = k.data();
    const float* vp = v.data();
    float* op = out.data();

    // 掩码偏置：合法 key 0，非法 key -1e30（与标量实现的 logits 值一致）
    std::vector<float> maskAdd((size_t)S_pad, -1e30f);
    for (int j = 0; j < S; ++j)
        maskAdd[(size_t)j] = (mask.empty() || mask[j] > 0.0f) ? 0.0f : -1e30f;

    float* kt = sc.kt.data();
    float* pm = sc.pmat.data();
    float* lg = sc.logits.data();

    // 1) 每个 head 转置 K -> (qDim, S_pad)
#if KG_OMP
#pragma omp parallel for schedule(static) num_threads(nt) if (nt > 1 && H >= 2)
#endif
    for (int h = 0; h < H; ++h) {
        float* dst = kt + (size_t)h * qDim * S_pad;
        for (int d = 0; d < qDim; ++d) {
            float* row = dst + (size_t)d * S_pad;
            for (int j = 0; j < S; ++j) row[j] = kp[((size_t)j * H + h) * qDim + d];
            for (int j = S; j < S_pad; ++j) row[j] = 0.0f;
        }
    }

    // 2) QK + softmax -> P，然后 PV
    const int ICH = (S >= 128) ? 2 : 1;          // 每个 head 拆成 2 段，便于负载均衡
    const int iPer = (S + ICH - 1) / ICH;
    const int ntasks = H * ICH;
    const int nDChunk = vDim / 16;

#if KG_OMP
#pragma omp parallel for schedule(dynamic, 1) num_threads(nt) if (nt > 1 && ntasks > 1)
#endif
    for (int task = 0; task < ntasks; ++task) {
        const int h = task / ICH;
        const int ic = task % ICH;
        const int i0 = ic * iPer;
        const int i1 = (i0 + iPer < S) ? (i0 + iPer) : S;
        if (i0 >= i1) continue;
        const float* kth = kt + (size_t)h * qDim * S_pad;
        float* ph = pm + (size_t)h * S * S;
        int tid = 0;
#if KG_OMP
        tid = omp_get_thread_num();
#endif
        float* myLogits = lg + (size_t)tid * 4 * S_pad;
        const int nFull = (i1 - i0) - ((i1 - i0) % 4);

        // --- QK + softmax：4 行一块 ---
        for (int i = i0; i < i0 + nFull; i += 4) {
            const float* q0 = qp + ((size_t)(i + 0) * H + h) * qDim;
            const float* q1 = qp + ((size_t)(i + 1) * H + h) * qDim;
            const float* q2 = qp + ((size_t)(i + 2) * H + h) * qDim;
            const float* q3 = qp + ((size_t)(i + 3) * H + h) * qDim;
            for (int jb = 0; jb < S_pad; jb += 16) {
                __m256 c00 = _mm256_setzero_ps(), c01 = _mm256_setzero_ps();
                __m256 c10 = _mm256_setzero_ps(), c11 = _mm256_setzero_ps();
                __m256 c20 = _mm256_setzero_ps(), c21 = _mm256_setzero_ps();
                __m256 c30 = _mm256_setzero_ps(), c31 = _mm256_setzero_ps();
                for (int d = 0; d < qDim; ++d) {
                    const float* ktp = kth + (size_t)d * S_pad + jb;
                    __m256 kb0 = _mm256_loadu_ps(ktp);
                    __m256 kb1 = _mm256_loadu_ps(ktp + 8);
                    __m256 va = _mm256_broadcast_ss(q0 + d);
                    __m256 vb = _mm256_broadcast_ss(q1 + d);
                    __m256 vc = _mm256_broadcast_ss(q2 + d);
                    __m256 vd = _mm256_broadcast_ss(q3 + d);
                    c00 = _mm256_fmadd_ps(va, kb0, c00);
                    c01 = _mm256_fmadd_ps(va, kb1, c01);
                    c10 = _mm256_fmadd_ps(vb, kb0, c10);
                    c11 = _mm256_fmadd_ps(vb, kb1, c11);
                    c20 = _mm256_fmadd_ps(vc, kb0, c20);
                    c21 = _mm256_fmadd_ps(vc, kb1, c21);
                    c30 = _mm256_fmadd_ps(vd, kb0, c30);
                    c31 = _mm256_fmadd_ps(vd, kb1, c31);
                }
                const __m256 vs = _mm256_set1_ps(scale);
                __m256 ma0 = _mm256_loadu_ps(maskAdd.data() + jb);
                __m256 ma1 = _mm256_loadu_ps(maskAdd.data() + jb + 8);
                _mm256_storeu_ps(myLogits + jb, _mm256_add_ps(_mm256_mul_ps(c00, vs), ma0));
                _mm256_storeu_ps(myLogits + jb + 8, _mm256_add_ps(_mm256_mul_ps(c01, vs), ma1));
                _mm256_storeu_ps(myLogits + S_pad + jb,
                                 _mm256_add_ps(_mm256_mul_ps(c10, vs), ma0));
                _mm256_storeu_ps(myLogits + S_pad + jb + 8,
                                 _mm256_add_ps(_mm256_mul_ps(c11, vs), ma1));
                _mm256_storeu_ps(myLogits + 2 * S_pad + jb,
                                 _mm256_add_ps(_mm256_mul_ps(c20, vs), ma0));
                _mm256_storeu_ps(myLogits + 2 * S_pad + jb + 8,
                                 _mm256_add_ps(_mm256_mul_ps(c21, vs), ma1));
                _mm256_storeu_ps(myLogits + 3 * S_pad + jb,
                                 _mm256_add_ps(_mm256_mul_ps(c30, vs), ma0));
                _mm256_storeu_ps(myLogits + 3 * S_pad + jb + 8,
                                 _mm256_add_ps(_mm256_mul_ps(c31, vs), ma1));
            }
            for (int r = 0; r < 4; ++r) {
                float* row = myLogits + (size_t)r * S_pad;
                float mx = -1e30f;
                for (int j = 0; j < S; ++j)
                    if (row[j] > mx) mx = row[j];
                float sum = 0.0f;
                for (int j = 0; j < S; ++j) {
                    const float e = std::exp(row[j] - mx);
                    row[j] = e;
                    sum += e;
                }
                const float inv = (sum > 0.0f) ? (1.0f / sum) : 0.0f;
                for (int j = 0; j < S; ++j) row[j] *= inv;
                std::memcpy(ph + (size_t)(i + r) * S, row, sizeof(float) * (size_t)S);
            }
        }
        // 尾部行（<4）：标量，累加顺序与标量实现一致
        for (int i = i0 + nFull; i < i1; ++i) {
            const float* qi = qp + ((size_t)i * H + h) * qDim;
            float* row = myLogits;
            float mx = -1e30f;
            for (int j = 0; j < S; ++j) {
                float acc = 0.0f;
                for (int d = 0; d < qDim; ++d) acc += qi[d] * kth[(size_t)d * S_pad + j];
                const float lv = acc * scale + maskAdd[(size_t)j];
                row[j] = lv;
                if (lv > mx) mx = lv;
            }
            float sum = 0.0f;
            for (int j = 0; j < S; ++j) {
                const float e = std::exp(row[j] - mx);
                row[j] = e;
                sum += e;
            }
            const float inv = (sum > 0.0f) ? (1.0f / sum) : 0.0f;
            for (int j = 0; j < S; ++j) row[j] *= inv;
            std::memcpy(ph + (size_t)i * S, row, sizeof(float) * (size_t)S);
        }

        // --- PV：按 16 个输出通道分块 ---
        for (int dc = 0; dc < nDChunk; ++dc) {
            const int d0 = dc * 16;
            for (int ib = i0; ib < i1; ib += 4) {
                const int nrow = (ib + 4 <= i1) ? 4 : (i1 - ib);
                if (nrow < 4) break;   // 尾部行走标量兜底
                const float* p0 = ph + (size_t)(ib + 0) * S;
                const float* p1 = ph + (size_t)(ib + 1) * S;
                const float* p2 = ph + (size_t)(ib + 2) * S;
                const float* p3 = ph + (size_t)(ib + 3) * S;
                __m256 a00 = _mm256_setzero_ps(), a01 = _mm256_setzero_ps();
                __m256 a10 = _mm256_setzero_ps(), a11 = _mm256_setzero_ps();
                __m256 a20 = _mm256_setzero_ps(), a21 = _mm256_setzero_ps();
                __m256 a30 = _mm256_setzero_ps(), a31 = _mm256_setzero_ps();
                for (int j = 0; j < S; ++j) {
                    const float* vj = vp + ((size_t)j * H + h) * vDim + d0;
                    __m256 v0 = _mm256_loadu_ps(vj);
                    __m256 v1 = _mm256_loadu_ps(vj + 8);
                    __m256 w0 = _mm256_broadcast_ss(p0 + j);
                    __m256 w1 = _mm256_broadcast_ss(p1 + j);
                    __m256 w2 = _mm256_broadcast_ss(p2 + j);
                    __m256 w3 = _mm256_broadcast_ss(p3 + j);
                    a00 = _mm256_fmadd_ps(w0, v0, a00);
                    a01 = _mm256_fmadd_ps(w0, v1, a01);
                    a10 = _mm256_fmadd_ps(w1, v0, a10);
                    a11 = _mm256_fmadd_ps(w1, v1, a11);
                    a20 = _mm256_fmadd_ps(w2, v0, a20);
                    a21 = _mm256_fmadd_ps(w2, v1, a21);
                    a30 = _mm256_fmadd_ps(w3, v0, a30);
                    a31 = _mm256_fmadd_ps(w3, v1, a31);
                }
                float* o0 = op + ((size_t)(ib + 0) * H + h) * vDim + d0;
                float* o1 = op + ((size_t)(ib + 1) * H + h) * vDim + d0;
                float* o2 = op + ((size_t)(ib + 2) * H + h) * vDim + d0;
                float* o3 = op + ((size_t)(ib + 3) * H + h) * vDim + d0;
                _mm256_storeu_ps(o0, a00);
                _mm256_storeu_ps(o0 + 8, a01);
                _mm256_storeu_ps(o1, a10);
                _mm256_storeu_ps(o1 + 8, a11);
                _mm256_storeu_ps(o2, a20);
                _mm256_storeu_ps(o2 + 8, a21);
                _mm256_storeu_ps(o3, a30);
                _mm256_storeu_ps(o3 + 8, a31);
            }
            // 尾部行（i1 对齐后剩下的 0~3 行）：标量
            const int ibTail = i0 + (i1 - i0) - ((i1 - i0) % 4);
            for (int i = ibTail; i < i1; ++i) {
                const float* pi = ph + (size_t)i * S;
                for (int d = d0; d < d0 + 16; ++d) {
                    float acc = 0.0f;
                    for (int j = 0; j < S; ++j) acc += pi[j] * vp[((size_t)j * H + h) * vDim + d];
                    op[((size_t)i * H + h) * vDim + d] = acc;
                }
            }
        }
    }
}
#endif  // KG_X64_SIMD

}  // namespace attn_detail

inline void attentionApply(const std::vector<float>& q, const std::vector<float>& k,
                           const std::vector<float>& v, int S, int H, int qDim,
                           int vDim, const std::vector<float>& mask,
                           std::vector<float>& out, AttentionScratch& sc) {
    if (S <= 0 || H <= 0 || qDim <= 0 || vDim <= 0) {
        out.assign((size_t)(S > 0 ? S : 0) * (size_t)(H > 0 ? H : 0) *
                       (size_t)(vDim > 0 ? vDim : 0), 0.0f);
        return;
    }
    out.resize((size_t)S * H * vDim);   // 下面会写满
#if KG_X64_SIMD
    if (cpuHasAvx2() && (qDim % 8) == 0 && (vDim % 16) == 0 && S >= 8 &&
        q.size() >= (size_t)S * H * qDim && k.size() >= (size_t)S * H * qDim &&
        v.size() >= (size_t)S * H * vDim) {
        const int S_pad = (S + 15) & ~15;
        sc.kt.resize((size_t)H * qDim * S_pad + 16);
        sc.pmat.resize((size_t)H * S * S + 16);
        sc.logits.resize((size_t)effectiveThreads() * 4 * S_pad + 16);
        std::memset(out.data(), 0, sizeof(float) * out.size());
        attn_detail::attentionAvx2(q, k, v, S, H, qDim, vDim, mask, out, sc);
        return;
    }
#endif
    out.assign((size_t)S * H * vDim, 0.0f);
    attn_detail::attentionScalar(q, k, v, S, H, qDim, vDim, mask, out);
}

// 兼容接口：内部临时分配 scratch（测试/一次性调用用；前向热路径用上面的重载）
inline void attentionApply(const std::vector<float>& q, const std::vector<float>& k,
                           const std::vector<float>& v, int S, int H, int qDim,
                           int vDim, const std::vector<float>& mask,
                           std::vector<float>& out) {
    AttentionScratch sc;
    attentionApply(q, k, v, S, H, qDim, vDim, mask, out, sc);
}

}  // namespace kg

#endif  // KG_OPS_H
