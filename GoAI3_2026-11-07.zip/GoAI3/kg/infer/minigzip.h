// ============================================================================
//  minigzip.h -- 自带 DEFLATE/gzip 解压器（仅标准库，无 zlib 依赖）
//
//  为什么自带：KataGo 的权重文件是 .bin.gz，C++ 侧必须自己解压。而这个项目
//  的原则是不引入第三方库（go_ai.cpp 也只链接系统自带的 gdiplus/gdi32/user32）。
//  所以这里放一份紧凑的、只读的 inflate（RFC 1951）+ gzip 包装（RFC 1952）。
//
//  支持：stored / fixed-Huffman / dynamic-Huffman 三种块；多成员 gzip 流。
//  不支持：需要预置字典的流（DEFLATE 中极少出现，KataGo 权重文件不会有）。
// ============================================================================
#ifndef MINIGZIP_H
#define MINIGZIP_H

#include <cstdint>
#include <cstdio>
#include <cstring>
#include <string>
#include <vector>
#include <stdexcept>

namespace minigzip {

// ---------------------------------------------------------------- 位读取器
class BitReader {
public:
    BitReader(const uint8_t* data, size_t size) : d_(data), n_(size), pos_(0), bit_(0) {}

    // 读 n 位（n <= 24），低位在前（DEFLATE 的位序）。
    inline uint32_t bits(int n) {
        if (n == 0) return 0;
        // 先把 bit_ 里剩余的位用掉
        while (bit_ < n) {
            uint32_t b = (pos_ < n_) ? d_[pos_] : 0;
            if (pos_ >= n_) { err_ = true; }
            buf_ |= (uint64_t)b << bit_;
            bit_ += 8;
            ++pos_;
        }
        uint32_t v = (uint32_t)(buf_ & ((1u << n) - 1u));
        buf_ >>= n;
        bit_ -= n;
        return v;
    }

    inline void alignToByte() {
        int drop = bit_ & 7;
        buf_ >>= drop;
        bit_ -= drop;
    }

    // 读 len 字节的原始数据（用于 stored 块），要求已按字节对齐。
    bool raw(uint8_t* out, size_t len) {
        alignToByte();
        // buf_ 里可能还留有整字节
        while (bit_ >= 8 && len > 0) {
            *out++ = (uint8_t)(buf_ & 0xFF);
            buf_ >>= 8;
            bit_ -= 8;
            --len;
        }
        if (len > 0) {
            if (pos_ + len > n_) {
                // 尽量拷贝剩余部分
                size_t avail = (pos_ < n_) ? (n_ - pos_) : 0;
                if (avail > 0) std::memcpy(out, d_ + pos_, avail);
                pos_ += avail;
                err_ = true;
                return false;
            }
            std::memcpy(out, d_ + pos_, len);
            pos_ += len;
        }
        return true;
    }

    inline bool failed() const { return err_; }
    inline size_t bytePos() const { return pos_; }

    // 逻辑上已完整消费的字节数。pos_ 指向"最后一个读入缓冲的字节"之后，
    // 但缓冲里可能还剩 bit_/8 个整字节尚未被逻辑消费，所以要做这个减法。
    inline size_t consumedBytes() const { return pos_ - (size_t)(bit_ / 8); }

private:
    const uint8_t* d_;
    size_t n_;
    size_t pos_;
    int bit_ = 0;
    uint64_t buf_ = 0;
    bool err_ = false;
};

// ---------------------------------------------------------------- Huffman 解码
// 规范 Huffman：按码长分配码字，用"计数 + 偏移"表做快速解码。
class Huffman {
public:
    void build(const uint8_t* lengths, int n) {
        counts_.assign(kMaxBits + 1, 0);
        for (int i = 0; i < n; ++i) {
            if (lengths[i] > kMaxBits) throw std::runtime_error("huffman: code too long");
            counts_[lengths[i]]++;
        }
        counts_[0] = 0;
        // 每个码长的第一个码字
        std::vector<int> offs(kMaxBits + 2, 0);
        for (int b = 1; b <= kMaxBits; ++b)
            offs[b + 1] = offs[b] + counts_[b];
        int total = offs[kMaxBits + 1];
        symbols_.assign(total, 0);
        // 注意：这里必须用花括号初始化。写成 cursor(offs.begin(), offs.end())
        // 会被 C++ 解析成函数声明（most vexing parse），后面整段语法都会崩。
        std::vector<int> cursor{offs.begin(), offs.end()};
        for (int i = 0; i < n; ++i) {
            if (lengths[i] != 0) symbols_[cursor[lengths[i]]++] = (uint16_t)i;
        }
        // 校验码字空间不溢出（不完整码是合法的，但超长不合法）
        int left = 1;
        for (int b = 1; b <= kMaxBits; ++b) {
            left <<= 1;
            left -= counts_[b];
            if (left < 0) throw std::runtime_error("huffman: over-subscribed code");
        }
    }

    // 从位流解出一个符号；失败返回 -1。
    inline int decode(BitReader& br) const {
        int code = 0, first = 0, index = 0;
        for (int len = 1; len <= kMaxBits; ++len) {
            code |= (int)br.bits(1);
            int count = counts_[len];
            if (code - first < count) return symbols_[index + (code - first)];
            index += count;
            first = (first + count) << 1;
            code <<= 1;
        }
        return -1;
    }

    static const int kMaxBits = 15;

private:
    std::vector<int> counts_;
    std::vector<uint16_t> symbols_;
};

// ---------------------------------------------------------------- inflate
namespace detail {

const int kLenBase[29] = {3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 15, 17, 19, 23, 27, 31,
                          35, 43, 51, 59, 67, 83, 99, 115, 131, 163, 195, 227, 258};
const int kLenExtra[29] = {0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2,
                           3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 0};
const int kDistBase[30] = {1, 2, 3, 4, 5, 7, 9, 13, 17, 25, 33, 49, 65, 97, 129,
                           193, 257, 385, 513, 769, 1025, 1537, 2049, 3073, 4097,
                           6145, 8193, 12289, 16385, 24577};
const int kDistExtra[30] = {0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6,
                            7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13};

// 一次 Huffman 块的解码。返回 false 表示流损坏。
inline bool inflateBlock(BitReader& br, std::vector<uint8_t>& out,
                         const Huffman& lit, const Huffman& dist) {
    for (;;) {
        int sym = lit.decode(br);
        if (sym < 0) return false;
        if (sym < 256) {
            out.push_back((uint8_t)sym);
        } else if (sym == 256) {
            return true;   // 块结束
        } else {
            sym -= 257;
            if (sym >= 29) return false;
            int len = kLenBase[sym] + (int)br.bits(kLenExtra[sym]);
            int dsym = dist.decode(br);
            if (dsym < 0 || dsym >= 30) return false;
            int d = kDistBase[dsym] + (int)br.bits(kDistExtra[dsym]);
            if ((size_t)d > out.size()) return false;
            size_t start = out.size() - d;
            for (int i = 0; i < len; ++i) out.push_back(out[start + i]);
        }
    }
}

inline void buildFixed(Huffman& lit, Huffman& dist) {
    uint8_t ll[288];
    for (int i = 0; i < 144; ++i) ll[i] = 8;
    for (int i = 144; i < 256; ++i) ll[i] = 9;
    for (int i = 256; i < 280; ++i) ll[i] = 7;
    for (int i = 280; i < 288; ++i) ll[i] = 8;
    lit.build(ll, 288);
    uint8_t dl[30];
    for (int i = 0; i < 30; ++i) dl[i] = 5;
    dist.build(dl, 30);
}

// 语义与 zlib 相同的动态块长度读取顺序
const int kClOrder[19] = {16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15};

inline bool readDynamic(BitReader& br, Huffman& lit, Huffman& dist) {
    int hlit = (int)br.bits(5) + 257;
    int hdist = (int)br.bits(5) + 1;
    int hclen = (int)br.bits(4) + 4;
    if (hlit > 286 || hdist > 30 || hclen > 19) return false;

    uint8_t cl[19] = {0};
    for (int i = 0; i < hclen; ++i) cl[kClOrder[i]] = (uint8_t)br.bits(3);
    Huffman clh;
    try { clh.build(cl, 19); } catch (...) { return false; }

    std::vector<uint8_t> lengths(hlit + hdist, 0);
    int i = 0;
    while (i < hlit + hdist) {
        int sym = clh.decode(br);
        if (sym < 0) return false;
        if (sym < 16) {
            lengths[i++] = (uint8_t)sym;
        } else if (sym == 16) {
            if (i == 0) return false;
            uint8_t prev = lengths[i - 1];
            int rep = 3 + (int)br.bits(2);
            while (rep-- > 0 && i < hlit + hdist) lengths[i++] = prev;
        } else if (sym == 17) {
            int rep = 3 + (int)br.bits(3);
            while (rep-- > 0 && i < hlit + hdist) lengths[i++] = 0;
        } else if (sym == 18) {
            int rep = 11 + (int)br.bits(7);
            while (rep-- > 0 && i < hlit + hdist) lengths[i++] = 0;
        } else {
            return false;
        }
    }
    try {
        lit.build(&lengths[0], hlit);
        dist.build(&lengths[hlit], hdist);
    } catch (...) { return false; }
    return true;
}

}  // namespace detail

// 解压一段 raw DEFLATE 流，返回是否成功；consumed 回传逻辑消费的字节数。
inline bool inflateStream(const uint8_t* in, size_t inSize, std::vector<uint8_t>& out,
                          size_t* consumed, std::string* errMsg) {
    auto fail = [&](const char* m) { if (errMsg) *errMsg = m; return false; };
    BitReader br(in, inSize);
    Huffman fixedLit, fixedDist;
    bool fixedReady = false;

    for (;;) {
        int last = (int)br.bits(1);
        int type = (int)br.bits(2);
        if (type == 0) {
            br.alignToByte();
            uint32_t len = br.bits(16);
            uint32_t nlen = br.bits(16);
            if ((len ^ 0xFFFFu) != nlen) return fail("inflate: bad stored block length");
            size_t old = out.size();
            out.resize(old + len);
            if (!br.raw(&out[old], len)) return fail("inflate: truncated stored block");
        } else if (type == 1) {
            if (!fixedReady) { detail::buildFixed(fixedLit, fixedDist); fixedReady = true; }
            if (!detail::inflateBlock(br, out, fixedLit, fixedDist))
                return fail("inflate: corrupt fixed-Huffman block");
        } else if (type == 2) {
            Huffman lit, dist;
            if (!detail::readDynamic(br, lit, dist))
                return fail("inflate: corrupt dynamic-Huffman block header");
            if (!detail::inflateBlock(br, out, lit, dist))
                return fail("inflate: corrupt dynamic-Huffman block");
        } else {
            return fail("inflate: illegal block type 3");
        }
        if (br.failed()) return fail("inflate: read past end of input");
        if (last) break;
    }
    if (consumed) *consumed = br.consumedBytes();
    return true;
}

// 解压一段 raw DEFLATE 流（不关心消费字节数）。返回是否成功。
inline bool inflateRaw(const uint8_t* in, size_t inSize, std::vector<uint8_t>& out,
                       size_t reserveHint = 0) {
    if (reserveHint) out.reserve(reserveHint);
    return inflateStream(in, inSize, out, nullptr, nullptr);
}

// 解压 gzip 容器（RFC 1952）。支持多成员流，并校验每个成员的 ISIZE。
inline bool gzipDecompress(const uint8_t* in, size_t inSize, std::vector<uint8_t>& out,
                           size_t reserveHint = 0, std::string* errMsg = nullptr) {
    auto fail = [&](const char* m) { if (errMsg) *errMsg = m; return false; };
    if (inSize < 18) return fail("gzip: file too small");
    if (in[0] != 0x1F || in[1] != 0x8B) return fail("gzip: bad magic");
    if (in[2] != 8) return fail("gzip: unsupported compression method");

    if (reserveHint) out.reserve(reserveHint);

    auto skipHeader = [&](size_t& p, uint8_t flg) -> bool {
        if (flg & 0x04) {                                  // FEXTRA
            if (p + 2 > inSize) return false;
            uint16_t xlen = (uint16_t)(in[p] | (in[p + 1] << 8));
            p += 2 + (size_t)xlen;
        }
        if (flg & 0x08) { while (p < inSize && in[p] != 0) ++p; ++p; }   // FNAME
        if (flg & 0x10) { while (p < inSize && in[p] != 0) ++p; ++p; }   // FCOMMENT
        if (flg & 0x02) p += 2;                                          // FHCRC
        return p < inSize;
    };

    size_t p = 10;
    if (!skipHeader(p, in[3])) return fail("gzip: bad header");

    int members = 0;
    while (p < inSize) {
        size_t before = out.size();
        size_t consumed = 0;
        if (!inflateStream(in + p, inSize - p, out, &consumed, errMsg)) return false;
        p += consumed;

        if (p + 8 > inSize) return fail("gzip: truncated trailer");
        uint32_t isize = (uint32_t)in[p + 4] | ((uint32_t)in[p + 5] << 8) |
                         ((uint32_t)in[p + 6] << 16) | ((uint32_t)in[p + 7] << 24);
        uint32_t produced = (uint32_t)(out.size() - before);
        if (isize != produced) return fail("gzip: ISIZE mismatch");
        p += 8;
        ++members;

        if (p + 3 <= inSize && in[p] == 0x1F && in[p + 1] == 0x8B) {
            p += 10;
            if (!skipHeader(p, in[p - 7])) return fail("gzip: bad header (additional member)");
            continue;
        }
        break;
    }
    if (members == 0) return fail("gzip: no members decoded");
    return true;
}

// 读文件（二进制）到 vector
inline bool readFile(const std::string& path, std::vector<uint8_t>& out, std::string* errMsg = nullptr) {
    FILE* f = nullptr;
#if defined(_MSC_VER)
    if (fopen_s(&f, path.c_str(), "rb") != 0) f = nullptr;
#else
    f = std::fopen(path.c_str(), "rb");
#endif
    if (!f) { if (errMsg) *errMsg = "cannot open file"; return false; }
    std::fseek(f, 0, SEEK_END);
    long sz = std::ftell(f);
    std::fseek(f, 0, SEEK_SET);
    if (sz < 0) { std::fclose(f); if (errMsg) *errMsg = "cannot size file"; return false; }
    out.resize((size_t)sz);
    size_t rd = (sz > 0) ? std::fread(&out[0], 1, (size_t)sz, f) : 0;
    std::fclose(f);
    if (rd != (size_t)sz) { if (errMsg) *errMsg = "short read"; return false; }
    return true;
}

}  // namespace minigzip

#endif  // MINIGZIP_H
