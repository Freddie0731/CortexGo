# GPU 推理后端：ONNX Runtime + DirectML（可选，运行时加载）

> 目标机器：Intel Core Ultra 5 225H + Intel Arc 130T（**iGPU，无独立显存，共享系统内存**）
> 模型：KataGo v17 `b11c768h12nbt3tflrs-fs-silu`（`kata1.bin.gz` 导出的 ONNX，fp32，
> `build_out\npu\models\kata1_b11_b1.onnx`，292 MB）
> 运行时：`onnxruntime-directml` **1.24.4**（pip 包，已解包在 `build_out\npu\py\`）

---

## 0. 一句话结论

**能用，数值上就是同一个网络。**

| 指标 | 结果 |
|---|---|
| session 创建（一次性，进程内只做一次） | **5.5 – 7.1 s** |
| 单次前向（ORT DirectML / Arc 130T） | **min 70.3 ms / median 73.0 ms**（机器较空时）；重负载下 106–145 ms |
| 单次前向（原生 C++ CPU，**已优化后**的 `forward.h`） | min 268.3 ms / median 279.0 ms（同一次测试） |
| 对比：优化前的 CPU 前向 | 1089 ms → GPU 约 **14×**；对比当前优化后的 CPU 约 **3.3–3.8×** |
| policy 概率最大绝对差 | **≤ 1.16e-6**（验收阈值 2e-3） |
| value logits（3 个）最大绝对差 | **≤ 3.05e-5**（验收阈值 0.2） |
| policy top-1 | **5/5 一致** |
| ownership 最大绝对差 | ≤ 6.9e-6（仅报告） |
| 进程内存（ORT session 单独） | ~874 MB working set |
| 进程内存（同时加载原生权重 + ORT session） | ~1.15 GB working / **peak ~1.47 GB** |
| 显存（iGPU 共享内存，Windows GPU 计数器） | **~668 MB shared，0 dedicated** |
| 不含 `onnxruntime.dll` 的机器 | `ortBackendLoad` 返回 false + 可读错误，引擎退回原生 CPU，**不崩** |

> 注意：GPU 数字是 **iGPU 共享内存**，和桌面/其它 GPU 任务争用；MCTS 叶子并发会被本后端
> 用互斥锁串行化（单 DML 设备）。单次 73 ms 已经远低于一次搜索展开的开销，现阶段够用。

---

## 1. 文件清单

| 文件 | 说明 |
|---|---|
| `kg/infer/ort_backend.h` | **唯一要 include 的头**。header-only，运行时 `LoadLibraryA` 加载 ORT，零编译期/链接期依赖 |
| `kg/infer/ort/onnxruntime_c_api.h` | ONNX Runtime **1.24.4** 官方 C API 头（MIT，保留原始版权头） |
| `kg/infer/ort/onnxruntime_ep_c_api.h` | 同上，被 `onnxruntime_c_api.h` 在文件末尾 `#include`，必须一起放 |
| `kg/infer/ort/onnxruntime_float16.h` | ORT 官方 float16 头（同批复制；本后端不直接 include，保留以保持头文件集完整） |
| `kg/test/test_ort.cpp` | 数值验收 + 计时 + 降级行为测试源码 |
| `build_out\ort\test_ort.exe` | 已编译好的验收程序（440 KB） |
| `build_out\ort\probe_abi.cpp/.exe` | 底层 ABI/DLL 探测（session 是否能建、I/O 名字/形状） |
| `build_out\ort\probe_ladder.cpp/.exe` | 扫描真实棋谱里哪些 ply 的征子特征平面非零（选测试局面用） |
| `build_out\ort\pick_games.py` | 从 `kg\build\sgf\games.7z` 解出的真实棋谱里选合法前缀，生成测试着法数组 |
| `build_out\ort\run_with_mem.ps1` | 跑 test_ort 时用 Windows GPU 计数器采显存的脚本 |

### 头文件来源（重要）

pip 的 `onnxruntime-directml` wheel **不带 C API 头**（`capi\` 里只有 DLL 和 pybind），所以
`kg/infer/ort/*.h` 是从 `microsoft/onnxruntime` **v1.24.4** 标签原样复制的：

```
include/onnxruntime/core/session/onnxruntime_c_api.h      (373,908 B)
include/onnxruntime/core/session/onnxruntime_ep_c_api.h   (102,494 B)
```

与 `build_out\npu\py\onnxruntime\capi\onnxruntime.dll`（文件版本 1.24.20260316、`ORT_API_VERSION=24`）
严格同版本 —— 头/ DLL 版本必须一致，**不能拿 `C:\Windows\System32\onnxruntime.dll`（1.17）的头来配 1.24 的 DLL**。

---

## 2. 对外接口（已固定，Lead 直接照此接线）

```cpp
// kg/infer/ort_backend.h
namespace kg {

// 加载 ONNX 并创建 ORT session（DML）。进程内只做一次；重复调用同路径直接返回 true。
// 失败返回 false，err 写可读原因；后端保持"未就绪"，调用方应退回原生 CPU 前向。
bool ortBackendLoad(const std::string& onnxPath, std::string* err);

bool ortBackendReady();                       // 是否已就绪（atomic，无锁可调）

// 一次完整前向。串行化（内部 mutex）。失败返回 false 并清空三个输出。
//   spatial     : (22,19,19) 行优先 = encodeV7().spatial，长度 22*361 = 7942
//   global      : (19,)            = encodeV7().global
//   policyLogits: 6*362，[c*362 + loc]；通道 0 是常规 policy，loc==361 是 pass
//   valueLogits : 3，win/loss/noresult 的 logits（当前行棋方视角，需自己 softmax）
//   ownership   : 361，逐点归属（+1 黑 / -1 白，白方视角，KataGo 官方约定）
bool ortBackendForward(const std::vector<float>& spatial,
                       const std::vector<float>& global,
                       std::vector<float>& policyLogits,
                       std::vector<float>& valueLogits,
                       std::vector<float>& ownership);

void ortBackendRelease();                     // 释放 session/DLL；可重复调用

// —— 诊断（不影响上述语义）——
const std::string& ortBackendError();         // 最近一次失败原因
std::string ortBackendProvider();             // "DirectML" / "CPU" / ""（未加载）
std::string ortBackendOrtVersion();           // 实际加载的 DLL 版本，如 "1.24.4"
std::string ortBackendDllPath();              // 实际加载的 DLL 完整路径
void ortBackendStats(long long* calls, double* seconds);

}  // namespace kg
```

线程安全：`Load/Forward/Release` 内部一把 `std::mutex`（与 `katago_backend.h` 相同做法），
`ortBackendReady()` 用 `std::atomic<bool>` 无锁；`ortBackendError()` 返回引用、**不加锁**，
请在单线程（如启动/失败分支）里读。

---

## 3. DLL / ONNX 摆放 & 最短上手

### 3.1 需要哪些文件

推理只需要这 3 个 DLL（都在 `build_out\npu\py\onnxruntime\capi\` 里，直接拷）：

```
onnxruntime.dll                 21,111,840 B
DirectML.dll                    18,527,776 B
onnxruntime_providers_shared.dll  21,528 B   （可选，存在就预加载，避免个别 EP 缺依赖）
```

`onnxruntime_pybind11_state.pyd` / `capi\__init__.py` 等 Python 文件**不需要**。
ONNX 模型：任何路径，用参数传入（不写死在库里）。

### 3.2 两种摆法（二选一）

**A. 放 exe 同目录（推荐部署）**

```
<引擎exe所在目录>\
    GoAI3.exe
    onnxruntime.dll
    DirectML.dll
    onnxruntime_providers_shared.dll
    kata1_b11_b1.onnx        # 292 MB
```

代码里 `ortBackendLoad("kata1_b11_b1.onnx", &err)`（相对路径按**当前工作目录**解析，
建议用 exe 同目录的绝对路径或 `.\kata1_b11_b1.onnx`）。

**B. 原地复用 pip 目录（开发机最省事）**

不动任何文件，直接给 `GOAI3_ORT_DLL`：

```
set GOAI3_ORT_DLL=D:\GoAI3\GoAI3\GoAI3\build_out\npu\py\onnxruntime\capi\onnxruntime.dll
```

加载器会先把**同一个目录**里的 `DirectML.dll` 用绝对路径 + `LOAD_WITH_ALTERED_SEARCH_PATH`
拉起来，再加载 `onnxruntime.dll`（这是绕过依赖解析失败的关键）。

### 3.3 DLL 搜索顺序（`GOAI3_ORT_DLL` 优先）

1. 环境变量 `GOAI3_ORT_DLL`（完整路径；换机器只改这一行）
2. exe 同目录的 `onnxruntime.dll`
3. 当前目录下 `build_out\npu\py\onnxruntime\capi\onnxruntime.dll`
4. 当前目录下 `onnxruntime.dll`
5. `C:\Windows\System32\onnxruntime.dll`（**1.17 精简版，只有 API 1/17，加载会失败并报版本不匹配** —— 这是最后兜底，不会被误用）

### 3.4 最短上手命令（不接引擎也能先自测）

```bat
:: 在仓库根目录
build_out\ort\test_ort.exe
```

会用默认 ONNX（`build_out\npu\models\kata1_b11_b1.onnx`）和 `kata1.bin.gz` 跑完整验收
（原生 CPU vs ORT-DML，5 个局面，打印数值差 + 计时），约 40 s（其中 session 创建 5–7 s、
原生权重加载 ~4 s），末尾自动跑降级测试。

只想验证 GPU 路径（跳过 280 MB 原生权重加载，快很多）：

```bat
build_out\ort\test_ort.exe --no-native --iters 2 --no-degrade
```

---

## 4. 引擎接线示例（go_ai.cpp，Lead 用）

```cpp
#include "kg/infer/ort_backend.h"
#include "kg/infer/encode.h"

// 1) 启动时加载一次（例如在加载 kata1.bin.gz 成功之后；本函数会阻塞 5–7 s）
{
    std::string oerr;
    if (kg::ortBackendLoad("build_out\\npu\\models\\kata1_b11_b1.onnx", &oerr)) {
        std::cerr << "[ort] GPU provider=" << kg::ortBackendProvider()
                  << " ort=" << kg::ortBackendOrtVersion() << std::endl;
    } else {
        std::cerr << "[ort] disabled, using native CPU: " << oerr << std::endl;
    }
}

// 2) forward_katago 里：encodeV7 之后先试 ORT，失败再走原来的 kg::kgBackendForward
kg::EncodedInput in;
kg::encodeV7(kb, kh, (kg::Color)b.to_move, rules, in);

std::vector<float> pl, vl, own;
// 建议只在 provider=="DirectML" 时用 ORT：没有 GPU 时 ORT 的 CPU EP（~347 ms）
// 比优化后的原生 CPU（~240–280 ms）还慢，此时走原生更划算。
if (kg::ortBackendReady() && kg::ortBackendProvider() == "DirectML" &&
    kg::ortBackendForward(in.spatial, in.global, pl, vl, own)) {
    // policy：通道 0 的 362 个 logits -> softmax（与 kgBackendForward 的输出语义一致）
    const int S = 361, NP = 362;
    float mx = -1e30f;
    for (int i = 0; i < NP; ++i) mx = std::max(mx, pl[i]);
    double sum = 0.0;
    policy.assign(NP, 0.0f);
    for (int i = 0; i < NP; ++i) { policy[i] = std::exp(pl[i] - mx); sum += policy[i]; }
    for (int i = 0; i < NP; ++i) policy[i] = (float)(policy[i] / sum);
    // value：3 个 logits -> [-1,1] 当前行棋方胜率（与 ForwardResult::winrate 同一公式）
    double m = std::max((double)vl[0], std::max((double)vl[1], (double)vl[2]));
    double ew = std::exp(vl[0] - m), el = std::exp(vl[1] - m), en = std::exp(vl[2] - m);
    value = (float)((ew - el) / (ew + el + en));
    return true;
}
// 失败：一定要退回原生 CPU（kg::kgBackendForward），不能崩、不能返回空 policy
```

> 只在 `provider == "DirectML"` 时用 ORT 是**有意的策略**：ORT CPU EP 在同一次测试里
> 前向 244–351 ms（重负载），而优化后的原生 CPU 是 428–468 ms（同负载）/ 240–280 ms（轻负载）。
> 轻负载下原生 CPU 更快，所以没有 GPU 时没必要用 ORT。

---

## 5. 验收结果（`build_out\ort\test_ort.exe` 原始输出摘录）

5 个局面：空盘 + 3 盘真实职业棋谱（`kg\build\sgf\games.7z`，括号里是该局面前缀手数）的
中盘，且 encode.h 修好后的**征子特征平面 14/17 非零**（不是随机棋盘）：

```
[case 0] empty        to_move=B  history=0   ladder features: plane14=0  pts, plane17=0 pts
[case 1] game1-ply30  to_move=B  history=30  ladder features: plane14=8  pts, plane17=0 pts
[case 2] game1-ply60  to_move=B  history=60  ladder features: plane14=7  pts, plane17=1 pts
[case 3] game2-ply55  to_move=W  history=55  ladder features: plane14=1  pts, plane17=1 pts
[case 4] game3-ply58  to_move=B  history=58  ladder features: plane14=11 pts, plane17=3 pts
```

| case | policy prob max\|Δ\| | value logits max\|Δ\| | top-1 | native median | ORT-DML median |
|---|---|---|---|---|---|
| empty | 4.619e-07 | 3.052e-05 | SAME (Q16) | 279.0 ms | 75.3 ms |
| game1-ply30 | 3.129e-07 | 3.052e-05 | SAME (C17) | 278.6 ms | 72.2 ms |
| game1-ply60 | 3.725e-07 | 3.338e-06 | SAME (G6) | 280.6 ms | 74.1 ms |
| game2-ply55 | 6.407e-07 | 1.192e-07 | SAME (K8) | 279.1 ms | 72.7 ms |
| game3-ply58 | 1.162e-06 | 3.052e-05 | SAME (M4) | 275.8 ms | 73.4 ms |

汇总（轻负载那次，机器上另有 python 进程但 CPU 较空）：

```
cases compared            : 5/5
policy prob max|d| worst  : 1.162e-06   (threshold 2e-3)  PASS
value logits max|d| worst : 3.052e-05   (threshold 0.2)   PASS
ownership max|d| worst    : 6.914e-06   (info only)
policy top-1 agreement    : 5/5
ORT-DML forward  min/median: 70.3 / 73.0 ms  (over 25 runs)
native CPU fwd   min/median: 268.3 / 279.0 ms  (over 25 runs)
speedup (median of medians): 3.82x
session creation time     : 7.07 s
```

**重负载下**（后台 python 占 86% CPU + iGPU 争用）同一条命令复测：

```
ORT-DML forward  min/median: 106.3 / 130.2 ms
native CPU fwd   min/median: 428.5 / 460.0 ms
speedup: 3.59x
```

即：**GPU 前向本身受 CPU/iGPU 抢占影响会从 ~73 ms 掉到 ~130 ms，但相对原生 CPU 的倍数基本稳定在 3.5–3.8×**。

再补一次更极端的观察（后台 python 进程占 86% CPU，原生 CPU 的 OpenMP 14 线程被抢光）：

```
[case 1] game1-ply30  native min=1281.5 ms median=1466.7 ms | ORT-DML min=73.8 ms median=75.5 ms
[case 2] game1-ply60  native min=1287.5 ms median=1683.1 ms | ORT-DML min=74.3 ms median=75.3 ms
[case 3] game2-ply55  native min=1151.9 ms median=1185.7 ms | ORT-DML min=75.2 ms median=76.9 ms
[case 4] game3-ply58  native min=1458.1 ms median=1473.0 ms | ORT-DML min=74.5 ms median=77.0 ms
summary: native median 1473.0 ms / ORT-DML median 75.6 ms (19.5x)；session 创建 12.45 s
```

结论：**原生 CPU 前向对后台负载非常敏感（239 ms 空闲 → 1.5 s 抢满），DML 路径几乎不受
CPU 抢占影响**。所以给引擎接线时，GPU 后端的收益在"机器同时在干别的"场景下比空闲时更大。

**要复现干净的 ~73 ms / ~280 ms 数字，请在机器真正空闲时跑**（本机测试期间有别的 agent
的 python 进程长期占用 86% CPU，这个会显著影响原生 CPU 侧；GPU 侧基本稳定）。

其它结论：
* `native policy ch1` 与 **ONNX channel 1** 一致（不是 `katago_backend.h` 注释里写的 ch5；
  那条注释是错的）。引擎只用通道 0，所以不影响；但不要照那条注释做通道映射。
* 空盘 policy 四星位 Q16/D16/Q4/D4 = 0.311/0.271/0.205/0.137，两侧完全一致。
* value 三个 logits 两侧完全一致，但**数值本身是坏的**（空盘 winrate≈-0.99999）——
  这是 `kata1.bin.gz` 价值头本身的问题，不是 GPU 后端的问题；两条路径给出的坏值一样。

---

## 6. 失败 / 降级行为（全部实测）

| 场景 | `ortBackendLoad` 行为 | 引擎该怎么做 |
|---|---|---|
| `onnxPath` 为空 | 返回 false，`err="onnxPath is empty"`，不崩 | 退回原生 CPU |
| ONNX 文件不存在 | 返回 false，`err="ONNX model not found: '<绝对路径>'"` | 退回原生 CPU |
| 找不到可用 `onnxruntime.dll` | 返回 false + 列出每个候选路径与原因；若只找到系统 1.17 版，错误为 `ORT 1.17.1 does not support OrtApi v24 (header/DLL mismatch; upgrade the DLL)` | 退回原生 CPU |
| 有 DLL 但 DirectML EP 不可用 | **不失败**：自动降级到 ORT CPU EP，`provider="CPU"`，stderr 一行警告；session 创建 1.1 s | 建议**仍走原生 CPU**（更快）；或仅在 `provider=="DirectML"` 时用 ORT |
| 未 Load / 已 Release 就调 Forward | 返回 false，`err="ORT backend is not ready (call ortBackendLoad first)"`，输出被清空 | 退回原生 CPU |
| Run 失败 / 输出形状不符 | 返回 false + 具体 `OrtStatus` 消息，输出被清空 | 退回原生 CPU |
| 进程里根本没有 ONNX Runtime | 同上（Load 返回 false） | 退回原生 CPU |

已实测的降级原始输出：

```
# 1) 进程内降级测试（--degrade-only）
[PASS] empty onnx path        -> ok=0  err="onnxPath is empty"
[PASS] missing onnx file      -> ok=0  err="ONNX model not found: '...__definitely_missing__.onnx'"
[PASS] forward while not loaded -> ok=0 cleaned=1 err="ORT backend is not ready (...)"

# 2) 把工作目录换到 build_out\ort（pip DLL 不在搜索路径，只剩系统 1.17）：
FAILED: cannot load a usable onnxruntime.dll with OrtApi v24 -- tried:
  '...\build_out\ort\onnxruntime.dll' (not found);
  '...\build_out\ort\build_out\npu\py\onnxruntime\capi\onnxruntime.dll' (not found);
  '...\build_out\ort\onnxruntime.dll' (not found);
  'C:\Windows\System32\onnxruntime.dll': ORT 1.17.1 does not support OrtApi v24 (...);
-> engine must fall back to the native CPU path

# 3) 同一工作目录 + GOAI3_ORT_DLL 指到 pip 的 DLL：
OK in 5.49 s  provider=DirectML  ort=1.24.4
```

调试开关：`GOAI3_ORT_FORCE_CPU=1` 强制跳过 DML（走上面第 4 行的 CPU EP 降级路径，
`provider="CPU"`），用来在没有 GPU 的机器上验证接线是否正常。

---

## 7. 内存 / 显存（实测）

| 时刻 | 进程 working set |
|---|---|
| 进程启动 | 3.7 MB |
| 加载原生 `kata1.bin.gz` 后 | 274 MB |
| 再建 ORT-DML session 后 | **1.15 GB**（peak 1.47 GB） |
| 只建 ORT session（不加载原生权重） | **874 MB** |
| `ortBackendRelease()` + 释放原生权重后 | 391–664 MB（DLL 有缓存，不会立刻全还） |

* GPU 侧（Windows `GPU Process Memory` 计数器，session 建好、尚未跑前向时采样）：
  **Dedicated 0 MB / Shared 667.8 MB / Total Committed 667.8 MB**。
  Arc 130T 是 iGPU，没有独立显存，这 668 MB 就是系统内存；整机可用内存 17.7 GB 时跑测试无压力。
* 292 MB 是 fp32 权重本身；要显著降显存只能换 fp16/INT8 模型（本后端目前是 fp32 ONNX，
  换 fp16 需要重新导出并验证精度，未做）。

---

## 8. 已知限制 / 注意事项

1. **ONNX 必须和 `.bin.gz` 同源**。当前 ONNX 是从**旧的、坏的价值头**的 `kata1.bin.gz` 导出的；
   价值头重训产出 `kata1_value_fixed.bin.gz` 后，必须用 `tools\export_onnx.py` **重新导出 ONNX**，
   否则 GPU 路径用的还是旧价值头（现在两边价值头都坏，所以数值对比仍然一致 —— 这是预期）。
2. **session 创建 5.5–7.1 s、只做一次**。绝不能在每次前向里新建（本实现已保证单例）。
   引擎启动时调 `ortBackendLoad` 会阻塞这段时间；如需"先出界面后加载"，把 Load 放到后台线程，
   加载完成前 `ortBackendReady()==false` 会自动走原生 CPU —— 但**不要**同时从两个线程调 Load。
3. **第一次前向略慢**：DML 端第一次 Run 约 93 ms（shader/设备初始化），之后稳定 70–75 ms。
   本后端没有做 warm-up（省掉 Load 里的一次前向）。
4. **并发被串行化**：`ortBackendForward` 有一把 mutex，MCTS 多线程展开叶子时 GPU 请求排队。
   单次 73 ms 仍远低于原生 270 ms，但**吞吐**上限需要 batch 推理才能突破
   （`build_out\npu\models\kata1_b11_b8.onnx` 已有，未接入；接入需要改接口传 batch）。
5. **iGPU 与桌面争用**：Arc 130T 共享内存，重负载/游戏/多显示器时前向会掉到 110–150 ms。
6. **DLL/头版本必须配对**：头是 1.24.4（`ORT_API_VERSION=24`）。换 DLL 就必须换同名头，
   或在 `loadOrtLocked` 里降低 `ORT_API_VERSION`（不推荐猜旧布局）。系统自带 1.17 不可用。
7. **DML 设备号**：固定 device 0（当前机器只有一块 iGPU）；多 GPU 机器需要加 provider option。
8. **数值**：DML 在 Arc 上是 fp32 计算，误差 ~1e-5（见上表），不是 fp16 近似。
9. 本后端**不改** go_ai.cpp / ops.h / forward.h / encode.h / board.h；`kg/infer/ort/` 只放
   ORT 官方头（MIT）。

---

## 9. 复现命令

```bat
:: 重新编译验收程序（在仓库根目录，显式 vcvars64）
cmd /c "call ""C:\Program Files\Microsoft Visual Studio\18\Community\VC\Auxiliary\Build\vcvars64.bat"" >nul && cl /nologo /O2 /EHsc /std:c++17 /W3 /DNDEBUG /utf-8 /openmp /Fe:build_out\ort\test_ort.exe /Fo:build_out\ort\ kg\test\test_ort.cpp"

:: 完整验收（原生 CPU vs ORT-DML，5 局，数值 + 计时 + 降级）
build_out\ort\test_ort.exe

:: 只测 GPU 路径
build_out\ort\test_ort.exe --no-native --iters 2 --no-degrade

:: 降级测试
build_out\ort\test_ort.exe --degrade-only

:: 采显存（脚本内部用 Windows GPU 计数器，--hold 15 让进程停在 session 建好后）
powershell -NoProfile -ExecutionPolicy Bypass -File build_out\ort\run_with_mem.ps1
```
