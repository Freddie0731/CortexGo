// ============================================================================
//  forward.h -- KataGo v17 前向推理（单精度 CPU）
//
//  严格对照官方 python/katago/train/model_pytorch.py：
//    _per_block_embed        -> 输入嵌入（3x3 卷积 + 全局线性，相加）
//    _per_block_trunk_unit   -> 每个 trunk 块，含**跨块残差累积**
//                               out = out + residual_in;  residual = block(out)
//    _per_block_finish       -> out += residual;  norm_trunkfinal; act_trunkfinal
//    PolicyHead.forward      -> 策略头
//    ValueHead.forward       -> 价值头
//
//  布局：主干全程 (S, C)，S = H*W（行优先）。只有输入 3x3 卷积用 (C,H,W)。
//  掩码在盘的合法点为 1、盘外为 0。测试用例里掩码全 1，因此与官方 NCHW 路径
//  在数值上完全等价。
//
//  性能：所有矩阵乘走 ops.h 的 AVX2 微内核 + LinearWeightCache（权重转置只做
//  一次）；注意力/逐点算子见 ops.h 顶部说明。profile=true 时会向 stderr 打印
//  各阶段耗时（gemm/attn/norm/act/rope/other），用于定位剩余瓶颈。
// ============================================================================
#ifndef KG_FORWARD_H
#define KG_FORWARD_H

#include "weights.h"
#include "ops.h"

#include <chrono>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <map>
#include <stdexcept>
#include <string>
#include <vector>

namespace kg {

struct ForwardResult {
    int S = 0;                 // 361
    std::vector<float> policy; // (numPolicyOut, S+1)；[..., S] 是 pass
    std::vector<float> value;  // (3,)  win/loss/noresult（当前行棋方视角）
    std::vector<float> misc;   // (6,)  scoremean/scorestdev/lead/vtime/…
    std::vector<float> ownership;  // (S,)
    int numPolicyOut = 0;

    // 把 win/loss/noresult 三个通道转成 [-1,1] 胜率（当前行棋方视角）。
    //
    // 这三个通道是 **logit，不是概率**（导出侧就是 linear_valuehead 的裸输出），
    // 所以必须先 softmax 再取 p_win - p_loss。早先这里写成 (w-l)/(w+l+n) 并配了
    // `if (d <= 1e-9) return 0.0f` 的守卫，是当成概率写的：空盘时三者之和是
    // -70.26，负数让守卫无条件命中，于是 value 恒等于 0 —— 搜索拿到一个恒定
    // 的"五五开"，价值信号被整条丢掉。
    inline float winrate() const {
        if (value.size() < 3) return 0.0f;
        double m = value[0];
        if (value[1] > m) m = value[1];
        if (value[2] > m) m = value[2];
        if (!(m == m)) return 0.0f;               // NaN 保护
        double ew = std::exp((double)value[0] - m);
        double el = std::exp((double)value[1] - m);
        double en = std::exp((double)value[2] - m);
        double s = ew + el + en;
        if (!(s > 0.0)) return 0.0f;
        double r = (ew - el) / s;
        if (r > 1.0) r = 1.0;
        if (r < -1.0) r = -1.0;
        return (float)r;
    }
};

class Forward {
public:
    Forward(const Model& m, int posLen) : M_(m), N_(posLen) {}

    // 调试：按官方 hook 的名字记录中间张量（键名如 "blocks.0.blockstack.0"）
    // 这些成员是 mutable 的，因为抓取点都在 const 方法里。
    mutable bool debug = false;
    mutable bool profile = false;
    mutable std::map<std::string, std::vector<float> > debugTensors;
    mutable std::vector<std::string> debugKeys;

    // 各阶段累计耗时（秒），只在 profile==true 时有意义
    mutable double profGemm = 0, profAttn = 0, profNorm = 0, profAct = 0, profRope = 0,
                   profOther = 0;

    void dbg(const std::string& key, const std::vector<float>& v) const {
        if (!debug) return;
        // 官方 hook 的模块名不带 "model." 前缀（顶层模块叫 model，
        // 其子模块名是 "blocks.0"、"conv_spatial" 等）。这里统一去掉前缀以便比对。
        std::string k = key;
        if (k.compare(0, 6, "model.") == 0) k = k.substr(6);
        if (debugTensors.find(k) == debugTensors.end()) debugKeys.push_back(k);
        debugTensors[k] = v;
    }

    // inputSpatial: (C, H, W) 行优先，C = numInputChannels
    // inputGlobal : (numInputGlobalChannels,)
    // mask        : (S,) 每点 1/0；为空视为全 1
    void run(const std::vector<float>& inputSpatial,
             const std::vector<float>& inputGlobal,
             const std::vector<float>& maskIn,
             ForwardResult& res) const {
        const Trunk& T = M_.trunk;
        const int H = N_, W = N_;
        const int S = H * W;
        const int C = M_.numInputChannels;
        if ((int)inputSpatial.size() != C * S)
            throw std::runtime_error("inputSpatial size mismatch");

        if (profile) {
            profGemm = profAttn = profNorm = profAct = profRope = profOther = 0.0;
        }

        std::vector<float> mask = maskIn;
        if (mask.empty()) mask.assign(S, 1.0f);
        float maskSum = 0.0f;
        for (int s = 0; s < S; ++s) maskSum += mask[s];

        // ---- _per_block_embed: 3x3 conv + global linear ----
        std::vector<float> xSpatial;
        convSpatialApply(inputSpatial, C, H, W, T.initialConv, xSpatial);
        const int CT = T.trunkNumChannels;
        std::vector<float> xGlobal;
        linearApplyCached(inputGlobal, 1, T.initialMatMul.ic, T.initialMatMul.oc,
                          T.initialMatMul.w, nullptr, xGlobal, wtc_);
        // 抓取抓成 (S,C) 便于与参考的序列布局比对
        {
            std::vector<float> cs((size_t)S * CT);
            for (int c = 0; c < CT; ++c)
                for (int s = 0; s < S; ++s) cs[(size_t)s * CT + c] = xSpatial[(size_t)c * S + s];
            dbg("conv_spatial", cs);
            std::vector<float> gl((size_t)S * CT);
            for (int s = 0; s < S; ++s)
                for (int c = 0; c < CT; ++c) gl[(size_t)s * CT + c] = xGlobal[c];
            dbg("linear_global", gl);
        }

        std::vector<float> out((size_t)S * CT);
        for (int s = 0; s < S; ++s)
            for (int c = 0; c < CT; ++c)
                out[(size_t)s * CT + c] = xSpatial[(size_t)c * S + s] + xGlobal[c];
        dbg("embed.out", out);

        // ---- trunk blocks: 跨块残差累积 ----
        std::vector<float> residual;
        bool hasResidual = false;
        for (size_t bi = 0; bi < T.blocks.size(); ++bi) {
            auto _bt0 = std::chrono::steady_clock::now();
            if (hasResidual) {
                {
                    auto _t0 = std::chrono::steady_clock::now();
                    addInPlace(out.data(), residual.data(), out.size());
                    if (profile) profOther += std::chrono::duration<double>(
                        std::chrono::steady_clock::now() - _t0).count();
                }
            }
            blockForward(T.blocks[bi], out, S, CT, mask, residual);
            hasResidual = true;
            if (profile) {
                auto _bt1 = std::chrono::steady_clock::now();
                std::fprintf(stderr, "  block %2zu: %.1f ms\n", bi,
                    std::chrono::duration<double, std::milli>(_bt1 - _bt0).count());
            }
        }
        if (hasResidual) {
            auto _t0 = std::chrono::steady_clock::now();
            addInPlace(out.data(), residual.data(), out.size());
            if (profile) profOther += std::chrono::duration<double>(
                std::chrono::steady_clock::now() - _t0).count();
        }

        // ---- trunk tip: norm + activation ----
        std::vector<float> tip;
        if (T.trunkNormKind == 0) {
            auto _t0 = std::chrono::steady_clock::now();
            normMaskApply(out, S, CT, T.trunkTipNorm, mask, tip);
            if (profile) profNorm += std::chrono::duration<double>(
                std::chrono::steady_clock::now() - _t0).count();
        } else {
            // ---- RMSNorm trunk tip（modelVersion 15 网络，例如 b10c384h6nbttflrs）----
            // 官方实现是 RMSNormMask（model_pytorch.py:246-279），和原来这里的写法有两处
            // 实质差别。原来的写法对 normKind==0 的网络毫无影响（根本走不到这个分支），
            // 但一旦换成 v15 网络就会"能跑、出招看着像样、其实算错"：
            //   1) spatial=True 时 RMS 是**整盘一个标量**：
            //        mean_sq = Σ(x²·mask) / (C·mask_sum_hw + eps)
            //      而不是逐位置跨通道各求各的；
            //   2) 归一化之后还要 *gamma[c] + beta[c]，最后再乘 mask。原来的写法把 beta 整个丢了。
            // 实测（把 trunk 末端张量 dump 出来与官方公式复算对比）：错公式带来约 24% 的
            // 相对误差，而 trunk 末端正是 policy / value 两个头的共同输入。
            auto _t0 = std::chrono::steady_clock::now();
            const RmsNormLayer& R = T.trunkTipRmsNorm;
            const float eps = R.epsilon;
            const float* gam = (R.gamma.size() == (size_t)CT) ? R.gamma.data() : NULL;
            const float* bet = (R.beta.size() == (size_t)CT) ? R.beta.data() : NULL;
            const double maskSumD = mask.empty() ? (double)S : (double)maskSum;
            tip.resize((size_t)S * CT);
            if (R.spatial) {
                double ss = 0.0;
                for (int s = 0; s < S; ++s) {
                    const float m = mask.empty() ? 1.0f : mask[s];
                    if (m <= 0.0f) continue;
                    const float* row = &out[(size_t)s * CT];
                    for (int c = 0; c < CT; ++c) ss += (double)row[c] * row[c] * m;
                }
                const double denom = (double)CT * maskSumD + (double)eps;
                const float inv = 1.0f / std::sqrt((float)(ss / denom) + eps);
                for (int s = 0; s < S; ++s) {
                    const float m = mask.empty() ? 1.0f : mask[s];
                    const float* src = &out[(size_t)s * CT];
                    float* dst = &tip[(size_t)s * CT];
                    for (int c = 0; c < CT; ++c) {
                        const float g = gam ? gam[c] : 1.0f;
                        const float b = bet ? bet[c] : 0.0f;
                        dst[c] = (src[c] * inv * g + b) * m;
                    }
                }
            } else {
                // 非 spatial：逐位置跨通道求 RMS（带可学习 weight），再补 beta 与 mask。
                for (int s = 0; s < S; ++s) {
                    const float* src = &out[(size_t)s * CT];
                    double ss = 0.0;
                    for (int c = 0; c < CT; ++c) ss += (double)src[c] * src[c];
                    const float inv = 1.0f / std::sqrt((float)(ss / (double)CT) + eps);
                    const float m = mask.empty() ? 1.0f : mask[s];
                    float* dst = &tip[(size_t)s * CT];
                    for (int c = 0; c < CT; ++c) {
                        const float g = gam ? gam[c] : 1.0f;
                        const float b = bet ? bet[c] : 0.0f;
                        dst[c] = (src[c] * inv * g + b) * m;
                    }
                }
            }
            if (profile) profNorm += std::chrono::duration<double>(
                std::chrono::steady_clock::now() - _t0).count();
        }
        {
            auto _t0 = std::chrono::steady_clock::now();
            applyActivation(tip, T.trunkTipAct.kind);
            if (profile) profAct += std::chrono::duration<double>(
                std::chrono::steady_clock::now() - _t0).count();
        }
        dbg("act_trunkfinal", tip);

        // ---- 头部 ----
        policyForward(tip, mask, maskSum, S, res);
        valueForward(tip, mask, maskSum, S, res);
        res.S = S;

        if (profile) {
            std::fprintf(stderr,
                         "  [profile] gemm=%.1f attn=%.1f norm=%.1f act=%.1f rope=%.1f "
                         "other=%.1f ms\n",
                         profGemm * 1e3, profAttn * 1e3, profNorm * 1e3, profAct * 1e3,
                         profRope * 1e3, profOther * 1e3);
            profGemm = profAttn = profNorm = profAct = profRope = profOther = 0.0;
        }
    }

private:
    const Model& M_;
    int N_;

    // 权重转置缓存 + 注意力 scratch（模型权重在 Forward 生命周期内不变）
    mutable LinearWeightCache wtc_;
    mutable AttentionScratch attnScr_;

    // 单个 NormActConv：norm -> act -> conv（1x1）
    void nacForward(const NormActConv& nc, const std::vector<float>& x, int S, int C,
                    const std::vector<float>& mask, std::vector<float>& out) const {
        std::vector<float> n;
        {
            auto _t0 = std::chrono::steady_clock::now();
            normMaskApply(x, S, C, nc.norm, mask, n);
            if (profile) profNorm += std::chrono::duration<double>(
                std::chrono::steady_clock::now() - _t0).count();
        }
        dbg(nc.norm.name, n);
        {
            auto _t0 = std::chrono::steady_clock::now();
            applyActivation(n, nc.act.kind);
            if (profile) profAct += std::chrono::duration<double>(
                std::chrono::steady_clock::now() - _t0).count();
        }
        dbg(nc.act.name, n);
        {
            auto _t0 = std::chrono::steady_clock::now();
            conv1x1ApplyCached(n, S, nc.conv, out, wtc_);
            if (profile) profGemm += std::chrono::duration<double>(
                std::chrono::steady_clock::now() - _t0).count();
        }
        dbg(nc.conv.name, out);
    }

    // transformer attention 块
    void attnForward(const TfAttentionBlock& a, const std::vector<float>& x, int S,
                     int C, const std::vector<float>& mask,
                     std::vector<float>& out) const {
        std::vector<float> xn;
        {
            auto _t0 = std::chrono::steady_clock::now();
            rmsNormApply(x, S, C, a.preLN.weight, a.preLN.epsilon, xn);
            if (profile) profNorm += std::chrono::duration<double>(
                std::chrono::steady_clock::now() - _t0).count();
        }
        dbg(a.name + ".norm1", xn);

        std::vector<float> q, k, v;
        {
            auto _t0 = std::chrono::steady_clock::now();
            linearApplyCached(xn, S, a.qProj.ic, a.qProj.oc, a.qProj.w, nullptr, q, wtc_);
            linearApplyCached(xn, S, a.kProj.ic, a.kProj.oc, a.kProj.w, nullptr, k, wtc_);
            linearApplyCached(xn, S, a.vProj.ic, a.vProj.oc, a.vProj.w, nullptr, v, wtc_);
            if (profile) profGemm += std::chrono::duration<double>(
                std::chrono::steady_clock::now() - _t0).count();
        }
        dbg(a.name + ".q_proj", q);
        dbg(a.name + ".k_proj", k);
        dbg(a.name + ".v_proj", v);

        if (a.useRope) {
            std::vector<float> freqs;
            if (a.learnableRope) {
                freqs = a.ropeFreqs;   // (H, P, 2)
            } else {
                throw std::runtime_error("non-learnable rope not implemented");
            }
            auto _t0 = std::chrono::steady_clock::now();
            ropeApply(q, S, a.numHeads, a.qHeadDim, freqs, N_);
            ropeApply(k, S, a.numKVHeads, a.qHeadDim, freqs, N_);
            if (profile) profRope += std::chrono::duration<double>(
                std::chrono::steady_clock::now() - _t0).count();
        }
        dbg(a.name + ".q_roped", q);
        dbg(a.name + ".k_roped", k);

        std::vector<float> att;
        {
            auto _t0 = std::chrono::steady_clock::now();
            attentionApply(q, k, v, S, a.numHeads, a.qHeadDim, a.vHeadDim, mask, att,
                           attnScr_);
            if (profile) profAttn += std::chrono::duration<double>(
                std::chrono::steady_clock::now() - _t0).count();
        }

        std::vector<float> proj;
        {
            auto _t0 = std::chrono::steady_clock::now();
            linearApplyCached(att, S, a.outProj.ic, a.outProj.oc, a.outProj.w, nullptr,
                              proj, wtc_);
            if (profile) profGemm += std::chrono::duration<double>(
                std::chrono::steady_clock::now() - _t0).count();
        }
        dbg(a.name + ".out_proj", proj);
        out.swap(proj);
    }

    // transformer FFN 块（SwiGLU）
    void ffnForward(const TfFFNBlock& f, const std::vector<float>& x, int S, int C,
                    std::vector<float>& out) const {
        std::vector<float> xn;
        {
            auto _t0 = std::chrono::steady_clock::now();
            rmsNormApply(x, S, C, f.preLN.weight, f.preLN.epsilon, xn);
            if (profile) profNorm += std::chrono::duration<double>(
                std::chrono::steady_clock::now() - _t0).count();
        }
        dbg(f.name + ".norm", xn);
        std::vector<float> h1, h2;
        {
            auto _t0 = std::chrono::steady_clock::now();
            linearApplyCached(xn, S, f.linear1.ic, f.linear1.oc, f.linear1.w, nullptr, h1,
                              wtc_);
            if (f.useSwiGLU)
                linearApplyCached(xn, S, f.linearGate.ic, f.linearGate.oc, f.linearGate.w,
                                  nullptr, h2, wtc_);
            if (profile) profGemm += std::chrono::duration<double>(
                std::chrono::steady_clock::now() - _t0).count();
        }
        if (f.useSwiGLU) {
            auto _t0 = std::chrono::steady_clock::now();
            // silu(h1) * h2（融合成一次遍历，向量化 exp）
            siluMulInPlace(h1.data(), h2.data(), h1.size());
            if (profile) profAct += std::chrono::duration<double>(
                std::chrono::steady_clock::now() - _t0).count();
        } else {
            auto _t0 = std::chrono::steady_clock::now();
            applyActivation(h1, "ACTIVATION_SILU");
            if (profile) profAct += std::chrono::duration<double>(
                std::chrono::steady_clock::now() - _t0).count();
        }
        std::vector<float> o;
        {
            auto _t0 = std::chrono::steady_clock::now();
            linearApplyCached(h1, S, f.linear2.ic, f.linear2.oc, f.linear2.w, nullptr, o,
                              wtc_);
            if (profile) profGemm += std::chrono::duration<double>(
                std::chrono::steady_clock::now() - _t0).count();
        }
        out.swap(o);
    }

    // 一个普通 NormActConv 残差子块：out = nc2(nc1(x))
    void ordinaryForward(const OrdinaryBlock& b, const std::vector<float>& x, int S,
                         int C, const std::vector<float>& mask,
                         std::vector<float>& out) const {
        std::vector<float> t;
        nacForward(b.nc1, x, S, C, mask, t);
        nacForward(b.nc2, t, S, b.nc1.conv.oc, mask, out);
    }

    // 块分派。seqLayout=true 表示输入输出是 (S,C)，false 表示 (S,C) 但内容是空间特征
    void blockForward(const Block& b, const std::vector<float>& x, int S, int C,
                      const std::vector<float>& mask, std::vector<float>& out) const {
        switch (b.kind) {
            case BLK_NESTED_BOTTLENECK: {
                std::vector<float> t;
                nacForward(b.p, x, S, C, mask, t);
                dbg(b.name + ".normactconvp", t);
                const int cMid = b.p.conv.oc;
                for (size_t i = 0; i < b.stack.size(); ++i) {
                    std::vector<float> sub;
                    blockForward(b.stack[i], t, S, cMid, mask, sub);
                    dbg(b.name + ".blockstack." + std::to_string(i), sub);
                    {
                        auto _t0 = std::chrono::steady_clock::now();
                        addInPlace(t.data(), sub.data(), t.size());
                        if (profile) profOther += std::chrono::duration<double>(
                            std::chrono::steady_clock::now() - _t0).count();
                    }
                }
                dbg(b.name + ".preq", t);
                nacForward(b.q, t, S, cMid, mask, out);
                dbg(b.name, out);
                break;
            }
            case BLK_TF_ATTENTION: {
                // 注意：官方 attention 块只返回**残差**，加法由调用方负责
                // （见 TransformerAttentionBlock.forward 的 docstring：
                //  "residual only, caller is responsible for adding to trunk"）。
                // 父层 NestedBottleneckTransformerBlock.forward 里做 out = out + block(out)。
                attnForward(b.attn, x, S, C, mask, out);
                break;
            }
            case BLK_TF_FFN: {
                // 同上：FFN 块也只返回残差。
                ffnForward(b.ffn, x, S, C, out);
                break;
            }
            case BLK_ORDINARY: {
                ordinaryForward(b.ordinary, x, S, C, mask, out);
                break;
            }
            default:
                throw std::runtime_error("unsupported block kind in forward");
        }
    }

    // ------------------------------------------------------- 策略头
    void policyForward(const std::vector<float>& trunkOut, const std::vector<float>& mask,
                       float maskSum, int S, ForwardResult& res) const {
        const PolicyHead& P = M_.policyHead;
        const int CT = M_.trunk.trunkNumChannels;

        std::vector<float> outp, outg;
        conv1x1ApplyCached(trunkOut, S, P.p1Conv, outp, wtc_);
        conv1x1ApplyCached(trunkOut, S, P.g1Conv, outg, wtc_);

        // biasg(掩码) -> actg -> gpool -> linear_g（当逐通道偏置加回去）
        std::vector<float> g1n;
        normMaskApply(outg, S, P.g1Conv.oc, P.g1BN, mask, g1n);
        applyActivation(g1n, P.g1Activation.kind);
        std::vector<float> pooledG;
        gpoolApply(g1n, S, P.g1Conv.oc, mask, maskSum, pooledG);
        std::vector<float> biasAdd;
        linearApplyCached(pooledG, 1, P.gpoolToBiasMul.ic, P.gpoolToBiasMul.oc,
                          P.gpoolToBiasMul.w, nullptr, biasAdd, wtc_);
        for (int s = 0; s < S; ++s)
            for (int c = 0; c < P.p1Conv.oc; ++c)
                outp[(size_t)s * P.p1Conv.oc + c] += biasAdd[c];

        // bias2(掩码) -> act2 -> conv2p
        std::vector<float> p1n;
        normMaskApply(outp, S, P.p1Conv.oc, P.p1BN, mask, p1n);
        applyActivation(p1n, P.p1Activation.kind);
        std::vector<float> logits;
        conv1x1ApplyCached(p1n, S, P.p2Conv, logits, wtc_);

        // pass 分支： linear_pass -> act_pass -> linear_pass2
        std::vector<float> passv;
        linearApplyCached(pooledG, 1, P.gpoolToPassMul.ic, P.gpoolToPassMul.oc,
                          P.gpoolToPassMul.w, P.gpoolToPassBias.b.data(), passv, wtc_);
        applyActivation(passv, P.passActivation.kind);
        std::vector<float> passOut;
        linearApplyCached(passv, 1, P.gpoolToPassMul2.ic, P.gpoolToPassMul2.oc,
                          P.gpoolToPassMul2.w, nullptr, passOut, wtc_);

        const int NO = P.p2Conv.oc;              // 文件里是 2
        // 官方策略头输出 6 通道（v17 且 predict_q_values=False 时）：
        //   0 = regular policy, 1 = opponent reply, 2/3 = soft policy,
        //   4 = long-term optimistic, 5 = short-term optimistic
        // 但 .bin.gz 只写 2 个通道，并且实测它们对应模型的通道 0 与 5。
        // 其余通道文件未写，官方那边是零初始化，因此这里补零。
        const int NCH = 6;
        res.policy.assign((size_t)NCH * (S + 1), 0.0f);
        for (int o = 0; o < NO; ++o) {
            const int dstCh = (o == 0) ? 0 : 5;   // 文件第 1 个通道 -> 模型通道 5
            for (int s = 0; s < S; ++s) {
                float v = logits[(size_t)s * NO + o];
                if (mask[s] <= 0.0f) v -= 5000.0f;   // 官方：盘外减 5000
                res.policy[(size_t)dstCh * (S + 1) + s] = v;
            }
            res.policy[(size_t)dstCh * (S + 1) + S] = passOut[o];
        }
        res.numPolicyOut = NCH;
        (void)CT;
    }

    // ------------------------------------------------------- 价值头
    void valueForward(const std::vector<float>& trunkOut, const std::vector<float>& mask,
                      float maskSum, int S, ForwardResult& res) const {
        const ValueHead& V = M_.valueHead;
        const int CT = M_.trunk.trunkNumChannels;

        // conv1 -> bias1 -> act1
        std::vector<float> v1;
        conv1x1ApplyCached(trunkOut, S, V.v1Conv, v1, wtc_);
        std::vector<float> v1n;
        normMaskApply(v1, S, V.v1Conv.oc, V.v1BN, mask, v1n);
        applyActivation(v1n, V.v1Activation.kind);
        dbg("value_head.conv1", v1);
        dbg("value_head.act1", v1n);

        // gpool（价值头版：第三路是 mean 的二次式）-> linear2 -> act2
        std::vector<float> pooled;
        gpoolValueApply(v1n, S, V.v1Conv.oc, mask, maskSum, pooled);
        dbg("value_head.gpool", pooled);
        std::vector<float> v2;
        linearApplyCached(pooled, 1, V.v2Mul.ic, V.v2Mul.oc, V.v2Mul.w,
                          V.v2Bias.b.data(), v2, wtc_);
        dbg("value_head.linear2", v2);
        applyActivation(v2, V.v2Activation.kind);

        // 各子头
        std::vector<float> val, misc;
        linearApplyCached(v2, 1, V.v3Mul.ic, V.v3Mul.oc, V.v3Mul.w, V.v3Bias.b.data(), val,
                          wtc_);
        linearApplyCached(v2, 1, V.sv3Mul.ic, V.sv3Mul.oc, V.sv3Mul.w, V.sv3Bias.b.data(),
                          misc, wtc_);
        res.value.swap(val);
        res.misc.swap(misc);

        // ownership：作用在 act1 之后的 v1n 上，再乘掩码
        std::vector<float> own;
        conv1x1ApplyCached(v1n, S, V.vOwnershipConv, own, wtc_);
        res.ownership.resize(S);
        for (int s = 0; s < S; ++s)
            res.ownership[s] = own[s] * (mask.empty() ? 1.0f : mask[s]);
        (void)CT;
    }
};

}  // namespace kg

#endif  // KG_FORWARD_H
