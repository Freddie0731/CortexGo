// ============================================================================
//  test_ops.cpp -- 逐算子与 PyTorch 对齐
//
//  参考值由 _kg_ops_ref.py 生成（用同一权重文件 + 可控随机输入，跑 PyTorch 等价算子）。
//  这里逐个算子复算并比对，精确定位实现错误。
//
//  布局注意：PyTorch 侧 conv 用 NCHW，本工程主干用 (S,C)，因此做转置后再比。
//  用法: test_ops <ops_ref.bin>
// ============================================================================
#include "../infer/ops.h"
#include "../infer/refdata.h"

#include <cstdio>
#include <string>

using namespace kg;

static int g_fail = 0;

static std::vector<float> nchwToSC(const std::vector<float>& x, int C, int S) {
    std::vector<float> o((size_t)S * C);
    for (int c = 0; c < C; ++c)
        for (int s = 0; s < S; ++s) o[(size_t)s * C + c] = x[(size_t)c * S + s];
    return o;
}

static std::vector<float> scToNchw(const std::vector<float>& x, int C, int S) {
    std::vector<float> o((size_t)C * S);
    for (int s = 0; s < S; ++s)
        for (int c = 0; c < C; ++c) o[(size_t)c * S + s] = x[(size_t)s * C + c];
    return o;
}

static void check(const char* name, const std::vector<float>& mine,
                  const RefData& ref, const char* refKey, double tol = 1e-4,
                  bool dump = false) {
    const RefTensor* r = ref.get(refKey);
    if (!r) {
        std::printf("  %-24s SKIP (no reference %s)\n", name, refKey);
        return;
    }
    if (mine.size() != r->size()) {
        std::printf("  %-24s FAIL size %zu vs ref %zu\n", name, mine.size(), r->size());
        ++g_fail;
        return;
    }
    double ma = 0, mr = 0;
    size_t am = 0;
    compareArrays(mine, r->data, ma, mr, am);
    bool ok = ma < tol;
    if (!ok) ++g_fail;
    std::printf("  %-24s %s  maxAbsErr=%.3e  (n=%zu)\n", name, ok ? "OK  " : "FAIL", ma,
                mine.size());
    if (!ok) {
        std::printf("        first mismatch area: idx=%zu ref=%+.6f mine=%+.6f\n", am,
                    r->data[am], mine[am]);
    }
    if (dump || !ok) {
        size_t n = mine.size() < 12 ? mine.size() : 12;
        std::printf("        ref :");
        for (size_t i = 0; i < n; ++i) std::printf(" %+.4f", r->data[i]);
        std::printf("\n        mine:");
        for (size_t i = 0; i < n; ++i) std::printf(" %+.4f", mine[i]);
        std::printf("\n");
    }
}

static std::vector<float> asVec(const RefTensor* t) { return t ? t->data : std::vector<float>(); }

int main(int argc, char** argv) {
    if (argc < 2) {
        std::printf("usage: test_ops <ops_ref.bin>\n");
        return 2;
    }
    RefData ref;
    std::string err;
    if (!ref.load(argv[1], &err)) {
        std::printf("FAIL load: %s\n", err.c_str());
        return 1;
    }
    std::printf("loaded %zu tensors from %s\n\n", ref.count(), argv[1]);

    // ---------- 1. linear ----------
    {
        const RefTensor* x = ref.get("linear.x");
        const RefTensor* W = ref.get("linear.W");
        int S = x->dim(0), IC = x->dim(1), OC = W->dim(0);
        std::vector<float> o;
        linearApply(x->data, S, IC, OC, W->data, nullptr, o);
        check("linear", o, ref, "linear.out");
    }

    // ---------- 2. conv3x3 ----------
    {
        const RefTensor* x = ref.get("conv3.x");
        const RefTensor* W = ref.get("conv3.W");
        int C = x->dim(1), H = x->dim(2), Wd = x->dim(3);
        ConvLayer c;
        c.oc = W->dim(0); c.ic = W->dim(1); c.ky = W->dim(2); c.kx = W->dim(3);
        c.w = W->data;
        std::vector<float> o;
        convSpatialApply(x->data, C, H, Wd, c, o);
        check("conv3x3", o, ref, "conv3.out");
    }

    // ---------- 3. conv1x1 ----------
    {
        const RefTensor* x = ref.get("conv1.x");
        const RefTensor* W = ref.get("conv1.W");
        int C = x->dim(1), H = x->dim(2), Wd = x->dim(3);
        int S = H * Wd;
        ConvLayer c;
        c.oc = W->dim(0); c.ic = W->dim(1); c.ky = W->dim(2); c.kx = W->dim(3);
        c.w = W->data;
        std::vector<float> o;
        conv1x1Apply(nchwToSC(x->data, C, S), S, c, o);
        check("conv1x1", scToNchw(o, c.oc, S), ref, "conv1.out");
    }
    // ---------- 4. NormMask（y = x * scaleMul + beta，再乘掩码） ----------
    // 测试传入固定的 mul 数组，验证"逐通道乘性 + 加性 + 掩码"这层语义。
    {
        const RefTensor* x = ref.get("norm.x");
        const RefTensor* b = ref.get("norm.bias");
        const RefTensor* mul = ref.get("norm.mul");
        const RefTensor* mk = ref.get("norm.mask");
        int S = x->dim(0), C = x->dim(1);
        NormLayer n;
        n.c = C;
        n.bias = b->data;
        n.scaleMul = mul->data;
        std::vector<float> o;
        normMaskApply(x->data, S, C, n, mk->data, o);
        check("normMask", o, ref, "norm.out");
    }

    // ---------- 5. RMSNorm ----------
    {
        const RefTensor* x = ref.get("rmsnorm.x");
        const RefTensor* w = ref.get("rmsnorm.weight");
        const RefTensor* e = ref.get("rmsnorm.eps");
        int S = x->dim(0), C = x->dim(1);
        std::vector<float> o;
        rmsNormApply(x->data, S, C, w->data, e->data[0], o);
        check("rmsNorm", o, ref, "rmsnorm.out");
    }

    // ---------- 6. SiLU ----------
    {
        const RefTensor* x = ref.get("silu.x");
        std::vector<float> o = x->data;
        applyActivation(o, "ACTIVATION_SILU");
        check("silu", o, ref, "silu.out");
    }

    // ---------- 7. RoPE ----------
    {
        const RefTensor* q = ref.get("rope.q");
        const RefTensor* k = ref.get("rope.k");
        const RefTensor* fr = ref.get("rope.freqs");
        const RefTensor* pl = ref.get("rope.poslen");
        int S = q->dim(0), H = q->dim(1), D = q->dim(2);
        std::vector<float> qo = q->data, ko = k->data;
        ropeApply(qo, S, H, D, fr->data, (int)pl->data[0]);
        ropeApply(ko, S, H, D, fr->data, (int)pl->data[0]);
        check("rope.q", qo, ref, "rope.qout");
        check("rope.k", ko, ref, "rope.kout");
    }

    // ---------- 8. attention ----------
    {
        const RefTensor* q = ref.get("attn.q");   // (1,H,S,D)
        const RefTensor* k = ref.get("attn.k");
        const RefTensor* v = ref.get("attn.v");
        const RefTensor* mk = ref.get("attn.mask");
        int H = q->dim(1), S = q->dim(2), D = q->dim(3), V = v->dim(3);
        // (1,H,S,D) -> (S,H,D)
        std::vector<float> qs((size_t)S * H * D), ks((size_t)S * H * D), vs((size_t)S * H * V);
        for (int h = 0; h < H; ++h) {
            for (int s = 0; s < S; ++s) {
                for (int d = 0; d < D; ++d) {
                    qs[((size_t)s * H + h) * D + d] = q->data[((size_t)h * S + s) * D + d];
                    ks[((size_t)s * H + h) * D + d] = k->data[((size_t)h * S + s) * D + d];
                }
                for (int d = 0; d < V; ++d)
                    vs[((size_t)s * H + h) * V + d] = v->data[((size_t)h * S + s) * V + d];
            }
        }
        std::vector<float> o;
        attentionApply(qs, ks, vs, S, H, D, V, mk->data, o);
        // (S,H,V) -> (1,H,S,V)
        std::vector<float> on((size_t)H * S * V);
        for (int h = 0; h < H; ++h)
            for (int s = 0; s < S; ++s)
                for (int d = 0; d < V; ++d)
                    on[((size_t)h * S + s) * V + d] = o[((size_t)s * H + h) * V + d];
        check("attention", on, ref, "attn.out");
    }

    // ---------- 9. gpool ----------
    {
        const RefTensor* x = ref.get("gpool.x");     // (S,C)
        const RefTensor* mk = ref.get("gpool.mask"); // (S,)
        int S = x->dim(0), C = x->dim(1);
        float ms = 0.0f;
        for (int i = 0; i < S; ++i) ms += mk->data[i];
        // 转成 (C,S) 行优先，便于和 PyTorch 的 NCHW 语义对齐
        std::vector<float> xCS((size_t)C * S);
        for (int s = 0; s < S; ++s)
            for (int c = 0; c < C; ++c) xCS[(size_t)c * S + s] = x->data[(size_t)s * C + c];
        std::vector<float> o;
        gpoolApply(x->data, S, C, mk->data, ms, o);
        std::printf("  [gpool debug] S=%d C=%d maskSum=%.4f\n", S, C, ms);
        std::printf("    mask      :");
        for (int i = 0; i < S; ++i) std::printf(" %+.3f", mk->data[i]);
        std::printf("\n    x(s,c) ch0:");
        for (int s = 0; s < S; ++s) std::printf(" %+.4f", x->data[(size_t)s * C + 0]);
        std::printf("\n    xCS ch0   :");
        for (int s = 0; s < S; ++s) std::printf(" %+.4f", xCS[(size_t)0 * S + s]);
        std::printf("\n");
        check("gpool", o, ref, "gpool.out", 1e-4, true);
    }

    // ---------- 10. SwiGLU ----------
    {
        const RefTensor* x = ref.get("swiglu.x");
        const RefTensor* W1 = ref.get("swiglu.W1");
        const RefTensor* Wg = ref.get("swiglu.Wg");
        const RefTensor* W2 = ref.get("swiglu.W2");
        int S = x->dim(0), IC = x->dim(1);
        std::vector<float> h1, h2;
        linearApply(x->data, S, IC, W1->dim(0), W1->data, nullptr, h1);
        linearApply(x->data, S, IC, Wg->dim(0), Wg->data, nullptr, h2);
        siluInPlace(h1.data(), h1.size());
        for (size_t i = 0; i < h1.size(); ++i) h1[i] *= h2[i];
        std::vector<float> o;
        linearApply(h1, S, W2->dim(1), W2->dim(0), W2->data, nullptr, o);
        check("swiglu", o, ref, "swiglu.out");
    }

    std::printf("\n%s (%d failure(s))\n", g_fail == 0 ? "ALL PASS" : "FAILED", g_fail);
    return g_fail == 0 ? 0 : 1;
}
