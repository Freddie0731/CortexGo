// ============================================================================
//  probe_encode.cpp -- 把「编码 -> 网络输出」这条链摊开来看的诊断工具
//
//  为什么需要它：引擎只报一个胜率，看不出问题出在编码、权重还是解读。
//  这个程序直接打印：
//    * 价值头三通道原始 logits（win / loss / noresult）
//    * softmax 后的胜率
//    * 策略头 softmax 的 top-N、四个星位的概率、以及 8 对称平均后的对称性偏差
//    * 关键中间张量的幅值（trunk tip / value gpool / value linear2），
//      用来看价值头的输入是不是被放大了
//
//  用法：
//    probe_encode <weights.bin.gz> [--empty]
//                                 [--gl9 0|1]       覆盖全局特征 9（计分规则位）
//                                 [--gl-zero]       把 19 个全局特征全清零
//                                 [--moves-file F]  F 里是空格/换行分隔的着法（-1 或 361 = pass）
//                                 [--stride K]      每 K 手采样一次（默认 1）
//                                 [--max-moves N]
//
//  说明：--gl9 是给「官方 area scoring 时该位应为 0，而 encode.h 置 1」这个疑点
//  准备的开关，用来量化这一位到底影响多少。
// ============================================================================
#include "../infer/model_load.h"
#include "../infer/forward.h"
#include "../infer/encode.h"
#include "../infer/board.h"
#include "../infer/ops.h"

#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <string>
#include <vector>

using namespace kg;

static const int N = 19;
static const int S = N * N;

static std::string coordOf(int loc) {
    if (loc == Board::PASS || loc < 0) return "pass";
    char c[8];
    // 与本引擎一致的打印习惯：列字母 A..T（跳过 I）+ 行号 19..1
    static const char* L = "ABCDEFGHJKLMNOPQRST";
    std::snprintf(c, sizeof(c), "%c%d", L[loc % N], N - loc / N);
    return std::string(c);
}

static float maxAbs(const std::vector<float>& v) {
    float m = 0.0f;
    for (size_t i = 0; i < v.size(); ++i) {
        float a = std::fabs(v[i]);
        if (a > m) m = a;
    }
    return m;
}

static void softmaxPolicy(const std::vector<float>& logits, int ch, std::vector<float>& p) {
    // logits 布局：(numPolicyOut, S+1)
    const int n = S + 1;
    p.assign((size_t)n, 0.0f);
    float mx = -1e30f;
    for (int i = 0; i < n; ++i) {
        float v = logits[(size_t)ch * n + i];
        if (v > mx) mx = v;
    }
    double sum = 0.0;
    for (int i = 0; i < n; ++i) {
        double e = std::exp((double)logits[(size_t)ch * n + i] - mx);
        p[(size_t)i] = (float)e;
        sum += e;
    }
    if (sum > 0.0) for (int i = 0; i < n; ++i) p[(size_t)i] = (float)(p[(size_t)i] / sum);
}

struct Case {
    std::string label;
    Board board;
    std::vector<Move> history;
    Color toMove;
};

static void report(const Forward& fwd, const Model& M, const Rules& rules,
                   const Case& cs, const ForwardResult& r, bool patchGl9, bool glZero) {
    const int n = S + 1;
    (void)M;
    std::printf("  [%s] to_move=%s hist=%d  value=(%.3f, %.3f, %.3f)  winrate=%+.4f\n",
                cs.label.c_str(), cs.toMove == BLACK ? "B" : "W",
                (int)cs.history.size(), r.value[0], r.value[1], r.value[2], r.winrate());
    std::printf("        |trunk tip|=%.2f  |v.gpool|=%.2f  |v.linear2|=%.2f  |policy logit|max=%.2f\n",
                maxAbs(fwd.debugTensors.count("act_trunkfinal")
                           ? fwd.debugTensors.at("act_trunkfinal") : std::vector<float>()),
                maxAbs(fwd.debugTensors.count("value_head.gpool")
                           ? fwd.debugTensors.at("value_head.gpool") : std::vector<float>()),
                maxAbs(fwd.debugTensors.count("value_head.linear2")
                           ? fwd.debugTensors.at("value_head.linear2") : std::vector<float>()),
                [&]() {
                    float m = 0.0f;
                    for (int i = 0; i < n; ++i) {
                        float a = std::fabs(r.policy[(size_t)i]);
                        if (a > m) m = a;
                    }
                    return m;
                }());
    // misc 头（6 通道）：官方语义是 scoremean / scorestdev / lead / vtime / …，
    // 全部白方视角，并各带一个固定缩放系数（权重文件里的 scoreMeanMultiplier 等）。
    // 这里只打印原始值，用来判断分数信息到底落在哪个头里。
    if (!r.misc.empty()) {
        std::printf("        misc =");
        for (size_t i = 0; i < r.misc.size() && i < 6; ++i)
            std::printf(" %.3f", r.misc[i]);
        std::printf("   (raw; 官方 x20 之类缩放后是白方视角的目数/目差)\n");
    }
    // ownership：逐点期望归属（+1 = 黑方领地，-1 = 白方领地）。官方也是**白方视角**？
    // 还是行棋方视角？直接给和，和真实目差对照即可判断，同时判断这个头到底学没学到东西。
    if (!r.ownership.empty()) {
        double sum = 0.0, sumAbs = 0.0;
        for (size_t i = 0; i < r.ownership.size(); ++i) {
            sum += r.ownership[i];
            sumAbs += std::fabs(r.ownership[i]);
        }
        std::printf("        ownership: sum=%+.1f  meanAbs=%.3f  (sum 若≈真实目差则这个头可用)\n",
                    sum, sumAbs / (double)r.ownership.size());
    }

    std::vector<float> p;
    softmaxPolicy(r.policy, 0, p);

    std::vector<std::pair<float, int> > top;
    for (int i = 0; i < S; ++i) top.push_back(std::make_pair(p[(size_t)i], i));
    std::sort(top.begin(), top.end(),
              [](const std::pair<float, int>& a, const std::pair<float, int>& b) {
                  return a.first > b.first;
              });
    std::printf("        policy top: ");
    for (int k = 0; k < 6 && k < (int)top.size(); ++k)
        std::printf("%s %.3f  ", coordOf(top[k].second).c_str(), top[k].first);
    std::printf("| pass %.4f\n", p[(size_t)S]);

    // 四个星位（D4 / Q4 / D16 / Q16）概率：空盘上若网络正常，这四个点应当
    // 大致相等（8 对称平均后尤其如此）。它们不相等就说明输入或权重有问题。
    const int stars[4] = {3 * N + 3, 15 * N + 15, 15 * N + 3, 3 * N + 15};
    std::printf("        star pts  D4=%.4f Q16=%.4f D16=%.4f Q4=%.4f  (sum=%.4f)\n",
                p[(size_t)stars[0]], p[(size_t)stars[1]],
                p[(size_t)stars[2]], p[(size_t)stars[3]],
                p[(size_t)stars[0]] + p[(size_t)stars[1]] +
                p[(size_t)stars[2]] + p[(size_t)stars[3]]);
    (void)rules; (void)patchGl9; (void)glZero;
}

int main(int argc, char** argv) {
    if (argc < 2) {
        std::printf("usage: probe_encode <weights.bin.gz> [--empty] [--gl9 0|1] [--gl-zero]\n");
        std::printf("                    [--moves-file F] [--stride K] [--max-moves N]\n");
        return 2;
    }
    std::string wpath = argv[1];
    bool doEmpty = false, glZero = false, doTranspose = false, doLopsided = false,
         doSwap = false;
    int gl9 = -1;
    int forceToMove = 0;          // 0 = 自然, 1 = 黑, 2 = 白
    std::string movesFile;
    int stride = 1, maxMoves = 100000;
    for (int i = 2; i < argc; ++i) {
        std::string a = argv[i];
        if (a == "--empty") doEmpty = true;
        else if (a == "--gl-zero") glZero = true;
        else if (a == "--transpose") doTranspose = true;
        else if (a == "--lopsided") doLopsided = true;
        else if (a == "--swap") doSwap = true;
        else if (a == "--gl9" && i + 1 < argc) gl9 = std::atoi(argv[++i]);
        else if (a == "--moves-file" && i + 1 < argc) movesFile = argv[++i];
        else if (a == "--stride" && i + 1 < argc) stride = std::atoi(argv[++i]);
        else if (a == "--max-moves" && i + 1 < argc) maxMoves = std::atoi(argv[++i]);
        else if (a == "--force-tomove" && i + 1 < argc) {
            std::string c = argv[++i];
            if (c == "b" || c == "B") forceToMove = 1;
            else if (c == "w" || c == "W") forceToMove = 2;
        }
    }
    if (stride < 1) stride = 1;

    Model M;
    std::string err;
    std::printf("loading %s ...\n", wpath.c_str());
    auto t0 = std::chrono::steady_clock::now();
    if (!loadModelFromFile(wpath, M, &err)) {
        std::printf("FAIL load: %s\n", err.c_str());
        return 1;
    }
    std::printf("  loaded in %.1f s   in_ch=%d globals=%d blocks=%d ch=%d\n",
                std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count(),
                M.numInputChannels, M.numInputGlobalChannels,
                (int)M.trunk.blocks.size(), M.trunk.trunkNumChannels);
    Forward fwd(M, N);
    fwd.debug = true;   // 抓中间张量用来看幅值

    Rules rules;
    rules.komi = 7.5f;
    rules.areaScoring = true;
    rules.positionalKo = true;
    rules.multiStoneSuicideLegal = true;

    std::vector<int> moves;
    if (!movesFile.empty()) {
        std::ifstream f(movesFile.c_str());
        if (!f) { std::printf("FAIL open moves file %s\n", movesFile.c_str()); return 1; }
        int v;
        while (f >> v) {
            if (v == 361) v = -1;
            // npz 里的着法若是 "x*19+y" 约定（Python 训练脚本），而 kg::Board 用
            // "y*19+x"，两者互为转置。19x19 是方阵，转置后的棋谱看起来仍然合法，
            // 只有偶尔撞上非法着法才会暴露——这正是本项目文档里"坐标约定未验证"那条。
            if (doTranspose && v >= 0 && v < S) {
                // npz 约定是 "x*N + y"：x = v / N, y = v % N
                int x = v / N, y = v % N;
                v = y * N + x;   // kg::Board 约定是 "y*N + x"
            }
            moves.push_back(v);
        }
        std::printf("  moves file: %d moves%s\n", (int)moves.size(),
                    doTranspose ? "  (transposed)" : "");
    }

    auto runOne = [&](const std::string& label, const Board& b,
                      const std::vector<Move>& hist, Color tomove) {
        EncodedInput in;
        encodeV7(b, hist, tomove, rules, in);
        if (glZero) for (size_t i = 0; i < in.global.size(); ++i) in.global[i] = 0.0f;
        if (gl9 >= 0) in.global[9] = (float)gl9;
        ForwardResult r;
        fwd.debugTensors.clear();
        fwd.debugKeys.clear();
        fwd.run(in.spatial, in.global, std::vector<float>(), r);
        Case cs;
        cs.label = label;
        cs.board = b;
        cs.history = hist;
        cs.toMove = tomove;
        report(fwd, M, rules, cs, r, gl9 >= 0, glZero);
    };

    if (doEmpty || moves.empty()) {
        Board b;
        b.reset(N);
        std::vector<Move> hist;
        runOne("empty-as-is", b, hist, BLACK);
        if (gl9 >= 0) {
            std::printf("  (global[9] was forced to %d)\n", gl9);
        }
    }

    // --lopsided：人为构造一边倒局面（黑占上面 9 行、白占下面 5 行）。
    // 用来判定价值头到底是"行棋方视角"还是"白方视角"：
    //   行棋方视角 -> 黑先时 value 为正（黑赢）、白先时为负；
    //   白方视角   -> 两种轮次都应为负（白输）。
    if (doLopsided) {
        Board b;
        b.reset(N);
        std::vector<Move> hist;
        // --swap：把大块给白方，用来区分「白方视角」与「行棋方恒输」两种假设。
        //   黑大块 + 黑先 -> 两者都预测负值，无法区分；
        //   白大块 + 白先 -> 白方视角预测正值，行棋方恒输预测负值。
        Color bigC = doSwap ? WHITE : BLACK;
        Color smallC = doSwap ? BLACK : WHITE;
        for (int y = 0; y < 9; ++y)
            for (int x = 0; x < N; ++x) b.colors[(size_t)(y * N + x)] = bigC;
        for (int y = 14; y < N; ++y)
            for (int x = 0; x < N; ++x) b.colors[(size_t)(y * N + x)] = smallC;
        std::printf("  (lopsided: big block=%d stones (%s), small block=%d stones (%s), "
                    "big side leads about %d points)\n",
                    9 * N, bigC == BLACK ? "black" : "white",
                    5 * N, smallC == BLACK ? "black" : "white", 4 * N);
        runOne("lopsided-black-to-move", b, hist, BLACK);
        runOne("lopsided-white-to-move", b, hist, WHITE);
    }

    if (!moves.empty()) {
        Board b;
        b.reset(N);
        std::vector<Move> hist;
        Color tm = BLACK;
        int played = 0;
        for (size_t i = 0; i < moves.size() && played < maxMoves; ++i) {
            int mv = moves[i];
            if (mv != Board::PASS && !b.isLegal(mv, tm)) {
                std::printf("  !! move %d (%s) illegal at ply %d, stopping replay\n",
                            i, coordOf(mv).c_str(), (int)hist.size());
                break;
            }
            // 先报告「轮到这个着法之前」的局面
            if ((played % stride) == 0)
                runOne("ply" + std::to_string(played), b, hist, tm);
            b.playMove(mv, tm);
            Move m;
            m.loc = mv;
            m.pla = tm;
            hist.push_back(m);
            tm = other(tm);
            ++played;
        }
        if (forceToMove == 1) tm = BLACK;
        else if (forceToMove == 2) tm = WHITE;
        runOne("ply" + std::to_string(played) + "-final", b, hist, tm);
    }

    std::printf("\ninterpretation\n");
    std::printf("  value 三通道是 logits，不是概率；比较同一个局面在不同编码下的差异才\n");
    std::printf("  有意义。空盘上 winrate 应接近 50%%（贴目 7.5 时略偏白）。\n");
    std::printf("  |v.linear2| 若达到几十量级以上，说明价值头输入被放大，问题在编码或\n");
    std::printf("  trunk 之前的整体偏移，而不在价值头本身。\n");
    return 0;
}

