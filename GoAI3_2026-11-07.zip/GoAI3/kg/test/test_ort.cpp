// ============================================================================
//  test_ort.cpp -- ORT + DirectML GPU 后端的数值验收 / 性能 / 降级行为测试
//
//  它回答三个问题：
//    1) GPU(ORT-DirectML) 的输出和原生 C++ CPU 前向是不是同一个网络？
//       -> 5 个局面逐一对拍 policy(6x362)/value(3 logits)/ownership(361)，
//          断言 policy 概率最大绝对差 < 2e-3、value logits 最大绝对差 < 0.2。
//    2) 快多少？
//       -> 同一份模型：原生 CPU 前向 vs ORT-DML 前向，各 warmup 1 次后计时
//          iters(默认 5) 次，打印 min / median。
//    3) 坏了会怎样？
//       -> --degrade-only 模式下依次试：空路径、不存在的 ONNX、release 后前向，
//          要求全部返回 false + 可读错误且进程不崩溃。
//
//  用法：
//    build_out\ort\test_ort.exe [--onnx PATH] [--weights PATH]
//                               [--iters K] [--no-native] [--no-degrade]
//                               [--hold SEC] [--degrade-only]
//
//  默认：--onnx build_out\npu\models\kata1_b11_b1.onnx
//        --weights kata1.bin.gz
//
//  注意：ONNX 必须与 kata1.bin.gz 是**同一份权重**导出的，否则两边输出不同源，
//  对比没有意义。价值头重训之后要用 tools\export_onnx.py 重新导出 ONNX。
// ============================================================================
#include "../infer/ort_backend.h"

#include "../infer/board.h"
#include "../infer/encode.h"
#include "../infer/forward.h"
#include "../infer/model_load.h"

#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <windows.h>
#include <psapi.h>
#pragma comment(lib, "psapi.lib")

#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <vector>

using namespace kg;

static const int N = 19;
static const int S = N * N;          // 361
static const int NPASS = S + 1;      // 362
static const int NPOL = 6 * NPASS;   // 2172

// ===========================================================================
//  小工具
// ===========================================================================
static std::string coordOf(int loc) {
    if (loc == Board::PASS || loc < 0) return "pass";
    static const char* L = "ABCDEFGHJKLMNOPQRST";   // 与引擎/棋盘 GUI 一致（跳过 I）
    char c[12];
    std::snprintf(c, sizeof(c), "%c%d", L[loc % N], N - loc / N);
    return std::string(c);
}

static double nowSec() {
    return (double)std::chrono::duration_cast<std::chrono::microseconds>(
               std::chrono::steady_clock::now().time_since_epoch()).count() / 1e6;
}

static double medianOf(std::vector<double> v) {
    if (v.empty()) return 0.0;
    std::sort(v.begin(), v.end());
    size_t n = v.size();
    if (n & 1) return v[n / 2];
    return 0.5 * (v[n / 2 - 1] + v[n / 2]);
}
static double minOf(std::vector<double> v) {
    if (v.empty()) return 0.0;
    return *std::min_element(v.begin(), v.end());
}

static float maxAbsDiff(const std::vector<float>& a, const std::vector<float>& b, size_t n) {
    float m = 0.0f;
    for (size_t i = 0; i < n && i < a.size() && i < b.size(); ++i) {
        float d = std::fabs(a[i] - b[i]);
        if (!(d == d)) return 1e30f;   // NaN 也要被看见
        if (d > m) m = d;
    }
    return m;
}

static void memSnapshot(const char* stage) {
    PROCESS_MEMORY_COUNTERS_EX pmc;
    std::memset(&pmc, 0, sizeof(pmc));
    pmc.cb = sizeof(pmc);
    if (GetProcessMemoryInfo(GetCurrentProcess(), (PROCESS_MEMORY_COUNTERS*)&pmc, sizeof(pmc))) {
        std::printf("[mem] %-26s working=%7.1f MB  private=%7.1f MB  peakWS=%7.1f MB\n",
                    stage,
                    (double)pmc.WorkingSetSize / (1024.0 * 1024.0),
                    (double)pmc.PrivateUsage / (1024.0 * 1024.0),
                    (double)pmc.PeakWorkingSetSize / (1024.0 * 1024.0));
        std::fflush(stdout);
    } else {
        std::printf("[mem] %-26s <GetProcessMemoryInfo failed>\n", stage);
    }
}

// policy 单通道 softmax（输入是 logits）
static void softmaxChannel(const std::vector<float>& logits, int channel, int n,
                           std::vector<float>& p) {
    p.assign((size_t)n, 0.0f);
    const size_t base = (size_t)channel * (size_t)n;
    if (logits.size() < base + (size_t)n) return;
    float mx = -1e30f;
    for (int i = 0; i < n; ++i) {
        float v = logits[base + (size_t)i];
        if (v > mx) mx = v;
    }
    double sum = 0.0;
    for (int i = 0; i < n; ++i) {
        double e = std::exp((double)logits[base + (size_t)i] - (double)mx);
        p[(size_t)i] = (float)e;
        sum += e;
    }
    if (sum > 0.0)
        for (int i = 0; i < n; ++i) p[(size_t)i] = (float)((double)p[(size_t)i] / sum);
}

// policy top-k（只在 0..S-1 的 361 个着法里选；pass 单独打印）
static std::vector<std::pair<float, int> > topPolicy(const std::vector<float>& logits, int channel,
                                                     int n, int k) {
    std::vector<float> p;
    softmaxChannel(logits, channel, n, p);
    std::vector<std::pair<float, int> > all;
    for (int i = 0; i < S; ++i) all.push_back(std::make_pair(p[(size_t)i], i));
    std::sort(all.begin(), all.end(),
              [](const std::pair<float, int>& a, const std::pair<float, int>& b) {
                  return a.first > b.first;
              });
    if ((int)all.size() > k) all.resize((size_t)k);
    return all;
}

static void printTop(const char* tag, const std::vector<std::pair<float, int> >& top,
                     float passProb) {
    std::printf("    %-8s top5:", tag);
    for (size_t i = 0; i < top.size(); ++i)
        std::printf(" %s=%.4f", coordOf(top[i].second).c_str(), top[i].first);
    std::printf("  | pass=%.4f\n", passProb);
}

// win/loss/noresult 三个 logits -> [-1,1] 胜率（当前行棋方视角），与 ForwardResult::winrate 相同
static float winrateFromLogits(const std::vector<float>& v) {
    if (v.size() < 3) return 0.0f;
    double m = std::max((double)v[0], std::max((double)v[1], (double)v[2]));
    double ew = std::exp((double)v[0] - m), el = std::exp((double)v[1] - m),
           en = std::exp((double)v[2] - m);
    double s = ew + el + en;
    if (!(s > 0.0)) return 0.0f;
    return (float)((ew - el) / s);
}

// ===========================================================================
//  测试局面（空盘 + 3 盘真实 pro 棋谱的中盘；前缀着法见下面数组）
//
//  着法数组来自 kg\build\sgf\games.7z 里的真实职业棋谱，已经用中文规则回放校验
//  过合法性（build_out\ort\pick_games.py 生成）。loc = y*19+x，与 kg::Board 一致。
//  选这些 ply 的原因：encode.h 修好后的征子特征平面 14/15/16/17 在其中非零
//  （test 会打印具体点数），所以不是"随机棋盘"，而是真实会出现的征子/对杀局面。
// ===========================================================================
static const int kGame1Moves[] = {
    73, 301, 59, 61, 308, 71, 50, 306, 288, 268, 250, 54,
    53, 72, 52, 51, 70, 32, 35, 55, 33, 92, 31, 89,
    69, 78, 79, 60, 97, 77, 40, 96, 98, 41, 58, 115,
    20, 23, 22, 3, 21, 62, 100, 154, 57, 248, 249, 267,
    211, 269, 270, 251, 271, 118, 81, 232, 212, 156, 195, 234,
};
static const int kGame2Moves[] = {
    287, 59, 319, 281, 282, 263, 301, 243, 298, 53, 110, 149,
    61, 42, 43, 41, 187, 111, 129, 130, 91, 92, 72, 73,
    52, 148, 204, 241, 202, 239, 225, 245, 259, 222, 164, 146,
    166, 147, 276, 220, 181, 308, 291, 271, 250, 306, 272, 288,
    252, 249, 230, 269, 232, 217, 237, 200, 180, 236, 256, 203,
};
static const int kGame3Moves[] = {
    287, 300, 60, 71, 308, 173, 54, 92, 52, 70, 93, 111,
    51, 69, 112, 53, 72, 34, 73, 50, 35, 32, 15, 33,
    130, 43, 97, 230, 22, 81, 317, 294, 320, 319, 301, 281,
    338, 337, 339, 318, 263, 310, 279, 262, 244, 243, 241, 316,
    336, 335, 355, 298, 297, 299, 356, 282, 283, 264, 302, 224,
};

struct CaseDef {
    const char* label;
    const int* moves;
    int moveCount;
    int prefix;      // 回放多少手后取局面
};

static const CaseDef kCases[] = {
    {"empty",        NULL,          0,  0},
    {"game1-ply30",  kGame1Moves,  60, 30},
    {"game1-ply60",  kGame1Moves,  60, 60},
    {"game2-ply55",  kGame2Moves,  60, 55},
    {"game3-ply58",  kGame3Moves,  60, 58},
};
static const int kNumCases = (int)(sizeof(kCases) / sizeof(kCases[0]));

// 回放局面前缀；失败返回 false（非法着法/越界）
static bool buildCase(const CaseDef& c, Board& b, std::vector<Move>& hist, Color& toMove,
                      std::string* why) {
    b.reset(N);
    hist.clear();
    toMove = BLACK;
    if (c.prefix > c.moveCount) {
        if (why) *why = "prefix > moveCount";
        return false;
    }
    for (int i = 0; i < c.prefix; ++i) {
        int loc = c.moves[i];
        if (loc != Board::PASS && !b.isLegal(loc, (Color)toMove)) {
            if (why) {
                char buf[128];
                std::snprintf(buf, sizeof(buf), "illegal move #%d (%s) for %s", i,
                              coordOf(loc).c_str(), toMove == BLACK ? "B" : "W");
                *why = buf;
            }
            return false;
        }
        b.playMove(loc, (Color)toMove);
        Move m;
        m.loc = loc;
        m.pla = (Color)toMove;
        hist.push_back(m);
        toMove = other((Color)toMove);
    }
    return true;
}

// 统计 encodeV7 输出里征子特征平面 14/17 的非零点数（证明局面真的含征子特征）
static void ladderFeatureCounts(const EncodedInput& in, int* p14, int* p17) {
    int a = 0, b = 0;
    for (int l = 0; l < S; ++l) {
        if (in.spatial[(size_t)14 * S + l] != 0.0f) ++a;
        if (in.spatial[(size_t)17 * S + l] != 0.0f) ++b;
    }
    *p14 = a;
    *p17 = b;
}

// ===========================================================================
//  降级行为测试
// ===========================================================================
static int g_fail = 0;   // 数值验收失败数
static int g_degFail = 0; // 降级行为失败数

static void expectFalse(const char* what, bool ok, const std::string& err) {
    bool pass = (!ok) && !err.empty();
    if (!pass) ++g_degFail;
    std::printf("  [%s] %-34s -> ok=%d  err=\"%s\"\n", pass ? "PASS" : "FAIL", what, (int)ok,
                err.c_str());
}

static int runDegradeTests() {
    std::printf("\n================ 降级行为（失败必须 false + 可读错误，且不能崩）================\n");
    std::string err;

    // 0) 先确保当前状态：如果前面没加载过就 release 一下（幂等）
    ortBackendRelease();
    std::printf("  after release: ready=%d provider=\"%s\"\n", (int)ortBackendReady(),
                ortBackendProvider().c_str());

    // 1) 空路径
    err.clear();
    {
        bool ok = ortBackendLoad("", &err);
        expectFalse("empty onnx path", ok, err);
    }

    // 2) 不存在的 ONNX
    err.clear();
    {
        bool ok = ortBackendLoad("build_out\\ort\\__definitely_missing__.onnx", &err);
        expectFalse("missing onnx file", ok, err);
    }

    // 3) 未就绪时的前向：必须 false，不能崩，输出必须被清空
    {
        std::vector<float> sp(22 * 361, 0.0f), gl(19, 0.0f);
        std::vector<float> pol(1, 1.0f), val(1, 2.0f), own(1, 3.0f);
        bool ok = ortBackendForward(sp, gl, pol, val, own);
        bool cleaned = pol.empty() && val.empty() && own.empty();
        std::printf("  [%s] %-34s -> ok=%d cleaned=%d err=\"%s\"\n",
                    (!ok && cleaned) ? "PASS" : "FAIL", "forward while not loaded", (int)ok,
                    (int)cleaned, ortBackendError().c_str());
        if (ok || !cleaned) ++g_degFail;
    }

    // 4) 尺寸错误的输入（已就绪时才会走到；这里只验证未就绪也不能崩，已覆盖）
    std::printf("  降级行为失败数: %d\n", g_degFail);
    return g_degFail;
}

// ===========================================================================
//  main
// ===========================================================================
int main(int argc, char** argv) {
    std::string onnxPath = "build_out\\npu\\models\\kata1_b11_b1.onnx";
    std::string weightPath = "kata1.bin.gz";
    int iters = 5;
    bool noNative = false, noDegrade = false, degradeOnly = false;
    double holdSec = 0.0;

    for (int i = 1; i < argc; ++i) {
        std::string a = argv[i];
        if (a == "--onnx" && i + 1 < argc) onnxPath = argv[++i];
        else if (a == "--weights" && i + 1 < argc) weightPath = argv[++i];
        else if (a == "--iters" && i + 1 < argc) iters = std::atoi(argv[++i]);
        else if (a == "--no-native") noNative = true;
        else if (a == "--no-degrade") noDegrade = true;
        else if (a == "--degrade-only") degradeOnly = true;
        else if (a == "--hold" && i + 1 < argc) holdSec = std::atof(argv[++i]);
        else {
            std::printf("unknown arg: %s\n", a.c_str());
            return 2;
        }
    }
    if (iters < 1) iters = 1;

    std::printf("================ GoAI3 ORT/DirectML backend acceptance test ================\n");
    std::printf("onnx    : %s\n", onnxPath.c_str());
    std::printf("weights : %s\n", weightPath.c_str());
    std::printf("iters   : %d (warmup 1)\n", iters);
    std::printf("native  : %s\n", noNative ? "SKIPPED" : "enabled");
    std::fflush(stdout);

    if (degradeOnly) {
        int rc = runDegradeTests();
        std::printf("\nRESULT: degrade-only %s (failures=%d)\n", rc ? "FAILED" : "PASSED", rc);
        return rc ? 1 : 0;
    }

    memSnapshot("process start");

    // ---- 1) 原生 CPU 参照：加载 kata1.bin.gz ----
    Model model;
    Forward* fwd = NULL;
    bool nativeOk = false;
    if (!noNative) {
        std::string why;
        double t0 = nowSec();
        std::printf("\n[1] loading native weights %s ...\n", weightPath.c_str());
        std::fflush(stdout);
        if (!loadModelFromFile(weightPath, model, &why)) {
            std::printf("    FAILED to load native weights: %s\n", why.c_str());
            std::printf("    (native side will be skipped; GPU-only smoke test continues)\n");
        } else {
            nativeOk = true;
            fwd = new Forward(model, N);
            std::printf("    loaded in %.2f s  in_ch=%d globals=%d blocks=%d ch=%d policyOut=%s\n",
                        nowSec() - t0, model.numInputChannels, model.numInputGlobalChannels,
                        (int)model.trunk.blocks.size(), model.trunk.trunkNumChannels,
                        "2 (file)");
        }
        memSnapshot(nativeOk ? "after native load" : "native load failed");
    }

    // ---- 2) ORT 后端：LoadLibrary + session（DML 编译整张图）----
    std::printf("\n[2] ortBackendLoad(%s) ...\n", onnxPath.c_str());
    std::fflush(stdout);
    std::string ortErr;
    double tLoad0 = nowSec();
    bool ortOk = ortBackendLoad(onnxPath, &ortErr);
    double tLoad = nowSec() - tLoad0;
    if (!ortOk) {
        std::printf("    FAILED: %s\n", ortErr.c_str());
        std::printf("    -> engine must fall back to the native CPU path (go_ai.cpp checks the return value).\n");
        if (fwd) delete fwd;
        if (!noDegrade) {
            int rc = runDegradeTests();
            (void)rc;
        }
        std::printf("\nRESULT: FAILED (ORT backend could not load)\n");
        return 1;
    }
    std::printf("    OK in %.2f s  provider=%s  ort=%s\n", tLoad, ortBackendProvider().c_str(),
                ortBackendOrtVersion().c_str());
    std::printf("    dll=%s\n", ortBackendDllPath().c_str());
    memSnapshot("after ORT session");
    std::fflush(stdout);

    // 外部采样显存用（--hold N：在 ORT session 建好后停 N 秒）
    if (holdSec > 0.0) {
        std::printf("    [hold] sleeping %.1f s for external GPU-memory sampling...\n", holdSec);
        std::fflush(stdout);
        Sleep((DWORD)(holdSec * 1000.0));
    }

    // ---- 3) 逐个局面：编码 -> 两侧前向 -> 数值对比 + 计时 ----
    std::printf("\n[3] numeric acceptance: native C++ CPU  vs  ORT-DirectML (same ONNX weights)\n");
    std::printf("    thresholds: policy prob max|d| < 2e-3 ; value logits max|d| < 0.2\n");
    std::printf("    note: native policy has 2 channels from kata1.bin.gz; ONNX has 6. "
                "channel0 compares to channel0, file ch1 compares to model ch5.\n\n");
    std::fflush(stdout);

    double worstPolProb = 0.0, worstVal = 0.0, worstOwn = 0.0;
    double sumNativeMed = 0.0, sumOrtMed = 0.0;
    int nativeTop1Match = 0, cmpCount = 0;
    int rc = 0;

    Rules rules;   // 与 go_ai.cpp 的 forward_katago 一致：area scoring / positional ko / 多子自杀
    rules.komi = 7.5f;
    rules.areaScoring = true;
    rules.positionalKo = true;
    rules.multiStoneSuicideLegal = true;

    std::vector<double> nativeAll, ortAll;

    for (int ci = 0; ci < kNumCases; ++ci) {
        const CaseDef& cd = kCases[ci];
        Board b;
        std::vector<Move> hist;
        Color toMove = BLACK;
        std::string why;
        if (!buildCase(cd, b, hist, toMove, &why)) {
            std::printf("[case %d] %-12s SKIP: %s\n", ci, cd.label, why.c_str());
            continue;
        }

        EncodedInput in;
        double tEnc0 = nowSec();
        encodeV7(b, hist, toMove, rules, in);
        double tEnc = nowSec() - tEnc0;
        int p14 = 0, p17 = 0;
        ladderFeatureCounts(in, &p14, &p17);

        std::printf("[case %d] %-12s to_move=%s  history=%d  encode=%.2f ms  "
                    "ladder features: plane14=%d pts, plane17=%d pts\n",
                    ci, cd.label, toMove == BLACK ? "B" : "W", (int)hist.size(), tEnc * 1000.0,
                    p14, p17);

        // ---- ORT-DML 前向 ----
        std::vector<float> oPol, oVal, oOwn;
        bool oOk = ortBackendForward(in.spatial, in.global, oPol, oVal, oOwn);
        if (!oOk) {
            std::printf("    ORT forward FAILED: %s\n", ortBackendError().c_str());
            rc = 1;
            continue;
        }
        std::vector<double> tOrt;
        for (int k = 0; k < iters; ++k) {
            double t0 = nowSec();
            std::vector<float> p2, v2, w2;
            if (!ortBackendForward(in.spatial, in.global, p2, v2, w2)) {
                std::printf("    ORT timed forward FAILED: %s\n", ortBackendError().c_str());
                rc = 1;
                break;
            }
            tOrt.push_back(nowSec() - t0);
        }
        double ortMin = minOf(tOrt), ortMed = medianOf(tOrt);
        sumOrtMed += ortMed;
        for (size_t k = 0; k < tOrt.size(); ++k) ortAll.push_back(tOrt[k]);

        // 用第一次（warmup）的 ORT 输出做数值对比
        std::vector<float> nPol, nVal, nOwn;
        double natMin = 0.0, natMed = 0.0;
        bool nOk = false;
        if (nativeOk && fwd) {
            try {
                ForwardResult r;
                fwd->run(in.spatial, in.global, std::vector<float>(), r);   // warmup
                std::vector<double> tNat;
                for (int k = 0; k < iters; ++k) {
                    ForwardResult r2;
                    double t0 = nowSec();
                    fwd->run(in.spatial, in.global, std::vector<float>(), r2);
                    tNat.push_back(nowSec() - t0);
                }
                natMin = minOf(tNat);
                natMed = medianOf(tNat);
                sumNativeMed += natMed;
                for (size_t k = 0; k < tNat.size(); ++k) nativeAll.push_back(tNat[k]);
                nPol = r.policy;
                nVal = r.value;
                nOwn = r.ownership;
                nOk = !nPol.empty() && !nVal.empty();
            } catch (const std::exception& e) {
                std::printf("    native forward threw: %s\n", e.what());
            }
        }

        if (nOk) {
            // policy: 通道 0 的 logits / 概率
            std::vector<float> nP0(nPol.begin(), nPol.begin() + NPASS);
            std::vector<float> oP0(oPol.begin(), oPol.begin() + NPASS);
            float dLogit = maxAbsDiff(nP0, oP0, NPASS);
            std::vector<float> nProb, oProb;
            softmaxChannel(nP0, 0, NPASS, nProb);
            softmaxChannel(oP0, 0, NPASS, oProb);
            float dProb = maxAbsDiff(nProb, oProb, NPASS);
            std::vector<std::pair<float, int> > nTop = topPolicy(nP0, 0, NPASS, 5);
            std::vector<std::pair<float, int> > oTop = topPolicy(oP0, 0, NPASS, 5);

            printTop("native", nTop, nProb[(size_t)S]);
            printTop("ORT-DML", oTop, oProb[(size_t)S]);

            // value: 3 个 logits
            float dVal = maxAbsDiff(nVal, oVal, 3);
            float nWr = winrateFromLogits(nVal), oWr = winrateFromLogits(oVal);

            // ownership: 361
            float dOwn = maxAbsDiff(nOwn, oOwn, (size_t)S);
            double nOwnMean = 0.0, oOwnMean = 0.0;
            for (int i = 0; i < S; ++i) {
                nOwnMean += (double)nOwn[(size_t)i];
                oOwnMean += (double)oOwn[(size_t)i];
            }
            nOwnMean /= (double)S;
            oOwnMean /= (double)S;

            // 额外诊断：native 的通道 1（文件里只存了 2 个 policy 通道）到底对应
            // ONNX 的哪个通道？引擎（kg/infer/katago_backend.h）只用通道 0，所以
            // 这里只报告、不参与断言；但把真实映射写出来，避免以后误判。
            float dCh1 = -1.0f;
            int ch1Match = -1;
            if (nPol.size() >= 2 * (size_t)NPASS && oPol.size() >= 6 * (size_t)NPASS) {
                std::vector<float> nC1(nPol.begin() + NPASS, nPol.begin() + 2 * NPASS);
                std::vector<float> oC5(oPol.begin() + 5 * NPASS, oPol.begin() + 6 * NPASS);
                dCh1 = maxAbsDiff(nC1, oC5, (size_t)NPASS);
                float best = 1e30f;
                for (int ch = 0; ch < 6; ++ch) {
                    std::vector<float> oC(oPol.begin() + (size_t)ch * NPASS,
                                          oPol.begin() + (size_t)(ch + 1) * NPASS);
                    float d = maxAbsDiff(nC1, oC, (size_t)NPASS);
                    if (d < best) {
                        best = d;
                        ch1Match = ch;
                    }
                }
            }

            bool top1Match = !nTop.empty() && !oTop.empty() && nTop[0].second == oTop[0].second;
            if (top1Match) ++nativeTop1Match;
            ++cmpCount;

            bool polPass = dProb < 2e-3f;
            bool valPass = dVal < 0.2f;
            if (!polPass || !valPass) rc = 1;

            std::printf("    native   value logits = (%.5f, %.5f, %.5f)  winrate=%+.6f\n",
                        nVal[0], nVal[1], nVal[2], nWr);
            std::printf("    ORT-DML  value logits = (%.5f, %.5f, %.5f)  winrate=%+.6f\n",
                        oVal[0], oVal[1], oVal[2], oWr);
            std::printf("    native   ownership mean=%+.6f   ORT-DML ownership mean=%+.6f\n",
                        nOwnMean, oOwnMean);
            std::printf("    DIFF policy: logits max|d|=%.3e  prob max|d|=%.3e %s   "
                        "top1=%s (native %s / ort %s)\n",
                        dLogit, dProb, polPass ? "PASS" : "FAIL(<2e-3)",
                        top1Match ? "SAME" : "DIFF",
                        coordOf(nTop.empty() ? -2 : nTop[0].second).c_str(),
                        coordOf(oTop.empty() ? -2 : oTop[0].second).c_str());
            std::printf("    DIFF value: logits max|d|=%.3e %s   winrate |d|=%.3e\n", dVal,
                        valPass ? "PASS" : "FAIL(<0.2)", std::fabs(nWr - oWr));
            std::printf("    DIFF ownership: max|d|=%.3e (info only)   ch1-vs-ch5 max|d|=%.3e (info)\n",
                        dOwn, dCh1);
            if (ch1Match >= 0)
                std::printf("    INFO native policy ch1 best-matches ONNX channel %d "
                            "(engine only uses channel 0)\n", ch1Match);
            std::printf("    TIME native min=%.1f ms median=%.1f ms | ORT-DML min=%.1f ms "
                        "median=%.1f ms | speedup(median)=%.2fx\n\n",
                        natMin * 1000.0, natMed * 1000.0, ortMin * 1000.0, ortMed * 1000.0,
                        (ortMed > 0.0) ? (natMed / ortMed) : 0.0);

            worstPolProb = std::max(worstPolProb, (double)dProb);
            worstVal = std::max(worstVal, (double)dVal);
            worstOwn = std::max(worstOwn, (double)dOwn);
        } else {
            std::printf("    (native side unavailable: printing ORT stats only)\n");
            std::printf("    TIME ORT-DML min=%.1f ms median=%.1f ms\n\n", ortMin * 1000.0,
                        ortMed * 1000.0);
        }
        std::fflush(stdout);
    }

    // ---- 4) 汇总 ----
    std::printf("================ summary ================\n");
    if (cmpCount > 0) {
        std::printf("cases compared            : %d/%d\n", cmpCount, kNumCases);
        std::printf("policy prob max|d| worst  : %.3e   (threshold 2e-3)  %s\n", worstPolProb,
                    worstPolProb < 2e-3 ? "PASS" : "FAIL");
        std::printf("value logits max|d| worst : %.3e   (threshold 0.2)   %s\n", worstVal,
                    worstVal < 0.2 ? "PASS" : "FAIL");
        std::printf("ownership max|d| worst    : %.3e   (info only)\n", worstOwn);
        std::printf("policy top-1 agreement    : %d/%d\n", nativeTop1Match, cmpCount);
    }
    if (!ortAll.empty()) {
        std::printf("ORT-DML forward  min/median: %.1f / %.1f ms  (over %d runs)\n",
                    minOf(ortAll) * 1000.0, medianOf(ortAll) * 1000.0, (int)ortAll.size());
    }
    if (!nativeAll.empty()) {
        std::printf("native CPU fwd   min/median: %.1f / %.1f ms  (over %d runs)\n",
                    minOf(nativeAll) * 1000.0, medianOf(nativeAll) * 1000.0, (int)nativeAll.size());
        if (!ortAll.empty()) {
            double natMed = medianOf(nativeAll), ortMed = medianOf(ortAll);
            std::printf("speedup (median of medians): %.2fx\n", (ortMed > 0.0) ? natMed / ortMed : 0.0);
        }
    }
    {
        long long calls = 0;
        double secs = 0.0;
        ortBackendStats(&calls, &secs);
        std::printf("ORT stats: calls=%lld  total=%.3f s  avg=%.1f ms\n", calls, secs,
                    calls > 0 ? secs * 1000.0 / (double)calls : 0.0);
    }
    std::printf("session creation time     : %.2f s (one-off; measured around ortBackendLoad)\n",
                tLoad);
    memSnapshot("before release");

    // ---- 5) 释放 + 降级行为 ----
    ortBackendRelease();
    if (fwd) {
        delete fwd;
        fwd = NULL;
    }
    memSnapshot("after release");

    if (!noDegrade) {
        int degFail = runDegradeTests();
        std::printf("\nRESULT: numeric %s, degrade %s\n", rc ? "FAILED" : "PASSED",
                    degFail ? "FAILED" : "PASSED");
        return (rc || degFail) ? 1 : 0;
    }
    std::printf("\nRESULT: numeric %s\n", rc ? "FAILED" : "PASSED");
    return rc ? 1 : 0;
}
