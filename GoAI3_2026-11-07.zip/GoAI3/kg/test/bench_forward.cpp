// ============================================================================
//  bench_forward.cpp -- 可重复的前向基准
//
//  为什么需要它：此前用手工命令 + 挂钟计时比较优化效果，结论完全不可信
//  （同一份代码在不同时间测出 2.5 秒和 17 秒，相差 7 倍）。原因通常是
//  连续长搜索导致 CPU 降频，而挂钟把降频、冷启动、后台负载全混在一起。
//
//  这个基准的做法：
//    * 同一个进程内跑 N 次前向，跑之前先预热若干次并丢弃
//    * 输入局面固定（三手棋，确定性），所以每次测的都是同一件事
//    * 报最小值 / 中位数 / 最大值，而不只是平均值 —— 降频会让最大值和
//      后半段均值明显变大，这本身就是判断依据
//    * 把前半段和后半段的均值分开报，专门用来发现降频趋势
//    * 模型加载时间单独报，且不计入基准
//
//  用法：
//    bench_forward <权重.bin.gz> [--iters N] [--warmup N] [--threads N]
//                                  [--profile] [--ops]
//
//    --profile  逐块打印耗时（哪个块慢一目了然）
//    --ops      额外微基准：单独测 linearApply / attention 的吞吐
//
//  可比的输出行（每次运行都打印，直接对比这一行）：
//    RESULT iters=... threads=... median=...s min=...s max=...s pos_per_sec=...
//
//  注意：跑之前先确认没有别的 GoAI3 进程在占 CPU（任务管理器看一眼），
//  否则测的是别人的负载。
// ============================================================================
#include "../infer/model_load.h"
#include "../infer/forward.h"
#include "../infer/board.h"
#include "../infer/encode.h"
#include "../infer/ops.h"

#include <algorithm>
#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <vector>

using namespace kg;

// 本模型（b11c768, 11 个嵌套瓶颈块）一次前向的乘法累加量，手数而来：
//   initial conv 3x3 22->768        361 * 22*9 * 768
//   11 x [ p 768->384 + q 384->768 ]
//   11 x 3 x [ 4 个 384->384 投影 + 注意力 361^2*12*64 ]
//   11 x 3 x [ 384->1152 + 384->1152 + 1152->384 ]
//   策略头 / 价值头各若干
// 约 49.2 GMAC。报告里的 GFLOPS 由它换算，只作量级参考。
static const double kEstGigaMAC = 49.2;

static double nowSec() {
    return std::chrono::duration<double>(
        std::chrono::steady_clock::now().time_since_epoch()).count();
}

static double medianOf(std::vector<double> v) {
    if (v.empty()) return 0.0;
    std::sort(v.begin(), v.end());
    size_t n = v.size();
    return (n & 1) ? v[n / 2] : 0.5 * (v[n / 2 - 1] + v[n / 2]);
}

static double meanOf(const std::vector<double>& v) {
    if (v.empty()) return 0.0;
    double s = 0.0;
    for (size_t i = 0; i < v.size(); ++i) s += v[i];
    return s / (double)v.size();
}

int main(int argc, char** argv) {
    std::setvbuf(stdout, NULL, _IONBF, 0);
    if (argc < 2) {
        std::printf("usage: bench_forward <weights.bin.gz> [--iters N] [--warmup N]\n"
                    "                     [--threads N] [--profile] [--ops]\n");
        return 2;
    }
    const std::string wpath = argv[1];
    int iters = 10, warmup = 2, threads = 0;
    bool doProfile = false, doOps = false;
    for (int i = 2; i < argc; ++i) {
        if (!std::strcmp(argv[i], "--iters") && i + 1 < argc) iters = std::atoi(argv[++i]);
        else if (!std::strcmp(argv[i], "--warmup") && i + 1 < argc) warmup = std::atoi(argv[++i]);
        else if (!std::strcmp(argv[i], "--threads") && i + 1 < argc) threads = std::atoi(argv[++i]);
        else if (!std::strcmp(argv[i], "--profile")) doProfile = true;
        else if (!std::strcmp(argv[i], "--ops")) doOps = true;
    }
    if (threads > 0) threadCount() = threads;
    if (iters < 1) iters = 1;
    if (warmup < 0) warmup = 0;

    std::printf("================================================================\n");
    std::printf(" bench_forward -- 可重复前向基准\n");
    std::printf("================================================================\n");
    std::printf(" weights   : %s\n", wpath.c_str());
    std::printf(" threads   : %d  (effectiveThreads=%d)\n", threads, effectiveThreads());
    std::printf(" warmup    : %d      iters: %d\n", warmup, iters);
    std::printf("----------------------------------------------------------------\n");

    // ---- 加载（不计入基准）----
    double t0 = nowSec();
    Model M;
    std::string err;
    if (!loadModelFromFile(wpath, M, &err)) {
        std::printf(" [FAIL] load: %s\n", err.c_str());
        return 1;
    }
    const double loadSec = nowSec() - t0;
    std::printf(" model load : %.2f s   (blocks=%zu, ch=%d, %.2fM params)\n",
                loadSec, M.trunk.blocks.size(), M.trunk.trunkNumChannels,
                (double)M.numFloats / 1e6);

    // ---- 固定输入 ----
    Board b; b.reset(19);
    std::vector<Move> hist;
    {
        // 三手确定性开局，保证输入不随机：D4 / Q16 / Q4
        int mv[3] = { 3 * 19 + 3, 15 * 19 + 15, 15 * 19 + 3 };
        Color pl[3] = { BLACK, WHITE, BLACK };
        for (int i = 0; i < 3; ++i) {
            if (!b.isLegal(mv[i], pl[i])) { std::printf(" setup move %d illegal\n", i); return 1; }
            b.playMove(mv[i], pl[i]);
            Move m; m.loc = mv[i]; m.pla = pl[i];
            hist.push_back(m);
        }
    }
    Rules rules;
    EncodedInput in;
    encodeV7(b, hist, WHITE, rules, in);
    std::printf(" input      : 3 手固定局面，spatial=%zu global=%zu\n",
                in.spatial.size(), in.global.size());

    Forward fw(M, 19);
    ForwardResult r;

    // ---- 预热 ----
    if (warmup > 0) {
        std::printf(" warmup     : ");
        for (int i = 0; i < warmup; ++i) {
            fw.run(in.spatial, in.global, std::vector<float>(), r);
            std::printf(".");
        }
        std::printf(" done\n");
    }

    // ---- 正式计时 ----
    if (doProfile) fw.profile = true;
    std::printf("----------------------------------------------------------------\n");
    if (doProfile) std::printf(" (逐块耗时见下方，其余输出走 stderr)\n");

    std::vector<double> t(iters, 0.0);
    for (int i = 0; i < iters; ++i) {
        double a = nowSec();
        fw.run(in.spatial, in.global, std::vector<float>(), r);
        t[i] = nowSec() - a;
    }
    fw.profile = false;

    // ---- 统计 ----
    std::vector<double> sorted = t;
    std::sort(sorted.begin(), sorted.end());
    const double mn = sorted.front();
    const double mx = sorted.back();
    const double med = medianOf(t);
    const double mean = meanOf(t);
    const size_t half = t.size() / 2;
    std::vector<double> firstHalf(t.begin(), t.begin() + half);
    std::vector<double> secondHalf(t.begin() + half, t.end());
    const double m1 = meanOf(firstHalf);
    const double m2 = meanOf(secondHalf);

    std::printf(" per-forward (秒):\n");
    std::printf("   min      %.4f\n", mn);
    std::printf("   median   %.4f\n", med);
    std::printf("   mean     %.4f\n", mean);
    std::printf("   max      %.4f\n", mx);
    std::printf(" 前半均值   %.4f      后半均值 %.4f\n", m1, m2);
    if (m1 > 0.0 && m2 / m1 > 1.15) {
        std::printf(" !! 后半段比前半段慢 %.0f%% —— 典型的降频/后台负载迹象，\n",
                    (m2 / m1 - 1.0) * 100.0);
        std::printf("    这次测量不可比，请等机器冷却后重跑。\n");
    } else if (m1 > 0.0) {
        std::printf(" 前后半段差异 %.0f%% —— 测量稳定。\n", (m2 / m1 - 1.0) * 100.0);
    }
    std::printf("----------------------------------------------------------------\n");
    std::printf(" RESULT iters=%d threads=%d median=%.4fs min=%.4fs max=%.4fs "
                "pos_per_sec=%.3f est_GFLOPS=%.1f\n",
                iters, effectiveThreads(), med, mn, mx,
                (med > 0 ? 1.0 / med : 0.0),
                (med > 0 ? 2.0 * kEstGigaMAC / med : 0.0));
    std::printf("----------------------------------------------------------------\n");

    // ---- 单元微基准 ----
    if (doOps) {
        std::printf(" 单元微基准 (每个跑 5 次取最快):\n");
        const Block& b0 = M.trunk.blocks[0];
        const TfAttentionBlock& a = b0.stack[0].attn;
        const int S = 361;

        struct Case { const char* name; int ic, oc; const std::vector<float>* w; };
        Case cases[4];
        int nc = 0;
        cases[nc].name = "q_proj 384->384";   cases[nc].ic = a.qProj.ic;   cases[nc].oc = a.qProj.oc;   cases[nc].w = &a.qProj.w;   ++nc;
        cases[nc].name = "out_proj 384->384"; cases[nc].ic = a.outProj.ic; cases[nc].oc = a.outProj.oc; cases[nc].w = &a.outProj.w; ++nc;
        cases[nc].name = "ffn1 384->1152";    cases[nc].ic = b0.stack[1].ffn.linear1.ic; cases[nc].oc = b0.stack[1].ffn.linear1.oc; cases[nc].w = &b0.stack[1].ffn.linear1.w; ++nc;
        cases[nc].name = "ffn2 1152->384";    cases[nc].ic = b0.stack[1].ffn.linear2.ic; cases[nc].oc = b0.stack[1].ffn.linear2.oc; cases[nc].w = &b0.stack[1].ffn.linear2.w; ++nc;

        for (int i = 0; i < nc; ++i) {
            std::vector<float> x((size_t)S * cases[i].ic, 0.05f), out;
            double best = 1e30;
            for (int k = 0; k < 5; ++k) {
                double s = nowSec();
                linearApply(x, S, cases[i].ic, cases[i].oc, *cases[i].w, NULL, out);
                double e = nowSec() - s;
                if (e < best) best = e;
            }
            double mac = (double)S * cases[i].ic * cases[i].oc;
            std::printf("   %-18s %7.2f ms   %.1f GFLOPS\n", cases[i].name,
                        best * 1000.0, 2.0 * mac / best / 1e9);
        }
        {
            std::vector<float> q((size_t)S * a.numHeads * a.qHeadDim, 0.01f), o;
            double best = 1e30;
            for (int k = 0; k < 3; ++k) {
                double s = nowSec();
                attentionApply(q, q, q, S, a.numHeads, a.qHeadDim, a.vHeadDim,
                               std::vector<float>(), o);
                double e = nowSec() - s;
                if (e < best) best = e;
            }
            double mac = 2.0 * (double)S * S * a.numHeads * a.qHeadDim;
            std::printf("   %-18s %7.2f ms   %.1f GFLOPS\n", "attention 12 heads",
                        best * 1000.0, 2.0 * mac / best / 1e9);
        }
        std::printf("   (单个 linear 的 GFLOPS 若远低于整体，说明瓶颈在调用编排\n");
        std::printf("    而非内核本身；若单个也很低，就是内核要改。)\n");
    }

    return 0;
}
