// 决定性测试：value 是否会随局面强弱变化？
// 如果三种强弱悬殊的局面都给出约 -0.999，说明 value head 映射错位（而不是"过度自信"）。
#include "../infer/model_load.h"
#include "../infer/forward.h"
#include "../infer/board.h"
#include "../infer/encode.h"

#include <cstdio>
#include <string>
#include <vector>

using namespace kg;

static void evalPos(Model& M, Forward& fw, const Board& b, Color toMove,
                    const std::vector<Move>& hist, const char* tag) {
    EncodedInput in;
    Rules rules;
    rules.komi = 7.5f;
    encodeV7(b, hist, toMove, rules, in);
    ForwardResult r;
    fw.run(in.spatial, in.global, std::vector<float>(), r);
    // 策略最高分
    int bi = 0;
    for (int i = 1; i <= 361; ++i)
        if (r.policy[(size_t)i] > r.policy[(size_t)bi]) bi = i;
    std::printf("%-28s toMove=%s  value=[%+8.3f %+8.3f %+8.3f]  winrate=%+.4f  "
                "policyTop=%d(%.3f) pass=%.2e\n",
                tag, toMove == BLACK ? "B" : "W",
                r.value[0], r.value[1], r.value[2], r.winrate(),
                bi, r.policy[(size_t)bi], r.policy[361]);
}

int main(int argc, char** argv) {
    std::setvbuf(stdout, NULL, _IONBF, 0);
    Model M;
    std::string err;
    if (!loadModelFromFile(argv[1], M, &err)) { std::printf("load: %s\n", err.c_str()); return 1; }
    Forward fw(M, 19);
    std::vector<Move> noHist;

    // 1) 空盘
    Board e; e.reset(19);
    evalPos(M, fw, e, BLACK, noHist, "空盘（黑先）");

    // 2) 黑占左上 1/4 盘
    Board q; q.reset(19);
    for (int y = 0; y < 9; ++y)
        for (int x = 0; x < 9; ++x) q.colors[(size_t)(y * 19 + x)] = BLACK;
    evalPos(M, fw, q, WHITE, noHist, "黑占左上1/4（白先）");

    // 3) 黑占整盘 3/4，白只剩一角
    Board t; t.reset(19);
    for (int y = 0; y < 19; ++y)
        for (int x = 0; x < 19; ++x)
            t.colors[(size_t)(y * 19 + x)] = ((x >= 15 && y >= 15) ? WHITE : BLACK);
    evalPos(M, fw, t, WHITE, noHist, "黑占3/4（白先）");

    // 4) 反向：白占整盘 3/4
    Board t2; t2.reset(19);
    for (int y = 0; y < 19; ++y)
        for (int x = 0; x < 19; ++x)
            t2.colors[(size_t)(y * 19 + x)] = ((x >= 15 && y >= 15) ? BLACK : WHITE);
    evalPos(M, fw, t2, BLACK, noHist, "白占3/4（黑先）");

    // 5) 黑有一块死棋被打吃（黑明显不利）
    Board a; a.reset(19);
    a.colors[(size_t)(9 * 19 + 9)] = BLACK;
    a.colors[(size_t)(9 * 19 + 8)] = WHITE;
    a.colors[(size_t)(8 * 19 + 9)] = WHITE;
    a.colors[(size_t)(10 * 19 + 9)] = WHITE;
    evalPos(M, fw, a, WHITE, noHist, "黑一子被打吃（白先）");

    return 0;
}
