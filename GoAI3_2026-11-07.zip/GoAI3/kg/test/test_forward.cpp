// ============================================================================
//  test_forward.cpp -- 与官方 PyTorch 参考输出做数值对齐
//
//  输入与参考都来自 _kg_ref.py 导出的 ref.bin（用官方 model_pytorch.py 跑出的
//  真实激活）。这里用 C++ 前向复算，逐项比较：
//     out.policy.0  (1,6,362)  策略 logits
//     out.policy.1  (1,3)      价值 win/loss/noresult
//     out.policy.4  (1,1,19,19) ownership
//
//  用法: test_forward <weights.bin.gz> <ref.bin>
// ============================================================================
#include "../infer/model_load.h"
#include "../infer/forward.h"
#include "../infer/refdata.h"

#include <chrono>
#include <cmath>
#include <cstdio>
#include <string>

using namespace kg;

int main(int argc, char** argv) {
    if (argc < 3) {
        std::printf("usage: test_forward <weights.bin.gz> <ref.bin>\n");
        return 2;
    }
    const std::string wpath = argv[1];
    const std::string rpath = argv[2];

    std::string err;
    Model M;
    std::printf("loading model %s ...\n", wpath.c_str());
    auto t0 = std::chrono::steady_clock::now();
    if (!loadModelFromFile(wpath, M, &err)) {
        std::printf("FAIL load model: %s\n", err.c_str());
        return 1;
    }
    auto t1 = std::chrono::steady_clock::now();
    std::printf("  model loaded in %.1f s\n",
                std::chrono::duration<double>(t1 - t0).count());

    RefData ref;
    std::printf("loading reference %s ...\n", rpath.c_str());
    if (!ref.load(rpath, &err)) {
        std::printf("FAIL load reference: %s\n", err.c_str());
        return 1;
    }
    std::printf("  %zu tensors\n", ref.count());

    const RefTensor* inSp = ref.get("input.spatial");
    const RefTensor* inGl = ref.get("input.global");
    const RefTensor* inMk = ref.get("input.mask");
    if (!inSp || !inGl) {
        std::printf("FAIL reference missing input tensors\n");
        return 1;
    }
    std::printf("  input.spatial dims:");
    for (size_t i = 0; i < inSp->dims.size(); ++i) std::printf(" %d", inSp->dims[i]);
    std::printf("   (data %zu)\n", inSp->size());
    std::printf("  input.global dims:");
    for (size_t i = 0; i < inGl->dims.size(); ++i) std::printf(" %d", inGl->dims[i]);
    std::printf("\n");

    // 参考里 input.spatial 是 NCHW (1,C,H,W)，内存即 (C,H,W) 行优先，可直接用
    Forward fw(M, 19);
    fw.debug = true;
    ForwardResult res;
    std::printf("\nrunning C++ forward ...\n");
    auto t2 = std::chrono::steady_clock::now();
    try {
        fw.run(inSp->data, inGl->data, std::vector<float>(), res);
    } catch (const std::exception& e) {
        std::printf("FAIL forward: %s\n", e.what());
        return 1;
    }
    auto t3 = std::chrono::steady_clock::now();
    double fwdSec = std::chrono::duration<double>(t3 - t2).count();
    std::printf("  forward done in %.2f s\n", fwdSec);

    // ---- 逐层定位第一处发散 ----
    // 布局注意：参考 hook 出来的张量有两种形态
    //   (1, S, C)   —— 序列布局（绝大多数中间激活，如 norm/attention/ffn）
    //   (1, C, H, W)—— NCHW（只有 norm_trunkfinal / act_trunkfinal / ownership 等）
    // 我的抓取一律是 (S, C) 行优先存储。需要按参考形状判断该转成哪种。
    // 判据：dims 为 3 且 dim2 != S 时是 (1,S,C)；dims 为 4 时是 (1,C,H,W)。
    std::printf("\n=== 逐层对齐（定位第一处发散）===\n");
    std::printf("%-46s %-14s %14s %14s  %s\n", "tensor", "layout", "maxAbsErr", "refMax",
                "verdict");
    std::printf("%s\n", std::string(108, '-').c_str());
    int firstBad = -1;
    int nChecked = 0;
    int nShown = 0;
    const int Sneeded = 19 * 19;
    for (size_t i = 0; i < fw.debugKeys.size(); ++i) {
        const std::string& k = fw.debugKeys[i];
        const RefTensor* r = ref.get(k);
        if (!r) continue;
        const std::vector<float>& mine = fw.debugTensors[k];
        if (mine.size() != r->size()) {
            std::printf("%-46s %-14s %14s %14s  SIZE %zu vs %zu\n", k.c_str(), "?", "-", "-",
                        mine.size(), r->size());
            if (firstBad < 0) firstBad = (int)i;
            ++nShown;
            continue;
        }
        const char* layout = "?";
        std::vector<float> cmp;
        const bool flat = (r->dims.size() == 1) ||
                          (r->dims.size() == 4 && r->dim(2) == 1 && r->dim(3) == 1) ||
                          (r->dims.size() == 2 && r->dim(0) == 1);
        // 4 维张量有两种来源：
        //   真正的 NCHW —— dim1 是通道数、dim2*dim3 = S 且 dim2 != 1（如 768,19,19）
        //   序列布局多出来的 1 维 —— (1, S, C) 被当成 4 维（如 value_head.conv1 是 (1,361,768)）
        // 判据：dim1 == S = 361 且 dim3 == 通道数时，其实是 (1,S,C,1)/(1,S,C)。
        const bool looksSeq4 = (r->dims.size() == 4) && (r->dim(1) == Sneeded);
        if (flat) {
            layout = "flat";
            cmp = mine;
        } else if (looksSeq4) {
            layout = "seq";
            cmp = mine;
        } else if (r->dims.size() == 4) {
            // NCHW (1,C,H,W) -> 我的 (S,C) 转成 (C,S)
            int C = r->dim(1);
            int S = (int)(r->size() / (size_t)C);
            layout = "NCHW";
            cmp.resize(r->size());
            for (int s = 0; s < S; ++s)
                for (int c = 0; c < C; ++c)
                    cmp[(size_t)c * S + s] = mine[(size_t)s * C + c];
        } else if (r->dims.size() == 3 && r->dim(2) != Sneeded) {
            // (1,S,C)：与我的 (S,C) 内存顺序相同，直接比
            layout = "SC";
            cmp = mine;
        } else {
            // (1,C,S)
            int C = r->dim(1);
            int S = (int)(r->size() / (size_t)C);
            layout = "CS";
            cmp.resize(r->size());
            for (int s = 0; s < S; ++s)
                for (int c = 0; c < C; ++c)
                    cmp[(size_t)c * S + s] = mine[(size_t)s * C + c];
        }
        double ma = 0, mr = 0;
        size_t am = 0;
        compareArrays(cmp, r->data, ma, mr, am);
        double rmax = 0;
        for (size_t j = 0; j < r->data.size(); ++j)
            rmax = std::fmax(rmax, std::fabs((double)r->data[j]));
        const char* verdict = (ma < 1e-4) ? "ok" : (ma < 1e-3 ? "near" : "DIVERGED");
        if (ma >= 1e-3 && firstBad < 0) firstBad = (int)i;
        if (nShown < 40 || (firstBad >= 0 && (int)i <= firstBad + 2)) {
            std::printf("%-46s %-14s %14.4e %14.4e  %s\n", k.c_str(), layout, ma, rmax,
                        verdict);
            ++nShown;
        }
        if (ma >= 1e-3) {
            // 打印前 8 个元素，帮助定位是"数值"还是"符号/顺序"问题
            std::printf("      ref :");
            for (size_t j = 0; j < 8 && j < r->data.size(); ++j)
                std::printf(" %+.5f", r->data[j]);
            std::printf("\n      mine:");
            for (size_t j = 0; j < 8 && j < cmp.size(); ++j)
                std::printf(" %+.5f", cmp[j]);
            std::printf("\n");
        }
        ++nChecked;
    }
    std::printf("%s\n", std::string(108, '-').c_str());
    std::printf("比对 %d 个中间张量；第一处发散索引 = %d", nChecked, firstBad);
    if (firstBad >= 0) std::printf("  ->  %s", fw.debugKeys[(size_t)firstBad].c_str());
    std::printf("\n");

    int failures = 0;
    auto report = [&](const char* label, const std::vector<float>& mine,
                      const RefTensor* r, bool needsReshape) {
        std::printf("\n--- %s ---\n", label);
        if (!r) { std::printf("  (reference tensor absent, skipped)\n"); return; }
        std::printf("  ref dims:");
        for (size_t i = 0; i < r->dims.size(); ++i) std::printf(" %d", r->dims[i]);
        std::printf("  (size %zu)   mine size %zu\n", r->size(), mine.size());
        if (!needsReshape && mine.size() != r->size()) {
            std::printf("  FAIL size mismatch\n");
            ++failures;
            return;
        }
        double ma = 0, mr = 0;
        size_t am = 0;
        if (!compareArrays(mine, r->data, ma, mr, am)) {
            std::printf("  FAIL shape mismatch\n");
            ++failures;
            return;
        }
        std::printf("  maxAbsErr = %.6e   maxRelErr = %.6e   at index %zu\n", ma, mr, am);
        std::printf("  ref[0]=%.6f mine[0]=%.6f   ref[last]=%.6f mine[last]=%.6f\n",
                    r->data[0], mine[0], r->data[r->size() - 1], mine[mine.size() - 1]);
        // 阈值：单精度多步运算，1e-3 绝对误差以内视为对齐
        if (ma < 1e-3) {
            std::printf("  OK   within 1e-3\n");
        } else if (ma < 1e-2) {
            std::printf("  WARN larger than 1e-3 (%.3e)\n", ma);
        } else {
            std::printf("  FAIL exceeds 1e-2\n");
            ++failures;
        }
    };

    report("policy (6 x 362)", res.policy, ref.get("out.policy.0"), false);
    report("value (3)", res.value, ref.get("out.policy.1"), false);

    // ownership：参考是 (1,1,19,19)，我们是 (S,)，内存顺序一致
    report("ownership (361)", res.ownership, ref.get("out.policy.4"), false);

    std::printf("\n%s (%d failure(s))\n", failures == 0 ? "ALL PASS" : "FAILED", failures);
    return failures == 0 ? 0 : 1;
}
