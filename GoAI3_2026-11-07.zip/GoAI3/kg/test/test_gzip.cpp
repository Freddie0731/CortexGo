// ============================================================================
//  test_gzip.cpp -- 验证自带的 gzip/inflate 实现
//
//  判据（全部可独立核实）：
//    1. 解压 KataGo 权重文件成功
//    2. 解压后大小 == 281905904 字节（Python gzip 已测出的真值）
//    3. 头部是 "kata1-tf3-b11c768-..." 且第二行 == "17"（模型版本）
//    4. 尾部包含 "conv_ownership"（Python 侧测出它在文件末尾附近）
// ============================================================================
#include "../infer/minigzip.h"

#include <cstdio>
#include <string>
#include <vector>

int main(int argc, char** argv) {
    if (argc < 2) {
        std::printf("usage: test_gzip <file.bin.gz>\n");
        return 2;
    }
    const std::string path = argv[1];

    std::vector<uint8_t> raw;
    std::string err;
    if (!minigzip::readFile(path, raw, &err)) {
        std::printf("FAIL readFile: %s\n", err.c_str());
        return 1;
    }
    std::printf("compressed size   : %zu bytes\n", raw.size());

    std::vector<uint8_t> out;
    err.clear();
    if (!minigzip::gzipDecompress(raw.data(), raw.size(), out, 300u * 1024u * 1024u, &err)) {
        std::printf("FAIL gzipDecompress: %s\n", err.c_str());
        return 1;
    }
    std::printf("decompressed size : %zu bytes\n", out.size());

    int failures = 0;
    const size_t kExpected = 281905904u;
    if (out.size() != kExpected) {
        std::printf("FAIL size: expected %zu, got %zu\n", kExpected, out.size());
        ++failures;
    } else {
        std::printf("OK   size matches Python gzip (%zu)\n", kExpected);
    }

    // 头部：第一行是 magic 名字
    size_t nl = 0;
    while (nl < out.size() && out[nl] != '\n') ++nl;
    std::string line1((const char*)out.data(), nl);
    std::printf("header line 1     : %s\n", line1.c_str());
    if (line1.compare(0, 9, "kata1-tf3") != 0) {
        std::printf("FAIL header line 1 does not start with kata1-tf3\n");
        ++failures;
    }
    size_t s2 = nl + 1;
    size_t nl2 = s2;
    while (nl2 < out.size() && out[nl2] != '\n') ++nl2;
    std::string line2((const char*)out.data() + s2, nl2 - s2);
    std::printf("header line 2     : %s\n", line2.c_str());
    if (line2 != "17") {
        std::printf("FAIL header line 2 expected 17 (modelVersion)\n");
        ++failures;
    }

    // 尾部附近应出现 conv_ownership（最后一个张量名）
    {
        const char* needle = "conv_ownership";
        size_t nlen = 14;
        size_t from = (out.size() > 4096) ? out.size() - 4096 : 0;
        bool found = false;
        for (size_t i = from; i + nlen <= out.size(); ++i) {
            if (std::memcmp(&out[i], needle, nlen) == 0) { found = true; break; }
        }
        std::printf("tail has conv_ownership: %s\n", found ? "yes" : "NO");
        if (!found) { std::printf("FAIL tail missing conv_ownership\n"); ++failures; }
    }

    std::printf("\n%s (%d failure(s))\n", failures == 0 ? "ALL PASS" : "FAILED", failures);
    return failures == 0 ? 0 : 1;
}
