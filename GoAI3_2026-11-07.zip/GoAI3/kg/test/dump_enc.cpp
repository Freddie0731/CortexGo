// ============================================================================
//  dump_enc.cpp -- 把 SGF 采样局面用「引擎同一个编码器」编成训练用的紧凑二进制
//
//  为什么必须用这个工具：训练/评测的输入必须和引擎推理时逐位一致，而唯一的
//  真源是 kg/infer/encode.h 的 encodeV7()。任何在 Python 里重写编码器的做法
//  都会引入"看起来对"的静默错位。所以这里只做一件事：读清单 -> 用 kg::Board
//  逐手复验合法性 -> encodeV7 -> 落盘。
//
//  用法:
//    dump_enc <manifest.txt> <out.bin> [--aux <aux.bin>] [--aux-count K]
//             [--max-pos N] [--verbose]
//             [--selfcheck-out <sc.bin> --selfcheck-count K]
//    dump_enc --describe
//
//  清单格式（tools/value_sgf_manifest.py 产出，制表符分隔，一行一局）:
//    <gid> \t <komi> \t <winner 1=B 2=W> \t <nMoves> \t <m1,m2,...> \t
//    <nSamples> \t <p1,p2,...>
//    -1 = pass；loc = y*19 + x，y 向下（与 kg::Board / SGF 行号字母一致）
//
//  out.bin 格式（小端）:
//    magic  : "KGDUMP01" (8 字节)
//    int32  nPos
//    int32  numPlanes = 22
//    int32  S = 361
//    int32  numGlobal = 19
//    然后 nPos 个定长记录（REC 字节）:
//      int32 gameIdx      清单里的行号（0 基，只数数据行）
//      int32 ply          已经落了 ply 手
//      int32 toMove       1=黑 2=白
//      int32 winner       1=黑胜 2=白胜
//      float komi
//      float finalMargin  整盘按 area scoring 从黑方看的目差（含贴目）
//      uint8 planes[993]  22 平面位图，bit = plane*361 + s，字节内 LSB 优先
//      float global[19]
//      uint8 board[361]   0/1/2，仅供交叉校验（编码是否与局面一致）
//
//  aux.bin 格式（数值对齐用，只对前 K 个局面做 C++ 前向）:
//    magic "KGAUX001" (8 字节)
//    int32 count
//    每项: int32 posIdx; float gpool[576]; float value[3]; float policy[362]
//          （policy 是策略头通道 0 的**裸 logit**，[361] 是 pass）
//
//  selfcheck（黑白互换自检）: 取前 K 个局面，额外生成"颜色互换"版本
//    （棋盘黑白互换、toMove 互换、komi 取负、历史每手 pla 互换），写成标准
//    记录格式，成对存放：偶数条=原局面，奇数条=互换局面。评估侧 value 应该
//    大致取反，用来证明视角约定没写反。
// ============================================================================
#include "../infer/board.h"
#include "../infer/encode.h"
#include "../infer/forward.h"
#include "../infer/model_load.h"

#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <vector>

using namespace kg;

static const int N = 19;
static const int S = N * N;
static const int NF = 22;
static const int NG = 19;
static const int NBITS = NF * S;                 // 7942
static const int NBYTES = (NBITS + 7) / 8;       // 993
static const int REC = 4 * 4 + 4 * 2 + NBYTES + NG * 4 + S;

static void putI32(std::vector<uint8_t>& b, int32_t v) {
    uint8_t t[4];
    std::memcpy(t, &v, 4);
    b.insert(b.end(), t, t + 4);
}
static void putF32(std::vector<uint8_t>& b, float v) {
    uint8_t t[4];
    std::memcpy(t, &v, 4);
    b.insert(b.end(), t, t + 4);
}

// 与 encodeV7 输出逐位一致的位图打包（plane 是 0/1 float）
static void packPlanes(const std::vector<float>& sp, uint8_t* out) {
    std::memset(out, 0, (size_t)NBYTES);
    for (int i = 0; i < NBITS; ++i) {
        if (sp[(size_t)i] != 0.0f) out[i >> 3] |= (uint8_t)(1u << (i & 7));
    }
}

// area scoring：盘上子 + 只被一方围住的空点；同时接触两色算单官(0)
static double areaScore(const Board& b, double komi) {
    std::vector<uint8_t> vis((size_t)S, 0);
    int black = 0, white = 0;
    for (int l = 0; l < S; ++l) {
        if (b.at(l) == BLACK) ++black;
        else if (b.at(l) == WHITE) ++white;
    }
    int nb[4];
    for (int l = 0; l < S; ++l) {
        if (b.at(l) != EMPTY || vis[l]) continue;
        int stack[S], sp = 0;
        std::vector<int> reg;
        stack[sp++] = l;
        vis[l] = 1;
        bool tb = false, tw = false;
        while (sp > 0) {
            int cur = stack[--sp];
            reg.push_back(cur);
            int n = b.neighbors(cur, nb);
            for (int i = 0; i < n; ++i) {
                int q = nb[i];
                Color cq = b.at(q);
                if (cq == EMPTY) {
                    if (!vis[q]) { vis[q] = 1; stack[sp++] = q; }
                } else if (cq == BLACK) tb = true;
                else tw = true;
            }
        }
        if (tb && !tw) black += (int)reg.size();
        else if (tw && !tb) white += (int)reg.size();
    }
    return (double)black - (double)white - komi;
}

struct Rec {
    int32_t gameIdx;
    int32_t ply;
    int32_t toMove;
    int32_t winner;
    float komi;
    float finalMargin;
    uint8_t planes[NBYTES];
    float global[NG];
    uint8_t board[S];
};

static void writeRec(FILE* f, const Rec& r) {
    std::vector<uint8_t> buf;
    buf.reserve(REC);
    putI32(buf, r.gameIdx);
    putI32(buf, r.ply);
    putI32(buf, r.toMove);
    putI32(buf, r.winner);
    putF32(buf, r.komi);
    putF32(buf, r.finalMargin);
    buf.insert(buf.end(), r.planes, r.planes + NBYTES);
    for (int i = 0; i < NG; ++i) putF32(buf, r.global[i]);
    buf.insert(buf.end(), r.board, r.board + S);
    std::fwrite(buf.data(), 1, buf.size(), f);
}

static void fillRec(Rec& r, const Board& b, const std::vector<Move>& hist,
                    Color toMove, const Rules& rules, int gameIdx, int ply,
                    int winner, float komi, double finalMargin) {
    EncodedInput in;
    encodeV7(b, hist, toMove, rules, in);
    r.gameIdx = gameIdx;
    r.ply = ply;
    r.toMove = (int32_t)toMove;
    r.winner = winner;
    r.komi = komi;
    r.finalMargin = (float)finalMargin;
    packPlanes(in.spatial, r.planes);
    for (int i = 0; i < NG; ++i) r.global[i] = in.global[(size_t)i];
    for (int i = 0; i < S; ++i) r.board[i] = (uint8_t)b.at(i);
}

// 颜色互换：棋盘颜色对调、toMove 对调、历史每手 pla 对调、ko 保持不变
static Board swapColors(const Board& b) {
    Board t = b;
    for (int i = 0; i < S; ++i) {
        if (t.colors[(size_t)i] == BLACK) t.colors[(size_t)i] = WHITE;
        else if (t.colors[(size_t)i] == WHITE) t.colors[(size_t)i] = BLACK;
    }
    return t;
}

int main(int argc, char** argv) {
    if (argc >= 2 && std::string(argv[1]) == "--describe") {
        std::printf("REC=%d  NBYTES=%d  S=%d  NBITS=%d\n", REC, NBYTES, S, NBITS);
        return 0;
    }
    if (argc < 3) {
        std::printf("usage: dump_enc <manifest.txt> <out.bin> [--aux <aux.bin>] "
                    "[--aux-count K]\n"
                    "                [--max-pos N] [--verbose]\n"
                    "                [--selfcheck-out <sc.bin>] [--selfcheck-count K]\n"
                    "                [--orient-out <orient.bin>]\n"
                    "                [--weights <bin.gz>]\n");
        return 2;
    }
    std::string manPath = argv[1], outPath = argv[2], auxPath, scPath, wPath, orientPath;
    int auxCount = 0, scCount = 0, maxPos = 100000000;
    bool verbose = false;
    for (int i = 3; i < argc; ++i) {
        std::string a = argv[i];
        if (a == "--aux" && i + 1 < argc) auxPath = argv[++i];
        else if (a == "--aux-count" && i + 1 < argc) auxCount = std::atoi(argv[++i]);
        else if (a == "--selfcheck-out" && i + 1 < argc) scPath = argv[++i];
        else if (a == "--orient-out" && i + 1 < argc) orientPath = argv[++i];
        else if (a == "--selfcheck-count" && i + 1 < argc) scCount = std::atoi(argv[++i]);
        else if (a == "--weights" && i + 1 < argc) wPath = argv[++i];
        else if (a == "--max-pos" && i + 1 < argc) maxPos = std::atoi(argv[++i]);
        else if (a == "--verbose") verbose = true;
    }

    FILE* fm = std::fopen(manPath.c_str(), "rb");
    if (!fm) { std::printf("FAIL open manifest %s\n", manPath.c_str()); return 1; }
    std::string text;
    {
        char buf[1 << 16];
        size_t n;
        while ((n = std::fread(buf, 1, sizeof(buf), fm)) > 0) text.append(buf, n);
        std::fclose(fm);
    }
    // 切行
    std::vector<std::string> lines;
    {
        size_t i = 0;
        while (i < text.size()) {
            size_t j = text.find('\n', i);
            if (j == std::string::npos) j = text.size();
            std::string ln = text.substr(i, j - i);
            if (!ln.empty() && ln[ln.size() - 1] == '\r') ln.erase(ln.size() - 1);
            if (!ln.empty() && ln[0] != '#') lines.push_back(ln);
            i = j + 1;
        }
    }
    std::printf("manifest: %d game lines\n", (int)lines.size());

    FILE* fo = std::fopen(outPath.c_str(), "wb");
    if (!fo) { std::printf("FAIL write %s\n", outPath.c_str()); return 1; }
    std::fwrite("KGDUMP01", 1, 8, fo);
    long hdrPos = std::ftell(fo);
    int32_t zero = 0, npl = NF, ss = S, ngl = NG;
    std::fwrite(&zero, 4, 1, fo);
    std::fwrite(&npl, 4, 1, fo);
    std::fwrite(&ss, 4, 1, fo);
    std::fwrite(&ngl, 4, 1, fo);

    std::vector<Rec> auxRecs;      // 需要做 C++ 前向的（前 auxCount 个）
    std::vector<Rec> scRecs;       // 自检对
    int nPos = 0;
    int gamesOk = 0, gamesBad = 0;
    long long illegalMoves = 0;
    int firstBadGame = -1;

    std::vector<Move> hist;
    for (size_t gi = 0; gi < lines.size(); ++gi) {
        if (nPos >= maxPos) break;
        const std::string& ln = lines[gi];
        // 拆 <gid>\t<komi>\t<winner>\t<nMoves>\t<moves>\t<nSamples>\t<plies>
        std::vector<std::string> f;
        {
            size_t i = 0;
            while (i <= ln.size()) {
                size_t j = ln.find('\t', i);
                if (j == std::string::npos) j = ln.size();
                f.push_back(ln.substr(i, j - i));
                if (j == ln.size()) break;
                i = j + 1;
            }
        }
        if (f.size() < 7) { std::printf("  !! bad manifest line %d\n", (int)gi); continue; }
        float komi = (float)std::atof(f[1].c_str());
        int winner = std::atoi(f[2].c_str());
        int nMoves = std::atoi(f[3].c_str());
        // moves
        std::vector<int> moves;
        moves.reserve((size_t)nMoves);
        {
            const std::string& s = f[4];
            size_t i = 0;
            while (i < s.size()) {
                size_t j = s.find(',', i);
                if (j == std::string::npos) j = s.size();
                moves.push_back(std::atoi(s.substr(i, j - i).c_str()));
                i = j + 1;
            }
        }
        std::vector<int> want;
        {
            const std::string& s = f[6];
            size_t i = 0;
            while (i < s.size()) {
                size_t j = s.find(',', i);
                if (j == std::string::npos) j = s.size();
                want.push_back(std::atoi(s.substr(i, j - i).c_str()));
                i = j + 1;
            }
        }
        if ((int)moves.size() != nMoves) {
            std::printf("  !! game %d: nMoves %d != parsed %d\n", (int)gi, nMoves,
                        (int)moves.size());
            continue;
        }
        Rules rules;
        rules.komi = komi;
        rules.areaScoring = true;
        rules.positionalKo = true;
        rules.multiStoneSuicideLegal = true;

        Board b;
        b.reset(N);
        hist.clear();
        // 先整盘复验一遍（同时算 finalMargin），任一非法 -> 整局丢弃
        bool bad = false;
        Color tm = BLACK;
        int illegalAt = -1;
        for (int i = 0; i < nMoves; ++i) {
            int mv = moves[(size_t)i];
            if (mv != Board::PASS && !b.isLegal(mv, tm)) {
                bad = true;
                illegalAt = i;
                break;
            }
            b.playMove(mv, tm);
            Move m;
            m.loc = mv;
            m.pla = tm;
            hist.push_back(m);
            tm = other(tm);
        }
        if (bad) {
            ++gamesBad;
            if (firstBadGame < 0) firstBadGame = (int)gi;
            if (verbose || gamesBad <= 10)
                std::printf("  !! game %d (%s): illegal move at ply %d -> drop\n",
                            (int)gi, f[0].c_str(), illegalAt);
            continue;
        }
        double margin = areaScore(b, (double)komi);

        // 第二遍：边落子边在想要的 ply 上编码
        Board b2;
        b2.reset(N);
        std::vector<Move> h2;
        h2.clear();
        Color tm2 = BLACK;
        size_t wi = 0;
        int played = 0;
        while (wi < want.size() && nPos < maxPos) {
            int p = want[wi];
            if (p < 0) { ++wi; continue; }
            while (played < p) {
                int mv = moves[(size_t)played];
                b2.playMove(mv, tm2);
                Move m;
                m.loc = mv;
                m.pla = tm2;
                h2.push_back(m);
                tm2 = other(tm2);
                ++played;
            }
            Rec r;
            fillRec(r, b2, h2, tm2, rules, (int)gi, played, winner, komi, margin);
            writeRec(fo, r);
            if (auxCount > 0 && (int)auxRecs.size() < auxCount) auxRecs.push_back(r);
            if (scCount > 0 && (int)scRecs.size() / 2 < scCount) {
                scRecs.push_back(r);
                // 颜色互换版本
                Board sb = swapColors(b2);
                std::vector<Move> sh;
                sh.reserve(h2.size());
                for (size_t k = 0; k < h2.size(); ++k) {
                    Move m;
                    m.loc = h2[k].loc;
                    m.pla = other(h2[k].pla);
                    sh.push_back(m);
                }
                Rules srules = rules;
                srules.komi = -komi;
                Rec rs;
                fillRec(rs, sb, sh, other(tm2), srules, (int)gi, played,
                        winner == 1 ? 2 : 1, -komi, -margin);
                scRecs.push_back(rs);
            }
            ++nPos;
            ++wi;
        }
        ++gamesOk;
        if (verbose && (gi % 200) == 0)
            std::printf("  .. game %d/%d  pos=%d\n", (int)gi, (int)lines.size(), nPos);
    }

    std::fseek(fo, hdrPos, SEEK_SET);
    int32_t npos32 = nPos;
    std::fwrite(&npos32, 4, 1, fo);
    std::fclose(fo);
    std::printf("\nwrote %s : %d positions from %d games (%d dropped, %lld illegal moves)\n",
                outPath.c_str(), nPos, gamesOk, gamesBad, illegalMoves);
    if (firstBadGame >= 0) std::printf("  first dropped game idx = %d\n", firstBadGame);
    double mb = (double)(16 + (long long)REC * nPos) / 1048576.0;
    std::printf("  expected size ~%.1f MB (REC=%d)\n", mb, REC);

    // ---- 自检对 ----
    if (!scPath.empty() && !scRecs.empty()) {
        FILE* fs = std::fopen(scPath.c_str(), "wb");
        if (!fs) { std::printf("FAIL write %s\n", scPath.c_str()); return 1; }
        std::fwrite("KGDUMP01", 1, 8, fs);
        int32_t n2 = (int32_t)(scRecs.size() / 2) * 2;
        std::fwrite(&n2, 4, 1, fs);
        std::fwrite(&npl, 4, 1, fs);
        std::fwrite(&ss, 4, 1, fs);
        std::fwrite(&ngl, 4, 1, fs);
        // 前半 = 原局面，后半 = 颜色互换局面，第 k 对由 k 关联
        for (size_t i = 0; i < (size_t)n2; ++i) {
            size_t pair = i % (size_t)(n2 / 2);
            bool swapped = (i >= (size_t)n2 / 2);
            Rec x = scRecs[pair * 2 + (swapped ? 1 : 0)];
            x.gameIdx = (int32_t)pair;
            writeRec(fs, x);
        }
        std::fclose(fs);
        std::printf("wrote %s : %d pairs (orig, swapped)\n", scPath.c_str(), n2 / 2);
    }

    // ---- aux：C++ 前向，供 PyTorch 数值对齐 ----
    if (!auxPath.empty() && !auxRecs.empty()) {
        if (wPath.empty()) {
            std::printf("!! --aux needs --weights <bin.gz>\n");
            return 1;
        }
        Model M;
        std::string err;
        std::printf("\nloading %s ...\n", wPath.c_str());
        if (!loadModelFromFile(wPath, M, &err)) {
            std::printf("FAIL load: %s\n", err.c_str());
            return 1;
        }
        Forward fwd(M, N);
        fwd.debug = true;
        FILE* fa = std::fopen(auxPath.c_str(), "wb");
        if (!fa) { std::printf("FAIL write %s\n", auxPath.c_str()); return 1; }
        std::fwrite("KGAUX001", 1, 8, fa);
        int32_t cnt = (int32_t)auxRecs.size();
        std::fwrite(&cnt, 4, 1, fa);
        for (int k = 0; k < cnt; ++k) {
            const Rec& r = auxRecs[(size_t)k];
            // 从位图还原 spatial，global 直接来自记录 —— 用的就是落盘的那份数据
            std::vector<float> sp((size_t)NF * S, 0.0f);
            for (int i = 0; i < NBITS; ++i)
                if (r.planes[i >> 3] & (uint8_t)(1u << (i & 7))) sp[(size_t)i] = 1.0f;
            std::vector<float> gl(r.global, r.global + NG);
            ForwardResult res;
            fwd.debugTensors.clear();
            fwd.debugKeys.clear();
            fwd.run(sp, gl, std::vector<float>(), res);
            std::vector<float> gpool;
            std::map<std::string, std::vector<float> >::const_iterator it =
                fwd.debugTensors.find("value_head.gpool");
            if (it != fwd.debugTensors.end()) gpool = it->second;
            gpool.resize(576, 0.0f);
            std::vector<float> val = res.value;
            val.resize(3, 0.0f);
            std::vector<float> pol((size_t)S + 1, 0.0f);
            if ((int)res.policy.size() >= (S + 1))
                for (int i = 0; i <= S; ++i) pol[(size_t)i] = res.policy[(size_t)i];
            std::vector<uint8_t> buf;
            int32_t idx = (int32_t)k;
            putI32(buf, idx);
            for (int i = 0; i < 576; ++i) putF32(buf, gpool[(size_t)i]);
            for (int i = 0; i < 3; ++i) putF32(buf, val[(size_t)i]);
            for (int i = 0; i <= S; ++i) putF32(buf, pol[(size_t)i]);
            std::fwrite(buf.data(), 1, buf.size(), fa);
            std::printf("  aux[%d] ply=%d toMove=%d winrate=%+.4f\n", k,
                        (int)r.ply, (int)r.toMove, res.winrate());
        }
        std::fclose(fa);
        std::printf("wrote %s : %d aux records\n", auxPath.c_str(), cnt);
    }

    // ---- orient：外部朝向锚点（判定行棋方视角 vs 白方视角）----
    if (!orientPath.empty()) {
        Rules orules;
        orules.komi = 7.5f;
        orules.areaScoring = true;
        orules.positionalKo = true;
        orules.multiStoneSuicideLegal = true;
        std::vector<Rec> ors;
        std::vector<Move> emptyHist;
        // 1/2) 空盘，黑先 / 白先
        Board eb;
        eb.reset(N);
        {
            Rec r;
            fillRec(r, eb, emptyHist, BLACK, orules, -1, 0, 0, 7.5f, 0.0);
            ors.push_back(r);
            fillRec(r, eb, emptyHist, WHITE, orules, -2, 0, 0, 7.5f, 0.0);
            ors.push_back(r);
        }
        // 3/4) 一边倒：黑占上面 9 行(171 子)、白占下面 5 行(95 子)，黑约领先 76 目
        Board lb;
        lb.reset(N);
        for (int y = 0; y < 9; ++y)
            for (int x = 0; x < N; ++x) lb.colors[(size_t)(y * N + x)] = BLACK;
        for (int y = 14; y < N; ++y)
            for (int x = 0; x < N; ++x) lb.colors[(size_t)(y * N + x)] = WHITE;
        {
            Rec r;
            fillRec(r, lb, emptyHist, BLACK, orules, -3, 0, 0, 7.5f, 76.0);
            ors.push_back(r);
            fillRec(r, lb, emptyHist, WHITE, orules, -4, 0, 0, 7.5f, 76.0);
            ors.push_back(r);
        }
        FILE* fb = std::fopen(orientPath.c_str(), "wb");
        if (!fb) { std::printf("FAIL write %s\n", orientPath.c_str()); return 1; }
        std::fwrite("KGDUMP01", 1, 8, fb);
        int32_t no = (int32_t)ors.size();
        std::fwrite(&no, 4, 1, fb);
        std::fwrite(&npl, 4, 1, fb);
        std::fwrite(&ss, 4, 1, fb);
        std::fwrite(&ngl, 4, 1, fb);
        for (int i = 0; i < no; ++i) writeRec(fb, ors[(size_t)i]);
        std::fclose(fb);
        std::printf("wrote %s : %d orientation anchors\n", orientPath.c_str(), no);
    }
    return 0;
}
