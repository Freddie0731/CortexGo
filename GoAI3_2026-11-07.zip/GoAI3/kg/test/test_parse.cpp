// ============================================================================
//  test_parse.cpp -- 验证 C++ 侧 KataGo v17 权重解析器
//
//  判据（真值全部来自已通过验证的 Python 实现 _katago_v17_load.py）：
//    1. 解析后 bytesConsumed == totalBytes（精确闭合，最强判据）
//    2. modelVersion == 17，22 个空间平面，19 个全局特征
//    3. trunk: 11 块 / 768 通道 / mid 384 / regular 288 / gpool 96 / normKind 0
//    4. 块结构: nested=11, transformer=66（无 ordinary / gpool）
//    5. 张量计数: conv=28, matmul=238
// ============================================================================
#include "../infer/model_load.h"

#include <cstdio>
#include <string>

using namespace kg;

static int g_failures = 0;

static void check(bool cond, const char* what) {
    if (cond) {
        std::printf("  OK   %s\n", what);
    } else {
        std::printf("  FAIL %s\n", what);
        ++g_failures;
    }
}

static void checkEq(long long got, long long want, const char* what) {
    if (got == want) {
        std::printf("  OK   %-38s = %lld\n", what, got);
    } else {
        std::printf("  FAIL %-38s got %lld, want %lld\n", what, got, want);
        ++g_failures;
    }
}

int main(int argc, char** argv) {
    if (argc < 2) {
        std::printf("usage: test_parse <file.bin.gz>\n");
        return 2;
    }
    const std::string path = argv[1];

    Model M;
    std::string err;
    std::printf("loading %s ...\n", path.c_str());
    if (!loadModelFromFile(path, M, &err)) {
        std::printf("FAIL load: %s\n", err.c_str());
        return 1;
    }
    std::printf("\n=== 解析结果 ===\n");
    std::printf("  name           : %s\n", M.name.c_str());
    std::printf("  modelVersion   : %d\n", M.modelVersion);
    std::printf("  input channels : %d spatial + %d global\n",
                M.numInputChannels, M.numInputGlobalChannels);
    std::printf("  bytes consumed : %zu / %zu\n", M.bytesConsumed, M.totalBytes);
    std::printf("  floats loaded  : %zu (%.2f M params)\n", M.numFloats,
                (double)M.numFloats / 1e6);
    std::printf("  tensors        : conv=%d matmul=%d norms=%d\n",
                M.numConvs, M.numMatMuls, M.numNorms);
    std::printf("  blocks         : nested=%d transformer=%d\n",
                M.numNestedBlocks, M.numTfBlocks);

    std::printf("\n=== 校验 ===\n");
    // 1. 闭合：数据全部消费且剩余只有空白（最后一个 @BIN@ 块后有一个 '\n'）
    check(M.atEnd(), "stream consumed exactly to EOF (only whitespace left)");
    checkEq((long long)(M.totalBytes - M.bytesConsumed), 1LL,
            "leftover bytes (the trailing '\\n')");
    // 2. 头部
    checkEq(M.modelVersion, 17, "modelVersion");
    checkEq(M.numInputChannels, 22, "numInputChannels");
    checkEq(M.numInputGlobalChannels, 19, "numInputGlobalChannels");
    // 3. trunk
    checkEq(M.trunk.numBlocks, 11, "trunk.numBlocks");
    checkEq(M.trunk.trunkNumChannels, 768, "trunk.trunkNumChannels");
    checkEq(M.trunk.midNumChannels, 384, "trunk.midNumChannels");
    checkEq(M.trunk.regularNumChannels, 288, "trunk.regularNumChannels");
    checkEq(M.trunk.gpoolNumChannels, 96, "trunk.gpoolNumChannels");
    checkEq(M.trunk.trunkNormKind, 0, "trunk.trunkNormKind");
    checkEq((long long)M.trunk.blocks.size(), 11, "trunk.blocks.size()");
    // 4. 块结构
    checkEq(M.numNestedBlocks, 11, "nested block count");
    checkEq(M.numTfBlocks, 66, "transformer block count");
    // 5. 张量计数
    checkEq(M.numConvs, 28, "conv tensor count");
    checkEq(M.numMatMuls, 238, "matmul tensor count");

    // 抽查首层与头部形状
    std::printf("\n=== 抽查 ===\n");
    const ConvLayer& ic = M.trunk.initialConv;
    std::printf("  initialConv    : %s  ky=%d kx=%d ic=%d oc=%d  (w.size=%zu)\n",
                ic.name.c_str(), ic.ky, ic.kx, ic.ic, ic.oc, ic.w.size());
    const MatMulLayer& im = M.trunk.initialMatMul;
    std::printf("  initialMatMul  : %s  ic=%d oc=%d  (w.size=%zu)\n",
                im.name.c_str(), im.ic, im.oc, im.w.size());
    check(ic.oc == 768 && ic.ic == 22 && ic.ky == 3 && ic.kx == 3, "initialConv is 3x3 22->768");
    check(im.oc == 768 && im.ic == 19, "initialMatMul is 19->768");
    std::printf("  trunkTipAct    : %s\n", M.trunk.trunkTipAct.kind.c_str());
    std::printf("  policyOutChannels: %d\n", M.policyHead.policyOutChannels);
    checkEq(M.policyHead.policyOutChannels, 2, "policyOutChannels");

    // 抽查第一个 nested 块
    if (!M.trunk.blocks.empty() && M.trunk.blocks[0].kind == BLK_NESTED_BOTTLENECK) {
        const Block& b0 = M.trunk.blocks[0];
        std::printf("  blocks[0]      : %s internal=%d stack=%zu\n",
                    b0.name.c_str(), b0.internalLength, b0.stack.size());
        checkEq((long long)b0.stack.size(), 6, "blocks[0].stack.size()");
        int nAttn = 0, nFfn = 0;
        for (size_t i = 0; i < b0.stack.size(); ++i) {
            if (b0.stack[i].kind == BLK_TF_ATTENTION) ++nAttn;
            if (b0.stack[i].kind == BLK_TF_FFN) ++nFfn;
        }
        checkEq(nAttn, 3, "blocks[0] attention count");
        checkEq(nFfn, 3, "blocks[0] ffn count");
    }

    // 端到端：最后一个张量应是 conv_ownership，形状 (1,192,1,1)
    const ConvLayer& own = M.valueHead.vOwnershipConv;
    std::printf("  vOwnershipConv : %s  ic=%d oc=%d  (%dx%d)\n", own.name.c_str(),
                own.ic, own.oc, own.ky, own.kx);
    check(own.name == "model.value_head.conv_ownership", "last tensor name is conv_ownership");
    check(own.oc == 1 && own.ic == 192, "vOwnershipConv is 192->1");

    std::printf("\n%s (%d failure(s))\n", g_failures == 0 ? "ALL PASS" : "FAILED", g_failures);
    return g_failures == 0 ? 0 : 1;
}
