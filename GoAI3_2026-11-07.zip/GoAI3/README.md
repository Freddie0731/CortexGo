# GoAI3 — 一个用 C++ 实现的 KataGo v17 围棋引擎

用 C++17/20 写的 19×19 围棋 AI：**KataGo v17 神经网络推理（header-only，零第三方依赖）**
+ KataGo 风格 MCTS + GTP 协议 + Win32 图形界面 + 官方 ONNX/DirectML GPU 后端 + 训练与评测工具链。

> 本仓库不含神经网络权重（单个 250 MB）。取法见 [`weights/README.md`](weights/README.md)。

---

## 目录

| 路径 | 内容 |
|---|---|
| `go_ai.cpp` | 引擎主程序（搜索 / GTP / GUI / 自对弈 / 自检 / 基准） |
| `kg/infer/` | KataGo v17 推理栈：`.bin.gz` 解析、V7 输入编码、前向、ONNX Runtime 后端 |
| `kg/test/` | 推理栈的自检工具与基准（`test_ops` / `test_forward` / `bench_forward` / `probe_encode` / `dump_enc`） |
| `tools/` | 构建脚本、回归验证、A/B 对局、价值头训练管线、网络下载、补丁脚本 |
| `python/` | KataGo 权重解析 / PyTorch 参考实现 / 自对弈与微调管线（`_kg_pipeline.py`） |
| `third_party/katago_src/` | 官方 KataGo v1.17.1 源码（**仅供语义对照**，非本项目代码，见其自身许可） |
| `cloud/` | 云端（GPU）训练与自对弈脚本 |
| `aistudio/` | 百度 AI Studio 上传包生成与说明 |
| `docs/` | 交接文档、接入说明、发布说明、方案文档 |
| `bat/` | Windows 一键批处理（构建、自检、转换权重、全流程） |
| `weights/` | 权重获取说明（不放二进制） |

---

## 构建

需要 MSVC（VS 2022+）与 Windows SDK。

```bat
:: 一键：构建 + 自检 + 安装到 x64\Release
bat\构建并自检.bat

:: 或手动
cl /nologo /O2 /EHsc /std:c++20 /W3 /DNDEBUG /utf-8 /openmp go_ai.cpp ^
   /Fe:GoAI3.exe /link gdiplus.lib gdi32.lib user32.lib
```

GPU 路径（可选）：把 `onnxruntime.dll`、`DirectML.dll`、`onnxruntime_providers_shared.dll`
放到 exe 同目录，再把 `kata1_b11.onnx` 放到工作目录，引擎启动时会自动探测并使用 DirectML。
没有这些文件时自动回落到原生 CPU 内核。

## 运行

```bat
GoAI3.exe                 :: Win32 图形界面
GoAI3.exe --cli --time 10 :: 终端对局，每手 10 秒
GoAI3.exe --selftest      :: 自检（搜索不变量 / 规则枚举 / 网络 I/O 契约）
GoAI3.exe --benchmark     :: 速度与网络参与度基准
```

GTP 用法（接 Sabaki 等前端）：

```bat
GoAI3.exe --gtp
```

## 测试与回归

```bat
python tools\verify.py                 :: 9 项回归：构建产物 / 自检 / GTP 健壮性
python tools\match.py --help           :: A/B 对局驱动（两引擎互下，出 SGF 与胜率）
python tools\check_net.py <net.bin.gz> :: 网络体检：sha256/gzip/解析/bench/空盘冒烟
```

---

## 技术要点（踩过的坑都在这）

这几条是让引擎**真正变强**的关键改动，细节与复现方法见 [`docs/HANDOFF.md`](docs/HANDOFF.md)。

### 1. 归一化语义必须按官方导出格式解读（最重要）

官方 `export_model_pytorch.py:write_bn()` 写进 `.bin.gz` 的四个量是
`running_mean`、`running_var`、**已折好逐层 scale 的乘子（gamma 槽位）**、`beta`，
正确前向只有一条：

```
y = (x - running_mean) / sqrt(running_var + eps) * 槽位 + beta
```

早期实现把它当成"乘一个固定常数"，并把 `running_mean/var` 丢掉 —— **trunk 末端那层
真实 batchnorm 被整个跳过**，导致 policy 与 value 同时出错（引擎空盘只会点星位、胜率显示 73%，
而官方引擎同权重是 34%）。修正后与官方引擎逐点一致：

| 空盘黑先 | 修前 | 修后 | 官方引擎 |
|---|---:|---:|---:|
| 四星位合计 | 0.9229 | **0.1535** | 0.1523 |
| 黑方胜率 | 0% | **34.4%** | 34.1~34.4% |

### 2. 输入编码必须逐平面对齐官方 `nninputs.cpp::fillRowV7`

22 个空间平面 + 19 个全局特征。最容易错的是**征子平面**（14/15/16/17）和**劫/超劫平面**（6）：
官方征子求解器要考虑防守方"提子长气逃出"、根节点清劫、防守方遇劫直接判逃；
超劫判据依赖 `getPosHashAfterMove` 会把"自杀掉的整串"一起 XOR 掉。
修正后在 10 个中盘局面上与官方 Python 复刻版**逐位一致**。

### 3. 验证要用官方引擎作 oracle，且固定 symmetry

* `katago analysis` 模式**不按 symmetry 0 评估**，官方自己 8 个 symmetry 之间就差 0.02~0.05。
  做 1e-3 级判据必须用 GTP 的 `kata-raw-nn 0`。
* "我们自己的 PyTorch 与 C++ 对得上" **不能证明实现对** —— 两边可能用的是同一张错的图。

### 4. 性能

| 项 | 优化前 | 优化后 |
|---|---:|---:|
| 单次前向（70M 网络） | 1.0895 s | **0.077 s**（DirectML GPU） |
| 单次前向（原生 CPU） | 1.0895 s | 0.239 s（SIMD 内核） |
| 每手 30 秒可达访问数 | ~12 | **~390** |

* CPU 内核做了连续性优化（conv/attention/gpool 全宽向量化），4.56 倍。
* **FTZ/DAZ**：新一代 KataGo 网络会把激活压进次正规数区间，x86 处理有 10~100 倍惩罚。
  `_controlfp_s(NULL, _DN_FLUSH, _MCW_DN)` 一行，让 94MB 网络从 0.344 s → 0.242 s（1.42×）。
* GPU 走 ONNX Runtime + DirectML，`LoadLibrary` 动态加载，缺 DLL 时自动回落。

### 5. 搜索层修正

PUCT 此前**从不生效**（修正为在所有合法着法上选择）、FPU 符号错、virtual loss 泄漏、
根对称未平均、树复用深度不足 —— 全部修正后，同样 30 秒从"深度 0"变成"深度 8"。

---

## 网络格式速查

| 后缀 | norm_kind | 本引擎 |
|---|---|---|
| 无后缀 | `fixup` | ✅ 支持（文件里的槽位即 `gamma+1`/`1`） |
| `-fs` | `fixscale` | ✅ 支持 |
| `-fson` | `fixscaleonenorm`（**末端是 batchnorm**） | ✅ 支持（需 §1 的语义修正） |
| `-fson-...-rsnh` | 同上 + trunk 末端 RMSNorm | ✅ 支持（spatial RMSNormMask） |

官方网络里 **38 MB 的 `b10c384h6nbttflrs`** 是个好选择：FTZ 后单次前向 0.077 s
（约为 70M 网络的 2.9 倍速度），每访问质量不输，空盘胜率与官方引擎逐点一致（0.3704）。

---

## 已知限制

* **policy head 仍有 ~1e-2 残差**：value 已与官方引擎一致到 1e-6，policy 的 max diff 约 0.02
  （个别局面 0.0086）。问题定位在 policy head（gating / 最后一层 1×1 conv），尚未修完。
* **AI Studio 不能用于训练**：该平台环境为 PaddlePaddle，**平台层面禁止 `import torch`**，
  且免费实例只有 CPU。AI Studio 目前仅用于存放数据集与代码。
* 大规模自对弈训练需要 GPU 与 PyTorch 环境（`python/` 下的管线可直接用）。

## 许可

本仓库代码为 MIT（见 `LICENSE`）。`third_party/katago_src/` 为官方 KataGo 源码，
遵循其自身许可；网络权重由 KataGo 项目发布，使用时请遵守其条款。

## 交接文档

[`docs/HANDOFF.md`](docs/HANDOFF.md) 记录了每个改动的**原因、实测数字、复现命令与踩坑教训**，
是继续开发的入口；[`docs/项目现状与操作指南.md`](docs/项目现状与操作指南.md) 是面向使用者的操作说明。
