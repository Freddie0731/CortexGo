# 在百度 AI Studio 上做自我对弈 + 接力训练

本目录是给云端 GPU 用的。**本机 CPU 也能跑同一套流程,只是慢几十倍**
（本机 0.19 秒/前向,GPU 约 0.02 秒）。

---

## 一、要上传什么

AI Studio 的持久目录是 `/home/aistudio/work/`（重启不丢）。把下面这些放进
`work/` 下的同一个目录，比如 `/home/aistudio/work/kg/`：

### 代码（必需）

```
_kg_pipeline.py         自我对弈 / 训练 / 检查点 / 导出
_kg_mcts.py             PUCT MCTS（产出策略目标，这是学棋的机制）
_kg_export.py           原地字节打补丁导出
_kg_map.py              块序号 <-> 层名映射
_katago_v17_load.py     .bin.gz 解析器
_katago_official.py     加载官方 model_pytorch.py
_kg_ref.py              .bin.gz -> PyTorch state_dict
_kg_enc.py              Python 版 V7 输入编码
_katago_src/            官方模型定义（必须整个目录）
```

### 权重（必需）

```
kata1.bin.gz            250 MB
```

AI Studio 单文件上传有大小限制，250 MB 通常要用**数据集**方式上传：
新建数据集 → 上传 `kata1.bin.gz` → 在 notebook 里挂载 → 它会出现在
`/home/aistudio/data/data<id>/`，脚本里用 `--weights` 指过去即可
（不必复制到 work，复制反而占持久空间）。

---

## 二、环境检查（进 notebook 第一格）

```bash
!cd /home/aistudio/work/kg && bash ../kg_check.sh
```

或手动：

```python
import torch
print('torch', torch.__version__, 'cuda', torch.cuda.is_available())
if torch.cuda.is_available():
    print(torch.cuda.get_device_name(0))
```

**依赖只有 numpy 和 torch**，AI Studio 镜像都自带。
`packaging` 不需要装 —— `_katago_official.py` 会自己打桩。

如果 `cuda` 是 `False`，说明选了 CPU 环境：去「环境」里换一个 GPU 版本的镜像。

---

## 三、跑起来

### 第 1 步：自我对弈产数据

```bash
cd /home/aistudio/work/kg
python _kg_pipeline.py selfplay \
    --weights /home/aistudio/data/data<id>/kata1.bin.gz \
    --games 40 --out work_data \
    --mcts-visits 100 --max-moves 250 --temp 1.0
```

`--mcts-visits 100` 是关键：**只有 MCTS 的访问分布才含有"网络原来没看出来、
但确实更好"的招**，这是策略能变强的唯一来源。不加这个参数就是纯策略自对弈，
策略目标的梯度恒为 0，学不到东西。

耗时估算（V100 级，每手 0.02–0.05 秒）：

| visits | 秒/手 | 一局(200手) | 40 局 | 产出局面 |
|---|---|---|---|---|
| 50 | 1–2.5 | 3–8 分 | 2–5 小时 | 约 8000 |
| 100 | 2–5 | 7–17 分 | 5–11 小时 | 约 8000 |
| 200 | 4–10 | 13–33 分 | 9–22 小时 | 约 8000 |

> 想缩短单局时间，先降 `--max-moves`（比如 150）：开局到中盘才是学习价值
> 最高的部分，官子阶段对策略提升帮助很小。

### 第 2 步：训练

```bash
python _kg_pipeline.py train \
    --weights /home/aistudio/data/data<id>/kata1.bin.gz \
    --data work_data --steps 2000 \
    --ckpt work_ckpt.pt --lr 1e-5
```

会打出每 10 步的 loss：

```
    step 10  loss_v=1.9843  loss_p=2.7712  （0.83 步/秒）
    ...
  检查点已存 work_ckpt.pt（step 2000，累计消费 40 局，1 轮）
  下次接力: --resume work_ckpt.pt
```

### 第 3 步：导出成引擎能加载的权重

```bash
python _kg_pipeline.py export \
    --weights /home/aistudio/data/data<id>/kata1.bin.gz \
    --ckpt work_ckpt.pt --out kata1_ft.bin.gz
```

`kata1_ft.bin.gz` 就是成果：**本机双击 run.bat 就能用它下棋**
（把它放到工程根目录、改名 `kata1.bin.gz`，或改 run.bat 里的 WEIGHTS）。

---

## 四、接力训练（这是重点）

第二轮开始，仍然用同一个 `--ckpt`，加 `--resume`：

```bash
# 产新数据（换 --seed 和 --start-index，别覆盖旧的）
python _kg_pipeline.py selfplay --weights .../kata1.bin.gz \
    --games 40 --out work_data2 --mcts-visits 100 --seed 100 --start-index 40

# 在上一轮成果上继续
python _kg_pipeline.py train --weights .../kata1.bin.gz \
    --data work_data2 --steps 2000 \
    --ckpt work_ckpt.pt --resume work_ckpt.pt
```

`--resume` 会完全恢复：**模型权重 + Adam 动量 + 步数 + 已消费对局列表**。
因为检查点里记了 `consumed`，即使 `--data` 指向包含旧文件的大目录，
也**只会训练新增的对局**，不会重复消费。

想看这个检查点做过什么：

```bash
python _kg_pipeline.py info --ckpt work_ckpt.pt
```

输出里有每一轮的样本数、损失、耗时，方便判断哪一轮有效。

> 检查点约 **807 MB**（模型 282 MB + Adam 两个动量 564 MB）。
> AI Studio 的持久空间有限，跑几轮就要注意清理。
> 如果只想省空间、不在乎续训开头几步抖一下，可以只保留导出的
> `.bin.gz`（262 MB），下轮用 `--weights` 指向它重新开始。

---

## 五、后台长跑（推荐）

自我对弈要跑几小时，notebook 页面容易断。用 nohup：

```bash
cd /home/aistudio/work/kg
nohup python -u _kg_pipeline.py selfplay \
    --weights /home/aistudio/data/data<id>/kata1.bin.gz \
    --games 40 --out work_data --mcts-visits 100 \
    > selfplay.log 2>&1 &
echo $! > selfplay.pid
```

看进度：

```bash
tail -f selfplay.log
```

`-u` 必须有，否则 Python 会缓冲输出，`tail` 看不到东西。

想一次跑完整轮（产数据 → 训练 → 导出），用 `run_loop.sh`：

```bash
bash run_loop.sh /home/aistudio/data/data<id>/kata1.bin.gz 1 40 100 2000
#                 权重路径                               轮次 局数 visits 步数
```

---

## 六、一键往返：把成果拿回本机

```bash
ls -lh /home/aistudio/work/kg/kata1_ft.bin.gz
```

在 AI Studio 文件树里右键下载（262 MB，可能需要用「数据集」方式导出）。
下回本机后：

1. 放到 `D:\GoAI3\GoAI3\GoAI3\`
2. 改名 `kata1.bin.gz`（或改 `run.bat` 里的 `WEIGHTS`）
3. 双击 `run.bat`

**验证完整性**（可选，确认文件没在传输中损坏）：

```powershell
.\kg\build\test_parse.exe kata1_ft.bin.gz
```

`ALL PASS` 就说明引擎能正常加载。

---

## 七、几个容易踩的坑

**1. 忘了 `--mcts-visits`。**
默认是 0（纯策略），那样策略目标就是网络自己的输出，**梯度恒为 0，白跑**。
脚本会打警告，注意看日志开头。

**2. 数据存太大。**
脚本只存棋谱和政策目标（一局约 1 MB 压缩后），不存编码平面。
如果你自己改脚本去存 `sp`，一局会变成 6–8 MB，几百局就爆盘。

**3. 检查点占满持久空间。**
807 MB/份。AI Studio 持久空间通常几十 GB，跑几十轮要清理旧数据。

**4. `--steps` 和样本数不匹配。**
`--steps 2000` 配 8000 个局面 = 每局面的样本被看 0.25 遍（不到一个 epoch）。
想多训就加 `--steps`；但要注意**过拟合**：只有几十局数据时，反复训很多遍
会让它在这几十局上变强、整体变弱。

**5. GPU 没被用上。**
脚本会自动检测 CUDA 并显示 `设备=cuda` 和显卡名。如果显示 `设备=cpu`，
检查镜像是不是 GPU 版。

**6. 单次前向时间要看日志。**
如果 GPU 上每手耗时远高于 0.05×visits 秒，多半是没开 flex attention
或环境有问题 —— 看 `设备=cuda` 是否打印了。

---

## 八、这一套的极限（说清楚）

- 本机 CPU 跑不出有意义的提升（0.4 访问/秒），**必须用 GPU**。
- 几十局 × 100 visits 属于**验证规模**，能让 loss 下降、让 value 头
  从"行棋方输 99.97%"这种坏标定回到接近真实，但**不会让它明显变强**。
  AlphaZero 级别的提升需要 10 万局量级。
- 真正的性价比曲线是：**先修 value 头**（几万局面就够，收益确定），
  再考虑策略提升（需要海量对局）。
