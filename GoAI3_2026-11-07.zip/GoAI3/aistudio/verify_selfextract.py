# -*- coding: utf-8 -*-
"""验证 selfextract.py：base64 能解码、zip 结构对、内容与源文件逐字节相同。"""
import base64
import io
import os
import re
import sys
import zipfile

sys.stdout.reconfigure(encoding='utf-8', errors='replace')

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
SRC = os.path.join(HERE, 'selfextract.py')

src = open(SRC, encoding='utf-8').read()
m = re.search(r'_B64 = """(.*?)"""', src, re.S)
if not m:
    print('找不到 _B64')
    sys.exit(1)

b64 = ''.join(m.group(1).split())
data = base64.b64decode(b64)
print('base64 解码: %d 字节' % len(data))

z = zipfile.ZipFile(io.BytesIO(data))
names = sorted(z.namelist())
print('zip 内文件: %d 个' % len(names))
print()

bad = 0
for n in names:
    rel = n[len('kg/'):] if n.startswith('kg/') else n
    orig = os.path.join(ROOT, '_katago_src', rel[len('_katago_src/'):]) \
        if rel.startswith('_katago_src/') else os.path.join(ROOT, rel)
    a = z.read(n)
    if not os.path.isfile(orig):
        print('  %-46s %7d B  源文件不存在' % (rel, len(a)))
        bad += 1
        continue
    b = open(orig, 'rb').read()
    same = (a == b)
    if not same:
        bad += 1
    print('  %-46s %7d B  %s' % (rel, len(a), 'OK' if same else '**不一致**'))

print()
print('逐字节校验: %d 个文件，不一致 %d 个' % (len(names), bad))

# 顺带确认自解压脚本本身语法正确（它是要粘进 notebook 的，语法错就白搭）
import py_compile
try:
    py_compile.compile(SRC, doraise=True, cfile=os.path.join(HERE, '_se_check.pyc'))
    os.remove(os.path.join(HERE, '_se_check.pyc'))
    print('selfextract.py 语法: OK')
except Exception as ex:
    print('selfextract.py 语法错误: %s' % ex)
    bad += 1

sys.exit(0 if bad == 0 else 1)
