# 在百度 AI Studio 上跑 GoAI3（当前版本，2026-10-24）

> 这份说明对应"棋力提升"之后的状态：GPU 推理已接好、价值头已重训、编码器已对齐官方。
> 在 AI Studio 上主要做**训练**（自对弈 / 价值头 / 策略微调），不必在那边下棋。

---

## 一、上传什么

`python aistudio/make_upload_bundle.py` 会生成 **`aistudio/upload/goai3_code.zip`（约 25~30 MB）**：

```
goai3_code.zip
├── _kg_pipeline.py / _kg_mcts.py / _kg_export.py / _kg_map.py / _kg_ref.py / _kg_enc.py
├── _katago_v17_load.py / _katago_official.py
├── _katago_src/*.py            官方 PyTorch 模型定义（13 个）
├── tools/value_*.py            价值头重训管线（features/train/export/policy_eval/compare）
├── tools/export_onnx.py        PyTorch → ONNX
├── cloud/*.sh                  一键脚本（setup / 全量价值头 / 自对弈闭环）
├── kg/test/dump_enc.cpp        编码 dump（要在云端重新生成数据时用）
├── data/dump.bin               **16,680 个局面的编码 + 标签（24 MB）**
├── data/manifest.txt           对应清单（棋局/棋步/胜者/贴目）
├── data/selfcheck.bin          编码自检样本
└── HANDOFF.md / README.md      交接与说明
```

**权重**（`kata1_value_fixed.bin.gz`，250 MB）**必须单独上传**：
AI Studio 的单文件上传有大小限制，走「数据 → 创建数据集 → 上传文件」。

---

## 二、上传步骤（浏览器）

1. 打开 <https://aistudio.baidu.com/> 并登录
2. 右上「我的控制台」→「数据」→「创建数据集」
   - 英文 ID：`goai3`
   - 展示名称：`GoAI3 围棋引擎（KataGo v17 + MCTS + 训练管线）`
   - 公开 / 私密：建议 **私密**
3. 创建后在数据集详情页「上传文件」：先传 `goai3_code.zip`，再传 `kata1_value_fixed.bin.gz`
4. 进「项目」→ 创建 Notebook 项目（选 **GPU** 镜像）→ 在 notebook 里挂载数据集：
   ```bash
   mkdir -p /home/aistudio/work/goai3 && cd /home/aistudio/work/goai3
   unzip /home/aistudio/data/data<id>/goai3_code.zip      # <id> 在数据集详情页 URL 里
   ls data/                                                # dump.bin / manifest.txt
   ```

---

## 三、跑什么（按性价比）

> AI Studio 的 GPU 对这套东西是"够快"的：单次前向约 10~20 ms（详情见 HANDOFF §7）。

### A. 全量价值头重训（最便宜、最确定，~30 分钟）
```bash
cd /home/aistudio/work/goai3
bash cloud/setup.sh                       # 装 CUDA 版 torch
python3 tools/value_features.py --dump data/dump.bin --aux /dev/null \
    --weights /home/aistudio/data/data<id>/kata1_value_fixed.bin.gz \
    --device cuda --batch 16 --out features_full.npz --skip-aux --skip-check
python3 tools/value_train.py --features features_full.npz --manifest data/manifest.txt \
    --out-weights value_head_full.npz --epochs 120
python3 tools/value_export.py --new value_head_full.npz \
    --src /home/aistudio/data/data<id>/kata1_value_fixed.bin.gz \
    --out kata1_value_fixed_v3.bin.gz
```

### B. 策略头微调（需要先补 `tools/train_policy.py`，仓库里还没有）

### C. 自对弈闭环（收益上限最高，耗 GPU 时长最多）
```bash
ROUNDS=2 GAMES=40 VISITS=200 bash cloud/run_selfplay_loop.sh
```

### D. 顺手验证编码器/网络（不训练也能做）
```bash
python3 tools/value_policy_eval.py --features features_full.npz
# 当前基线：policy top-1 = 0.2907，top-5 = 0.5721
```

---

## 四、把成果拿回本地

```bash
# AI Studio 里把文件放到 work/（持久目录），然后在「文件」面板下载
cp kata1_value_fixed_v3.bin.gz /home/aistudio/work/
```
拿回本地后（参考 HANDOFF §7.5/§7.6）：

1. 覆盖 `kata1_value_fixed.bin.gz`
2. **重新导出 ONNX**（GPU 路径必须与原生同源）：`tools\export_onnx_fixed.bat`，
   输出改名成 `kata1_value_fixed.onnx`
3. `x64\Release\GoAI3.exe --selftest`：空盘胜率应在 **45~55%**
4. 代理指标 A/B（比完整对局省几十倍算力）确认没退步，再提交

---

## 五、已知坑

1. **权重按工作目录查找**：本地引擎从 cwd 找权重；AI Studio 上跑训练脚本用 `--weights` 显式指定，别指望自动找。
2. **`--device cuda` 是新加的**（`tools/value_features.py`）；不加就只会跑 CPU（1.9 局面/秒）。
3. **dump.bin 与 encode.h 版本绑定**：本地 `encode.h` 若再改编码，必须重新 `dump_enc`，否则训练输入与引擎不一致。
4. **价值头标签是"行棋方视角"**：`linear_valuehead` 三通道顺序是 `0=win, 1=loss, 2=noresult`，把"是否获胜"直接当类别索引用会让结果恰好反号（我们踩过）。
5. ONNX 里的 7 个 aux 价值头张量每次导出是随机初值（引擎不读取），不用管。
