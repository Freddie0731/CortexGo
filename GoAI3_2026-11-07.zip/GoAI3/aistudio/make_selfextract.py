# -*- coding: utf-8 -*-
"""生成一个「粘贴进 notebook 就能用」的自解压脚本。

## 为什么需要这个

目标机器（百度 AI Studio）上找不到上传入口，数据集页面也进不去，
所以唯一剩下的通道是**把代码粘进 notebook 单元格**。

做法：把需要的文件打成一个 zip -> base64 -> 塞进一个 Python 脚本。
本机打开这个脚本、全选复制、粘进 notebook 一格、运行，它自己把文件写出来。

## 只放必需的

官方 _katago_src 里 13 个文件，实测只有 5 个被用到（见 README 里的说明）。
其余 8 个（export_model_pytorch / load_model / metrics / genboard* 等）我的流程
根本不 import，放进去只是白白让粘贴文本变长。

用法: python aistudio/make_selfextract.py
"""
import base64
import io
import os
import sys
import zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
OUT = os.path.join(HERE, 'selfextract.py')

# 我自己的脚本
MINE = [
    '_kg_pipeline.py',      # 自我对弈 / 训练 / 检查点 / 导出
    '_kg_mcts.py',          # PUCT MCTS
    '_kg_map.py',           # 块序号 <-> 层名映射
    '_kg_export.py',        # 原地字节打补丁导出
    '_kg_ref.py',           # .bin.gz -> state_dict
    '_kg_enc.py',           # Python 版 V7 输入编码
    '_kg_vfix.py',          # 修 value head
    '_katago_v17_load.py',  # .bin.gz 解析器
    '_katago_official.py',  # 加载官方 model_pytorch.py
]

# 官方文件里真正被用到的 5 个
OFFICIAL = [
    'modelconfigs.py',
    'trainloop_helpers.py',
    'model_pytorch.py',
    'fused_rope.py',
    'fused_swiglu.py',
]

DOCS = ['README.md']


def main():
    buf = io.BytesIO()
    n = 0
    total = 0
    with zipfile.ZipFile(buf, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for f in MINE + DOCS:
            p = os.path.join(ROOT, f)
            if not os.path.isfile(p):
                print('  !! 缺少 %s' % f)
                return 1
            data = open(p, 'rb').read()
            z.writestr('kg/' + f, data)
            total += len(data)
            n += 1
        for f in OFFICIAL:
            p = os.path.join(ROOT, '_katago_src', f)
            if not os.path.isfile(p):
                print('  !! 缺少 _katago_src/%s' % f)
                return 1
            data = open(p, 'rb').read()
            z.writestr('kg/_katago_src/' + f, data)
            total += len(data)
            n += 1

    raw = buf.getvalue()
    b64 = base64.b64encode(raw).decode('ascii')
    # 每 160 字符一行，方便编辑器显示、也避免单行过长
    lines = [b64[i:i + 160] for i in range(0, len(b64), 160)]

    body = '''# ============================================================================
#  自解压：把 go.ai 的 AI Studio 代码包写出来
#
#  用法：本机打开这个文件 -> 全选(Ctrl+A) -> 复制(Ctrl+C)
#        -> AI Studio notebook 新建一格 -> 粘贴 -> Shift+Enter
#
#  它会写到 /home/aistudio/work/kg/，共 %d 个文件。
#  只有 numpy + torch 依赖，AI Studio 镜像自带。
# ============================================================================
import base64, io, os, zipfile

_B64 = """
%s
"""

def _run():
    data = base64.b64decode("".join(_B64.split()))
    dst = "/home/aistudio/work"
    os.makedirs(dst, exist_ok=True)
    zipfile.ZipFile(io.BytesIO(data)).extractall(dst)
    root = os.path.join(dst, "kg")
    files = []
    for dp, dn, fn in os.walk(root):
        for f in fn:
            files.append(os.path.relpath(os.path.join(dp, f), root))
    print("已写入 %%d 个文件到 %%s" %% (len(files), root))
    for f in sorted(files):
        print("   ", f)
    # 顺手检查关键模块能不能 import（不加载模型，很快）
    import subprocess, sys
    r = subprocess.run([sys.executable, "-c",
                        "import sys; sys.path.insert(0, r'%%s');"
                        "import _katago_v17_load, _kg_map, _kg_export, _kg_mcts;"
                        "print('核心模块 import OK')" %% root],
                       capture_output=True, text=True)
    print(r.stdout.strip() or r.stderr.strip()[-500:])

_run()
''' % (n, '\n'.join(lines))

    with open(OUT, 'w', encoding='utf-8', newline='\n') as f:
        f.write(body)

    print('已生成 %s' % OUT)
    print('  原始文件 %d 个，%.1f KB' % (n, total / 1024.0))
    print('  压缩后   %.1f KB' % (len(raw) / 1024.0))
    print('  base64   %.1f KB  <- 这就是要粘贴的文本量' % (os.path.getsize(OUT) / 1024.0))
    print()
    print('下一步：用记事本打开 selfextract.py，Ctrl+A 全选、Ctrl+C 复制，')
    print('        在 AI Studio notebook 里新建一格、粘贴、Shift+Enter 运行。')
    return 0


if __name__ == '__main__':
    sys.exit(main())
