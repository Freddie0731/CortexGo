# -*- coding: utf-8 -*-
"""aistudio/make_upload_bundle.py —— 把"现在这一版"的代码/管线打成 AI Studio 上传包。

和 2026-10 早期那版 `make_bundle.py` 的区别：
  * 早期那版只含"自对弈+微调"的最小集，且不含任何数据；
  * 现在多了整套价值头重训管线（tools/value_*.py）、云端脚本（cloud/）、
    ONNX 导出、GitHub 下载工具、编码 dump 工具；
  * 还带上 `build_out/value/dump.bin` + `manifest.txt`（约 25 MB）——
    有了它，AI Studio 上不必先编译 C++ 就能直接跑价值头训练
    （dump.bin 是 16,680 个局面的编码 + 标签，与引擎逐位一致）。

产出：
    aistudio/upload/goai3/            展平的目录（要传什么一目了然）
    aistudio/upload/goai3_code.zip    打包结果（约 25~30 MB）

用法:
    python aistudio/make_upload_bundle.py
    python aistudio/make_upload_bundle.py --no-dump     # 不带 dump.bin（约 2 MB）
"""
import argparse
import os
import shutil
import sys
import zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
DST = os.path.join(HERE, 'upload', 'goai3')
ZIP = os.path.join(HERE, 'upload', 'goai3_code.zip')

# 顶层文件（AI Studio 上直接可跑的训练/导出脚本 + 解析器）
ROOT_PY = [
    '_kg_pipeline.py',      # 自对弈 / 训练 / 检查点 / 导出
    '_kg_mcts.py',          # PUCT MCTS（产策略目标）
    '_kg_export.py',        # 原地字节打补丁导出
    '_kg_map.py',           # 块序号 <-> 层名映射
    '_kg_ref.py',           # .bin.gz -> PyTorch state_dict
    '_kg_enc.py',           # Python 版 V7 输入编码
    '_katago_v17_load.py',  # .bin.gz 解析器
    '_katago_official.py',  # 加载官方 model_pytorch.py
]

# tools/ 里训练侧真正需要的
TOOLS_PY = [
    'value_lib.py', 'value_sgf_manifest.py', 'value_features.py',
    'value_train.py', 'value_export.py', 'value_selfcheck.py',
    'value_policy_eval.py', 'value_compare.py', 'export_onnx.py',
    # 2026-10-24 归一化修复之后新增/更新过的：
    'export_onnx_fson.py',   # 用正确 fson 图导出 ONNX（GPU 路径）
    'check_net.py',          # 一条命令做 sha256/gzip/解析/bench/空盘冒烟
    'patch_norm_semantics.py',  # 归一化语义补丁（可重放，便于核对云端副本是否同一版）
]

DOCS = ['HANDOFF.md', 'aistudio/README.md', 'aistudio/AISTUDIO_README.md']

# 小数据：编码 dump + 清单（价值头训练的输入，省掉在云端编译 C++ 的步骤）
DUMP = [
    ('build_out/value/dump.bin', 'data/dump.bin'),
    ('build_out/value/manifest.txt', 'data/manifest.txt'),
    ('build_out/value/selfcheck.bin', 'data/selfcheck.bin'),
]

# 云端脚本（在 AI Studio 上同样适用）
CLOUD = ['cloud/run_value_full.sh', 'cloud/run_selfplay_loop.sh',
         'cloud/setup.sh', 'cloud/README_cloud.md']


def copy_rel(rel, dst_dir, missing):
    src = os.path.join(ROOT, rel)
    if not os.path.isfile(src):
        missing.append(rel)
        return 0
    out = os.path.join(dst_dir, os.path.basename(rel))
    os.makedirs(os.path.dirname(out), exist_ok=True)
    shutil.copy2(src, out)
    return os.path.getsize(src)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--no-dump', action='store_true', help='不打包 25MB 的编码 dump')
    args = ap.parse_args()

    if os.path.isdir(os.path.join(HERE, 'upload')):
        shutil.rmtree(os.path.join(HERE, 'upload'))
    os.makedirs(DST)
    missing = []
    total = 0

    for f in ROOT_PY:
        total += copy_rel(f, DST, missing)
    for f in TOOLS_PY:
        total += copy_rel(os.path.join('tools', f), os.path.join(DST, 'tools'), missing)
    for f in DOCS:
        total += copy_rel(f, DST, missing)
    for f in CLOUD:
        total += copy_rel(f, os.path.join(DST, 'cloud'), missing)

    # 官方模型定义（整个目录；训练必须）
    src_dir = os.path.join(ROOT, '_katago_src')
    n_katago = 0
    if os.path.isdir(src_dir):
        out_dir = os.path.join(DST, '_katago_src')
        os.makedirs(out_dir, exist_ok=True)
        for f in sorted(os.listdir(src_dir)):
            if not f.endswith('.py'):
                continue
            p = os.path.join(src_dir, f)
            shutil.copy2(p, os.path.join(out_dir, f))
            total += os.path.getsize(p)
            n_katago += 1
    else:
        missing.append('_katago_src/')

    # 编码/dump 工具源码 + kg/infer 头文件（header-only，云端可用 g++ 直接编译出 dump_enc）
    total += copy_rel(os.path.join('kg', 'test', 'dump_enc.cpp'),
                      os.path.join(DST, 'kg', 'test'), missing)
    infer_src = os.path.join(ROOT, 'kg', 'infer')
    if os.path.isdir(infer_src):
        out_dir = os.path.join(DST, 'kg', 'infer')
        os.makedirs(out_dir, exist_ok=True)
        for f in sorted(os.listdir(infer_src)):
            if not f.endswith('.h'):
                continue
            p2 = os.path.join(infer_src, f)
            shutil.copy2(p2, os.path.join(out_dir, f))
            total += os.path.getsize(p2)
    else:
        missing.append('kg/infer/')

    if not args.no_dump:
        for rel, out_rel in DUMP:
            src = os.path.join(ROOT, rel)
            if not os.path.isfile(src):
                missing.append(rel)
                continue
            out = os.path.join(DST, out_rel)
            os.makedirs(os.path.dirname(out), exist_ok=True)
            shutil.copy2(src, out)
            total += os.path.getsize(src)

    # 打 zip
    with zipfile.ZipFile(ZIP, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for base, _dirs, files in os.walk(DST):
            for f in files:
                full = os.path.join(base, f)
                arc = os.path.relpath(full, DST)
                z.write(full, arc)

    print('展平目录 : %s' % DST)
    print('zip      : %s  (%.1f MB)' % (ZIP, os.path.getsize(ZIP) / 1e6))
    print('未压缩   : %.1f MB   | _katago_src %d 个 .py' % (total / 1e6, n_katago))
    if missing:
        print('\n缺失（不影响主流程，但请确认）:')
        for m in missing:
            print('  -', m)
    print('\n下一步：AI Studio → 数据 → 创建数据集 → 上传 %s' % os.path.basename(ZIP))
    print('        权重 kata1_value_fixed.bin.gz (250MB) 需要单独上传（同数据集或另建一个）')
    return 0


if __name__ == '__main__':
    sys.exit(main())
