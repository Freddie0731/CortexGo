# 上传到百度 AI Studio —— 已备好什么、还差哪一步

> 状态（2026-10-24）：**上传包已经做好并在本地校验过；浏览器自动化的点击流程没跑完**
> （见文末"为什么没自动传完"）。下面给出可以照做的 4 步，和两个不用上传的替代方案。

---

## 一、已经做好的东西

`python aistudio/make_upload_bundle.py` 已经生成并校验过：

| 文件 | 大小 | 说明 |
|---|---:|---|
| `aistudio/upload/goai3_code.zip` | **3.4 MB**（解压 26.4 MB） | 52 个文件，内容见下 |
| `aistudio/upload/goai3/` | — | 同样的内容展平后的目录，传之前可以先看一眼 |

zip 里有什么：

```
_kg_pipeline.py / _kg_mcts.py / _kg_export.py / _kg_map.py / _kg_ref.py / _kg_enc.py
_katago_v17_load.py / _katago_official.py
_katago_src/*.py            官方 PyTorch 模型定义（13 个）
tools/value_*.py            价值头重训管线（features/train/export/policy_eval/compare）
tools/export_onnx.py        PyTorch → ONNX
cloud/*.sh                  一键脚本（setup / 全量价值头 / 自对弈闭环）
kg/infer/*.h                引擎推理栈（header-only）+ kg/test/dump_enc.cpp
data/dump.bin               16,680 局面的编码 + 标签（24 MB，价值头训练的输入）
data/manifest.txt           对应清单（棋局/棋步/胜者/贴目）
data/selfcheck.bin          编码自检样本
HANDOFF.md / AISTUDIO_README.md / README.md
```

> `data/dump.bin` 是关键：有了它，AI Studio 上**不用先编译 C++** 就能直接跑价值头训练。
> 想在上云后重新生成数据，用 g++ 编 `kg/test/dump_enc.cpp` 即可（头文件都带上了）。

**权重不在包里**：`kata1_value_fixed.bin.gz`（250 MB）超过单文件上传限制，按 AI Studio 的
规定要走「数据集」上传。

---

## 二、照这 4 步就能传完（浏览器手动操作，约 3 分钟）

1. 打开 <https://aistudio.baidu.com/>，登录（右上角应能看到「我的控制台」）
2. **我的控制台 → 数据 → 创建数据集**
   - 数据集英文 ID：`goai3`
   - 展示名称：`GoAI3 围棋引擎（KataGo v17 + MCTS + 训练管线）`
   - 是否公开：建议 **私密**
   - 点「创建」
3. 进刚建好的数据集 → **上传文件** → 先传 `aistudio/upload/goai3_code.zip`，
   再传 `kata1_value_fixed.bin.gz`（250 MB；如果上传慢，可以先只传 zip，权重到云端再下载，见下面方案 B）
4. 进「项目」→「创建项目」→ 选 **BML Codelab（Notebook）+ GPU 镜像** →
   在 notebook 里挂载数据集：
   ```bash
   mkdir -p /home/aistudio/work/goai3 && cd /home/aistudio/work/goai3
   unzip /home/aistudio/data/data<id>/goai3_code.zip
   ls data/          # dump.bin / manifest.txt
   ```

数据集 ID（`data<id>` 里的数字）在数据集详情页的 URL 里。

---

## 三、两个"根本不用上传"的替代方案

### 方案 A：把代码粘进 notebook（仓库里原有的思路，已验证可行）
```bat
python aistudio\make_selfextract.py      :: 生成一个自解压脚本
```
打开生成的脚本 → 全选复制 → 粘进 AI Studio notebook 的一个单元格 → 运行 → 文件自动落地。
适合"代码要传、但数据集入口找不到/上传慢"的情况。
（注意：自解压脚本只带代码，不带 24MB 的 dump.bin；dump.bin 可在云端用 g++ 重编 `dump_enc.cpp` 生成。）

### 方案 B：代码 + 权重都让 AI Studio 自己去下（最快）
AI Studio 的机器**能直连 GitHub**（我们这台机器不行），所以：
```bash
# 官方 KataGo 网络（比现在的 b11c768 更小更快的那几个都在这里）
wget -O kata1_b10c384.bin.gz \
  https://github.com/lightvector/KataGo/releases/download/v1.17.1/b10c384h6nbttflrs.bin.gz
# 或者用官方大网络训练
wget -O kata1.bin.gz \
  https://github.com/lightvector/KataGo/releases/download/v1.17.1/b11c768h12nbt3tflrs-fson-silu.bin.gz
```
这样只需要传 3.4 MB 的代码包，**250 MB 权重让云端自己拉**。

---

## 四、为什么没自动传完（诚实说明）

我用浏览器自动化试了 3 次（3 个独立会话），现象一致：

| 尝试 | 结果 |
|---|---|
| 第 1 次：首页 →「数据」→「创建数据集」 | ✅ 表单打开、英文 ID 与展示名称都填进去了；点到「私密」单选后**标签页停止响应** |
| 第 2 次：新开标签直达数据集列表 | ❌ observe/click 全部 30s 超时，随后 transport 断开 |
| 第 3 次：新会话直达 `datasetcreate/create` | ❌ 连 navigate 都 62s 超时 |

判断：AI Studio 是重前端 SPA（一次 observe 就吐上千个节点），**把浏览器自动化的调试通道拖死了**，
不是登录或权限问题（页面里能看到「我的控制台」「令牌」「创建数据集」，说明是已登录状态）。

**要继续自动化的话，有两种更稳的做法（告诉我就行）：**
1. **借用你已经打开的标签页**（`bsk_tabs borrow`）——比新开窗口轻，通常不会把通道拖死；
2. 你先把页面点到「创建数据集」弹窗，我再接手填表 + 提交。
