#!/usr/bin/env bash
# ===========================================================================
#  run_loop.sh -- 在 AI Studio 上跑完整的一轮：自我对弈 -> 训练 -> 导出
#
#  用法:
#    bash run_loop.sh <权重.bin.gz> [轮次] [局数] [visits] [训练步数]
#
#  例:
#    bash run_loop.sh /home/aistudio/data/data123/kata1.bin.gz 1 40 100 2000
#
#  它做的事:
#    1. 检查 GPU
#    2. 自我对弈产数据到 work_data<轮次>/  （不会覆盖上一轮）
#    3. 训练并更新同一个检查点 work_ckpt.pt （--resume 接力）
#    4. 导出 work_kata1_ft.bin.gz
#
#  每一轮都用同一个检查点，所以是"在前一轮成果上继续增强"。
# ===========================================================================
set -e

WEIGHTS="${1:?用法: bash run_loop.sh <权重.bin.gz> [轮次] [局数] [visits] [步数]}"
ROUND="${2:-1}"
GAMES="${3:-40}"
VISITS="${4:-100}"
STEPS="${5:-2000}"

cd "$(dirname "$0")"
HERE="$(pwd)"

DATA="work_data${ROUND}"
CKPT="work_ckpt.pt"
OUT="work_kata1_ft.bin.gz"
START_INDEX=$(( (ROUND - 1) * GAMES ))
SEED=$(( 1000 + ROUND ))

echo "=============================================================="
echo "  第 ${ROUND} 轮"
echo "  权重    : ${WEIGHTS}"
echo "  目录    : ${HERE}"
echo "  局数    : ${GAMES}   visits: ${VISITS}   训练步数: ${STEPS}"
echo "  数据    : ${DATA}   （起始编号 ${START_INDEX}，种子 ${SEED}）"
echo "=============================================================="
echo

# ---------------------------------------------------------------- 1. 环境
echo "[1/4] 检查环境"
python - <<'PY'
import os, sys
import torch
print('  python  :', sys.version.split()[0])
print('  torch   :', torch.__version__)
print('  cuda    :', torch.cuda.is_available())
if not torch.cuda.is_available():
    print('  ** 警告: 没有检测到 CUDA。这一轮会以 CPU 速度运行，')
    print('     visits=%d 时每手可能要好几十秒。建议换 GPU 版镜像。' % int(os.environ.get('VISITS_TMP', 0) or 0))
else:
    print('  gpu     :', torch.cuda.get_device_name(0))
    print('  显存    : %.1f GB' % (torch.cuda.get_device_properties(0).total_memory / 2**30))
PY
echo

if [ ! -f "$WEIGHTS" ]; then
  echo "[错误] 找不到权重: $WEIGHTS"
  exit 1
fi
for f in _kg_pipeline.py _kg_mcts.py _kg_map.py _kg_export.py \
         _katago_v17_load.py _katago_official.py _kg_ref.py _kg_enc.py; do
  if [ ! -f "$f" ]; then echo "[错误] 缺少 $f"; exit 1; fi
done
if [ ! -d "_katago_src" ]; then echo "[错误] 缺少 _katago_src/ 目录"; exit 1; fi
echo "  代码与权重齐备"
echo

# ---------------------------------------------------------------- 2. 自对弈
echo "[2/4] 自我对弈（策略目标 = MCTS 访问分布）"
echo "      预计耗时: 每手约 $(( VISITS * 2 / 100 + 1 ))~$(( VISITS * 5 / 100 + 1 )) 秒（GPU 上）"
python -u _kg_pipeline.py selfplay \
    --weights "$WEIGHTS" \
    --games "$GAMES" --out "$DATA" \
    --mcts-visits "$VISITS" --max-moves 250 \
    --seed "$SEED" --start-index "$START_INDEX" \
    2>&1 | tee "selfplay_r${ROUND}.log"
echo

# ---------------------------------------------------------------- 3. 训练
echo "[3/4] 训练（接力到 ${CKPT}）"
if [ -f "$CKPT" ]; then
  echo "      检测到已有检查点，将用 --resume 在它基础上继续"
  RESUME_ARG="--resume $CKPT"
else
  echo "      没有旧检查点，这是第一轮，从原始权重开始"
  RESUME_ARG=""
fi
python -u _kg_pipeline.py train \
    --weights "$WEIGHTS" \
    --data "$DATA" --steps "$STEPS" \
    --ckpt "$CKPT" $RESUME_ARG --lr 1e-5 \
    2>&1 | tee "train_r${ROUND}.log"
echo

# ---------------------------------------------------------------- 4. 导出
echo "[4/4] 导出成引擎能加载的权重"
python -u _kg_pipeline.py export \
    --weights "$WEIGHTS" --ckpt "$CKPT" --out "$OUT" \
    2>&1 | tee "export_r${ROUND}.log"
echo

echo "=============================================================="
echo "  第 ${ROUND} 轮完成"
echo "  检查点  : ${CKPT}"
echo "  可下载  : ${OUT}"
echo
python _kg_pipeline.py info --ckpt "$CKPT"
echo
echo "  下一轮:  bash run_loop.sh \"$WEIGHTS\" $((ROUND + 1)) $GAMES $VISITS $STEPS"
echo "=============================================================="
