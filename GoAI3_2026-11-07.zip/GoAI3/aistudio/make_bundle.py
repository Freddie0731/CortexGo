# -*- coding: utf-8 -*-
"""把 AI Studio 需要上传的文件收拢到 aistudio/kg/ 目录。

只收真正需要的：代码 + 官方模型定义 + 本文档 + 循环脚本。
**不含权重**（250 MB，请用 AI Studio 的数据集功能单独上传）。

用法: python aistudio/make_bundle.py
"""
import os
import shutil
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
DST = os.path.join(HERE, 'kg')

PY_FILES = [
    '_kg_pipeline.py',      # 自我对弈 / 训练 / 检查点 / 导出
    '_kg_mcts.py',          # PUCT MCTS
    '_kg_export.py',        # 原地字节打补丁导出
    '_kg_map.py',           # 块序号 <-> 层名映射
    '_katago_v17_load.py',  # .bin.gz 解析器
    '_katago_official.py',  # 加载官方 model_pytorch.py
    '_kg_ref.py',           # .bin.gz -> state_dict
    '_kg_enc.py',           # Python V7 输入编码
]

SRC_DIRS = ['_katago_src']
DOCS = ['README.md', 'run_loop.sh']


def main():
    if os.path.isdir(DST):
        shutil.rmtree(DST)
    os.makedirs(DST)

    missing = []
    n = 0
    for f in PY_FILES:
        src = os.path.join(ROOT, f)
        if not os.path.isfile(src):
            missing.append(f)
            continue
        shutil.copy2(src, os.path.join(DST, f))
        n += 1

    for d in SRC_DIRS:
        src = os.path.join(ROOT, d)
        if not os.path.isdir(src):
            missing.append(d + '/')
            continue
        # 只拷 .py，跳过 __pycache__
        dst_d = os.path.join(DST, d)
        os.makedirs(dst_d, exist_ok=True)
        for name in os.listdir(src):
            p = os.path.join(src, name)
            if os.path.isfile(p) and name.endswith('.py'):
                shutil.copy2(p, os.path.join(dst_d, name))
                n += 1

    for f in DOCS:
        src = os.path.join(HERE, f)
        if os.path.isfile(src):
            shutil.copy2(src, os.path.join(DST, f))
            n += 1

    total = 0
    print('打包到 %s' % DST)
    for dirpath, dirnames, filenames in os.walk(DST):
        dirnames[:] = [d for d in dirnames if d != '__pycache__']
        for name in sorted(filenames):
            p = os.path.join(dirpath, name)
            sz = os.path.getsize(p)
            total += sz
            rel = os.path.relpath(p, DST)
            print('  %-40s %8.1f KB' % (rel, sz / 1024.0))
    print('  共 %d 个文件, %.1f MB' % (n, total / 1e6))
    if missing:
        print()
        print('  !! 缺少以下文件（请确认路径）:')
        for m in missing:
            print('     %s' % m)
        return 1
    print()
    print('下一步: 把 %s 整个目录传到 AI Studio 的 /home/aistudio/work/' % DST)
    print('        权重 kata1.bin.gz 用「数据集」功能单独上传（250 MB）')
    print('        然后在里面: bash run_loop.sh <权重路径> 1 40 100 2000')
    return 0


if __name__ == '__main__':
    sys.exit(main())
