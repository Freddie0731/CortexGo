#!/usr/bin/python3
"""
This file contains a bunch of configs for models of different sizes.
See the bottom of this file "base_config_of_name" for a dictionary of all the different
base model architectures, and which ones are recommended of each different model size.

For each base model, additional configs are also pregenerated with different suffixes.

For example, for b10c384nbt, we also have models like:
b10c384nbt-mish  (use mish instead of relu)
b10c384nbt-bn-mish-rvgl (use batchnorm, mish, and repvgg-linear-style convolutions).

KataGo's main models for the distributed training run currently find the following to work
well or best: "-fson-mish-rvgl-bnh"
* Use fixed activation scale initialization + one batch norm for the whole net
* Mish activation
* Repvgg-linear-style convolutions
* Batch norm output head + non-batch-norm output head, where the former drives optimization
  but the latter is used for inference.
"""

from typing import Dict, Any, Union

ModelConfig = Dict[str,Any]

# version = 0 # V1 features, with old head architecture using crelus (no longer supported)
# version = 1 # V1 features, with new head architecture, no crelus
# version = 2 # V2 features, no internal architecture change.
# version = 3 # V3 features, selfplay-planned features with lots of aux targets
# version = 4 # V3 features, but supporting belief stdev and dynamic scorevalue
# version = 5 # V4 features, slightly different pass-alive stones feature
# version = 6 # V5 features, most higher-level go features removed
# version = 7 # V6 features, more rules support
# version = 8 # V7 features, asym, lead, variance time
# version = 9 # V7 features, shortterm value error prediction, inference actually uses variance time, unsupported now
# version = 10 # V7 features, shortterm value error prediction done properly
# version = 11 # V7 features, New architectures!
# version = 12 # V7 features, Optimistic policy head
# version = 13 # V7 features, Adjusted scaling on shortterm score variance, and made C++ side read in scalings.
# version = 14 # V7 features, Squared softplus for error variance predictions
# version = 15 # V7 features, Extra nonlinearity for pass output
# version = 16 # V7 features, Q value predictions in the policy head
# version = 17 # V7 features, Q value predictions made optional (config "predict_q_values"), introduced transformers and added guards to unused params

def get_version(config: ModelConfig):
    return config["version"]

def get_num_bin_input_features(config: ModelConfig):
    version = get_version(config)
    if version == 10 or version == 11 or version == 12 or version == 13 or version == 14 or version == 15 or version == 16 or version == 17:
        return 22
    else:
        assert(False)

def get_num_global_input_features(config: ModelConfig):
    version = get_version(config)
    if version == 10 or version == 11 or version == 12 or version == 13 or version == 14 or version == 15 or version == 16 or version == 17:
        return 19
    else:
        assert(False)

def get_num_meta_encoder_input_features(config_or_meta_encoder_version: Union[ModelConfig,int]):
    if isinstance(config_or_meta_encoder_version,int):
        version = config_or_meta_encoder_version
    else:
        if "metadata_encoder" not in config:
            version = 0
        elif "meta_encoder_version" not in config["metadata_encoder"]:
            version = 1
        else:
            version = config["metadata_encoder"]["meta_encoder_version"]
    assert version == 1
    return 192

b1c6nbt = {
    "version":15,
    "norm_kind":"fixup",
    "bnorm_epsilon": 1e-4,
    "bnorm_running_avg_momentum": 0.001,
    "initial_conv_1x1": False,
    "trunk_num_channels":6,
    "mid_num_channels":4,
    "gpool_num_channels":4,
    "gamma_weight_decay_center_1":True,
    "block_kind": [
        ["rconv1","bottlenest2"],
    ],
    "p1_num_channels":4,
    "g1_num_channels":4,
    "v1_num_channels":4,
    "sbv2_num_channels":4,
    "num_scorebeliefs":2,
    "v2_size":6,
}

b2c16 = {
    "version":15,
    "norm_kind":"fixup",
    "bnorm_epsilon": 1e-4,
    "bnorm_running_avg_momentum": 0.001,
    "initial_conv_1x1": False,
    "trunk_num_channels":16,
    "mid_num_channels":16,
    "gpool_num_channels":8,
    "gamma_weight_decay_center_1":True,
    "block_kind": [
        ["rconv1","regular"],
        ["rconv2","regulargpool"],
    ],
    "p1_num_channels":8,
    "g1_num_channels":8,
    "v1_num_channels":8,
    "sbv2_num_channels":12,
    "num_scorebeliefs":2,
    "v2_size":12,
}

b4c32 = {
    "version":15,
    "norm_kind":"fixup",
    "bnorm_epsilon": 1e-4,
    "bnorm_running_avg_momentum": 0.001,
    "initial_conv_1x1": False,
    "trunk_num_channels":32,
    "mid_num_channels":32,
    "gpool_num_channels":16,
    "gamma_weight_decay_center_1":True,
    "block_kind": [
        ["rconv1","regular"],
        ["rconv2","regular"],
        ["rconv3","regulargpool"],
        ["rconv4","regular"],
    ],
    "p1_num_channels":12,
    "g1_num_channels":12,
    "v1_num_channels":12,
    "sbv2_num_channels":24,
    "num_scorebeliefs":4,
    "v2_size":24,
}

b6c96 = {
    "version":15,
    "norm_kind":"fixup",
    "bnorm_epsilon": 1e-4,
    "bnorm_running_avg_momentum": 0.001,
    "initial_conv_1x1": False,
    "trunk_num_channels":96,
    "mid_num_channels":96,
    "gpool_num_channels":32,
    "gamma_weight_decay_center_1":True,
    "block_kind": [
        ["rconv1","regular"],
        ["rconv2","regular"],
        ["rconv3","regulargpool"],
        ["rconv4","regular"],
        ["rconv5","regulargpool"],
        ["rconv6","regular"],
    ],
    "p1_num_channels":32,
    "g1_num_channels":32,
    "v1_num_channels":32,
    "sbv2_num_channels":48,
    "num_scorebeliefs":4,
    "v2_size":64,
}

b10c128 = {
    "version":15,
    "norm_kind":"fixup",
    "bnorm_epsilon": 1e-4,
    "bnorm_running_avg_momentum": 0.001,
    "initial_conv_1x1": False,
    "trunk_num_channels":128,
    "mid_num_channels":128,
    "gpool_num_channels":32,
    "gamma_weight_decay_center_1":True,
    "block_kind": [
        ["rconv1","regular"],
        ["rconv2","regular"],
        ["rconv3","regular"],
        ["rconv4","regular"],
        ["rconv5","regulargpool"],
        ["rconv6","regular"],
        ["rconv7","regular"],
        ["rconv8","regulargpool"],
        ["rconv9","regular"],
        ["rconv10","regular"],
    ],
    "p1_num_channels":32,
    "g1_num_channels":32,
    "v1_num_channels":32,
    "sbv2_num_channels":64,
    "num_scorebeliefs":6,
    "v2_size":80,
}

b5c192nbt = {
    "version":15,
    "norm_kind":"fixup",
    "bnorm_epsilon": 1e-4,
    "bnorm_running_avg_momentum": 0.001,
    "initial_conv_1x1": False,
    "trunk_num_channels":192,
    "mid_num_channels":96,
    "gpool_num_channels":32,
    "gamma_weight_decay_center_1":True,
    "block_kind": [
        ["rconv1","bottlenest2"],
        ["rconv2","bottlenest2gpool"],
        ["rconv3","bottlenest2"],
        ["rconv4","bottlenest2gpool"],
        ["rconv5","bottlenest2"],
    ],
    "p1_num_channels":32,
    "g1_num_channels":32,
    "v1_num_channels":32,
    "sbv2_num_channels":64,
    "num_scorebeliefs":6,
    "v2_size":80,
}

b8c192nbt = {
    "version":15,
    "norm_kind":"fixup",
    "bnorm_epsilon": 1e-4,
    "bnorm_running_avg_momentum": 0.001,
    "initial_conv_1x1": False,
    "trunk_num_channels":192,
    "mid_num_channels":96,
    "gpool_num_channels":32,
    "gamma_weight_decay_center_1":True,
    "block_kind": [
        ["rconv1","bottlenest2"],
        ["rconv2","bottlenest2"],
        ["rconv3","bottlenest2gpool"],
        ["rconv4","bottlenest2"],
        ["rconv5","bottlenest2"],
        ["rconv6","bottlenest2gpool"],
        ["rconv7","bottlenest2"],
        ["rconv8","bottlenest2"],
    ],
    "p1_num_channels":32,
    "g1_num_channels":32,
    "v1_num_channels":32,
    "sbv2_num_channels":64,
    "num_scorebeliefs":6,
    "v2_size":80,
}

b15c192 = {
    "version":15,
    "norm_kind":"fixup",
    "bnorm_epsilon": 1e-4,
    "bnorm_running_avg_momentum": 0.001,
    "initial_conv_1x1": False,
    "trunk_num_channels":192,
    "mid_num_channels":192,
    "gpool_num_channels":64,
    "gamma_weight_decay_center_1":True,
    "block_kind": [
        ["rconv1","regular"],
        ["rconv2","regular"],
        ["rconv3","regular"],
        ["rconv4","regular"],
        ["rconv5","regular"],
        ["rconv6","regular"],
        ["rconv7","regulargpool"],
        ["rconv8","regular"],
        ["rconv9","regular"],
        ["rconv10","regular"],
        ["rconv11","regular"],
        ["rconv12","regulargpool"],
        ["rconv13","regular"],
        ["rconv14","regular"],
        ["rconv15","regular"],
    ],
    "p1_num_channels":32,
    "g1_num_channels":32,
    "v1_num_channels":32,
    "sbv2_num_channels":80,
    "num_scorebeliefs":8,
    "v2_size":96,
}

b10c256nbt = {
    "version":15,
    "norm_kind":"fixup",
    "bnorm_epsilon": 1e-4,
    "bnorm_running_avg_momentum": 0.001,
    "initial_conv_1x1": False,
    "trunk_num_channels":256,
    "mid_num_channels":128,
    "gpool_num_channels":64,
    "gamma_weight_decay_center_1":True,
    "block_kind": [
        ["rconv1","bottlenest2"],
        ["rconv2","bottlenest2"],
        ["rconv3","bottlenest2gpool"],
        ["rconv4","bottlenest2"],
        ["rconv5","bottlenest2"],
        ["rconv6","bottlenest2gpool"],
        ["rconv7","bottlenest2"],
        ["rconv8","bottlenest2"],
        ["rconv9","bottlenest2gpool"],
        ["rconv10","bottlenest2"],
    ],
    "p1_num_channels":32,
    "g1_num_channels":32,
    "v1_num_channels":32,
    "sbv2_num_channels":80,
    "num_scorebeliefs":8,
    "v2_size":96,
}

b20c256 = {
    "version":15,
    "norm_kind":"fixup",
    "bnorm_epsilon": 1e-4,
    "bnorm_running_avg_momentum": 0.001,
    "initial_conv_1x1": False,
    "trunk_num_channels":256,
    "mid_num_channels":256,
    "gpool_num_channels":64,
    "gamma_weight_decay_center_1":True,
    "block_kind": [
        ["rconv1","regular"],
        ["rconv2","regular"],
        ["rconv3","regular"],
        ["rconv4","regular"],
        ["rconv5","regular"],
        ["rconv6","regular"],
        ["rconv7","regulargpool"],
        ["rconv8","regular"],
        ["rconv9","regular"],
        ["rconv10","regular"],
        ["rconv11","regular"],
        ["rconv12","regulargpool"],
        ["rconv13","regular"],
        ["rconv14","regular"],
        ["rconv15","regular"],
        ["rconv16","regular"],
        ["rconv17","regulargpool"],
        ["rconv18","regular"],
        ["rconv19","regular"],
        ["rconv20","regular"],
    ],
    "p1_num_channels":48,
    "g1_num_channels":48,
    "v1_num_channels":48,
    "sbv2_num_channels":96,
    "num_scorebeliefs":8,
    "v2_size":112,
}

b20c384bt = {
    "version":15,
    "norm_kind":"fixup",
    "bnorm_epsilon": 1e-4,
    "bnorm_running_avg_momentum": 0.001,
    "initial_conv_1x1": False,
    "trunk_num_channels":384,
    "mid_num_channels":192,
    "gpool_num_channels":64,
    "gamma_weight_decay_center_1":True,
    "block_kind": [
        ["rconv1","bottle"],
        ["rconv2","bottle"],
        ["rconv3","bottle"],
        ["rconv4","bottle"],
        ["rconv5","bottle"],
        ["rconv6","bottlegpool"],
        ["rconv7","bottle"],
        ["rconv8","bottle"],
        ["rconv9","bottle"],
        ["rconv10","bottle"],
        ["rconv11","bottlegpool"],
        ["rconv12","bottle"],
        ["rconv13","bottle"],
        ["rconv14","bottle"],
        ["rconv15","bottle"],
        ["rconv16","bottlegpool"],
        ["rconv17","bottle"],
        ["rconv18","bottle"],
        ["rconv19","bottle"],
        ["rconv20","bottle"],
    ],
    "p1_num_channels":48,
    "g1_num_channels":48,
    "v1_num_channels":48,
    "sbv2_num_channels":96,
    "num_scorebeliefs":8,
    "v2_size":112,
}


b15c384lbt = {
    "version":15,
    "norm_kind":"fixup",
    "bnorm_epsilon": 1e-4,
    "bnorm_running_avg_momentum": 0.001,
    "initial_conv_1x1": False,
    "trunk_num_channels":384,
    "mid_num_channels":192,
    "gpool_num_channels":64,
    "gamma_weight_decay_center_1":True,
    "block_kind": [
        ["rconv1","bottle2"],
        ["rconv2","bottle2"],
        ["rconv3","bottle2"],
        ["rconv4","bottle2gpool"],
        ["rconv5","bottle2"],
        ["rconv6","bottle2"],
        ["rconv7","bottle2"],
        ["rconv8","bottle2gpool"],
        ["rconv9","bottle2"],
        ["rconv10","bottle2"],
        ["rconv11","bottle2"],
        ["rconv12","bottle2gpool"],
        ["rconv13","bottle2"],
        ["rconv14","bottle2"],
        ["rconv15","bottle2"],
    ],
    "p1_num_channels":48,
    "g1_num_channels":48,
    "v1_num_channels":48,
    "sbv2_num_channels":96,
    "num_scorebeliefs":8,
    "v2_size":112,
}


b10c384nbt = {
    "version":15,
    "norm_kind":"fixup",
    "bnorm_epsilon": 1e-4,
    "bnorm_running_avg_momentum": 0.001,
    "initial_conv_1x1": False,
    "trunk_num_channels":384,
    "mid_num_channels":192,
    "gpool_num_channels":64,
    "gamma_weight_decay_center_1":True,
    "block_kind": [
        ["rconv1","bottlenest2"],
        ["rconv2","bottlenest2"],
        ["rconv3","bottlenest2gpool"],
        ["rconv4","bottlenest2"],
        ["rconv5","bottlenest2"],
        ["rconv6","bottlenest2gpool"],
        ["rconv7","bottlenest2"],
        ["rconv8","bottlenest2"],
        ["rconv9","bottlenest2gpool"],
        ["rconv10","bottlenest2"],
    ],
    "p1_num_channels":48,
    "g1_num_channels":48,
    "v1_num_channels":48,
    "sbv2_num_channels":96,
    "num_scorebeliefs":8,
    "v2_size":112,
}


b10c480nb3t = {
    "version":15,
    "norm_kind":"fixup",
    "bnorm_epsilon": 1e-4,
    "bnorm_running_avg_momentum": 0.001,
    "initial_conv_1x1": False,
    "trunk_num_channels":480,
    "mid_num_channels":160,
    "gpool_num_channels":64,
    "gamma_weight_decay_center_1":True,
    "block_kind": [
        ["rconv1","bottlenest2"],
        ["rconv2","bottlenest2"],
        ["rconv3","bottlenest2gpool"],
        ["rconv4","bottlenest2"],
        ["rconv5","bottlenest2"],
        ["rconv6","bottlenest2gpool"],
        ["rconv7","bottlenest2"],
        ["rconv8","bottlenest2"],
        ["rconv9","bottlenest2gpool"],
        ["rconv10","bottlenest2"],
    ],
    "p1_num_channels":48,
    "g1_num_channels":48,
    "v1_num_channels":48,
    "sbv2_num_channels":96,
    "num_scorebeliefs":8,
    "v2_size":112,
}


b30c320 = {
    "version":15,
    "norm_kind":"fixup",
    "bnorm_epsilon": 1e-4,
    "bnorm_running_avg_momentum": 0.001,
    "initial_conv_1x1": False,
    "trunk_num_channels":320,
    "mid_num_channels":320,
    "gpool_num_channels":96,
    "gamma_weight_decay_center_1":True,
    "block_kind": [
        ["rconv1","regular"],
        ["rconv2","regular"],
        ["rconv3","regular"],
        ["rconv4","regular"],
        ["rconv5","regular"],
        ["rconv6","regulargpool"],
        ["rconv7","regular"],
        ["rconv8","regular"],
        ["rconv9","regular"],
        ["rconv10","regular"],
        ["rconv11","regulargpool"],
        ["rconv12","regular"],
        ["rconv13","regular"],
        ["rconv14","regular"],
        ["rconv15","regular"],
        ["rconv16","regulargpool"],
        ["rconv17","regular"],
        ["rconv18","regular"],
        ["rconv19","regular"],
        ["rconv20","regular"],
        ["rconv21","regulargpool"],
        ["rconv22","regular"],
        ["rconv23","regular"],
        ["rconv24","regular"],
        ["rconv25","regular"],
        ["rconv26","regulargpool"],
        ["rconv27","regular"],
        ["rconv28","regular"],
        ["rconv29","regular"],
        ["rconv30","regular"],
    ],
    "p1_num_channels":48,
    "g1_num_channels":48,
    "v1_num_channels":96,
    "sbv2_num_channels":112,
    "num_scorebeliefs":8,
    "v2_size":128,
}

b40c256 = {
    "version":15,
    "norm_kind":"fixup",
    "bnorm_epsilon": 1e-4,
    "bnorm_running_avg_momentum": 0.001,
    "initial_conv_1x1": False,
    "trunk_num_channels":256,
    "mid_num_channels":256,
    "gpool_num_channels":64,
    "gamma_weight_decay_center_1":True,
    "block_kind": [
        ["rconv1","regular"],
        ["rconv2","regular"],
        ["rconv3","regular"],
        ["rconv4","regular"],
        ["rconv5","regular"],
        ["rconv6","regulargpool"],
        ["rconv7","regular"],
        ["rconv8","regular"],
        ["rconv9","regular"],
        ["rconv10","regular"],
        ["rconv11","regulargpool"],
        ["rconv12","regular"],
        ["rconv13","regular"],
        ["rconv14","regular"],
        ["rconv15","regular"],
        ["rconv16","regulargpool"],
        ["rconv17","regular"],
        ["rconv18","regular"],
        ["rconv19","regular"],
        ["rconv20","regular"],
        ["rconv21","regulargpool"],
        ["rconv22","regular"],
        ["rconv23","regular"],
        ["rconv24","regular"],
        ["rconv25","regular"],
        ["rconv26","regulargpool"],
        ["rconv27","regular"],
        ["rconv28","regular"],
        ["rconv29","regular"],
        ["rconv30","regular"],
        ["rconv31","regulargpool"],
        ["rconv32","regular"],
        ["rconv33","regular"],
        ["rconv34","regular"],
        ["rconv35","regular"],
        ["rconv36","regulargpool"],
        ["rconv37","regular"],
        ["rconv38","regular"],
        ["rconv39","regular"],
        ["rconv40","regular"],
    ],
    "p1_num_channels":48,
    "g1_num_channels":48,
    "v1_num_channels":96,
    "sbv2_num_channels":112,
    "num_scorebeliefs":8,
    "v2_size":128,
}

b18c384nbt = {
    "version":15,
    "norm_kind":"fixup",
    "bnorm_epsilon": 1e-4,
    "bnorm_running_avg_momentum": 0.001,
    "initial_conv_1x1": False,
    "trunk_num_channels":384,
    "mid_num_channels":192,
    "gpool_num_channels":64,
    "gamma_weight_decay_center_1":True,
    "block_kind": [
        ["rconv1","bottlenest2"],
        ["rconv2","bottlenest2"],
        ["rconv3","bottlenest2gpool"],
        ["rconv4","bottlenest2"],
        ["rconv5","bottlenest2"],
        ["rconv6","bottlenest2gpool"],
        ["rconv7","bottlenest2"],
        ["rconv8","bottlenest2"],
        ["rconv9","bottlenest2gpool"],
        ["rconv10","bottlenest2"],
        ["rconv11","bottlenest2"],
        ["rconv12","bottlenest2gpool"],
        ["rconv13","bottlenest2"],
        ["rconv14","bottlenest2"],
        ["rconv15","bottlenest2gpool"],
        ["rconv16","bottlenest2"],
        ["rconv17","bottlenest2"],
        ["rconv18","bottlenest2"],
    ],
    "p1_num_channels":48,
    "g1_num_channels":48,
    "v1_num_channels":96,
    "sbv2_num_channels":112,
    "num_scorebeliefs":8,
    "v2_size":128,
}

b18c384dnbt1 = {
    "version":15,
    "norm_kind":"fixup",
    "bnorm_epsilon": 1e-4,
    "bnorm_running_avg_momentum": 0.001,
    "initial_conv_1x1": False,
    "trunk_num_channels":384,
    "mid_num_channels":192,
    "gpool_num_channels":64,
    "gamma_weight_decay_center_1":True,
    "block_kind": [
        ["rconv1","bottlenest2"],
        ["rconv2","bottlenest2"],
        ["rconv3","bottlenest2gpool"],
        ["rconv4","bottlenest2"],
        ["rconv5","bottlenest2"],
        ["rconv6","bottlenest2gpool"],
        ["rconv7","bottlenest2"],
        ["rconv8","bottlenest2"],
        ["rconv9","bottlenest2gpool"],
        ["rconv10","dilatedbottlenest2"],
        ["rconv11","bottlenest2"],
        ["rconv12","bottlenest2gpool"],
        ["rconv13","bottlenest2"],
        ["rconv14","bottlenest2"],
        ["rconv15","bottlenest2gpool"],
        ["rconv16","bottlenest2"],
        ["rconv17","bottlenest2"],
        ["rconv18","bottlenest2"],
    ],
    "p1_num_channels":48,
    "g1_num_channels":48,
    "v1_num_channels":96,
    "sbv2_num_channels":112,
    "num_scorebeliefs":8,
    "v2_size":128,
}

b40c384 = {
    "version":15,
    "norm_kind":"fixup",
    "bnorm_epsilon": 1e-4,
    "bnorm_running_avg_momentum": 0.001,
    "initial_conv_1x1": False,
    "trunk_num_channels":384,
    "mid_num_channels":384,
    "gpool_num_channels":128,
    "gamma_weight_decay_center_1":True,
    "block_kind": [
        ["rconv1","regular"],
        ["rconv2","regular"],
        ["rconv3","regular"],
        ["rconv4","regular"],
        ["rconv5","regular"],
        ["rconv6","regulargpool"],
        ["rconv7","regular"],
        ["rconv8","regular"],
        ["rconv9","regular"],
        ["rconv10","regular"],
        ["rconv11","regulargpool"],
        ["rconv12","regular"],
        ["rconv13","regular"],
        ["rconv14","regular"],
        ["rconv15","regular"],
        ["rconv16","regulargpool"],
        ["rconv17","regular"],
        ["rconv18","regular"],
        ["rconv19","regular"],
        ["rconv20","regular"],
        ["rconv21","regulargpool"],
        ["rconv22","regular"],
        ["rconv23","regular"],
        ["rconv24","regular"],
        ["rconv25","regular"],
        ["rconv26","regulargpool"],
        ["rconv27","regular"],
        ["rconv28","regular"],
        ["rconv29","regular"],
        ["rconv30","regular"],
        ["rconv31","regulargpool"],
        ["rconv32","regular"],
        ["rconv33","regular"],
        ["rconv34","regular"],
        ["rconv35","regular"],
        ["rconv36","regulargpool"],
        ["rconv37","regular"],
        ["rconv38","regular"],
        ["rconv39","regular"],
        ["rconv40","regular"],
    ],
    "p1_num_channels":64,
    "g1_num_channels":64,
    "v1_num_channels":96,
    "sbv2_num_channels":128,
    "num_scorebeliefs":8,
    "v2_size":144,
}


b60c320 = {
    "version":15,
    "norm_kind":"fixup",
    "bnorm_epsilon": 1e-4,
    "bnorm_running_avg_momentum": 0.001,
    "initial_conv_1x1": False,
    "trunk_num_channels":320,
    "mid_num_channels":320,
    "gpool_num_channels":96,
    "gamma_weight_decay_center_1":True,
    "block_kind": [
        ["rconv1","regular"],
        ["rconv2","regular"],
        ["rconv3","regular"],
        ["rconv4","regular"],
        ["rconv5","regular"],
        ["rconv6","regulargpool"],
        ["rconv7","regular"],
        ["rconv8","regular"],
        ["rconv9","regular"],
        ["rconv10","regular"],
        ["rconv11","regulargpool"],
        ["rconv12","regular"],
        ["rconv13","regular"],
        ["rconv14","regular"],
        ["rconv15","regular"],
        ["rconv16","regulargpool"],
        ["rconv17","regular"],
        ["rconv18","regular"],
        ["rconv19","regular"],
        ["rconv20","regular"],
        ["rconv21","regulargpool"],
        ["rconv22","regular"],
        ["rconv23","regular"],
        ["rconv24","regular"],
        ["rconv25","regular"],
        ["rconv26","regulargpool"],
        ["rconv27","regular"],
        ["rconv28","regular"],
        ["rconv29","regular"],
        ["rconv30","regular"],
        ["rconv31","regulargpool"],
        ["rconv32","regular"],
        ["rconv33","regular"],
        ["rconv34","regular"],
        ["rconv35","regular"],
        ["rconv36","regulargpool"],
        ["rconv37","regular"],
        ["rconv38","regular"],
        ["rconv39","regular"],
        ["rconv40","regular"],
        ["rconv41","regulargpool"],
        ["rconv42","regular"],
        ["rconv43","regular"],
        ["rconv44","regular"],
        ["rconv45","regular"],
        ["rconv46","regulargpool"],
        ["rconv47","regular"],
        ["rconv48","regular"],
        ["rconv49","regular"],
        ["rconv50","regular"],
        ["rconv51","regulargpool"],
        ["rconv52","regular"],
        ["rconv53","regular"],
        ["rconv54","regular"],
        ["rconv55","regular"],
        ["rconv56","regulargpool"],
        ["rconv57","regular"],
        ["rconv58","regular"],
        ["rconv59","regular"],
        ["rconv60","regular"],
    ],
    "p1_num_channels":64,
    "g1_num_channels":64,
    "v1_num_channels":96,
    "sbv2_num_channels":128,
    "num_scorebeliefs":8,
    "v2_size":144,
}


b32c448nbt = {
    "version":15,
    "norm_kind":"fixup",
    "bnorm_epsilon": 1e-4,
    "bnorm_running_avg_momentum": 0.001,
    "initial_conv_1x1": False,
    "trunk_num_channels":448,
    "mid_num_channels":224,
    "gpool_num_channels":64,
    "gamma_weight_decay_center_1":True,
    "block_kind": [
        ["rconv1","bottlenest2"],
        ["rconv2","bottlenest2"],
        ["rconv3","bottlenest2gpool"],
        ["rconv4","bottlenest2"],
        ["rconv5","bottlenest2"],
        ["rconv6","bottlenest2gpool"],
        ["rconv7","bottlenest2"],
        ["rconv8","bottlenest2"],
        ["rconv9","bottlenest2gpool"],
        ["rconv10","bottlenest2"],
        ["rconv11","bottlenest2"],
        ["rconv12","bottlenest2gpool"],
        ["rconv13","bottlenest2"],
        ["rconv14","bottlenest2"],
        ["rconv15","bottlenest2gpool"],
        ["rconv16","bottlenest2"],
        ["rconv17","bottlenest2"],
        ["rconv18","bottlenest2gpool"],
        ["rconv19","bottlenest2"],
        ["rconv20","bottlenest2"],
        ["rconv21","bottlenest2gpool"],
        ["rconv22","bottlenest2"],
        ["rconv23","bottlenest2"],
        ["rconv24","bottlenest2gpool"],
        ["rconv25","bottlenest2"],
        ["rconv26","bottlenest2"],
        ["rconv27","bottlenest2gpool"],
        ["rconv28","bottlenest2"],
        ["rconv29","bottlenest2"],
        ["rconv30","bottlenest2gpool"],
        ["rconv31","bottlenest2"],
        ["rconv32","bottlenest2"],
    ],
    "p1_num_channels":64,
    "g1_num_channels":64,
    "v1_num_channels":96,
    "sbv2_num_channels":128,
    "num_scorebeliefs":8,
    "v2_size":144,
}


b28c512nbt = {
    "version":15,
    "norm_kind":"fixup",
    "bnorm_epsilon": 1e-4,
    "bnorm_running_avg_momentum": 0.001,
    "initial_conv_1x1": False,
    "trunk_num_channels":512,
    "mid_num_channels":256,
    "gpool_num_channels":64,
    "gamma_weight_decay_center_1":True,
    "block_kind": [
        ["rconv1","bottlenest2"],
        ["rconv2","bottlenest2"],
        ["rconv3","bottlenest2gpool"],
        ["rconv4","bottlenest2"],
        ["rconv5","bottlenest2"],
        ["rconv6","bottlenest2gpool"],
        ["rconv7","bottlenest2"],
        ["rconv8","bottlenest2"],
        ["rconv9","bottlenest2gpool"],
        ["rconv10","bottlenest2"],
        ["rconv11","bottlenest2"],
        ["rconv12","bottlenest2gpool"],
        ["rconv13","bottlenest2"],
        ["rconv14","bottlenest2"],
        ["rconv15","bottlenest2gpool"],
        ["rconv16","bottlenest2"],
        ["rconv17","bottlenest2"],
        ["rconv18","bottlenest2gpool"],
        ["rconv19","bottlenest2"],
        ["rconv20","bottlenest2"],
        ["rconv21","bottlenest2gpool"],
        ["rconv22","bottlenest2"],
        ["rconv23","bottlenest2"],
        ["rconv24","bottlenest2gpool"],
        ["rconv25","bottlenest2"],
        ["rconv26","bottlenest2"],
        ["rconv27","bottlenest2gpool"],
        ["rconv28","bottlenest2"],
    ],
    "p1_num_channels":64,
    "g1_num_channels":64,
    "v1_num_channels":128,
    "sbv2_num_channels":128,
    "num_scorebeliefs":8,
    "v2_size":144,
}

b40c768nbt = {
    "version":15,
    "norm_kind":"fixup",
    "bnorm_epsilon": 1e-4,
    "bnorm_running_avg_momentum": 0.001,
    "initial_conv_1x1": False,
    "trunk_num_channels":768,
    "mid_num_channels":384,
    "gpool_num_channels":128,
    "gamma_weight_decay_center_1":True,
    "block_kind": [
        [f"rconv{i}", "bottlenest2gpool" if i % 3 == 0 else "bottlenest2"]
        for i in range(1, 41)
    ],
    "p1_num_channels":128,
    "g1_num_channels":128,
    "v1_num_channels":256,
    "sbv2_num_channels":256,
    "num_scorebeliefs":8,
    "v2_size":256,
}

b20c640nbt = {
    "version":15,
    "norm_kind":"fixup",
    "bnorm_epsilon": 1e-4,
    "bnorm_running_avg_momentum": 0.001,
    "initial_conv_1x1": False,
    "trunk_num_channels":640,
    "mid_num_channels":320,
    "gpool_num_channels":96,
    "gamma_weight_decay_center_1":True,
    "block_kind": [
        ["rconv1","bottlenest2"],
        ["rconv2","bottlenest2"],
        ["rconv3","bottlenest2gpool"],
        ["rconv4","bottlenest2"],
        ["rconv5","bottlenest2"],
        ["rconv6","bottlenest2gpool"],
        ["rconv7","bottlenest2"],
        ["rconv8","bottlenest2"],
        ["rconv9","bottlenest2gpool"],
        ["rconv10","bottlenest2"],
        ["rconv11","bottlenest2"],
        ["rconv12","bottlenest2gpool"],
        ["rconv13","bottlenest2"],
        ["rconv14","bottlenest2"],
        ["rconv15","bottlenest2gpool"],
        ["rconv16","bottlenest2"],
        ["rconv17","bottlenest2"],
        ["rconv18","bottlenest2gpool"],
        ["rconv19","bottlenest2"],
        ["rconv20","bottlenest2"],
    ],
    "p1_num_channels":64,
    "g1_num_channels":64,
    "v1_num_channels":96,
    "sbv2_num_channels":128,
    "num_scorebeliefs":8,
    "v2_size":144,
}

b5c48h3tfr = {
    "version":17,
    "norm_kind":"fixup",
    "bnorm_epsilon": 1e-4,
    "bnorm_running_avg_momentum": 0.001,
    "initial_conv_1x1": False,
    "gamma_weight_decay_center_1":True,
    "trunk_num_channels":48,
    "mid_num_channels":48,
    "gpool_num_channels":32,
    "transformer_ffn_channels":128,
    "transformer_heads":3,
    "transformer_kv_heads":3,
    "block_kind": [item for i in range(1,6) for item in [[f"attn{i}","attnrope"],[f"ffn{i}","ffng"]]],
    "p1_num_channels":16,
    "g1_num_channels":16,
    "v1_num_channels":16,
    "sbv2_num_channels":32,
    "num_scorebeliefs":4,
    "v2_size":48,
}

b7c96h3tfrs = {
    "version":17,
    "norm_kind":"fixup",
    "bnorm_epsilon": 1e-4,
    "bnorm_running_avg_momentum": 0.001,
    "initial_conv_1x1": False,
    "gamma_weight_decay_center_1":True,
    "trunk_num_channels":96,
    "mid_num_channels":96,
    "gpool_num_channels":32,
    "transformer_ffn_channels":256,
    "transformer_heads":3,
    "transformer_kv_heads":3,
    "block_kind": [item for i in range(1,8) for item in [[f"attn{i}","attnrope"],[f"ffn{i}","ffnsg"]]],
    "p1_num_channels":32,
    "g1_num_channels":32,
    "v1_num_channels":32,
    "sbv2_num_channels":48,
    "num_scorebeliefs":4,
    "v2_size":64,
}

# Like b7c96h3tfrs but with grouped-query attention (6 query heads, 3 KV heads), explicit
# query/key head dim 32 and value head dim 16, and learnable RoPE.
b7c96h6kv3qk32v16tflrs = {
    "version":17,
    "norm_kind":"fixup",
    "bnorm_epsilon": 1e-4,
    "bnorm_running_avg_momentum": 0.001,
    "initial_conv_1x1": False,
    "gamma_weight_decay_center_1":True,
    "trunk_num_channels":96,
    "mid_num_channels":96,
    "gpool_num_channels":32,
    "transformer_ffn_channels":256,
    "transformer_heads":6,
    "transformer_kv_heads":3,
    "attention_query_head_dim":32,
    "attention_value_head_dim":16,
    "learnable_rope":True,
    "block_kind": [item for i in range(1,8) for item in [[f"attn{i}","attnrope"],[f"ffn{i}","ffnsg"]]],
    "p1_num_channels":32,
    "g1_num_channels":32,
    "v1_num_channels":32,
    "sbv2_num_channels":48,
    "num_scorebeliefs":4,
    "v2_size":64,
}

b8c96h3tfrs = {
    "version":17,
    "norm_kind":"fixup",
    "bnorm_epsilon": 1e-4,
    "bnorm_running_avg_momentum": 0.001,
    "initial_conv_1x1": False,
    "gamma_weight_decay_center_1":True,
    "trunk_num_channels":96,
    "mid_num_channels":96,
    "gpool_num_channels":32,
    "transformer_ffn_channels":256,
    "transformer_heads":3,
    "transformer_kv_heads":3,
    "block_kind": [item for i in range(1,9) for item in [[f"attn{i}","attnrope"],[f"ffn{i}","ffnsg"]]],
    "p1_num_channels":32,
    "g1_num_channels":32,
    "v1_num_channels":32,
    "sbv2_num_channels":48,
    "num_scorebeliefs":4,
    "v2_size":64,
}

b2b10c96h3tfrs = {
    "version":17,
    "norm_kind":"fixup",
    "bnorm_epsilon": 1e-4,
    "bnorm_running_avg_momentum": 0.001,
    "initial_conv_1x1": False,
    "gamma_weight_decay_center_1":True,
    "trunk_num_channels":96,
    "mid_num_channels":96,
    "gpool_num_channels":32,
    "transformer_ffn_channels":256,
    "transformer_heads":3,
    "transformer_kv_heads":3,
    "block_kind": [
        ["rconv1","regular"],
        ["rconv2","regular"],
        ["attn3","attnrope"],
        ["ffn3","ffnsg"],
        ["attn4","attnrope"],
        ["ffn4","ffnsg"],
        ["attn5","attnrope"],
        ["ffn5","ffnsg"],
        ["attn6","attnrope"],
        ["ffn6","ffnsg"],
        ["attn7","attnrope"],
        ["ffn7","ffnsg"],
        ["attn8","attnrope"],
        ["ffn8","ffnsg"],
        ["attn9","attnrope"],
        ["ffn9","ffnsg"],
        ["attn10","attnrope"],
        ["ffn10","ffnsg"],
        ["attn11","attnrope"],
        ["ffn11","ffnsg"],
        ["attn12","attnrope"],
        ["ffn12","ffnsg"],
    ],
    "p1_num_channels":32,
    "g1_num_channels":32,
    "v1_num_channels":32,
    "sbv2_num_channels":48,
    "num_scorebeliefs":4,
    "v2_size":64,
}

b9c96h3tgabs = {
    "version":17,
    "norm_kind":"fixup",
    "bnorm_epsilon": 1e-4,
    "bnorm_running_avg_momentum": 0.001,
    "initial_conv_1x1": False,
    "gamma_weight_decay_center_1":True,
    "trunk_num_channels":96,
    "mid_num_channels":96,
    "gpool_num_channels":32,
    "transformer_ffn_channels":256,
    "transformer_heads":3,
    "transformer_kv_heads":3,
    "gab_d1":16,
    "gab_d2":16,
    "gab_num_templates":32,
    "gab_num_fourier_features":12,
    "gab_mlp_hidden":96,
    "block_kind": [item for i in range(1,10) for item in [[f"attn{i}","attngab"],[f"ffn{i}","ffnsg"]]],
    "p1_num_channels":32,
    "g1_num_channels":32,
    "v1_num_channels":32,
    "sbv2_num_channels":48,
    "num_scorebeliefs":4,
    "v2_size":64,
}

b10c192h6tgabs = {
    "version":17,
    "norm_kind":"fixup",
    "bnorm_epsilon": 1e-4,
    "bnorm_running_avg_momentum": 0.001,
    "initial_conv_1x1": False,
    "gamma_weight_decay_center_1":True,
    "trunk_num_channels":192,
    "mid_num_channels":192,
    "gpool_num_channels":32,
    "transformer_ffn_channels":512,
    "transformer_heads":6,
    "transformer_kv_heads":6,
    "gab_d1":32,
    "gab_d2":32,
    "gab_num_templates":48,
    "gab_num_fourier_features":16,
    "gab_mlp_hidden":128,
    "block_kind": [item for i in range(1,11) for item in [[f"attn{i}","attngab"],[f"ffn{i}","ffnsg"]]],
    "p1_num_channels":32,
    "g1_num_channels":32,
    "v1_num_channels":32,
    "sbv2_num_channels":80,
    "num_scorebeliefs":8,
    "v2_size":96,
}

b5c192h3nbttfrs = {
    "version":17,
    "norm_kind":"fixup",
    "bnorm_epsilon": 1e-4,
    "bnorm_running_avg_momentum": 0.001,
    "initial_conv_1x1": False,
    "gamma_weight_decay_center_1":True,
    "trunk_num_channels":192,
    "mid_num_channels":96,
    "gpool_num_channels":32,
    "transformer_ffn_channels":256,
    "transformer_heads":3,
    "transformer_kv_heads":3,
    "block_kind": [[f"block{i}","bottlenest2transformerropesg"] for i in range(1,6)],
    "p1_num_channels":32,
    "g1_num_channels":32,
    "v1_num_channels":32,
    "sbv2_num_channels":48,
    "num_scorebeliefs":4,
    "v2_size":64,
}

b4c256h4nbttflrs = {
    "version":17,
    "norm_kind":"fixup",
    "bnorm_epsilon": 1e-4,
    "bnorm_running_avg_momentum": 0.001,
    "initial_conv_1x1": False,
    "gamma_weight_decay_center_1":True,
    "trunk_num_channels":256,
    "mid_num_channels":128,
    "gpool_num_channels":32,
    "transformer_ffn_channels":384,
    "transformer_heads":4,
    "transformer_kv_heads":4,
    "learnable_rope":True,
    "block_kind": [[f"block{i}","bottlenest2transformerropesg"] for i in range(1,5)],
    "p1_num_channels":32,
    "g1_num_channels":32,
    "v1_num_channels":32,
    "sbv2_num_channels":64,
    "num_scorebeliefs":6,
    "v2_size":80,
}

b5c384h6nbttflrs = {
    "version":17,
    "norm_kind":"fixup",
    "bnorm_epsilon": 1e-4,
    "bnorm_running_avg_momentum": 0.001,
    "initial_conv_1x1": False,
    "gamma_weight_decay_center_1":True,
    "trunk_num_channels":384,
    "mid_num_channels":192,
    "gpool_num_channels":32,
    "transformer_ffn_channels":512,
    "transformer_heads":6,
    "transformer_kv_heads":6,
    "learnable_rope":True,
    "block_kind": [[f"block{i}","bottlenest2transformerropesg"] for i in range(1,6)],
    "p1_num_channels":32,
    "g1_num_channels":32,
    "v1_num_channels":32,
    "sbv2_num_channels":80,
    "num_scorebeliefs":8,
    "v2_size":96,
}

b6c384h6nbttflrs = {
    "version":17,
    "norm_kind":"fixup",
    "bnorm_epsilon": 1e-4,
    "bnorm_running_avg_momentum": 0.001,
    "initial_conv_1x1": False,
    "gamma_weight_decay_center_1":True,
    "trunk_num_channels":384,
    "mid_num_channels":192,
    "gpool_num_channels":32,
    "transformer_ffn_channels":512,
    "transformer_heads":6,
    "transformer_kv_heads":6,
    "learnable_rope":True,
    "block_kind": [[f"block{i}","bottlenest2transformerropesg"] for i in range(1,7)],
    "p1_num_channels":32,
    "g1_num_channels":32,
    "v1_num_channels":32,
    "sbv2_num_channels":80,
    "num_scorebeliefs":8,
    "v2_size":96,
}

b7c384h6nbttflrs = {
    "version":17,
    "norm_kind":"fixup",
    "bnorm_epsilon": 1e-4,
    "bnorm_running_avg_momentum": 0.001,
    "initial_conv_1x1": False,
    "gamma_weight_decay_center_1":True,
    "trunk_num_channels":384,
    "mid_num_channels":192,
    "gpool_num_channels":32,
    "transformer_ffn_channels":512,
    "transformer_heads":6,
    "transformer_kv_heads":6,
    "learnable_rope":True,
    "block_kind": [[f"block{i}","bottlenest2transformerropesg"] for i in range(1,8)],
    "p1_num_channels":32,
    "g1_num_channels":32,
    "v1_num_channels":32,
    "sbv2_num_channels":80,
    "num_scorebeliefs":8,
    "v2_size":96,
}

b9c768h12nbttflrs = {
    "version":17,
    "norm_kind":"fixup",
    "bnorm_epsilon": 1e-4,
    "bnorm_running_avg_momentum": 0.001,
    "initial_conv_1x1": False,
    "gamma_weight_decay_center_1":True,
    "trunk_num_channels":768,
    "mid_num_channels":384,
    "gpool_num_channels":64,
    "transformer_ffn_channels":1024,
    "transformer_heads":12,
    "transformer_kv_heads":12,
    "learnable_rope":True,
    "block_kind": [[f"block{i}","bottlenest2transformerropesg"] for i in range(1,10)],
    "p1_num_channels":64,
    "g1_num_channels":64,
    "v1_num_channels":128,
    "sbv2_num_channels":128,
    "num_scorebeliefs":8,
    "v2_size":128,
}

b15c512h8nbttflrs = {
    "version":17,
    "norm_kind":"fixup",
    "bnorm_epsilon": 1e-4,
    "bnorm_running_avg_momentum": 0.001,
    "initial_conv_1x1": False,
    "gamma_weight_decay_center_1":True,
    "trunk_num_channels":512,
    "mid_num_channels":256,
    "gpool_num_channels":64,
    "transformer_ffn_channels":768,
    "transformer_heads":8,
    "transformer_kv_heads":8,
    "learnable_rope":True,
    "block_kind": [[f"block{i}","bottlenest2transformerropesg"] for i in range(1,16)],
    "p1_num_channels":64,
    "g1_num_channels":64,
    "v1_num_channels":128,
    "sbv2_num_channels":128,
    "num_scorebeliefs":8,
    "v2_size":128,
}

b10c512h8nbt3tflrs = {
    "version":17,
    "norm_kind":"fixup",
    "bnorm_epsilon": 1e-4,
    "bnorm_running_avg_momentum": 0.001,
    "initial_conv_1x1": False,
    "gamma_weight_decay_center_1":True,
    "trunk_num_channels":512,
    "mid_num_channels":256,
    "gpool_num_channels":64,
    "transformer_ffn_channels":768,
    "transformer_heads":8,
    "transformer_kv_heads":8,
    "learnable_rope":True,
    "block_kind": [[f"block{i}","bottlenest3transformerropesg"] for i in range(1,11)],
    "p1_num_channels":64,
    "g1_num_channels":64,
    "v1_num_channels":128,
    "sbv2_num_channels":128,
    "num_scorebeliefs":8,
    "v2_size":128,
}

b14c768h12nbt3tflrs = {
    "version":17,
    "norm_kind":"fixup",
    "bnorm_epsilon": 1e-4,
    "bnorm_running_avg_momentum": 0.001,
    "initial_conv_1x1": False,
    "gamma_weight_decay_center_1":True,
    "trunk_num_channels":768,
    "mid_num_channels":384,
    "gpool_num_channels":96,
    "transformer_ffn_channels":1152,
    "transformer_heads":12,
    "transformer_kv_heads":12,
    "learnable_rope":True,
    "block_kind": [[f"block{i}","bottlenest3transformerropesg"] for i in range(1,15)],
    "p1_num_channels":96,
    "g1_num_channels":96,
    "v1_num_channels":192,
    "sbv2_num_channels":192,
    "num_scorebeliefs":8,
    "v2_size":192,
}

b11c768h12nbt3tflrs = {
    "version":17,
    "norm_kind":"fixup",
    "bnorm_epsilon": 1e-4,
    "bnorm_running_avg_momentum": 0.001,
    "initial_conv_1x1": False,
    "gamma_weight_decay_center_1":True,
    "trunk_num_channels":768,
    "mid_num_channels":384,
    "gpool_num_channels":96,
    "transformer_ffn_channels":1152,
    "transformer_heads":12,
    "transformer_kv_heads":12,
    "learnable_rope":True,
    "block_kind": [[f"block{i}","bottlenest3transformerropesg"] for i in range(1,12)],
    "p1_num_channels":96,
    "g1_num_channels":96,
    "v1_num_channels":192,
    "sbv2_num_channels":192,
    "num_scorebeliefs":8,
    "v2_size":192,
}

b13c1024h16nbttflrs = {
    "version":17,
    "norm_kind":"fixup",
    "bnorm_epsilon": 1e-4,
    "bnorm_running_avg_momentum": 0.001,
    "initial_conv_1x1": False,
    "gamma_weight_decay_center_1":True,
    "trunk_num_channels":1024,
    "mid_num_channels":512,
    "gpool_num_channels":96,
    "transformer_ffn_channels":1536,
    "transformer_heads":16,
    "transformer_kv_heads":16,
    "learnable_rope":True,
    "block_kind": [[f"block{i}","bottlenest2transformerropesg"] for i in range(1,14)],
    "p1_num_channels":96,
    "g1_num_channels":96,
    "v1_num_channels":192,
    "sbv2_num_channels":192,
    "num_scorebeliefs":8,
    "v2_size":192,
}

b15c1024h16nbt3tflrs = {
    "version":17,
    "norm_kind":"fixup",
    "bnorm_epsilon": 1e-4,
    "bnorm_running_avg_momentum": 0.001,
    "initial_conv_1x1": False,
    "gamma_weight_decay_center_1":True,
    "trunk_num_channels":1024,
    "mid_num_channels":512,
    "gpool_num_channels":96,
    "transformer_ffn_channels":1536,
    "transformer_heads":16,
    "transformer_kv_heads":16,
    "learnable_rope":True,
    "block_kind": [[f"block{i}","bottlenest3transformerropesg"] for i in range(1,16)],
    "p1_num_channels":96,
    "g1_num_channels":96,
    "v1_num_channels":192,
    "sbv2_num_channels":192,
    "num_scorebeliefs":8,
    "v2_size":192,
}

b14c192h6tfrs = {
    "version":17,
    "norm_kind":"fixup",
    "bnorm_epsilon": 1e-4,
    "bnorm_running_avg_momentum": 0.001,
    "initial_conv_1x1": False,
    "gamma_weight_decay_center_1":True,
    "trunk_num_channels":192,
    "mid_num_channels":192,
    "gpool_num_channels":32,
    "transformer_ffn_channels":512,
    "transformer_heads":6,
    "transformer_kv_heads":6,
    "block_kind": [item for i in range(1,15) for item in [[f"attn{i}","attnrope"],[f"ffn{i}","ffnsg"]]],
    "p1_num_channels":32,
    "g1_num_channels":32,
    "v1_num_channels":32,
    "sbv2_num_channels":80,
    "num_scorebeliefs":8,
    "v2_size":96,
}

b2b13c192h6tfrs = {
    "version":17,
    "norm_kind":"fixup",
    "bnorm_epsilon": 1e-4,
    "bnorm_running_avg_momentum": 0.001,
    "initial_conv_1x1": False,
    "gamma_weight_decay_center_1":True,
    "trunk_num_channels":192,
    "mid_num_channels":192,
    "gpool_num_channels":32,
    "transformer_ffn_channels":512,
    "transformer_heads":6,
    "transformer_kv_heads":6,
    "block_kind": [
        ["rconv1","regular"],
        ["rconv2","regular"],
        ["attn3","attnrope"],
        ["ffn3","ffnsg"],
        ["attn4","attnrope"],
        ["ffn4","ffnsg"],
        ["attn5","attnrope"],
        ["ffn5","ffnsg"],
        ["attn6","attnrope"],
        ["ffn6","ffnsg"],
        ["attn7","attnrope"],
        ["ffn7","ffnsg"],
        ["attn8","attnrope"],
        ["ffn8","ffnsg"],
        ["attn9","attnrope"],
        ["ffn9","ffnsg"],
        ["attn10","attnrope"],
        ["ffn10","ffnsg"],
        ["attn11","attnrope"],
        ["ffn11","ffnsg"],
        ["attn12","attnrope"],
        ["ffn12","ffnsg"],
        ["attn13","attnrope"],
        ["ffn13","ffnsg"],
        ["attn14","attnrope"],
        ["ffn14","ffnsg"],
        ["attn15","attnrope"],
        ["ffn15","ffnsg"],
    ],
    "p1_num_channels":32,
    "g1_num_channels":32,
    "v1_num_channels":32,
    "sbv2_num_channels":80,
    "num_scorebeliefs":8,
    "v2_size":96,
}

b16c256h8tfrs = {
    "version":17,
    "norm_kind":"fixup",
    "bnorm_epsilon": 1e-4,
    "bnorm_running_avg_momentum": 0.001,
    "initial_conv_1x1": False,
    "gamma_weight_decay_center_1":True,
    "trunk_num_channels":256,
    "mid_num_channels":256,
    "gpool_num_channels":48,
    "transformer_ffn_channels":768,
    "transformer_heads":8,
    "transformer_kv_heads":8,
    "block_kind": [item for i in range(1,17) for item in [[f"attn{i}","attnrope"],[f"ffn{i}","ffnsg"]]],
    "p1_num_channels":48,
    "g1_num_channels":48,
    "v1_num_channels":96,
    "sbv2_num_channels":96,
    "num_scorebeliefs":8,
    "v2_size":96,
}

b21c384h12tfrs = {
    "version":17,
    "norm_kind":"fixup",
    "bnorm_epsilon": 1e-4,
    "bnorm_running_avg_momentum": 0.001,
    "initial_conv_1x1": False,
    "gamma_weight_decay_center_1":True,
    "trunk_num_channels":384,
    "mid_num_channels":384,
    "gpool_num_channels":64,
    "transformer_ffn_channels":1024,
    "transformer_heads":12,
    "transformer_kv_heads":12,
    "block_kind": [item for i in range(1,22) for item in [[f"attn{i}","attnrope"],[f"ffn{i}","ffnsg"]]],
    "p1_num_channels":64,
    "g1_num_channels":64,
    "v1_num_channels":128,
    "sbv2_num_channels":128,
    "num_scorebeliefs":8,
    "v2_size":128,
}

b21c384h12tflrs = {
    "version":17,
    "norm_kind":"fixup",
    "bnorm_epsilon": 1e-4,
    "bnorm_running_avg_momentum": 0.001,
    "initial_conv_1x1": False,
    "gamma_weight_decay_center_1":True,
    "trunk_num_channels":384,
    "mid_num_channels":384,
    "gpool_num_channels":64,
    "transformer_ffn_channels":1024,
    "transformer_heads":12,
    "transformer_kv_heads":12,
    "learnable_rope":True,
    "block_kind": [item for i in range(1,22) for item in [[f"attn{i}","attnrope"],[f"ffn{i}","ffnsg"]]],
    "p1_num_channels":64,
    "g1_num_channels":64,
    "v1_num_channels":128,
    "sbv2_num_channels":128,
    "num_scorebeliefs":8,
    "v2_size":128,
}

b30c512h16tflrs = {
    "version":17,
    "norm_kind":"fixup",
    "bnorm_epsilon": 1e-4,
    "bnorm_running_avg_momentum": 0.001,
    "initial_conv_1x1": False,
    "gamma_weight_decay_center_1":True,
    "trunk_num_channels":512,
    "mid_num_channels":512,
    "gpool_num_channels":96,
    "transformer_ffn_channels":1536,
    "transformer_heads":16,
    "transformer_kv_heads":16,
    "learnable_rope":True,
    "block_kind": [item for i in range(1,31) for item in [[f"attn{i}","attnrope"],[f"ffn{i}","ffnsg"]]],
    "p1_num_channels":96,
    "g1_num_channels":96,
    "v1_num_channels":192,
    "sbv2_num_channels":192,
    "num_scorebeliefs":8,
    "v2_size":192,
}

b22c192h6tfrs = {
    "version":17,
    "norm_kind":"fixup",
    "bnorm_epsilon": 1e-4,
    "bnorm_running_avg_momentum": 0.001,
    "initial_conv_1x1": False,
    "gamma_weight_decay_center_1":True,
    "trunk_num_channels":192,
    "mid_num_channels":192,
    "gpool_num_channels":48,
    "transformer_ffn_channels":512,
    "transformer_heads":6,
    "transformer_kv_heads":6,
    "block_kind": [item for i in range(1,23) for item in [[f"attn{i}","attnrope"],[f"ffn{i}","ffnsg"]]],
    "p1_num_channels":48,
    "g1_num_channels":48,
    "v1_num_channels":96,
    "sbv2_num_channels":96,
    "num_scorebeliefs":8,
    "v2_size":96,
}
b10c384h6nbttflrs = {
    "version":17,
    "norm_kind":"fixup",
    "bnorm_epsilon": 1e-4,
    "bnorm_running_avg_momentum": 0.001,
    "initial_conv_1x1": False,
    "gamma_weight_decay_center_1":True,
    "trunk_num_channels":384,
    "mid_num_channels":192,
    "gpool_num_channels":48,
    "transformer_ffn_channels":512,
    "transformer_heads":6,
    "transformer_kv_heads":6,
    "learnable_rope":True,
    "block_kind": [[f"block{i}","bottlenest2transformerropesg"] for i in range(1,11)],
    "p1_num_channels":48,
    "g1_num_channels":48,
    "v1_num_channels":96,
    "sbv2_num_channels":96,
    "num_scorebeliefs":8,
    "v2_size":96,
}

b45c384h12tflrs = {
    "version":17,
    "norm_kind":"fixup",
    "bnorm_epsilon": 1e-4,
    "bnorm_running_avg_momentum": 0.001,
    "initial_conv_1x1": False,
    "gamma_weight_decay_center_1":True,
    "trunk_num_channels":384,
    "mid_num_channels":384,
    "gpool_num_channels":96,
    "transformer_ffn_channels":1024,
    "transformer_heads":12,
    "transformer_kv_heads":12,
    "learnable_rope":True,
    "block_kind": [item for i in range(1,46) for item in [[f"attn{i}","attnrope"],[f"ffn{i}","ffnsg"]]],
    "p1_num_channels":96,
    "g1_num_channels":96,
    "v1_num_channels":192,
    "sbv2_num_channels":192,
    "num_scorebeliefs":8,
    "v2_size":192,
}

b5c384h6nbttfgabs = {
    "version":17,
    "norm_kind":"fixup",
    "bnorm_epsilon": 1e-4,
    "bnorm_running_avg_momentum": 0.001,
    "initial_conv_1x1": False,
    "gamma_weight_decay_center_1":True,
    "trunk_num_channels":384,
    "mid_num_channels":192,
    "gpool_num_channels":32,
    "transformer_ffn_channels":512,
    "transformer_heads":6,
    "transformer_kv_heads":6,
    "gab_d1":32,
    "gab_d2":32,
    "gab_num_templates":48,
    "gab_num_fourier_features":16,
    "gab_mlp_hidden":128,
    "block_kind": [[f"block{i}","bottlenest2transformergabsg"] for i in range(1,6)],
    "p1_num_channels":32,
    "g1_num_channels":32,
    "v1_num_channels":32,
    "sbv2_num_channels":80,
    "num_scorebeliefs":8,
    "v2_size":96,
}

b5c384h6nbttftabs = {
    "version":17,
    "norm_kind":"fixup",
    "bnorm_epsilon": 1e-4,
    "bnorm_running_avg_momentum": 0.001,
    "initial_conv_1x1": False,
    "gamma_weight_decay_center_1":True,
    "trunk_num_channels":384,
    "mid_num_channels":192,
    "gpool_num_channels":32,
    "transformer_ffn_channels":512,
    "transformer_heads":6,
    "transformer_kv_heads":6,
    "gab_d1":32,
    "gab_d2":32,
    "tab_c_z":32,
    "tab_num_templates":32,
    "tab_num_freqs":8,
    "tab_num_blocks":3,
    "tab_dilation":3,
    "block_kind": [[f"block{i}","bottlenest2transformertabsg"] for i in range(1,6)],
    "p1_num_channels":32,
    "g1_num_channels":32,
    "v1_num_channels":32,
    "sbv2_num_channels":80,
    "num_scorebeliefs":8,
    "v2_size":96,
}

b5c384h6nbttfrtabs = {
    "version":17,
    "norm_kind":"fixup",
    "bnorm_epsilon": 1e-4,
    "bnorm_running_avg_momentum": 0.001,
    "initial_conv_1x1": False,
    "gamma_weight_decay_center_1":True,
    "trunk_num_channels":384,
    "mid_num_channels":192,
    "gpool_num_channels":32,
    "transformer_ffn_channels":512,
    "transformer_heads":6,
    "transformer_kv_heads":6,
    "gab_d1":32,
    "gab_d2":32,
    "tab_c_z":32,
    "tab_num_templates":32,
    "tab_num_freqs":8,
    "tab_num_blocks":3,
    "tab_dilation":3,
    "block_kind": [[f"block{i}","bottlenest2transformerropetabsg"] for i in range(1,6)],
    "p1_num_channels":32,
    "g1_num_channels":32,
    "v1_num_channels":32,
    "sbv2_num_channels":80,
    "num_scorebeliefs":8,
    "v2_size":96,
}

b5c384h6nbttflrtabcheaps = {
    "version":17,
    "norm_kind":"fixup",
    "bnorm_epsilon": 1e-4,
    "bnorm_running_avg_momentum": 0.001,
    "initial_conv_1x1": False,
    "gamma_weight_decay_center_1":True,
    "trunk_num_channels":384,
    "mid_num_channels":192,
    "gpool_num_channels":32,
    "transformer_ffn_channels":512,
    "transformer_heads":6,
    "transformer_kv_heads":6,
    "learnable_rope":True,
    "gab_d1":32,
    "gab_d2":32,
    "tab_c_z":16,
    "tab_num_templates":16,
    "tab_num_freqs":8,
    "tab_num_blocks":3,
    "tab_dilation":3,
    "block_kind": [[f"block{i}","bottlenest2transformerropetabsg"] for i in range(1,6)],
    "p1_num_channels":32,
    "g1_num_channels":32,
    "v1_num_channels":32,
    "sbv2_num_channels":80,
    "num_scorebeliefs":8,
    "v2_size":96,
}


b5c384h6nbttflrtab2cheaps = {
    "version":17,
    "norm_kind":"fixup",
    "bnorm_epsilon": 1e-4,
    "bnorm_running_avg_momentum": 0.001,
    "initial_conv_1x1": False,
    "gamma_weight_decay_center_1":True,
    "trunk_num_channels":384,
    "mid_num_channels":192,
    "gpool_num_channels":32,
    "transformer_ffn_channels":512,
    "transformer_heads":6,
    "transformer_kv_heads":6,
    "learnable_rope":True,
    "gab_d1":32,
    "gab_d2":32,
    "tab_c_z":16,
    "tab_num_templates":16,
    "tab_num_blocks":3,
    "tab_dilation":3,
    "tab_use_frequency_mixing":True,
    "block_kind": [[f"block{i}","bottlenest2transformerropetabsg"] for i in range(1,6)],
    "p1_num_channels":32,
    "g1_num_channels":32,
    "v1_num_channels":32,
    "sbv2_num_channels":80,
    "num_scorebeliefs":8,
    "v2_size":96,
}


base_config_of_name = {
    # CONVNETS ====================================================================
    # "nbt" (nested bottleneck) architectures are usually much better than the plain residual block nets

    # Micro-sized convnets
    "b1c6nbt": b1c6nbt,
    "b2c16": b2c16,
    "b4c32": b4c32,
    "b6c96": b6c96,          # Historic katago architecture

    # Tiny convnets
    "b10c128": b10c128,      # Historic katago architecture
    "b5c192nbt": b5c192nbt,  # Probably better (nbt architecture is better)

    "b8c192nbt": b8c192nbt,

    # Small convnets
    "b15c192": b15c192,       # Historic katago architecture
    "b10c256nbt": b10c256nbt, # Probably better (nbt architecture is better)

    # Roughly AlphaZero-sized convnets
    "b20c256": b20c256,         # Classic alphazero, historic katago architecture
    "b20c384bt": b20c384bt,
    "b15c384lbt": b15c384lbt,
    "b10c384nbt": b10c384nbt,   # Recommended best config for this cost
    "b10c480nb3t": b10c480nb3t,

    # Roughly AlphaGoZero-sized convnets
    "b30c320": b30c320,           # Historic katago architecture
    "b40c256": b40c256,           # Classic alphagozero, historic katago architecture
    "b18c384nbt": b18c384nbt,     # Recommended best config for this cost
    "b18c384dnbt1": b18c384dnbt1,

    # Medium-large convnets
    "b40c384": b40c384,
    "b60c320": b60c320,        # Historic katago architecture
    "b32c448nbt": b32c448nbt,
    "b28c512nbt": b28c512nbt,  # Recommended best config for this cost
    "b20c640nbt": b20c640nbt,

    # Large convnets
    "b40c768nbt": b40c768nbt,  # Historic katago/zhizi architecture

    # TRANSFORMERS ====================================================================
    # "nbt" (nested bottleneck) transformers are usually much better than plain transformers
    # Learnable RoPE transformers are usually much better than plain RoPE.
    # Swiglu is good.

    # Naming convention:
    # "b14c192h6tfrs" as an example:
    # "b14" = 14 layers
    # "c192" = 192 hidden dims
    # "h6" = 6 heads (traditional MHA, Q,K,V have same number of heads)
    # "tf" = transformer, "r" or "lr" = rope or learnable rope, "s" = swiglu

    # Tiny transformer models
    "b5c48h3tfr": b5c48h3tfr,  # no swiglu
    "b7c96h3tfrs": b7c96h3tfrs,
    "b7c96h6kv3qk32v16tflrs": b7c96h6kv3qk32v16tflrs, # testing wacky gqa and channel differences
    "b8c96h3tfrs": b8c96h3tfrs,
    "b5c192h3nbttfrs": b5c192h3nbttfrs,
    "b4c256h4nbttflrs": b4c256h4nbttflrs,

    # Small transformer models
    "b14c192h6tfrs": b14c192h6tfrs,
    "b14c192h6tflrs": {**b14c192h6tfrs, "learnable_rope": True},
    "b5c384h6nbttflrs": b5c384h6nbttflrs,
    "b6c384h6nbttflrs": b6c384h6nbttflrs,
    "b7c384h6nbttflrs": b7c384h6nbttflrs,
    "b6c384h6nbttflrs-qkn-ireg16": {
        **b6c384h6nbttflrs,
        "attention_qk_norm": True,
        "inline_registers": True,
        "attention_num_rw_registers": 16
    },

    # b18c384nbt-comparable transformers (Comparable to AlphaGoZero's convnet in inference cost)
    "b16c256h8tfrs": b16c256h8tfrs,
    "b22c192h6tfrs": b22c192h6tfrs,
    "b10c384h6nbttflrs": b10c384h6nbttflrs,

    # b28c512nbt-comparable transformers
    "b21c384h12tfrs": b21c384h12tfrs,
    "b21c384h12tflrs": b21c384h12tflrs,
    "b9c768h12nbttflrs": b9c768h12nbttflrs,
    "b9c768h12nbttflrs-ireg16": {**b9c768h12nbttflrs, "inline_registers": True, "attention_num_rw_registers": 16},
    "b15c512h8nbttflrs": b15c512h8nbttflrs,
    "b10c512h8nbt3tflrs": b10c512h8nbt3tflrs,
    "b14c512h8nbttflrs": {**b15c512h8nbttflrs, "block_kind": [[f"block{i}","bottlenest2transformerropesg"] for i in range(1,15)]},
    "b14c512h8nbttflrs-ireg16": {
        **b15c512h8nbttflrs,
        "inline_registers": True,
        "attention_num_rw_registers": 16,
        "block_kind": [[f"block{i}","bottlenest2transformerropesg"] for i in range(1,15)]
    },
    "b14c512h8nbttflrs-qkn-ireg16": {
        **b15c512h8nbttflrs,
        "attention_qk_norm": True,
        "inline_registers": True,
        "attention_num_rw_registers": 16,
        "block_kind": [[f"block{i}","bottlenest2transformerropesg"] for i in range(1,15)]
    },
    "b8c768h12nbttflrs-qkn-ireg16": {
        **b9c768h12nbttflrs,
        "attention_qk_norm": True,
        "inline_registers": True,
        "attention_num_rw_registers": 16,
        "block_kind": [[f"block{i}","bottlenest2transformerropesg"] for i in range(1,9)]
    },

    # More expensive than b28c512nbt but cheaper than b40c768nbt
    "b30c512h16tflrs": b30c512h16tflrs,
    "b45c384h12tflrs": b45c384h12tflrs,
    "b11c768h12nbt3tflrs": b11c768h12nbt3tflrs,
    "b14c768h12nbt3tflrs": b14c768h12nbt3tflrs,
    "b13c1024h16nbttflrs": b13c1024h16nbttflrs,

    # Large transformers, about as heavy or heavier than b40c768nbt
    "b15c1024h16nbt3tflrs": b15c1024h16nbt3tflrs,

    # EXPERIMENTAL STUFF =============================================================

    # Mixed conv and transformer
    "b2b10c96h3tfrs": b2b10c96h3tfrs,
    "b2b13c192h6tfrs": b2b13c192h6tfrs,

    # GAB
    "b9c96h3tgabs": b9c96h3tgabs,
    "b10c192h6tgabs": b10c192h6tgabs,

    # Nested bottleneck transformers with GAB/TAB
    "b5c384h6nbttfgabs": b5c384h6nbttfgabs, # +GAB
    "b5c384h6nbttftabs": b5c384h6nbttftabs, # TAB alone
    "b5c384h6nbttfrtabs": b5c384h6nbttfrtabs, # RoPE+TAB
    "b5c384h6nbttflrtabcheaps": b5c384h6nbttflrtabcheaps, # Learnable RoPE+TAB cheap
    "b5c384h6nbttflrtab2cheaps": b5c384h6nbttflrtab2cheaps, # Learnable RoPE+TAB cheap, frequency mixing

    "b2b5c384h6nbttflrs": {**b6c384h6nbttflrs, "block_kind": [
        ["block1","bottlenest2"],
        ["block2","bottlenest2"],
        ["block3","bottlenest2transformerropesg"],
        ["block4","bottlenest2transformerropesg"],
        ["block5","bottlenest2transformerropesg"],
        ["block6","bottlenest2transformerropesg"],
        ["block7","bottlenest2transformerropesg"],
    ]},
    "b4b4c384h6nbttflrs": {**b6c384h6nbttflrs, "block_kind": [
        ["block1","bottlenest2"],
        ["block2","bottlenest2"],
        ["block3","bottlenest2"],
        ["block4","bottlenest2"],
        ["block5","bottlenest2transformerropesg"],
        ["block6","bottlenest2transformerropesg"],
        ["block7","bottlenest2transformerropesg"],
        ["block8","bottlenest2transformerropesg"],
    ]},

    "b6c384h6nbttflrs-dwc": {**b6c384h6nbttflrs, "transformer_ffn_depthwise_conv": True},
    "b6c384h6nbttflrs-qkn": {**b6c384h6nbttflrs, "attention_qk_norm": True},
}


config_of_name = {}
for name, base_config in base_config_of_name.items():
    config = base_config.copy()
    config_of_name[name] = config


for name, base_config in list(config_of_name.items()):
    # Fixup initialization
    config = base_config.copy()
    config["norm_kind"] = "fixup"
    config_of_name[name+""] = config

    # Fixed scaling normalization
    config = base_config.copy()
    config["norm_kind"] = "fixscale"
    config_of_name[name+"-fs"] = config

    # Batchnorm without gamma terms
    config = base_config.copy()
    config["norm_kind"] = "bnorm"
    config_of_name[name+"-bn"] = config

    # Batchrenorm without gamma terms
    config = base_config.copy()
    config["norm_kind"] = "brenorm"
    config_of_name[name+"-brn"] = config

    # Fixed scaling normalization + Batchrenorm without gamma terms
    config = base_config.copy()
    config["norm_kind"] = "fixbrenorm"
    config_of_name[name+"-fbrn"] = config

    # Batchnorm with gamma terms
    config = base_config.copy()
    config["norm_kind"] = "bnorm"
    config["bnorm_use_gamma"] = True
    config_of_name[name+"-bng"] = config

    # Batchrenorm with gamma terms
    config = base_config.copy()
    config["norm_kind"] = "brenorm"
    config["bnorm_use_gamma"] = True
    config_of_name[name+"-brng"] = config

    # Fixed scaling normalization + Batchrenorm with gamma terms
    config = base_config.copy()
    config["norm_kind"] = "fixbrenorm"
    config["bnorm_use_gamma"] = True
    config_of_name[name+"-fbrng"] = config

    # Fixed scaling normalization + ONE batch norm layer in the entire net.
    config = base_config.copy()
    config["norm_kind"] = "fixscaleonenorm"
    config["bnorm_use_gamma"] = True
    config_of_name[name+"-fson"] = config

for name, base_config in list(config_of_name.items()):
    config = base_config.copy()
    config["activation"] = "elu"
    config_of_name[name+"-elu"] = config

    config = base_config.copy()
    config["activation"] = "gelu"
    config_of_name[name+"-gelu"] = config

    config = base_config.copy()
    config["activation"] = "mish"
    config_of_name[name+"-mish"] = config

    config = base_config.copy()
    config["activation"] = "silu"
    config_of_name[name+"-silu"] = config

for name, base_config in list(config_of_name.items()):
    config = base_config.copy()
    config["use_repvgg_init"] = True
    config_of_name[name+"-rvgi"] = config

    config = base_config.copy()
    config["use_repvgg_linear"] = True
    config_of_name[name+"-rvgl"] = config

    config = base_config.copy()
    config["use_repvgg_init"] = True
    config["use_repvgg_learning_rate"] = True
    config_of_name[name+"-rvglr"] = config

for name, base_config in list(config_of_name.items()):
    # Trunk channel gate
    config = base_config.copy()
    config["use_trunk_channel_gate"] = True
    config_of_name[name+"-tcg"] = config

for name, base_config in list(config_of_name.items()):
    # Trunk residual backout: parallel backout trunk that later blocks can learn to subtract
    config = base_config.copy()
    config["use_trunk_residual_backout"] = True
    config_of_name[name+"-trb"] = config

    config = base_config.copy()
    config["use_trunk_residual_backout"] = True
    config["trunk_residual_backout_noreg"] = True
    config_of_name[name+"-trbnr"] = config

for name, base_config in list(config_of_name.items()):
    config = base_config.copy()
    config["has_intermediate_head"] = True
    config["intermediate_head_blocks"] = len(config["block_kind"]) // 2
    config_of_name[name+"-ih"] = config

    # Add parallel heads that uses the final trunk batchnorm.
    # The original normal heads disables the final trunk batchnorm
    # This only makes sense for configs that use some form of batchnorm.
    if "norm" in config["norm_kind"]:
        config = base_config.copy()
        config["has_intermediate_head"] = True
        config["intermediate_head_blocks"] = len(config["block_kind"])
        config["trunk_normless"] = True
        config_of_name[name+"-bnh"] = config

    # RMSNorm before heads. No intermediate head.
    config = base_config.copy()
    config["trunk_final_rmsnorm"] = True
    config_of_name[name+"-rnh"] = config

    # RMSNorm spatial before heads. No intermediate head.
    config = base_config.copy()
    config["trunk_final_rmsnorm"] = True
    config["trunk_rmsnorm_spatial"] = True
    config_of_name[name+"-rsnh"] = config

    # RMSNorm spatial before heads. No intermediate head.
    config = base_config.copy()
    config["trunk_final_rmsnorm"] = True
    config["trunk_rmsnorm_spatial"] = True
    config["rmsnorm_spatial_cgroup_size"] = 16
    config_of_name[name+"-rgnh"] = config


for name, base_config in list(config_of_name.items()):
    config = base_config.copy()
    config["metadata_encoder"] = {
        "meta_encoder_version": 1,
        "internal_num_channels": config["trunk_num_channels"],
    }
    config_of_name[name+"-meta"] = config
