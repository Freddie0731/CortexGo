# -*- coding: utf-8 -*-
"""Step F: 把新的价值头权重按字节原位写回 .bin.gz，产出 kata1_value_fixed.bin.gz。

为什么可以"原位改写"：.bin.gz 解压后是「空白分隔 token 流 + @BIN@ 后跟裸 float32」，
每个张量的载荷在解压流里的偏移是确定的。新权重的形状和旧权重完全一样（192x576、
192、3x192、3），所以只需把对应字节区间覆盖掉，其余一个字节都不动。

校验三件套（缺一不可）：
  1. 用 _katago_v17_load 重新解析新文件，逐张量比对：只有那 4 个张量变了，
     其余必须字节级完全相同。
  2. 解压流层面做 diff mask：变化区间的并集必须正好等于这 4 个载荷区间。
  3. 端到端：把新文件装进官方 PyTorch 模型，对同一批 gpool 输入跑前向，
     与"训练脚本用 numpy 算出来的 logits"比对 —— 证明导出的权重经过真实前向
     得到的正是训练时的那个函数。

用法:
  python tools/value_export.py --new build_out/value/value_head_new.npz \
      --src kata1.bin.gz --out kata1_value_fixed.bin.gz \
      [--features build_out/value/features.npz]
"""
import os
import sys
import gzip
import argparse

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import value_lib as V

try:
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
except Exception:
    pass

TARGETS = ('v2Mul', 'v2Bias', 'v3Mul', 'v3Bias')


def load_and_locate(src):
    import _katago_v17_load as L
    data = V.decompress_model(src)
    M = L.load(src, verbose=False)
    slots = V.locate_tensor_slots(data, M)
    return data, M, slots


def patch(data, slots, new_vals):
    out = bytearray(data)
    for name in TARGETS:
        a, b = slots[name]
        blob = new_vals[name]
        if len(blob) != b - a:
            raise SystemExit('%s: new blob %d bytes != slot %d bytes'
                             % (name, len(blob), b - a))
        out[a:b] = blob
    return bytes(out)


def verify_bytes(name, old, new, slots, verbose=True):
    """解压流层面：差异必须严格限制在这 4 个区间内。"""
    if len(old) != len(new):
        raise SystemExit('decompressed size changed: %d -> %d' % (len(old), len(new)))
    o = np.frombuffer(old, dtype=np.uint8)
    n = np.frombuffer(new, dtype=np.uint8)
    diff = np.nonzero(o != n)[0]
    allowed = np.zeros(len(old), dtype=bool)
    for k in TARGETS:
        a, b = slots[k]
        allowed[a:b] = True
    stray = diff[~allowed[diff]]
    print('  [bytes] 变化字节数 = %d，其中落在 4 个目标张量区间外的 = %d'
          % (len(diff), len(stray)))
    for k in TARGETS:
        a, b = slots[k]
        ch = int((o[a:b] != n[a:b]).sum())
        print('    %-8s [%9d,%9d)  %d 字节不同 (共 %d)' % (k, a, b, ch, b - a))
    if len(stray):
        print('  !! 有 %d 字节变化在目标区间之外，前几个偏移: %r'
              % (len(stray), stray[:10].tolist()))
        return False
    return True


def _walk_leaves(obj, path=''):
    """遍历解析出来的模型 dict，产出 (path, name, ndarray) 三元组。"""
    if isinstance(obj, dict):
        for k, v in obj.items():
            for x in _walk_leaves(v, path + '.' + str(k) if path else str(k)):
                yield x
    elif isinstance(obj, (list, tuple)):
        for i, v in enumerate(obj):
            for x in _walk_leaves(v, path + '[%d]' % i):
                yield x
    elif isinstance(obj, np.ndarray):
        yield (path, obj)


def verify_tensors(src, dst, new_vals, expect_changed=True):
    import _katago_v17_load as L
    Mo = L.load(src, verbose=False)
    Mn = L.load(dst, verbose=False)
    print('  [tensors] 重新解析新文件: at_end=%s  bytes_consumed=%d/%d'
          % (Mn['at_end'], Mn['bytes_consumed'], Mn['file_size']))
    ok = True
    lo = list(_walk_leaves(Mo))
    ln = list(_walk_leaves(Mn))
    if len(lo) != len(ln):
        print('  !! 张量个数不同 %d vs %d' % (len(lo), len(ln)))
        return False
    changed, same = [], 0
    for (pa, a), (pb, b) in zip(lo, ln):
        if pa != pb:
            print('  !! 路径不同: %s vs %s' % (pa, pb))
            ok = False
            continue
        if np.asarray(a, np.float32).tobytes() == np.asarray(b, np.float32).tobytes():
            same += 1
        else:
            changed.append(pa)
    print('  [tensors] 共 %d 个数组：未变 %d，变化 %d' % (len(lo), same, len(changed)))
    for p in changed:
        print('    变化: %s' % p)
    # 变化的必须正好是这 4 个
    expect_sub = ('valueHead.v2Mul.w', 'valueHead.v2Bias.b',
                  'valueHead.v3Mul.w', 'valueHead.v3Bias.b')
    if not expect_changed:
        expect_sub = ()
    if sorted(changed) != sorted(expect_sub):
        print('  !! 变化的张量与预期不符（预期正好 %r）' % (expect_sub,))
        ok = False
    vh_n = Mn['valueHead']
    checks = {
        'v2Mul': (vh_n['v2Mul']['w'], new_vals['v2Mul'], 'mat'),
        'v2Bias': (vh_n['v2Bias']['b'], new_vals['v2Bias'], 'bias'),
        'v3Mul': (vh_n['v3Mul']['w'], new_vals['v3Mul'], 'mat'),
        'v3Bias': (vh_n['v3Bias']['b'], new_vals['v3Bias'], 'bias'),
    }
    for k, (got, want, kind) in checks.items():
        gb = V.file_layout_mat(got) if kind == 'mat' else V.file_layout_bias(got)
        if gb != want:
            print('    !! %s 解析回来的字节与新权重不一致' % k)
            ok = False
        else:
            print('    %-8s 解析回来与新权重逐字节一致 (%d 字节)' % (k, len(want)))
    return ok


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--new', required=True)
    ap.add_argument('--src', default='kata1.bin.gz')
    ap.add_argument('--out', required=True)
    ap.add_argument('--features', default='')
    ap.add_argument('--skip-e2e', action='store_true')
    args = ap.parse_args()

    z = np.load(args.new) if args.new != 'old' else None
    if z is None:
        # 自测模式：把源文件里的 4 个张量当成"新权重"写回。
        # 正确实现下，解压流应当 0 字节变化、文件内容完全等价。
        print('*** 自测模式：--new old，用源文件自己的张量当新权重（预期 0 字节变化）***')
        import _katago_v17_load as L
        M0 = L.load(args.src, verbose=False)
        vh = M0['valueHead']
        new_vals = {
            'v2Mul': V.file_layout_mat(vh['v2Mul']['w']),
            'v2Bias': V.file_layout_bias(vh['v2Bias']['b']),
            'v3Mul': V.file_layout_mat(vh['v3Mul']['w']),
            'v3Bias': V.file_layout_bias(vh['v3Bias']['b']),
        }
    else:
        new_vals = {
            'v2Mul': V.file_layout_mat(z['linear2_weight']),
            'v2Bias': V.file_layout_bias(z['linear2_bias']),
            'v3Mul': V.file_layout_mat(z['v3_weight']),
            'v3Bias': V.file_layout_bias(z['v3_bias']),
        }
        for k, w in z.items():
            print('  new[%s] shape=%s' % (k, w.shape))

    print('\n=== 1) 定位并替换 ===')
    data, M, slots = load_and_locate(args.src)
    for k in TARGETS:
        a, b = slots[k]
        print('  %-8s slot [%9d,%9d)  %d 字节' % (k, a, b, b - a))
    newdata = patch(data, slots, new_vals)

    print('\n=== 2) 解压流 diff 校验 ===')
    ok_bytes = verify_bytes('x', data, newdata, slots)

    # 重新压缩写出（不覆盖源文件）
    if os.path.abspath(args.out) == os.path.abspath(args.src):
        raise SystemExit('refusing to overwrite %s' % args.src)
    with open(args.out, 'wb') as f:
        with gzip.GzipFile(fileobj=f, mode='wb', compresslevel=6, mtime=0) as g:
            g.write(newdata)
    print('\n  写出 %s (%.1f MB)' % (args.out, os.path.getsize(args.out) / 1048576.0))

    print('\n=== 3) 重新解析 + 逐张量比对 ===')
    ok_t = verify_tensors(args.src, args.out, new_vals, expect_changed=(z is not None))

    print('\n=== 4) 端到端：新文件 -> 官方 PyTorch 前向 ===')
    ok_e2e = True
    if args.features and not args.skip_e2e and z is not None:
        from value_features import load_official_model
        model_new, _ = load_official_model(args.out, verbose=False)
        zf = np.load(args.features)
        gpool = zf['gpool'][:16].astype(np.float32)
        feat = np.load(args.new)
        W1 = feat['linear2_weight'].astype(np.float64)
        b1 = feat['linear2_bias'].astype(np.float64)
        W2 = feat['v3_weight'].astype(np.float64)
        b2 = feat['v3_bias'].astype(np.float64)
        h = gpool.astype(np.float64).dot(W1.T) + b1
        h = h / (1.0 + np.exp(-h))
        ref = h.dot(W2.T) + b2

        import torch
        # 用新文件里的 linear2 / act2 / linear_valuehead 直接算
        l2 = model_new.value_head.linear2(torch.from_numpy(gpool))
        a2 = model_new.value_head.act2(l2)
        got = model_new.value_head.linear_valuehead(a2).detach().numpy()
        diff = float(np.abs(got - ref).max())
        print('  新文件里的 linear2/linear_valuehead 直接算 16 个样本：')
        print('  max|torch(新文件) - numpy(训练权重)| = %.3e' % diff)
        ok_e2e = diff < 2e-3
        print('  ==> 端到端 %s' % ('PASS' if ok_e2e else 'FAIL'))
    elif not args.features:
        print('  (跳过：未提供 --features)')
    elif z is None:
        print('  (自测模式跳过端到端)')

    print('\n=== 总结 ===')
    print('  byte-diff 校验: %s' % ('PASS' if ok_bytes else 'FAIL'))
    print('  tensor 校验   : %s' % ('PASS' if ok_t else 'FAIL'))
    print('  端到端校验    : %s' % ('PASS' if ok_e2e else 'FAIL/SKIP'))
    if not (ok_bytes and ok_t and ok_e2e):
        raise SystemExit(1)


if __name__ == '__main__':
    main()
