# -*- coding: utf-8 -*-
"""Step G: 策略头 top-1/top-5 命中率基线（用 pro 棋谱的实战着法当裁判）。

这是"后续编码器改动值不值得"的裁判指标：同一份 dump（=同一份 encode.h 编码）
喂给策略头，看法沿着法的排名。编码器/权重任何一边改坏，这个数字立刻掉。

口径说明（两种都报，别只看高的那个）：
  * raw    : 在策略头 362 个输出（361 点 + pass）里直接排名，不做任何合法性过滤。
            这是"网络原始输出"的诚实数字。
  * legal  : 先把已占的点排除（棋盘上有子的点不可能下），再排名。KataGo 论文里
             报的 policy accuracy 一般也是 masked 口径。
另外报「实战着法上分到的概率均值」——比 top-k 更平滑，适合做小改动的 A/B。

用法:
  python tools/value_policy_eval.py --features build_out/value/features.npz \
      --dump build_out/value/dump.bin --manifest build_out/value/manifest.txt
"""
import os
import sys
import argparse

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import value_lib as V

try:
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
except Exception:
    pass


def read_manifest(manifest):
    games = []
    with open(manifest, 'r', encoding='utf-8') as f:
        for ln in f:
            ln = ln.rstrip('\n').rstrip('\r')
            if not ln or ln.startswith('#'):
                continue
            p = ln.split('\t')
            moves = [int(x) for x in p[4].split(',')]
            games.append({'gid': p[0], 'komi': float(p[1]), 'winner': int(p[2]),
                          'moves': moves})
    return games


def softmax_rows(x):
    m = x.max(axis=1, keepdims=True)
    e = np.exp(x - m)
    return e / e.sum(axis=1, keepdims=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--features', default='build_out/value/features.npz')
    ap.add_argument('--dump', default='build_out/value/dump.bin')
    ap.add_argument('--manifest', default='build_out/value/manifest.txt')
    ap.add_argument('--limit', type=int, default=0)
    ap.add_argument('--by-ply', action='store_true', default=True)
    args = ap.parse_args()

    z = None
    # --features 支持逗号分隔的多个分片（按 posIdx 起点排序后拼接）
    chunks = []
    for fp in args.features.split(','):
        fp = fp.strip()
        if not fp:
            continue
        zz = np.load(fp)
        if 'posIdx' in zz:
            pidx = zz['posIdx'].astype(np.int64)
        else:
            pidx = np.arange(zz['gpool'].shape[0], dtype=np.int64)
        chunks.append((int(pidx[0]), fp, zz, pidx))
    chunks.sort(key=lambda t: t[0])
    pols, plies, gidxs, allidx = [], [], [], []
    for st, fp, zz, pidx in chunks:
        pols.append(zz['policy_ch0'].astype(np.float32))
        plies.append(zz['meta_ply'].astype(np.int32))
        gidxs.append(zz['meta_gameIdx'].astype(np.int32))
        allidx.append(pidx)
    pol = np.concatenate(pols)
    ply = np.concatenate(plies)
    gameIdx = np.concatenate(gidxs)
    posIdx = np.concatenate(allidx)
    print('  特征分片: %s' % ', '.join('%s(%d)' % (os.path.basename(f), len(i))
                                      for _, f, _, i in chunks))
    d = V.read_dump(args.dump, verbose=False)
    games = read_manifest(args.manifest)
    n = pol.shape[0]
    if args.limit:
        n = min(n, args.limit)
    posIdx = posIdx[:n]
    print('=== 策略头基线评测：%d 个局面，%d 局 ===' % (n, int(np.unique(gameIdx[:n]).size)))

    # 实战着法 = 该局面之后的下一个着法
    actual = np.empty(n, np.int64)
    ok = 0
    for i in range(n):
        gi = int(gameIdx[i])
        p = int(ply[i])
        mv = games[gi]['moves']
        if p < len(mv):
            actual[i] = mv[p]
            ok += 1
        else:
            actual[i] = -999
    print('  实际着法解析成功 %d / %d' % (ok, n))

    probs = softmax_rows(pol[:n])                      # (n,362)
    board = d['board'][posIdx]                         # (n,361)  0=空
    empty = (board == 0)

    def rank_stats(mask_legal, tag):
        # 给非法/已占点一个极小概率，然后排名
        p = probs.copy()
        if mask_legal:
            p[:, :V.S] = np.where(empty, p[:, :V.S], -1.0)
        # top-k 判定
        act = actual[:n]
        rows = np.arange(n)
        p_act = p[rows, act]
        # 排名 = 比实战着法概率更大的点数（含非法被压到 -1 的不算）
        better = (p > p_act[:, None]).sum(axis=1)
        top1 = float((better == 0).mean())
        top5 = float((better < 5).mean())
        meanp = float(probs[rows, act].mean())
        print('  %-6s top-1 = %.4f   top-5 = %.4f   实战着法平均概率 = %.4f'
              % (tag, top1, top5, meanp))
        return top1, top5, meanp

    t1_raw, t5_raw, mp_raw = rank_stats(False, 'raw')
    t1_leg, t5_leg, mp_leg = rank_stats(True, 'legal')

    if args.by_ply:
        print('\n  按手数分桶（legal 口径）：')
        for lo, hi in ((8, 40), (40, 80), (80, 120), (120, 160), (160, 201)):
            m = (ply[:n] >= lo) & (ply[:n] < hi)
            if m.sum() < 50:
                continue
            p = probs[m].copy()
            p[:, :V.S] = np.where(empty[m], p[:, :V.S], -1.0)
            act = actual[m]
            rows = np.arange(int(m.sum()))
            p_act = p[rows, act]
            better = (p > p_act[:, None]).sum(axis=1)
            print('    ply %3d-%-3d n=%-5d top-1=%.4f top-5=%.4f meanp=%.4f'
                  % (lo, hi, int(m.sum()), float((better == 0).mean()),
                     float((better < 5).mean()),
                     float(probs[m][rows, act].mean())))

    # pass 的合理性：真实着法为 pass 的局面极少（采样在 200 手内），略过
    print('\n  参考：pass 输出概率均值 = %.5f' % float(probs[:, V.S].mean()))
    print('\n==> 基线：legal top-1=%.4f  top-5=%.4f  meanp=%.4f（后续任何编码器/权重改动都用同一脚本对比）'
          % (t1_leg, t5_leg, mp_leg))


if __name__ == '__main__':
    main()
