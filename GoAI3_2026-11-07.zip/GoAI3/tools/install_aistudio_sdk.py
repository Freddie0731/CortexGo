# -*- coding: utf-8 -*-
"""tools/install_aistudio_sdk.py —— 不用 pip 安装 aistudio-sdk 及其依赖

为什么不用 pip：本机 `pip install --target ...` 会在**它自己的解包目录**里报
`Permission denied (Errno 13)`（DSH 沙箱限制，不是网络问题）。而 wheel 下载本身走
HTTP 镜像是通的，所以这里手动做「下 wheel → 解压 → 建 .pth」。

用法:
    python tools/install_aistudio_sdk.py              # 只装 aistudio-sdk
    python tools/install_aistudio_sdk.py --with-deps   # 连依赖一起装（推荐）
    python tools/install_aistudio_sdk.py --with-deps --version 0.3.9
"""
import argparse
import io
import os
import re
import sys
import urllib.request
import zipfile

INDEXES = ['http://mirrors.aliyun.com/pypi/simple', 'https://pypi.org/simple']
MIRROR = 'http://mirrors.aliyun.com/pypi/simple'
REPO = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DEST = os.path.join(REPO, 'build_out', 'aistudio_sdk')
DL = os.path.join(REPO, 'build_out', 'downloads')

# aistudio-sdk 的 Requires-Dist（0.3.9）及其常见传递依赖。
# 顺序：被依赖的在前，方便失败时快速定位。
DEPS = [
    'certifi', 'idna', 'urllib3', 'charset-normalizer', 'requests',
    'six', 'click', 'tqdm', 'prettytable', 'wcwidth',
    'psutil', 'pycryptodome', 'bce-python-sdk',
    'future', 'pyparsing', 'protobuf',
]


def http_get(url, timeout=120):
    req = urllib.request.Request(url, headers={'User-Agent': 'goai3/1.0'})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read()


def py_tags():
    v = sys.version_info
    tags = ['py3-none-any']
    tags.append('cp%d%d-cp%d%d' % (v.major, v.minor, v.major, v.minor))
    tags.append('cp%d%d' % (v.major, v.minor))
    return tags


def _ver_tuple(name):
    """从 wheel 文件名取版本号，用于"多版本里挑最新"。"""
    parts = os.path.basename(name).split('-')
    if len(parts) < 2:
        return (0,)
    out = []
    for tok in re.split(r'[.\-_+]', parts[1]):
        m = re.match(r'^(\d+)', tok)
        out.append(int(m.group(1)) if m else 0)
    return tuple(out) or (0,)


def _tag_score(name):
    """只接受本机可装的 wheel：纯 Python、精确 cp3XX、或任意 abi3（向前兼容）。
    其它（别的 CPython 版本、cp314t 自由线程、别的平台）一律拒绝。"""
    b = os.path.basename(name).lower()
    v = sys.version_info
    cp = 'cp%d%d' % (v.major, v.minor)
    if 'py3-none-any' in b or 'py2.py3-none-any' in b:
        return 100
    if '%s-%s-win_amd64' % (cp, cp) in b:       # 精确匹配，cp314t 不会命中
        return 90
    if re.search(r'cp3\d+-abi3-win_amd64', b):  # 稳定 ABI：3.x 通用
        return 80
    return -1


def _is_prerelease(name):
    """判断 wheel 是不是预发布版（1.5.0a1 / 1.14.0rc1 这种）。

    镜像索引里预发布版也会出现，而 `max(版本号)` 会挑到它们 ——
    实测踩过坑：mpmath 1.5.0a1 缺 bitcount、sympy 1.14.0rc1 不兼容，
    导致 torch._dynamo 直接 import 失败。所以**稳定版优先**。
    """
    parts = os.path.basename(name).split('-')
    if len(parts) < 2:
        return False
    return bool(re.search(r'\d+(a|b|rc)\d', parts[1].lower()))


def pick_wheel(pkg, version=None):
    # 先阿里云镜像（快），没有再回落到 pypi.org（本机 Python 走 OpenSSL，HTTPS 是通的）。
    # py3.14 上 psutil/pycryptodome 这类二进制包，阿里云镜像只同步了 cp314t（自由线程）
    # 的轮子，普通 cp314 得从 pypi 取。
    for base_idx in INDEXES:
        try:
            html = http_get('%s/%s/' % (base_idx, pkg)).decode('utf-8', 'replace')
        except Exception:
            continue
        raw = re.findall(r'href="([^"#]+\.whl)', html)
        cand = []
        for l in raw:
            b = os.path.basename(l)
            if version and version not in b:
                continue
            sc = _tag_score(b)
            if sc < 0:
                continue
            cand.append((sc, _ver_tuple(b), l))
        if not cand:
            continue
        stable = [c for c in cand if not _is_prerelease(c[2])]
        best = max(stable or cand, key=lambda c: (c[0], c[1]))[2]
        if best.startswith('http'):
            return best
        if best.startswith('/'):
            return 'http://mirrors.aliyun.com' + best
        return '%s/%s/%s' % (base_idx, pkg, best)
    return None


def install(pkg, version=None):
    url = pick_wheel(pkg, version)
    if not url:
        print('  [skip] %-18s 镜像里没有 wheel' % pkg)
        return False
    name = os.path.basename(url.split('?')[0])
    out = os.path.join(DL, name)
    if not os.path.isfile(out):
        data = http_get(url, timeout=300)
        io.open(out, 'wb').write(data)
    else:
        data = io.open(out, 'rb').read()
    with zipfile.ZipFile(out) as z:
        z.extractall(DEST)
    print('  [ok]   %-18s %-46s %.1f KB' % (pkg, name[:46], len(data) / 1024.0))
    return True


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--version', default='')
    ap.add_argument('--with-deps', action='store_true')
    args = ap.parse_args()

    os.makedirs(DL, exist_ok=True)
    os.makedirs(DEST, exist_ok=True)

    if args.with_deps:
        print('安装依赖（%d 个）：' % len(DEPS))
        for p in DEPS:
            try:
                install(p)
            except Exception as e:
                print('  [warn] %-18s %s' % (p, e))
    print('安装 aistudio-sdk：')
    install('aistudio-sdk', args.version or None)

    pth = os.path.join(DEST, 'goai3_aistudio_sdk.pth')
    io.open(pth, 'w', encoding='utf-8').write(DEST + '\n')
    print('\n安装目录: %s' % DEST)
    print('自检: python tools/aistudio_upload.py --help')
    return 0


if __name__ == '__main__':
    sys.exit(main())
