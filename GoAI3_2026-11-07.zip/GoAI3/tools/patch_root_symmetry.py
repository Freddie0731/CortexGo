# -*- coding: utf-8 -*-
"""go_ai.cpp 第二批补丁：根节点 8 对称平均。

为什么：这台机器上 KataGo b11c768 单次前向约 1 秒，每手 30 秒只买得到约 30 次
模拟。访问数这么低的时候，**根节点的先验几乎决定了选点**，而单个方向上前向的
策略分布带有明显方向偏差（实测空盘上四星位概率是 0.38/0.27/0.16/0.15，本该接近
均等）。在根节点做 8 对称平均把这个偏差平均掉，是低访问数下性价比最高的一项改动。

实现要点：
* 只在**根节点**做（params.root_symmetries，默认 8），深层叶子仍只评一次，
  否则每次模拟的代价会乘 8。
* expand_node 全部在 expand_mutex 之下调用，所以用一个全局布尔把"这次是根"
  传给 nn_forward() 是安全的（不是跨线程共享状态）。
"""
import io
import sys

PATH = 'go_ai.cpp'

EDITS = [
    # ---- 1) 全局开关 ----
    (
        'static bool g_kg_debug_value = false;',
        'static bool g_kg_debug_value = false;\n'
        '// 仅在一次"根节点展开"期间为 true：允许 nn_forward() 对 KataGo 做多对称\n'
        '// 平均。expand_node() 全部在 expand_mutex 下调用，所以这个全局量不会跨线程竞争。\n'
        'static bool g_kg_root_symmetry = false;'
    ),
    # ---- 2) SearchParams: 新增 root_symmetries ----
    (
        '    int symmetries = 1;         // 1..8 test-time augmentations',
        '    int symmetries = 1;         // 1..8 test-time augmentations (non-root)\n'
        '    // Network evaluations at the ROOT only (1..8). Averaging the policy over\n'
        '    // the 8 board symmetries removes the net\'s directional bias from the one\n'
        '    // thing that actually decides the move at low visit counts: the root\n'
        '    // prior. Deep leaves stay at 1 evaluation, so the cost is paid once per\n'
        '    // move, not once per simulation. Set to 1 to disable.\n'
        '    int root_symmetries = 8;'
    ),
    # ---- 3) nn_forward 的 KataGo 压制条件 ----
    (
        '    size_t n_sym = syms.size();\n'
        '    if (g_nn.is_katago && n_sym > 1) n_sym = 1;',
        '    size_t n_sym = syms.size();\n'
        '    if (g_nn.is_katago && n_sym > 1 && !g_kg_root_symmetry) n_sym = 1;'
    ),
    # ---- 4) expand_node：根用 root_symmetries ----
    (
        '        std::vector<int> syms;\n'
        '        int ns = params.symmetries < 1 ? 1 : params.symmetries;\n'
        '        if (ns > 8) ns = 8;\n'
        '        for (int k = 0; k < ns; ++k) syms.push_back(k);',
        '        // The root gets params.root_symmetries evaluations (averaging the prior\n'
        '        // over the 8 symmetries); every other node gets params.symmetries.\n'
        '        const bool is_root_expand = (idx == t->root);\n'
        '        int ns = is_root_expand ? params.root_symmetries : params.symmetries;\n'
        '        if (ns < 1) ns = 1;\n'
        '        if (ns > 8) ns = 8;\n'
        '        if (g_nn.is_katago && !is_root_expand) ns = 1;\n'
        '        g_kg_root_symmetry = (ns > 1);\n'
        '        std::vector<int> syms;\n'
        '        for (int k = 0; k < ns; ++k) syms.push_back(k);'
    ),
    # ---- 5) 用完复位 ----
    (
        '        nn_forward(b, syms, policy, wr, &history);\n'
        '        n->nn_v = wr;',
        '        nn_forward(b, syms, policy, wr, &history);\n'
        '        g_kg_root_symmetry = false;\n'
        '        n->nn_v = wr;'
    ),
    # ---- 6) 命令行参数 ----
    (
        '        else if (a == "--symmetries" && i + 1 < argc) sp.symmetries = std::stoi(argv[++i]);',
        '        else if (a == "--symmetries" && i + 1 < argc) sp.symmetries = std::stoi(argv[++i]);\n'
        '        else if (a == "--root-symmetries" && i + 1 < argc) sp.root_symmetries = std::stoi(argv[++i]);'
    ),
    # ---- 7) --help 文案 ----
    (
        '  --symmetries N    network evaluations per position, 1..8 (default 1)',
        '  --symmetries N    network evaluations per non-root position, 1..8 (default 1)\n'
        '  --root-symmetries N  network evaluations at the root only, 1..8 (default 8)'
    ),
]


def main():
    raw = io.open(PATH, 'r', encoding='utf-8', newline='').read()
    text = raw.replace('\r\n', '\n')
    fails = []
    for i, (old, new) in enumerate(EDITS):
        cnt = text.count(old)
        if cnt != 1:
            fails.append((i + 1, cnt, old.split('\n')[0][:70]))
            continue
        text = text.replace(old, new)
        print('[ok] patch %d: %s' % (i + 1, old.split('\n')[0][:70]))
    if fails:
        for f in fails:
            print('[FAIL] patch %d count=%d : %s' % f)
        raise SystemExit('有补丁没打上，文件未写回')
    out = text.replace('\r\n', '\n').replace('\n', '\r\n')
    io.open(PATH, 'w', encoding='utf-8', newline='').write(out)
    print('写回完成，%d 字节' % len(out))
    return 0


if __name__ == '__main__':
    sys.exit(main())
