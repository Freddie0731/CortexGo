# -*- coding: utf-8 -*-
"""Step B/C: 校验 dump、用官方 PyTorch 模型取价值头特征、算旧价值头 baseline AUC。

做三件事：
  1. 纯数据校验：平面 0 必须全 1；平面 1/2 必须与记录里的棋盘逐点一致；
     plane 3/4/5/14 只能落在有子的点上；全局特征与 komi/轮次自洽。
  2. 数值校验（C++ vs PyTorch）：dump_enc --aux 里存了 C++ 侧同一份输入的前向结果
     （gpool / value logits / policy logits），这里用 PyTorch 跑同样的输入逐项比对。
     同时验证 batch>1 与 batch=1 结果一致（norm_kind=fixscale，理论上是逐样本的）。
  3. 特征缓存：hook value_head.linear2 的**输入**（gpool，576 维），配合旧价值头
     的 logits 与策略头 logits 一起落盘，供训练脚本使用。顺便打印旧价值头的
     AUC/准确率 —— 这就是"旧头是坏的"的定量证据。

视角约定（重要）：标签 y = 1 表示**该局面的行棋方**最终赢了这盘棋。
KataGo 的输入平面是行棋方视角，引擎 nn_forward 也把 value 当行棋方视角，所以
这里不需要任何翻转。黑白互换的自检由 kg/test/dump_enc.cpp --selfcheck-out 生成。

用法:
  python tools/value_features.py --dump build_out/value/dump.bin \
      --aux build_out/value/aux.bin --weights kata1.bin.gz \
      --out build_out/value/features.npz [--batch 8] [--limit N]
"""
import os
import sys
import time
import argparse

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import value_lib as V

try:
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
except Exception:
    pass


# ---------------------------------------------------------------- torch 模型
# 前向所在设备。默认 cpu（与历史行为一致）；云端用 --device cuda。
# 特征始终以 CPU numpy 返回，所以下游 value_train / value_export 不用改。
DEVICE = 'cpu'


def load_official_model(wpath, verbose=True):
    import torch
    import _katago_v17_load as L
    from _kg_ref import build_state_dict, load_official

    M = L.load(wpath, verbose=False)
    Model, mc = load_official()
    cfg_name = 'b11c768h12nbt3tflrs-fs-silu'
    cfg = mc.config_of_name[cfg_name]
    model = Model(cfg, 19).eval()
    model.initialize()
    sd = build_state_dict(M)
    ref = model.state_dict()
    target = {}
    loaded = 0
    skipped = []
    for k, v in ref.items():
        if k in sd:
            a = np.array(sd[k], dtype=np.float32, copy=True, order='C')
            if tuple(a.shape) != tuple(v.shape):
                skipped.append((k, tuple(v.shape), tuple(a.shape)))
                continue
            target[k] = torch.from_numpy(a).clone()
            loaded += 1
        else:
            skipped.append((k, tuple(v.shape), None))
    model.load_state_dict(target, strict=False)
    if DEVICE != 'cpu':
        model = model.to(DEVICE)
    if verbose:
        print('model loaded: %d/%d tensors from %s (activation=%s, seq_layout=%s)'
              % (loaded, len(ref), wpath, model.activation,
                 getattr(model, 'transformer_seq_layout', None)))
        for k, a, b in skipped[:8]:
            print('  skipped %-52s ref%-18s file%s' % (k, a, b))
    return model, M


def _unwrap(res):
    """_forward_per_block_units / forward 的返回值统一成 heads 元组。"""
    if isinstance(res, tuple) and len(res) == 1 and isinstance(res[0], tuple):
        return res[0]
    return res


def _sc(x):
    """numpy 2.x 不再允许 float(size-1 ndarray)，统一转成真正的标量。"""
    a = np.asarray(x)
    return float(a.reshape(-1)[0])


def run_batch(model, spatial, glob, want_gpool=True):
    """返回 (gpool, value_logits, policy_logits_ch0)。spatial (B,22,19,19) float32。"""
    import torch
    feats = {}

    def pre_hook(mod, inp):
        if want_gpool and inp and torch.is_tensor(inp[0]):
            feats['gpool'] = inp[0].detach().float().cpu().numpy()
    h = model.value_head.linear2.register_forward_pre_hook(pre_hook)
    # KG_AUTOCAST=1 -> CPU bf16 自动混合精度。CPU 上通常能快 1.5~2x（尤其有 AMX 时），
    # 代价是特征精度降到 bf16。仅用于"大规模特征缓存"，数值对齐检查仍走 fp32。
    ac = os.environ.get('KG_AUTOCAST', '0') == '1'
    try:
        with torch.no_grad():
            sp = torch.from_numpy(np.ascontiguousarray(spatial)).float()
            gl = torch.from_numpy(np.ascontiguousarray(glob)).float()
            if DEVICE != 'cpu':
                sp = sp.to(DEVICE, non_blocking=True)
                gl = gl.to(DEVICE, non_blocking=True)
            if ac:
                with torch.autocast(DEVICE if DEVICE != 'cpu' else 'cpu',
                                    dtype=torch.bfloat16):
                    out = _unwrap(model._forward_per_block_units(sp, gl))
            else:
                out = _unwrap(model._forward_per_block_units(sp, gl))
    finally:
        h.remove()
    pol, val = out[0], out[1]
    return (feats.get('gpool'), val.detach().float().cpu().numpy(),
            pol.detach().float().cpu().numpy())


# ---------------------------------------------------------------- 校验 1：数据
def check_planes(d, max_report=5):
    print('\n=== [1] 数据自检：位图 vs 棋盘 ===')
    n = d['n']
    sp = V.planes_to_spatial(d['planes'])
    tm = d['toMove']
    board = d['board']

    bad = 0
    p0 = sp[:, 0]
    if not np.all(p0 == 1.0):
        bad += 1
        print('  FAIL plane0 not all ones: min=%g max=%g' % (p0.min(), p0.max()))
    else:
        print('  plane0 (在盘上) 全 1 : OK  (%d x %d)' % (n, V.S))

    pl = sp[:, 1].reshape(n, -1)
    op = sp[:, 2].reshape(n, -1)
    own = (board == tm[:, None]).astype(np.float32)
    opp = (board == (3 - tm)[:, None]).astype(np.float32)
    d1 = np.abs(pl - own).sum(axis=1)
    d2 = np.abs(op - opp).sum(axis=1)
    print('  plane1 (行棋方子) vs board==toMove : mismatch positions = %d / %d'
          % (int((d1 > 0).sum()), n))
    print('  plane2 (对手子)   vs board==opp     : mismatch positions = %d / %d'
          % (int((d2 > 0).sum()), n))
    if (d1 > 0).any() or (d2 > 0).any():
        bad += 1

    # 气数平面只能落在有子的点上；平面 14（征子标记）同理；
    # 平面 17（被征棋串的逃出工作点）必须落在空点上
    # 注意 plane 0 是"在盘上"恒 1，所以"有子"要取 plane 1..2
    # 平面 15/16 是"上两手局面的平面 14"，那个位置的子可能已经被提掉了，
    # 所以它允许落在当前空点上（只做统计，不判失败）。
    stone = sp[:, 1:3].max(axis=1).reshape(n, -1)
    for pname, pid in (('plane3 气=1', 3), ('plane4 气=2', 4), ('plane5 气=3', 5),
                       ('plane14 征子', 14)):
        m = sp[:, pid].reshape(n, -1)
        leak = int(np.sum((m > 0) & (stone == 0)))
        print('  %-18s 落在无子点上的次数 = %d' % (pname, leak))
        if leak:
            bad += 1
    for pname, pid in (('plane15 prev14', 15), ('plane16 prevprev14', 16)):
        m = sp[:, pid].reshape(n, -1)
        leak = int(np.sum((m > 0) & (stone == 0)))
        print('  %-18s 落在当前空点上的点数 = %d / %d（上一手的子可能已被提，允许）'
              % (pname, leak, int(m.sum())))
    m17 = sp[:, 17].reshape(n, -1)
    leak17 = int(np.sum((m17 > 0) & (stone > 0)))
    print('  plane17 逃出点 落在有子点上的次数 = %d （应为 0：逃出点都是空点）' % leak17)
    if leak17:
        bad += 1

    # 平面 18/19（领地）：互相不重叠；18 里不能有对手的子，19 里不能有自己的子
    p18 = sp[:, 18].reshape(n, -1) > 0
    p19 = sp[:, 19].reshape(n, -1) > 0
    both = int((p18 & p19).sum())
    wrong18 = int((p18 & (board == (3 - tm)[:, None])).sum())
    wrong19 = int((p19 & (board == tm[:, None])).sum())
    print('  plane18/19 领地：重叠点 = %d，18 含对手子 = %d，19 含自己子 = %d'
          % (both, wrong18, wrong19))
    if both or wrong18 or wrong19:
        bad += 1
    print('  plane18 覆盖点数均值 = %.1f  plane19 = %.1f（含自己的子 + 单色围空）'
          % (float(p18.sum(axis=1).mean()), float(p19.sum(axis=1).mean())))

    # 全局特征：global[5] = selfKomi/20，selfKomi = -komi(黑) / +komi(白)
    gl = d['global']
    selfk = np.where(tm == 1, -d['komi'], d['komi'])
    g5 = gl[:, 5] * 20.0
    err = np.abs(g5 - selfk)
    print('  global[5]*20 vs selfKomi : max|err| = %.6f' % err.max())
    if err.max() > 1e-3:
        bad += 1
    print('  global[9] (计分规则: AREA=0, TERRITORY=1) 取值集合 = %r'
          % sorted(set(np.round(gl[:, 9], 3).tolist())))
    if gl[:, 9].max() > 1e-6:
        print('  !! global[9] 应为 0（本引擎是 AREA 计分）')
        bad += 1
    print('  global[6]/[7] (劫规则)   取值集合 = %r / %r'
          % (sorted(set(np.round(gl[:, 6], 3).tolist())),
             sorted(set(np.round(gl[:, 7], 3).tolist()))))
    print('  平面 1 的占比（行棋方子数/361）均值 = %.4f' % float(sp[:, 1].mean()))
    print('  每个局面平均子数 = %.1f' % float(board.max(axis=1).size and
                                             (board > 0).sum(axis=1).mean()))
    print('==> 数据自检 %s' % ('PASS' if bad == 0 else 'FAIL (%d 项)' % bad))
    return bad == 0, sp


# ---------------------------------------------------------------- 校验 2：数值
def check_aux(model, d, aux, sp=None, max_report=6):
    print('\n=== [2] 数值自检：C++ 前向 vs PyTorch 前向（同一份 dump 输入）===')
    idx = aux['posIdx']
    if sp is None:
        sp = V.planes_to_spatial(d['planes'])
    ii = [int(x) for x in idx]
    # 一次批量跑完（batch 越大越快；这里只有几十个）
    g_all, v_all, p_all = run_batch(model, sp[ii], d['global'][ii])
    dg = np.abs(g_all - aux['gpool']).reshape(len(ii), -1).max(axis=1)
    dv = np.abs(v_all - aux['value']).reshape(len(ii), -1).max(axis=1)
    dp = np.abs(p_all[:, 0, :] - aux['policy']).reshape(len(ii), -1).max(axis=1)
    for k in range(min(max_report, len(ii))):
        wr_py = V.value_from_logits(v_all[k][None, :])[0]
        wr_cpp = V.value_from_logits(aux['value'][k][None, :])[0]
        print('  [%2d] ply=%-3d toMove=%d  value_cpp=(%+.3f,%+.3f,%+.3f) '
              'value_torch=(%+.3f,%+.3f,%+.3f)  winrate cpp=%+.4f torch=%+.4f  '
              '|d gpool|=%.1e' % (
                  k, int(d['ply'][ii[k]]), int(d['toMove'][ii[k]]),
                  _sc(aux['value'][k][0]), _sc(aux['value'][k][1]),
                  _sc(aux['value'][k][2]),
                  _sc(v_all[k][0]), _sc(v_all[k][1]), _sc(v_all[k][2]),
                  _sc(wr_cpp), _sc(wr_py), float(dg[k])))
    print('  max|C++ - PyTorch| : gpool=%.3e  value=%.3e  policy=%.3e'
          % (float(dg.max()), float(dv.max()), float(dp.max())))
    ok = max(float(dg.max()), float(dv.max()), float(dp.max())) < 2e-3
    print('==> 数值自检 %s (阈值 2e-3)' % ('PASS' if ok else 'FAIL'))

    # batch 一致性（norm_kind=fixscale 是逐样本的，batch 不应改变结果）
    k4 = min(4, len(ii))
    if k4 >= 2:
        g4, v4, _ = run_batch(model, sp[ii[:k4]], d['global'][ii[:k4]])
        g1 = np.concatenate([run_batch(model, sp[i:i + 1], d['global'][i:i + 1])[0]
                             for i in ii[:k4]], axis=0)
        v1 = np.concatenate([run_batch(model, sp[i:i + 1], d['global'][i:i + 1])[1]
                             for i in ii[:k4]], axis=0)
        diff_g = float(np.abs(g4 - g1).max())
        diff_v = float(np.abs(v4 - v1).max())
        print('  batch=%d vs batch=1 : max|gpool| diff = %.3e  max|value| diff = %.3e'
              % (k4, diff_g, diff_v))
        if diff_g > 2e-3 or diff_v > 2e-3:
            print('  !! batch 不一致 —— 特征缓存必须用与比对相同的 batch 语义')
            ok = False
    return ok


# ---------------------------------------------------------------- 特征缓存
def extract_features(model, d, batch, limit=0, sp=None, offset=0, stride=1):
    n_all = d['n']
    lo = max(0, offset)
    hi = n_all if limit <= 0 else min(n_all, lo + limit)
    idx = np.arange(lo, hi, max(1, stride), dtype=np.int64)
    n = len(idx)
    print('\n=== [3] 提取特征：局面 [%d, %d) stride=%d  共 %d 个 ==='
          % (lo, hi, stride, n), flush=True)
    if sp is None:
        sp = V.planes_to_spatial(d['planes'])
    gp = np.empty((n, 576), np.float32)
    val = np.empty((n, 3), np.float32)
    pol = np.empty((n, V.S + 1), np.float32)
    t0 = time.time()
    done = 0
    while done < n:
        b = min(batch, n - done)
        sel = idx[done:done + b]
        g, v, p = run_batch(model, sp[sel], d['global'][sel])
        gp[done:done + b] = g
        val[done:done + b] = v
        pol[done:done + b] = p[:, 0, :]
        done += b
        if done % (batch * 20) == 0 or done == n:
            el = time.time() - t0
            print('  %6d/%d  %.1fs  (%.2f pos/s)' % (done, n, el, done / max(el, 1e-9)),
                  flush=True)
    return gp, val, pol, idx


# ---------------------------------------------------------------- baseline
def report_baseline(d, val_logits, tag='旧价值头'):
    y = (d['winner'] == d['toMove']).astype(np.int32)
    wr = V.value_from_logits(val_logits)          # [-1,1]
    print('\n=== [4] %s baseline（行棋方视角）===' % tag)
    print('  样本数 = %d   行棋方胜率标签均值 = %.4f (0.5 附近说明采样没偏)' % (len(y), y.mean()))
    print('  AUC          = %.4f' % V.auc_score(wr, y))
    print('  acc(@0)      = %.4f' % float(((wr > 0).astype(np.int32) == y).mean()))
    pw = (wr + 1.0) * 0.5
    print('  Brier        = %.4f' % V.brier(pw, y))
    print('  预测胜率 mean=%.4f  std=%.4f  min=%.4f max=%.4f'
          % (pw.mean(), pw.std(), pw.min(), pw.max()))
    print('  校准：')
    for lo, hi, c, pm, ym in V.calib_bins(pw, y):
        if c:
            print('    [%.1f,%.1f) n=%-7d pred=%.3f actual=%.3f' % (lo, hi, c, pm, ym))
    # 按手数分桶：晚盘局面本来更容易预测，早盘标签噪声大
    print('  按手数分桶 AUC：')
    for lo, hi in ((8, 40), (40, 80), (80, 120), (120, 160), (160, 201)):
        m = (d['ply'] >= lo) & (d['ply'] < hi)
        if m.sum() > 100:
            print('    ply %3d-%-3d n=%-7d AUC=%.4f' % (
                lo, hi, int(m.sum()), V.auc_score(wr[m], y[m])))
    return wr


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--dump', required=True)
    ap.add_argument('--aux', default='')
    ap.add_argument('--weights', default='kata1.bin.gz')
    ap.add_argument('--out', default='')
    ap.add_argument('--batch', type=int, default=4)
    ap.add_argument('--limit', type=int, default=0)
    ap.add_argument('--offset', type=int, default=0)
    ap.add_argument('--stride', type=int, default=1)
    ap.add_argument('--threads', type=int, default=6)
    ap.add_argument('--device', default='cpu', choices=('cpu', 'cuda'),
                    help='forward device; cuda when running on a cloud GPU')
    ap.add_argument('--skip-aux', action='store_true')
    ap.add_argument('--skip-check', action='store_true')
    args = ap.parse_args()

    import torch
    global DEVICE
    DEVICE = args.device
    if DEVICE == 'cuda' and not torch.cuda.is_available():
        raise SystemExit('--device cuda requested but torch.cuda.is_available() is False')
    print('device=%s%s' % (DEVICE, (' (%s)' % torch.cuda.get_device_name(0))
                          if DEVICE == 'cuda' else ''), flush=True)
    torch.set_num_threads(args.threads)
    print('torch %s  threads=%d' % (torch.__version__, torch.get_num_threads()),
          flush=True)

    d = V.read_dump(args.dump)
    ok1, sp = (True, None)
    if not args.skip_check:
        ok1, sp = check_planes(d)

    model, _M = load_official_model(args.weights)

    ok2 = True
    if args.aux and not args.skip_aux:
        aux = V.read_aux(args.aux)
        ok2 = check_aux(model, d, aux, sp=sp)

    gp, val, pol, idx = extract_features(model, d, args.batch, args.limit, sp=sp,
                                        offset=args.offset, stride=args.stride)
    n = gp.shape[0]
    d2 = {k: (v[idx] if isinstance(v, np.ndarray) and v.shape[0] >= d['n'] else v)
          for k, v in d.items()}
    report_baseline(d2, val)

    if args.out:
        meta = {k: d2[k] for k in ('gameIdx', 'ply', 'toMove', 'winner', 'komi',
                                   'finalMargin', 'board')}
        np.savez_compressed(args.out, gpool=gp, value_old=val, policy_ch0=pol,
                            posIdx=idx, start=np.int64(idx[0]), end=np.int64(idx[-1] + 1),
                            **{'meta_' + k: v for k, v in meta.items()})
        print('\nwrote %s (gpool %s, positions [%d,%d) stride=%d)'
              % (args.out, gp.shape, idx[0], idx[-1] + 1, args.stride))
    print('\n==> 总判定: 数据自检 %s, 数值自检 %s'
          % ('PASS' if ok1 else 'FAIL', 'PASS' if ok2 else 'FAIL/SKIP'))


if __name__ == '__main__':
    main()
