# -*- coding: utf-8 -*-
"""go_ai.cpp：补一个 GTP `final_score` / `compute_score` 命令。

为什么：verify 的 GTP 探针里剩下唯一一条 quirk 就是"没有 final_score，客户端只能
自己数子"。这一条确实会让 Sabaki 之类的前端无法显示终局结果，也会让 A/B 对局驱动
不得不用自己的棋盘副本判分（两边规则一旦有细微差别就会污染胜率统计）。

实现直接用引擎自己的 area_score()（中国规则数子 + 贴目），所以和搜索里的终局判定
完全一致。已知限制照实写在注释里：它按**盘面**数子，不清理死子，所以对局还没真正
收完时给出的结果会偏高。
"""
import io
import sys

PATH = 'go_ai.cpp'

EDITS = [
    # 1) 命令实现：插在 version 之后
    (
        '        else if (cmd == "version") resp = "3.0";',
        '        else if (cmd == "version") resp = "3.0";\n'
        '        else if (cmd == "final_score" || cmd == "compute_score") {\n'
        '            // Chinese-rules area score + komi, identical to the terminal\n'
        '            // evaluation the search itself uses. Caveat: area_score() counts\n'
        '            // the board as it stands and does not remove dead stones, so the\n'
        '            // number is only exact once the position is actually settled.\n'
        '            double sc = area_score(board, komi);\n'
        '            char scbuf[48];\n'
        '            if (sc > 0.001) std::snprintf(scbuf, sizeof(scbuf), "B+%.1f", sc);\n'
        '            else if (sc < -0.001) std::snprintf(scbuf, sizeof(scbuf), "W+%.1f", -sc);\n'
        '            else std::snprintf(scbuf, sizeof(scbuf), "0");\n'
        '            resp = scbuf;\n'
        '        }'
    ),
    # 2) list_commands 里登记
    (
        '            "boardsize\\nclear_board\\nkomi\\nplay\\ngenmove\\ntime_settings\\ntime_left\\nquit";',
        '            "boardsize\\nclear_board\\nkomi\\nplay\\ngenmove\\ntime_settings\\n"\n'
        '            "time_left\\nfinal_score\\ncompute_score\\nquit";'
    ),
]


def main():
    raw = io.open(PATH, 'r', encoding='utf-8', newline='').read()
    text = raw.replace('\r\n', '\n')
    bad = []
    for i, (old, new) in enumerate(EDITS):
        c = text.count(old)
        if c != 1:
            bad.append((i + 1, c))
            continue
        text = text.replace(old, new)
        print('[ok] patch %d' % (i + 1))
    if bad:
        raise SystemExit('补丁没打上: %r' % (bad,))
    out = text.replace('\r\n', '\n').replace('\n', '\r\n')
    io.open(PATH, 'w', encoding='utf-8', newline='').write(out)
    print('写回完成 %d 字节' % len(out))
    return 0


if __name__ == '__main__':
    sys.exit(main())
