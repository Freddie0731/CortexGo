# -*- coding: utf-8 -*-
r"""tools/export_onnx_fson.py -- re-export kata1's ONNX from the CORRECT graph.

Background (commit d598554): the .bin.gz norm slots already contain the final
multiplier, and the trunk-final norm is a real batchnorm (the net was trained
with norm_kind="fixscaleonenorm" + bnorm_use_gamma=True, i.e. the "-fson"
variant). Previous exports used norm_kind="fixscale" and dropped
running_mean/running_std, so they reproduced a wrong network.

This script:
  1. builds the official PyTorch graph with config ...-fson-silu
  2. maps the parsed .bin.gz weights into that graph:
       gamma   = slot/scale - 1        (center-1 convention, scale from module)
       beta    = file bias
       running_mean = file mean
       running_std  = sqrt(var + 1e-20)
  3. validates the PyTorch output against OUR native C++ output on the exact
     same encoded inputs (cmp_*.in.bin from build_out\\github\\normfix\\dump_io.exe)
  4. exports ONNX (legacy exporter, same patches as tools/export_onnx.py)
  5. validates the ONNX Runtime (CPU) output against PyTorch

usage:
  $env:PYTHONPATH="build_out\\np\u py"   (so onnx/onnxruntime are importable)
  python tools\\export_onnx_fson.py --weights kata1.bin.gz \\
         --out build_out\\github\\kata1_b11_fson.onnx
"""
import argparse
import os
import sys

REPO = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, REPO)
sys.path.insert(0, os.path.join(REPO, 'build_out', 'npu', 'py'))
os.environ.setdefault('TORCHDYNAMO_DISABLE', '1')
os.environ.setdefault('TORCH_COMPILE_DISABLE', '1')
os.environ.setdefault('TORCHINDUCTOR_DISABLE', '1')
os.environ['KATAGO_FLEX_ATTENTION'] = '0'

import numpy as np  # noqa: E402
import torch  # noqa: E402

import _katago_v17_load as L  # noqa: E402
from _katago_official import load_official  # noqa: E402

HERE = os.path.join(REPO, 'build_out', 'github')
CFG_NAME = 'b11c768h12nbt3tflrs-fson-silu'
OUT_NAMES = ["policy", "value", "miscvalue", "moremiscvalue", "ownership",
             "scoring", "futurepos", "seki", "scorebelief"]
EPS = 1e-20


def build_state_dict(M, model):
    """Map parsed .bin.gz weights to the official fson PyTorch model."""
    sd = {}
    mods = dict(model.named_modules())
    tr = M['trunk']
    sd['conv_spatial.weight'] = tr['initialConv']['w']
    sd['linear_global.weight'] = tr['initialMatMul']['w']

    def put_norm(prefix, n):
        m = mods.get(prefix)
        if m is None:
            raise SystemExit('no module for ' + prefix)
        scale = getattr(m, 'scale', None)
        gamma = getattr(m, 'gamma', None)
        if gamma is not None:
            slot = np.asarray(n['scale'], dtype=np.float32)
            g = slot / float(scale) - 1.0 if scale is not None else slot - 1.0
            sd[prefix + '.gamma'] = g.reshape(1, -1, 1, 1)
        sd[prefix + '.beta'] = np.asarray(n['bias'], dtype=np.float32).reshape(1, -1, 1, 1)
        if getattr(m, 'is_using_batchnorm', False):
            sd[prefix + '.running_mean'] = np.asarray(n['running_mean'], dtype=np.float32)
            sd[prefix + '.running_std'] = np.sqrt(
                np.asarray(n['running_var'], dtype=np.float32) + np.float32(EPS))

    def put_nac(prefix, nc):
        put_norm(prefix + '.norm', nc['norm'])
        sd[prefix + '.conv.weight'] = nc['conv']['w']

    def put_block(prefix, b):
        k = b['kind']
        if k == 'nested_bottleneck_block':
            put_nac(prefix + '.normactconvp', b['p'])
            for j, sb in enumerate(b['stack']):
                put_block(prefix + '.blockstack.%d' % j, sb)
            put_nac(prefix + '.normactconvq', b['q'])
        elif k == 'transformer_attention_block':
            sd[prefix + '.norm1.weight'] = np.asarray(b['preLN']['weight'], dtype=np.float32)
            for kk, tg in (('qProj', 'q_proj'), ('kProj', 'k_proj'),
                           ('vProj', 'v_proj'), ('outProj', 'out_proj')):
                sd[prefix + '.' + tg + '.weight'] = b[kk]['w']
            if 'ropeFreqs' in b:
                sd[prefix + '.rope_freqs'] = np.asarray(b['ropeFreqs'], dtype=np.float32).reshape(
                    b['ropeNumKVHeads'], b['ropeNumPairs'], 2)
        elif k == 'transformer_ffn_block':
            sd[prefix + '.norm.weight'] = np.asarray(b['preLN']['weight'], dtype=np.float32)
            sd[prefix + '.ffn_linear1.weight'] = b['linear1']['w']
            if 'linearGate' in b:
                sd[prefix + '.ffn_linear_gate.weight'] = b['linearGate']['w']
            sd[prefix + '.ffn_linear2.weight'] = b['linear2']['w']
        else:
            raise SystemExit('unexpected block kind ' + k)

    for i, b in enumerate(tr['blocks']):
        put_block('blocks.%d' % i, b)

    if not tr['trunkTipNormIsRMS']:
        put_norm('norm_trunkfinal', tr['trunkTipNorm'])

    ph = M['policyHead']
    sd['policy_head.conv1p.weight'] = ph['p1Conv']['w']
    sd['policy_head.conv1g.weight'] = ph['g1Conv']['w']
    sd['policy_head.biasg.beta'] = np.asarray(ph['g1BN']['bias'], dtype=np.float32).reshape(1, -1, 1, 1)
    sd['policy_head.linear_g.weight'] = ph['gpoolToBiasMul']['w']
    sd['policy_head.bias2.beta'] = np.asarray(ph['p1BN']['bias'], dtype=np.float32).reshape(1, -1, 1, 1)
    c96 = ph['p2Conv']['w'].shape[1]
    full2 = np.zeros((6, c96, 1, 1), dtype=np.float32)
    full2[0] = ph['p2Conv']['w'][0]
    full2[5] = ph['p2Conv']['w'][1]
    sd['policy_head.conv2p.weight'] = full2
    sd['policy_head.linear_pass.weight'] = ph['gpoolToPassMul']['w']
    sd['policy_head.linear_pass.bias'] = np.asarray(ph['gpoolToPassBias']['b'])
    c_p1 = ph['gpoolToPassMul2']['w'].shape[1]
    full2b = np.zeros((6, c_p1), dtype=np.float32)
    full2b[0] = ph['gpoolToPassMul2']['w'][0]
    full2b[5] = ph['gpoolToPassMul2']['w'][1]
    sd['policy_head.linear_pass2.weight'] = full2b

    vh = M['valueHead']
    sd['value_head.conv1.weight'] = vh['v1Conv']['w']
    sd['value_head.bias1.beta'] = np.asarray(vh['v1BN']['bias'], dtype=np.float32).reshape(1, -1, 1, 1)
    sd['value_head.linear2.weight'] = vh['v2Mul']['w']
    sd['value_head.linear2.bias'] = np.asarray(vh['v2Bias']['b'])
    sd['value_head.linear_valuehead.weight'] = vh['v3Mul']['w']
    sd['value_head.linear_valuehead.bias'] = np.asarray(vh['v3Bias']['b'])
    w = np.zeros((10, 192), dtype=np.float32)
    b = np.zeros((10,), dtype=np.float32)
    w[0:6] = np.asarray(vh['sv3Mul']['w'], dtype=np.float32)[0:6]
    b[0:6] = np.asarray(vh['sv3Bias']['b'], dtype=np.float32)[0:6]
    sd['value_head.linear_miscvaluehead.weight'] = w
    sd['value_head.linear_miscvaluehead.bias'] = b
    sd['value_head.conv_ownership.weight'] = vh['vOwnershipConv']['w']
    return sd


def load_input(prefix):
    a = np.fromfile(prefix + '.in.bin', dtype=np.float32)
    sp = a[:22 * 361].reshape(1, 22, 19, 19).copy()
    gl = a[22 * 361:22 * 361 + 19].reshape(1, 19).copy()
    return sp, gl


def load_cpp_out(prefix):
    a = np.fromfile(prefix + '.out.bin', dtype=np.float32)
    return a[:362], a[362:365]


def softmax(x):
    e = np.exp(x - x.max())
    return e / e.sum()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--weights', default=os.path.join(REPO, 'kata1.bin.gz'))
    ap.add_argument('--out', default=os.path.join(HERE, 'kata1_b11_fson.onnx'))
    ap.add_argument('--check-only', action='store_true')
    args = ap.parse_args()

    print('== parse weights')
    M = L.load(args.weights, verbose=False)
    print('   name=%s version=%d trunkNormKind=%d' % (
        M['name'], M['modelVersion'], M['trunk']['trunkNormKind']))

    print('== build official PyTorch graph (config %s)' % CFG_NAME)
    Model, mc = load_official()
    cfg = mc.config_of_name[CFG_NAME].copy()
    assert cfg['norm_kind'] == 'fixscaleonenorm' and cfg.get('bnorm_use_gamma') is True
    model = Model(cfg, 19).eval()
    model.initialize()

    print('== map weights')
    sd = build_state_dict(M, model)
    target = {}
    for k, v in model.state_dict().items():
        if k in sd:
            a = np.ascontiguousarray(sd[k], dtype=np.float32)
            if tuple(a.shape) != tuple(v.shape):
                raise SystemExit('shape mismatch %s: file %s vs model %s'
                                 % (k, a.shape, tuple(v.shape)))
            target[k] = torch.from_numpy(a).clone()
    missing = model.load_state_dict(target, strict=False)
    print('   loaded %d/%d tensors; missing=%d unexpected=%d'
          % (len(target), len(model.state_dict()), len(missing.missing_keys),
             len(missing.unexpected_keys)))
    if missing.missing_keys:
        print('   missing keys:', missing.missing_keys[:12])

    # ---- validate PyTorch vs our native C++ on the SAME inputs ----
    print('== PyTorch vs our C++ (same encoded inputs)')
    for tag in ('empty', 'p0', 'p1', 'p2'):
        inpf = os.path.join(HERE, 'cmp_kata1_%s.in.bin' % tag)
        outf = os.path.join(HERE, 'cmp_kata1_%s.out.bin' % tag)
        if not os.path.exists(inpf):
            continue
        sp, gl = load_input(os.path.join(HERE, 'cmp_kata1_%s' % tag))
        mask = torch.ones((1, 1, 19, 19), dtype=torch.float32)
        with torch.no_grad():
            res = model(torch.from_numpy(sp), torch.from_numpy(gl), mask)
        # output tensors: policy (1,6,362), value (1,3)
        fr = flatten(res)
        pol_t = next(t for t in fr if t.dim() == 3 and t.shape[1] == 6 and t.shape[2] == 362)
        val_t = next(t for t in fr if t.dim() == 2 and t.shape[1] == 3)
        pol_np = pol_t[0, 0].numpy().astype('float64')   # channel 0: 361 + pass logits
        val_np = val_t[0].numpy().astype('float64')
        cpp_pol, cpp_val = load_cpp_out(os.path.join(HERE, 'cmp_kata1_%s' % tag))
        d_logit = np.abs(pol_np[:362] - cpp_pol[:362].astype('float64'))
        d_prob = np.abs(softmax(pol_np) - softmax(cpp_pol.astype('float64')))
        dval = np.abs(val_np - cpp_val)
        print('  %-6s policy logit maxdiff=%.2e  prob maxdiff=%.2e  value maxdiff=%.2e'
              % (tag, d_logit.max(), d_prob.max(), dval.max()))
        print('         pytorch val=%s  cpp val=%s' % (
            np.round(val_np, 4), np.round(cpp_val, 4)))

    if args.check_only:
        return 0

    # ---------------- ONNX export + ORT validation ----------------
    sys.path.insert(0, os.path.join(REPO, 'tools'))
    import export_onnx as EO  # official exporter helpers (Wrapper / patches)

    EO.patch_rmsnorm()
    EO.patch_sdpa()
    wrapper = EO.Wrapper(model).eval()

    sp, gl = load_input(os.path.join(HERE, 'cmp_kata1_empty'))
    spatial = torch.from_numpy(sp)
    glob = torch.from_numpy(gl)
    print('== export ONNX -> %s' % args.out, flush=True)
    torch.onnx.export(
        wrapper, (spatial, glob), args.out,
        input_names=['spatial', 'global'], output_names=EO.OUT_NAMES,
        opset_version=17, dynamo=False, do_constant_folding=True,
    )
    print('   wrote %.1f MB' % (os.path.getsize(args.out) / 1e6), flush=True)

    print('== ONNX Runtime (CPU) vs PyTorch')
    import onnxruntime as ort
    sess = ort.InferenceSession(args.out, providers=['CPUExecutionProvider'])
    for tag in ('empty', 'p0', 'p1', 'p2'):
        inpf = os.path.join(HERE, 'cmp_kata1_%s.in.bin' % tag)
        if not os.path.exists(inpf):
            continue
        sp, gl = load_input(os.path.join(HERE, 'cmp_kata1_%s' % tag))
        with torch.no_grad():
            ref = flatten(wrapper(torch.from_numpy(sp), torch.from_numpy(gl)))
        pol_pt = next(t for t in ref if t.dim() == 3 and t.shape[1] == 6 and t.shape[2] == 362)[0, 0].numpy()
        val_pt = next(t for t in ref if t.dim() == 2 and t.shape[1] == 3)[0].numpy()
        outs = sess.run(None, {'spatial': sp, 'global': gl})
        pol_ort = np.asarray(outs[0])[0, 0].reshape(-1).astype('float64')
        val_ort = np.asarray(outs[1])[0].astype('float64')
        dpol = np.abs(softmax(pol_pt.astype('float64')) - softmax(pol_ort))
        dval = np.abs(val_pt.astype('float64') - val_ort)
        print('  %-6s policy prob maxdiff=%.2e  value maxdiff=%.2e' % (tag, dpol.max(), dval.max()))
    # save torch outputs for the record
    np.savez(os.path.join(HERE, 'ref_fson_empty.npz'),
             spatial=sp, global_=gl, policy=np.asarray(outs[0]), value=np.asarray(outs[1]))
    print('OK')
    return 0


def flatten(res, acc=None):
    if acc is None:
        acc = []
    if torch.is_tensor(res):
        acc.append(res)
    elif isinstance(res, (tuple, list)):
        for x in res:
            flatten(x, acc)
    elif isinstance(res, dict):
        for k in sorted(res):
            flatten(res[k], acc)
    return acc


if __name__ == '__main__':
    sys.exit(main())
