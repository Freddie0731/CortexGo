# -*- coding: utf-8 -*-
"""tools/fetch_github.py -- download GitHub release assets on this box.

Why this script exists (diagnosed 2026-10, see tools/README_github.md)
----------------------------------------------------------------------
1. curl.exe / PowerShell HTTPS is BROKEN here: schannel reports
   SEC_E_NO_CREDENTIALS / "the underlying connection was closed". The process
   cannot get a Schannel client credential. This is NOT a network problem.
   => every network call here uses Python (OpenSSL + certifi), never curl /
      Invoke-WebRequest / Test-NetConnection.
2. github.com:443 is unreachable (TCP timeout). But api.github.com IS reachable,
   and the REST "download a release asset" endpoint
       GET https://api.github.com/repos/<owner>/<repo>/releases/assets/<id>
       Accept: application/octet-stream
   answers 302 -> https://release-assets.githubusercontent.com/... which IS
   reachable. So **the primary channel is the GitHub API asset endpoint**,
   which needs no third-party proxy at all.
3. Third-party proxies are only a fallback. Measured on this box:
       ghproxy.net, gh-proxy.org, gh.ddlc.top   -> Range GET works (206)
       gh-proxy.com  -> HEAD 200 then GET hangs/0 bytes (do not use first)
       ghfast.top, moeyy, gh.llkk.cc, ghproxy.cc -> TLS handshake timeout
       hub.gitmirror.com, gh.xxooo.cf, ghproxy.cfd -> DNS fails
4. Every request uses a read timeout + Range resume, so a "hangs forever,
   0 bytes" proxy is detected in seconds and the next channel is tried.

Usage
-----
    python tools/fetch_github.py probe [--range-test]
        Show, per channel, whether a 1 MiB Range GET really returns bytes.

    python tools/fetch_github.py list lightvector/KataGo [tag]
        List release assets (name, size, API asset id).

    python tools/fetch_github.py get <owner/repo> <tag> <asset> [options]
        Download an asset with channel fallback + resume + retries.
        --out DIR       destination directory (default build_out/downloads)
        --timeout SEC   per-read socket timeout (default 20)
        --retries N     attempts per channel (default 4)
        --channel NAME  force one channel: api | proxy:<prefix> | direct
        --sha256 HEX    verify digest after download
        --no-verify     skip gzip sanity check

    python tools/fetch_github.py get-url <github release asset URL> [options]

Examples
--------
    python tools/fetch_github.py list lightvector/KataGo v1.17.1
    python tools/fetch_github.py get lightvector/KataGo v1.17.1 \\
        b10c384h6nbttflrs.bin.gz --out build_out\\github\\nets
"""
import argparse
import hashlib
import json
import os
import re
import socket
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
import zlib

API = 'https://api.github.com'
UA = {'User-Agent': 'goai3-fetch/2.0', 'Accept': '*/*'}
CHUNK = 1 << 20

# Fallback proxies. Order = order they are tried. Dead ones stay listed on
# purpose so `probe` keeps telling us when they come back.
PROXIES = [
    'https://ghproxy.net/',
    'https://gh-proxy.org/',
    'https://gh.ddlc.top/',
    'https://gh-proxy.com/',      # known: HEAD ok, GET may hang (kept last)
    'https://ghfast.top/',
    'https://github.moeyy.xyz/',
    'https://gh.llkk.cc/',
    'https://ghproxy.cc/',
]


def _req(url, headers=None, method=None, timeout=25):
    h = dict(UA)
    if headers:
        h.update(headers)
    return urllib.request.Request(url, headers=h, method=method)


def _read_json(path):
    with urllib.request.urlopen(_req(API + path), timeout=25) as r:
        return json.load(r)


def _release(repo, tag):
    return _read_json('/repos/%s/releases/tags/%s' % (repo, tag))


def _find_asset(repo, tag, name):
    rel = _release(repo, tag)
    for a in rel.get('assets', []):
        if a['name'] == name:
            return a
    names = [a['name'] for a in rel.get('assets', []) if a['name'].endswith('.bin.gz')]
    raise SystemExit('asset not found: %s (tag %s)\n  nets in this tag: %s'
                     % (name, tag, ', '.join(names) or '(none)'))


def _bytes_of(url, n, timeout):
    """Read up to n bytes; return (status, bytes, headers, final_url)."""
    r = urllib.request.urlopen(_req(url, {'Range': 'bytes=0-%d' % (n - 1)}), timeout=timeout)
    try:
        data = r.read(n)
    finally:
        r.close()
    return r.status, data, r.headers, r.geturl()


# --------------------------------------------------------------------- probe
def probe_targets(repo=None, tag=None, asset=None):
    """(label, url, optional Accept header) for a 1 MiB Range GET."""
    t = []
    t.append(('api.github.com/rate_limit', API + '/rate_limit', None))
    if repo and tag and asset:
        try:
            a = _find_asset(repo, tag, asset)
        except SystemExit as e:
            print('  ! %s' % e)
            a = None
        if a:
            t.append(('api-asset  (direct)',
                      '%s/repos/%s/releases/assets/%d' % (API, repo, a['id']),
                      {'Accept': 'application/octet-stream'}))
            for p in PROXIES:
                t.append(('proxy ' + p, p + a['browser_download_url'], None))
            t.append(('direct github.com', a['browser_download_url'], None))
    t.append(('hf-mirror.com', 'https://hf-mirror.com/api/models?search=katago', None))
    t.append(('gitee.com', 'https://gitee.com/', None))
    return t


def cmd_probe(args):
    print('Per-channel 1 MiB Range GET (Python/OpenSSL; trust this over curl).\n')
    ok = 0
    for label, url, acc in probe_targets(args.repo, args.tag, args.asset):
        t0 = time.time()
        try:
            status, data, hdrs, final = _bytes_of(url, 1 << 20, args.timeout)
            dt = time.time() - t0
            gz = data[:2] == b'\x1f\x8b'
            good = status in (200, 206) and len(data) > 1024
            ok += bool(good)
            print('  %-46s %-4s %8d B  %5.1fs  %s%s' % (
                label, status, len(data), dt,
                'OK' if good else 'BAD', '  (gzip)' if gz else ''))
            if good and 'api-asset' in label:
                print('        final host: %s' % final.split('/')[2])
                print('        content-range: %s' % hdrs.get('Content-Range'))
        except urllib.error.HTTPError as e:
            print('  %-46s HTTP %-3s %5.1fs  FAIL %s' % (label, e.code, time.time() - t0,
                                                          e.read(80).decode('utf-8', 'replace').strip()))
        except Exception as e:
            print('  %-46s %-4s %8d B  %5.1fs  FAIL %s: %s' % (
                label, '-', 0, time.time() - t0, type(e).__name__, str(e)[:70]))
    print('\n%d channel(s) usable. api-asset needs no proxy at all.' % ok)


# ---------------------------------------------------------------------- list
def cmd_list(args):
    if args.tag:
        rels = [_release(args.repo, args.tag)]
    else:
        rels = _read_json('/repos/%s/releases?per_page=6' % args.repo)
    for rel in rels:
        assets = rel.get('assets', [])
        nets = [a for a in assets if a['name'].endswith('.bin.gz')]
        print('=== %s  %s  (assets %d, nets %d)' % (
            rel.get('tag_name'), (rel.get('published_at') or '')[:10], len(assets), len(nets)))
        for a in nets:
            print('    %-62s %8.1f MB  id=%d' % (a['name'], a['size'] / 1e6, a['id']))


# ------------------------------------------------------------------ download
class ChannelError(Exception):
    pass


def _channels(repo, tag, asset, only=None):
    """Yield (name, url) where url is recomputed per attempt."""
    a = _find_asset(repo, tag, asset)
    cand = [('api', '%s/repos/%s/releases/assets/%d' % (API, repo, a['id']),
             {'Accept': 'application/octet-stream'})]
    for p in PROXIES:
        if p.rstrip('/') in ('https://gh-proxy.com',):
            continue          # known-broken GET, only in probe
        cand.append(('proxy:' + p.rstrip('/'), p + a['browser_download_url'], None))
    cand.append(('direct', a['browser_download_url'], None))
    for name, url, acc in cand:
        if only and name != only:
            continue
        yield name, url, acc, a['size']


def _download_one(url, acc, dst, expect_size, timeout, retries):
    """Download url -> dst with Range resume. Returns 'ok' or raises ChannelError."""
    part = dst + '.part'
    last = None
    for attempt in range(1, retries + 1):
        have = os.path.getsize(part) if os.path.exists(part) else 0
        if expect_size and have == expect_size:
            return 'ok'
        if expect_size and have > expect_size:
            os.remove(part)
            have = 0
        headers = {}
        if acc:
            headers.update(acc)
        if have:
            headers['Range'] = 'bytes=%d-' % have
        t0 = time.time()
        got = 0
        try:
            r = urllib.request.urlopen(_req(url, headers), timeout=timeout)
            status = r.status
            # server ignored our Range -> restart from scratch
            if have and status == 200:
                r.close()
                os.remove(part)
                have = 0
                r = urllib.request.urlopen(_req(url, acc or {}), timeout=timeout)
                status = r.status
            if status not in (200, 206):
                raise ChannelError('HTTP %s' % status)
            mode = 'ab' if have else 'wb'
            done = have
            with open(part, mode) as f:
                f.write(b'')
                while True:
                    chunk = r.read(CHUNK)
                    if not chunk:
                        break
                    f.write(chunk)
                    got += len(chunk)
                    done += len(chunk)
                    el = max(time.time() - t0, 1e-6)
                    if expect_size:
                        sys.stdout.write('\r    %5.1f%%  %7.1f/%7.1f MB  %5.2f MB/s' % (
                            100.0 * done / expect_size, done / 1e6, expect_size / 1e6,
                            got / 1e6 / el))
                    else:
                        sys.stdout.write('\r    %7.1f MB  %5.2f MB/s' % (
                            done / 1e6, got / 1e6 / el))
                    sys.stdout.flush()
            r.close()
            sys.stdout.write('\n')
            size = os.path.getsize(part)
            if expect_size and size != expect_size:
                raise ChannelError('short file: %d/%d bytes' % (size, expect_size))
            return 'ok'
        except ChannelError as e:
            last = str(e)
        except urllib.error.HTTPError as e:
            if e.code == 416:
                return 'ok'                     # already complete
            last = 'HTTP %s' % e.code
        except (urllib.error.URLError, socket.timeout, TimeoutError, ConnectionError, OSError) as e:
            last = '%s: %s' % (type(e).__name__, str(e)[:90])
        try:
            have_now = os.path.getsize(part) if os.path.exists(part) else 0
        except OSError:
            have_now = 0
        sys.stdout.write('\n')
        print('    attempt %d/%d failed after %.1fs (%d bytes kept): %s'
              % (attempt, retries, time.time() - t0, have_now, last), flush=True)
        if attempt < retries and have_now == have:
            time.sleep(min(2 * attempt, 6))     # no progress -> brief backoff
    raise ChannelError(last or 'unknown')


def _verify_gzip(path):
    d = zlib.decompressobj(16 + zlib.MAX_WBITS)
    total = 0
    with open(path, 'rb') as f:
        while True:
            b = f.read(CHUNK)
            if not b:
                break
            total += len(d.decompress(b))
    if not d.eof:
        raise SystemExit('gzip integrity check FAILED: stream truncated')
    return total


def _sha256(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for b in iter(lambda: f.read(CHUNK), b''):
            h.update(b)
    return h.hexdigest()


def _do_get(repo, tag, asset, outdir, args):
    os.makedirs(outdir, exist_ok=True)
    dst = os.path.join(outdir, asset)
    if os.path.exists(dst) and args.sha256:
        if _sha256(dst) == args.sha256.lower():
            print('already present and sha256 matches: %s' % dst)
            return dst
    errors = []
    for name, url, acc, size in _channels(repo, tag, asset, args.channel):
        print('\n[channel %s] %s' % (name, url[:120]), flush=True)
        try:
            _download_one(url, acc, dst, size, args.timeout, args.retries)
        except ChannelError as e:
            print('  channel %s FAILED: %s' % (name, e), flush=True)
            errors.append('%s: %s' % (name, e))
            continue
        if not args.no_verify:
            print('  checking gzip stream ...', end=' ', flush=True)
            raw = _verify_gzip(dst + '.part')
            print('ok (%d bytes uncompressed)' % raw, flush=True)
        os.replace(dst + '.part', dst)
        sz = os.path.getsize(dst)
        digest = _sha256(dst)
        print('  saved %s  (%.2f MB)' % (dst, sz / 1e6))
        print('  sha256 %s' % digest)
        if args.sha256 and digest.lower() != args.sha256.lower():
            raise SystemExit('sha256 MISMATCH: expected %s' % args.sha256)
        return dst
    raise SystemExit('all channels failed for %s:\n  %s' % (asset, '\n  '.join(errors)))


def _parse_gh_url(url):
    m = re.match(r'https?://github\.com/([^/]+)/([^/]+)/releases/download/([^/]+)/(.+)$', url)
    if not m:
        raise SystemExit('not a release asset URL: %s' % url)
    return (m.group(1) + '/' + m.group(2), m.group(3),
            urllib.parse.unquote(m.group(4)))


def main():
    ap = argparse.ArgumentParser(description='GitHub asset downloader for this box')
    sub = ap.add_subparsers(dest='cmd', required=True)

    p = sub.add_parser('probe', help='test channels with a 1 MiB Range GET')
    p.add_argument('--repo', default='')
    p.add_argument('--tag', default='')
    p.add_argument('--asset', default='')
    p.add_argument('--range-test', action='store_true', help='(default behaviour; kept for compatibility)')
    p.add_argument('--timeout', type=float, default=15)
    p.set_defaults(repo='lightvector/KataGo', tag='v1.17.1',
                   asset='b10c384h6nbttflrs.bin.gz')

    p = sub.add_parser('list')
    p.add_argument('repo')
    p.add_argument('tag', nargs='?', default='')

    def add_dl(p):
        p.add_argument('--out', default=os.path.join('build_out', 'downloads'))
        p.add_argument('--timeout', type=float, default=20, help='per-read socket timeout (s)')
        p.add_argument('--retries', type=int, default=4, help='attempts per channel')
        p.add_argument('--channel', default='', help='api | proxy:<prefix> | direct')
        p.add_argument('--sha256', default='')
        p.add_argument('--no-verify', action='store_true', help='skip gzip check')

    p = sub.add_parser('get')
    p.add_argument('repo')
    p.add_argument('tag')
    p.add_argument('asset')
    add_dl(p)

    p = sub.add_parser('get-url')
    p.add_argument('url')
    add_dl(p)

    args = ap.parse_args()
    if args.cmd == 'probe':
        cmd_probe(args)
    elif args.cmd == 'list':
        cmd_list(args)
    elif args.cmd == 'get':
        _do_get(args.repo, args.tag, args.asset, args.out, args)
    elif args.cmd == 'get-url':
        repo, tag, asset = _parse_gh_url(args.url)
        _do_get(repo, tag, asset, args.out, args)
    return 0


if __name__ == '__main__':
    sys.exit(main())
