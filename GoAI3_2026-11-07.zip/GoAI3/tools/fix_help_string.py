# -*- coding: utf-8 -*-
"""修复 patch_root_symmetry.py 第 7 条补丁打坏的 --help 字符串字面量。

原因：那条 help 文案位于一个多行 C++ 字符串字面量里，补丁在里面插入了裸换行，
造成 "newline in string literal"。这里把损坏的两行还原成正确的两行。
"""
import io
import sys

PATH = 'go_ai.cpp'

BROKEN = ('                "  --symmetries N    network evaluations per non-root position, 1..8 (default 1)\n'
          '  --root-symmetries N  network evaluations at the root only, 1..8 (default 8)\\n"')

FIXED = ('                "  --symmetries N    network evaluations per non-root position, 1..8 (default 1)\\n"\n'
         '                "  --root-symmetries N  network evaluations at the root only, 1..8 (default 8)\\n"')


def main():
    raw = io.open(PATH, 'r', encoding='utf-8', newline='').read()
    text = raw.replace('\r\n', '\n')
    n = text.count(BROKEN)
    print('损坏区段出现次数: %d' % n)
    if n != 1:
        raise SystemExit('没找到预期的损坏区段，停止（避免二次破坏）')
    text = text.replace(BROKEN, FIXED)
    out = text.replace('\r\n', '\n').replace('\n', '\r\n')
    io.open(PATH, 'w', encoding='utf-8', newline='').write(out)
    print('修复完成')
    return 0


if __name__ == '__main__':
    sys.exit(main())
