#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""GoAI3 regression / proof suite.

Runs a whole battery of checks against one or more engine executables and
prints one table, so a change can be judged without remembering ten commands:

  1. artifact     executable exists, size/mtime/sha256, build tag
  2. selftest     `exe --selftest` -> SELF TEST PASSED, plus the invariants
                  (symmetry/legal-set/prior normalisation/empty-board search)
  3. benchmark    `exe --benchmark --time T --threads N` -> visits/s, depth,
                  nn/sim (should approach 1.0; 1.5 with only 2 visits is the
                  unavoidable root-expansion overhead, not a regression)
  4. gtp          protocol_version, empty-board genmove, error replies,
                  genmove colour handling, final_score availability
  5. match        a short A/B match between two exes (reuses tools/match.py)

Usage (from the repository root):

  # default: both bundled exes, all checks except the (slow) A/B match
  python tools\\verify.py

  # full proof run including a quick A/B match
  python tools\\verify.py --match-games 2 --match-sims 2 --match-max-moves 20

  # fast full run using the heuristic (no-NN) search on both sides
  python tools\\verify.py --match-games 6 --match-sims 1 --match-max-moves 40 \\
      --match-args=--no-nn

  # compare two saved runs ("before vs after")
  python tools\\verify.py compare build_out\\match\\verify_before.json \\
      build_out\\match\\verify_after.json

The JSON result goes to build_out/match/last_verify.json by default.
All scratch output stays under build_out/match/.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import re
import shlex
import subprocess
import sys
import time
from pathlib import Path

TOOLS_DIR = Path(__file__).resolve().parent
REPO = Path.cwd()
sys.path.insert(0, str(TOOLS_DIR))
import match  # noqa: E402  (same-directory helper, also a delivered script)

DEFAULT_EXES = ["x64/Release/GoAI3.exe", "build_out/GoAI3_test.exe"]


# ----------------------------------------------------------------------------
# small helpers
# ----------------------------------------------------------------------------

def decode_bytes(raw):
    for enc in ("utf-8", "gbk", "latin-1"):
        try:
            return raw.decode(enc)
        except UnicodeDecodeError:
            continue
    return raw.decode("utf-8", "replace")


def run_proc(argv, cwd, timeout):
    t0 = time.perf_counter()
    try:
        proc = subprocess.run([str(a) for a in argv], cwd=str(cwd),
                              capture_output=True, timeout=timeout)
        out = decode_bytes(proc.stdout)
        err = decode_bytes(proc.stderr)
        return {"argv": [str(a) for a in argv], "rc": proc.returncode,
                "stdout": out, "stderr": err, "timed_out": False,
                "wall_s": round(time.perf_counter() - t0, 2)}
    except subprocess.TimeoutExpired as exc:
        out = decode_bytes(exc.stdout or b"")
        err = decode_bytes(exc.stderr or b"")
        return {"argv": [str(a) for a in argv], "rc": None,
                "stdout": out, "stderr": err, "timed_out": True,
                "wall_s": round(time.perf_counter() - t0, 2)}
    except OSError as exc:
        return {"argv": [str(a) for a in argv], "rc": None, "stdout": "",
                "stderr": str(exc), "timed_out": False,
                "wall_s": round(time.perf_counter() - t0, 2)}


def short_sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()[:16]


def exe_label(path):
    p = Path(path)
    text = str(p).replace("\\", "/").lower()
    if "build_out" in text and "test" in text:
        return "current"
    if "x64/release" in text:
        return "store"
    return p.stem


def table(rows, headers):
    widths = [len(h) for h in headers]
    for row in rows:
        for i, cell in enumerate(row):
            widths[i] = max(widths[i], len(str(cell)))
    line = "  ".join(str(h).ljust(widths[i]) for i, h in enumerate(headers))
    sep = "  ".join("-" * widths[i] for i in range(len(headers)))
    out = [line, sep]
    for row in rows:
        out.append("  ".join(str(cell).ljust(widths[i])
                             for i, cell in enumerate(row)))
    return "\n".join(out)


def _num(value, digits=3):
    if isinstance(value, float):
        if math.isnan(value) or math.isinf(value):
            return str(value)
        return ("%%.%df" % digits) % value
    return str(value)


# ----------------------------------------------------------------------------
# checks
# ----------------------------------------------------------------------------

def check_artifact(name, exe):
    path = Path(exe)
    ok = path.is_file()
    values = {"path": str(path), "exists": ok}
    detail = ""
    if ok:
        st = path.stat()
        values.update({"size": st.st_size,
                       "mtime": time.strftime("%Y-%m-%d %H:%M:%S",
                                              time.localtime(st.st_mtime)),
                       "sha256": short_sha256(path)})
        values["build_tag"] = match.detect_build_tag(path, REPO)
        detail = ("size=%d  sha256=%s  build=%s"
                  % (st.st_size, values["sha256"],
                     values.get("build_tag")))
    else:
        detail = "MISSING: %s" % path
    return {"name": "artifact:%s" % name,
            "status": "PASS" if ok else "FAIL",
            "detail": detail, "values": values,
            "duration_s": 0.0}


def check_selftest(name, exe, timeout=1800):
    res = run_proc([exe, "--selftest"], REPO, timeout)
    text = res["stdout"] + "\n" + res["stderr"]
    values = {"exit_code": res["rc"], "wall_s": res["wall_s"],
              "lines": [ln for ln in text.splitlines() if ln.strip()][:40]}
    fields = {
        "legal_enumeration": r"legal move enumeration is exact \((\d+) moves\)",
        "policy_width": r"policy=(\d+) \(want (\d+)\)",
        "prior_sum": r"priors normalise \(n=(\d+) sum=([\d.]+) min=([\d.eE+-]+) max=([\d.]+)",
        "empty_move": r"empty-board search: move=(\S+) visits=(\d+) wr=([\d.]+)% depth=(\d+) ([\d.]+)s policy_sum=([\d.]+) nn=(\w+)",
    }
    m = re.search(fields["legal_enumeration"], text)
    if m:
        values["legal_moves_count"] = int(m.group(1))
    m = re.search(fields["empty_move"], text)
    if m:
        values.update({"empty_genmove": m.group(1),
                       "empty_visits": int(m.group(2)),
                       "empty_winrate": float(m.group(3)),
                       "empty_depth": int(m.group(4)),
                       "empty_seconds": float(m.group(5)),
                       "policy_sum": float(m.group(6)),
                       "empty_uses_nn": m.group(7) == "yes"})
    m = re.search(fields["prior_sum"], text)
    if m:
        values.update({"prior_count": int(m.group(1)),
                       "prior_sum": float(m.group(2)),
                       "prior_min": float(m.group(3)),
                       "prior_max": float(m.group(4))})
    failed = [ln.strip() for ln in text.splitlines() if "[FAIL]" in ln]
    passed = ("SELF TEST PASSED" in text) and res["rc"] == 0
    status = "PASS" if passed else "FAIL"
    if passed and failed:
        status = "WARN"
    detail = ("PASSED in %.1fs" % res["wall_s"]) if passed else \
        ("FAILED rc=%r%s" % (res["rc"], " (timeout)" if res["timed_out"] else ""))
    if values.get("empty_genmove"):
        detail += ("  empty genmove=%s visits=%s wr=%s%% depth=%s"
                   % (values["empty_genmove"], values.get("empty_visits"),
                      values.get("empty_winrate"), values.get("empty_depth")))
    if failed:
        detail += "  failed=%d" % len(failed)
        values["failed_lines"] = failed
    return {"name": "selftest:%s" % name, "status": status,
            "detail": detail, "values": values,
            "duration_s": res["wall_s"]}


BENCH_LINE_RE = re.compile(
    r"t=\s*([\d.]+)s\s+visits=\s*(\d+)\s+depth=\s*(\d+)\s+"
    r"(\d+) visits/s\s+nn=(\d+) \(([\d.]+)/sim, ([\d.]+)/s\)\s+([\d.]+)s")


def check_benchmark(name, exe, time_budget=1.0, threads=2, timeout=1800):
    res = run_proc([exe, "--benchmark", "--time", "%g" % time_budget,
                    "--threads", str(threads)], REPO, timeout)
    text = res["stdout"] + "\n" + res["stderr"]
    cases = []
    for m in BENCH_LINE_RE.finditer(text):
        seconds = float(m.group(8))
        nn_calls = int(m.group(5))
        cases.append({
            "budget_s": float(m.group(1)),
            "visits": int(m.group(2)),
            "depth": int(m.group(3)),
            "visits_per_s": round(int(m.group(2)) / seconds, 2) if seconds > 0 else None,
            "nn_calls": nn_calls,
            "nn_per_sim": float(m.group(6)),
            "nn_per_s": float(m.group(7)),
            "seconds": seconds,
            "forward_s": round(seconds / nn_calls, 3) if nn_calls else None,
        })
    network_loaded = "network: loaded" in text
    values = {"exit_code": res["rc"], "wall_s": res["wall_s"],
              "network_loaded": network_loaded, "cases": cases}
    status = "PASS"
    notes = []
    if res["timed_out"]:
        status, notes = "FAIL", ["benchmark timed out"]
    elif not cases:
        status, notes = "FAIL", ["could not parse any benchmark case line"]
    elif not network_loaded:
        status, notes = "FAIL", ["network NOT loaded (heuristic search)"]
    else:
        last = cases[-1]
        values["max_visits"] = max(c["visits"] for c in cases)
        values["nn_per_sim"] = last["nn_per_sim"]
        values["forward_s"] = last["forward_s"]
        values["visits_per_s"] = last["visits_per_s"]
        values["depth"] = last["depth"]
        values["visits_grow_with_budget"] = last["visits"] > cases[0]["visits"]
        if last["nn_per_sim"] > 2.0:
            status = "FAIL"
            notes.append("nn/sim=%.2f > 2.0: positions are being evaluated twice"
                         % last["nn_per_sim"])
        elif last["nn_per_sim"] > 1.75:
            status = "WARN"
            notes.append("nn/sim=%.2f > 1.75" % last["nn_per_sim"])
        if not values["visits_grow_with_budget"]:
            status = "WARN" if status == "PASS" else status
            notes.append("visits did not grow with the time budget (machine too "
                         "slow or search stalls)")
        if last["visits"] < 8:
            status = "WARN" if status == "PASS" else status
            notes.append("only %d visits: nn/sim cannot approach 1.0 on this "
                         "machine load; treat nn/sim=%.2f as inconclusive"
                         % (last["visits"], last["nn_per_sim"]))
        if last["depth"] == 0:
            notes.append("depth=0 (expected at this visit count)")
    detail = "cases=%d  last: visits=%s visits/s=%s nn/sim=%s forward=%ss" \
             % (len(cases), values.get("max_visits"),
                _num(values.get("visits_per_s"), 1),
                _num(values.get("nn_per_sim"), 2),
                _num(values.get("forward_s"), 2))
    if notes:
        detail += "  [" + "; ".join(notes) + "]"
    values["notes"] = notes
    return {"name": "benchmark:%s" % name, "status": status,
            "detail": detail, "values": values, "duration_s": res["wall_s"]}


def check_gtp(name, exe, komi=7.5, timeout=600):
    """Start one GTP engine and probe the protocol surface plus known bugs."""
    t0 = time.time()
    values = {"exe": str(exe)}
    notes = []
    status = "PASS"
    engine = None
    try:
        engine = match.GtpEngine("verify_%s" % name, exe,
                                 ["--cli", "--max-sims", "1", "--threads", "1",
                                  "--time", "3600"], REPO,
                                 log_path=REPO / "build_out" / "match" / "logs"
                                 / ("verify_gtp_%s.log" % name),
                                 startup_timeout=timeout)
        engine.move_timeout = timeout
        t_probe = time.time()
        info = engine.startup()
        values.update({
            "protocol_version": info["protocol_version"],
            "engine_name": info["name"], "engine_version": info["version"],
            "commands": info["commands"],
            "nn_loaded_from_stderr": info["nn_loaded"],
            "nn_fallback": info["nn_fallback"],
            "startup_s": round(time.time() - t_probe, 2),
        })
        values["supports_final_score"] = "final_score" in info["commands"]
        values["supports_showboard"] = "showboard" in info["commands"]
        if info["protocol_version"] != "2":
            status = "FAIL"
            notes.append("protocol_version=%r" % info["protocol_version"])
        if info["nn_fallback"]:
            notes.append("engine fell back to heuristic search (weights not "
                         "loaded; wrong working directory?)")
        # basic setup
        engine.send_ok("boardsize 19")
        engine.send_ok("komi %g" % komi)
        engine.clear_board()
        # empty-board genmove
        body, lines, wall = engine.genmove("B")
        token, stats = match.parse_genmove(body)
        idx = match.gtp_to_index(token)
        empty_legal = idx == match.PASS or (idx != -2
                                            and match.Board().is_legal(idx))
        values.update({"empty_genmove": token,
                       "empty_genmove_legal": bool(empty_legal),
                       "empty_visits": stats["visits"],
                       "empty_winrate": stats["winrate"],
                       "empty_depth": stats["depth"],
                       "empty_search_s": stats["seconds"],
                       "empty_wall_s": round(wall, 2),
                       "uses_nn": not stats["no_nn"]})
        if not empty_legal:
            status = "FAIL"
            notes.append("empty-board genmove %r is not a legal coordinate" % token)
        # After `genmove b` it is White's turn, so `play B ...` MUST be rejected.
        # A spec-compliant engine answers with "?" -- GtpEngine.command() then
        # raises GtpCommandError, which used to abort the whole probe (the old
        # engine always answered "=", so this path was never exercised).
        try:
            body2, lines2, _ = engine.command(
                "play B %s" % ("D4" if token != "D4" else "Q16"))
            first_reply = lines2[0] if lines2 else ""
            values["error_reply_uses_question_mark"] = first_reply.startswith("?")
            values["error_reply_example"] = first_reply
            if not values["error_reply_uses_question_mark"]:
                notes.append("GTP errors are sent with '=' not '?' "
                             "(spec violation)")
            values["wrong_colour_play_response"] = body2.strip()
            if not body2.strip():
                notes.append("'play B ...' on White's turn was accepted "
                             "(colour validation missing?)")
        except match.GtpCommandError as exc:
            values["error_reply_uses_question_mark"] = True
            values["error_reply_example"] = "? " + str(exc.response)
            values["wrong_colour_play_response"] = str(exc.response)
        # final_score
        try:
            body3, _, _ = engine.command("final_score")
        except match.GtpCommandError as exc:
            body3 = str(exc.response)
        values["final_score_response"] = str(body3).strip()
        if not values["supports_final_score"]:
            notes.append("no final_score command: the harness must score the "
                         "board itself")
        # genmove colour handling: on a fresh board `genmove w` must either be
        # rejected or place a WHITE stone; go_ai.cpp ignores the colour, plays a
        # BLACK stone and leaves White to move.
        engine.clear_board()
        genmove_w_rejected = False
        try:
            body4, lines4, _ = engine.genmove("W")
            token4, stats4 = match.parse_genmove(body4)
        except match.GtpCommandError:
            genmove_w_rejected = True
            token4, stats4 = "", {}
        body5 = "sentinel"
        if not genmove_w_rejected:
            body5, _, _ = engine.command("play B pass")
        ignored = (not genmove_w_rejected) and bool(body5.strip())
        values["genmove_w_rejected"] = genmove_w_rejected
        values["genmove_ignores_colour"] = ignored
        values["genmove_w_token"] = token4
        if ignored:
            notes.append("genmove ignores its colour argument (it generates for "
                         "board.to_move) - engine bug")
        # komi with no argument is silently accepted (bug)
        engine.clear_board()
        try:
            body6, _, _ = engine.command("komi")
            values["komi_missing_arg_rejected"] = bool(str(body6).strip())
        except match.GtpCommandError as exc:
            # Correct behaviour: a missing argument is a syntax error, which
            # a spec-compliant engine reports with "?".
            body6 = str(exc.response)
            values["komi_missing_arg_rejected"] = True
        if not str(body6).strip():
            notes.append("'komi' with no argument is silently accepted "
                         "(should be an error)")
        values["protocol_findings"] = notes
        values["wall_s"] = round(time.time() - t0, 2)
        if notes and status == "PASS":
            status = "WARN"
    except Exception as exc:
        status = "FAIL"
        notes.append(str(exc))
        values["protocol_findings"] = notes
        values["wall_s"] = round(time.time() - t0, 2)
    finally:
        if engine is not None:
            try:
                engine.close()
            except Exception:
                pass
    core = ("proto=%s  empty=%s visits=%s wr=%s%% wall=%ss  quirks=%d"
            % (values.get("protocol_version"), values.get("empty_genmove"),
               values.get("empty_visits"), values.get("empty_winrate"),
               values.get("empty_wall_s"), len(notes)))
    return {"name": "gtp:%s" % name, "status": status, "detail": core,
            "values": values, "duration_s": values["wall_s"]}


def check_match(label, exe_a, exe_b, args):
    """Run a short A/B match between the two engines (reuses tools/match.py)."""
    if args.match_games <= 0:
        return {"name": "match:%s" % label, "status": "SKIP",
                "detail": ("skipped (pass --match-games N to run a short A/B; "
                           "e.g. --match-games 2 --match-sims 2 --match-max-moves 20)"),
                "values": {}, "duration_s": 0.0}
    t0 = time.time()
    opening_args = argparse.Namespace(
        opening=args.match_opening, opening_file=[],
        sgf_dir=args.match_sgf_dir, sgf_limit=args.match_sgf_limit,
        sgf_moves=args.match_sgf_moves, shuffle_openings=False, seed=args.seed)
    try:
        openings = match.load_openings(opening_args)
    except Exception as exc:
        return {"name": "match:%s" % label, "status": "FAIL",
                "detail": "bad opening config: %s" % exc, "values": {},
                "duration_s": round(time.time() - t0, 2)}
    cfg = match.MatchConfig(
        repo=REPO, a_exe=exe_a, b_exe=exe_b,
        games=args.match_games, max_sims=args.match_sims,
        threads=args.match_threads, komi=args.komi,
        max_moves=args.match_max_moves, seed=args.seed,
        openings=openings,
        a_extra_args=shlex.split(args.match_a_args),
        b_extra_args=shlex.split(args.match_b_args),
        engine_args=shlex.split(args.match_args),
        calibrate=not args.match_no_calibrate,
        out_json=str(REPO / "build_out" / "match" / "last_verify_match.json"),
        out_dir="build_out/match",
        quiet=not args.verbose, sgf=True,
        max_total_minutes=args.match_max_minutes,
        force=args.match_force, fwd_est=args.fwd_est,
        verbose=args.verbose)
    runner = match.MatchRunner(cfg)
    result = runner.run()
    if "error" in result:
        return {"name": "match:%s" % label, "status": "FAIL",
                "detail": "match refused: %s" % result["error"],
                "values": {"error": result["error"]},
                "duration_s": round(time.time() - t0, 2)}
    s = result["summary"]
    values = {
        "games_planned": s["games_planned"], "games_valid": s["games_valid"],
        "games_invalid": s["games_invalid"],
        "a_wins": s["a_wins"], "b_wins": s["b_wins"], "draws": s["draws"],
        "a_winrate": s["a_winrate"], "wilson95_low": s["wilson95_low"],
        "wilson95_high": s["wilson95_high"],
        "elo_a_minus_b": s["elo_a_minus_b"],
        "binomial_p_one_sided": s["binomial_p_one_sided"],
        "a_significantly_stronger_95": s["a_significantly_stronger_95"],
        "sprt_decision": (s.get("sprt") or {}).get("decision"),
        "sprt_llr": (s.get("sprt") or {}).get("llr"),
        "terminations": s["terminations"],
        "double_pass_rate": s["double_pass_rate"],
        "mean_moves": s["mean_moves"],
        "mean_game_wall_s": s["mean_game_wall_s"],
        "total_wall_s": s["total_wall_s"],
        "engine_error_count": len(s["engine_errors"]),
        "config": result["config"],
        "engine_a": result["engines"]["a"].get("fingerprint"),
        "engine_b": result["engines"]["b"].get("fingerprint"),
        "match_json": result.get("_json_path"),
        "notes": result.get("notes", []),
    }
    status = "PASS"
    issues = []
    if s["games_invalid"]:
        status = "FAIL"
        issues.append("%d invalid game(s)" % s["games_invalid"])
    if s["engine_errors"]:
        status = "FAIL" if status == "FAIL" else "WARN"
        issues.append("%d engine error(s)" % len(s["engine_errors"]))
    if s["games_valid"] == 0:
        status = "FAIL"
        issues.append("no valid games")
    detail = ("%d/%d valid, A wins=%d B wins=%d, A winrate=%s, "
              "Wilson95=[%s, %s], elo=%s, %d moves/game, %.0fs"
              % (s["games_valid"], s["games_planned"], s["a_wins"],
                 s["b_wins"], _num(s["a_winrate"], 3),
                 _num(s["wilson95_low"], 3), _num(s["wilson95_high"], 3),
                 _num(s["elo_a_minus_b"], 1), s["mean_moves"] or 0,
                 s["total_wall_s"]))
    if issues:
        detail += "  [" + "; ".join(issues) + "]"
    return {"name": "match:%s" % label, "status": status, "detail": detail,
            "values": values, "duration_s": round(time.time() - t0, 2)}


# ----------------------------------------------------------------------------
# compare mode
# ----------------------------------------------------------------------------

SCALAR_TYPES = (int, float, str, bool, type(None))


def flatten(result):
    flat = {}

    def add(prefix, value):
        if isinstance(value, dict):
            for k, v in value.items():
                add("%s.%s" % (prefix, k) if prefix else str(k), v)
        elif isinstance(value, list):
            if all(isinstance(v, SCALAR_TYPES) for v in value) and len(value) <= 8:
                flat[prefix] = json.dumps(value, ensure_ascii=False)
        elif isinstance(value, SCALAR_TYPES):
            flat[prefix] = value

    schema = result.get("schema", "")
    if schema.startswith("goai3-verify"):
        for chk in result.get("checks", []):
            flat["%s.status" % chk["name"]] = chk["status"]
            for k, v in chk.get("values", {}).items():
                if k in ("lines", "commands", "protocol_findings", "notes",
                         "failed_lines", "error", "match_json"):
                    continue
                add("%s.%s" % (chk["name"], k), v)
    elif schema.startswith("goai3-match"):
        for k, v in result.get("summary", {}).items():
            if k in ("power_analysis", "engine_errors"):
                continue
            add("match.%s" % k, v)
        add("config.max_sims", result.get("config", {}).get("max_sims"))
        add("config.games", result.get("config", {}).get("games"))
    else:
        add("", result)
    return flat


def compare_results(old, new):
    fold = flatten(old)
    fnew = flatten(new)
    keys = sorted(set(fold) | set(fnew))
    rows = []
    regressions, improvements = [], []
    for key in keys:
        ov = fold.get(key)
        nv = fnew.get(key)
        if ov == nv:
            continue
        delta = ""
        if isinstance(ov, (int, float)) and isinstance(nv, (int, float)) \
                and not isinstance(ov, bool) and not isinstance(nv, bool):
            d = nv - ov
            if ov != 0:
                pct = 100.0 * d / abs(ov)
                delta = "%+.4g (%+.1f%%)" % (d, pct)
            else:
                delta = "%+.4g" % d
        rows.append([key, _num(ov, 4), _num(nv, 4), delta])
        if key.endswith(".status"):
            if ov in ("PASS", "WARN") and nv == "FAIL":
                regressions.append(key)
            elif ov == "FAIL" and nv in ("PASS", "WARN"):
                improvements.append(key)
        elif key.endswith("nn_per_sim") and isinstance(ov, float) \
                and isinstance(nv, float) and ov > 0:
            if nv > ov * 1.10:
                regressions.append("%s (+%.0f%%)" % (key, 100 * (nv / ov - 1)))
            elif nv < ov * 0.90:
                improvements.append("%s (%.0f%%)" % (key, 100 * (nv / ov - 1)))
        elif key.endswith("visits_per_s") and isinstance(ov, float) \
                and isinstance(nv, float) and ov > 0:
            if nv < ov * 0.90:
                regressions.append("%s (-%.0f%%)" % (key, 100 * (1 - nv / ov)))
            elif nv > ov * 1.10:
                improvements.append("%s (+%.0f%%)" % (key, 100 * (nv / ov - 1)))
    if not rows:
        print("No differences between the two results.")
    else:
        print("\n" + table(rows, ["METRIC", "OLD", "NEW", "DELTA"]))
    print()
    if regressions:
        print("VERDICT: REGRESSION")
        for r in regressions:
            print("  - %s" % r)
    elif improvements:
        print("VERDICT: IMPROVED / FIXED")
        for r in improvements:
            print("  + %s" % r)
    else:
        print("VERDICT: no significant change detected")
    return {"rows": rows, "regressions": regressions,
            "improvements": improvements,
            "verdict": ("REGRESSION" if regressions else
                        ("IMPROVED" if improvements else "NO_CHANGE"))}


# ----------------------------------------------------------------------------
# CLI
# ----------------------------------------------------------------------------

def build_parser():
    p = argparse.ArgumentParser(
        description="GoAI3 regression/proof suite (selftest, benchmark, GTP "
                    "probe, A/B match) with before/after comparison.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__.split("Usage")[-1][:4000])
    p.add_argument("--exe", action="append", default=[],
                   help="engine executable to test (repeatable; default: %s)"
                        % DEFAULT_EXES)
    p.add_argument("--komi", type=float, default=7.5)
    p.add_argument("--threads", type=int, default=2,
                   help="threads for the benchmark check (default %(default)s)")
    p.add_argument("--benchmark-time", type=float, default=1.0,
                   help="time budget per benchmark case (default %(default)s)")
    p.add_argument("--skip-selftest", action="store_true")
    p.add_argument("--skip-benchmark", action="store_true",
                   help="benchmark is the slow check on a loaded machine")
    p.add_argument("--skip-gtp", action="store_true")
    p.add_argument("--fwd-est", type=float, default=1.1,
                   help="forward-pass estimate for match time planning")
    p.add_argument("--seed", type=int, default=1)
    # match options
    p.add_argument("--match-games", type=int, default=0,
                   help="games for the A/B check (0 = skip; default 0)")
    p.add_argument("--match-sims", type=int, default=2)
    p.add_argument("--match-threads", type=int, default=2)
    p.add_argument("--match-max-moves", type=int, default=20)
    p.add_argument("--match-args", default="",
                   help="extra args for BOTH match engines; use "
                        "--match-args=--no-nn for a fast heuristic match")
    p.add_argument("--match-a-args", default="")
    p.add_argument("--match-b-args", default="")
    p.add_argument("--match-opening", action="append", default=[],
                   metavar="MOVES", help='opening for the match, e.g. "Q16 D4"')
    p.add_argument("--match-sgf-dir", action="append", default=[],
                   help="use SGF files from this dir for match openings")
    p.add_argument("--match-sgf-limit", type=int, default=2)
    p.add_argument("--match-sgf-moves", type=int, default=4)
    p.add_argument("--match-no-calibrate", action="store_true")
    p.add_argument("--match-max-minutes", type=float, default=90.0)
    p.add_argument("--match-force", action="store_true")
    p.add_argument("--out", default="build_out/match/last_verify.json",
                   help="result JSON path (default %(default)s)")
    p.add_argument("--json", action="store_true",
                   help="print the result JSON to stdout")
    p.add_argument("--verbose", action="store_true")
    return p


def resolve_exes(args):
    exes = args.exe or DEFAULT_EXES
    resolved = []
    for exe in exes:
        p = Path(exe)
        if not p.is_file():
            p = REPO / exe
        resolved.append(p)
    return resolved


def run_suite(args):
    exes = resolve_exes(args)
    t_start = time.time()
    result = {"schema": "goai3-verify/1",
              "generated": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
              "repo": str(REPO),
              "python": sys.version.split()[0],
              "config": {"komi": args.komi, "threads": args.threads,
                         "benchmark_time": args.benchmark_time,
                         "match_games": args.match_games,
                         "match_sims": args.match_sims,
                         "match_max_moves": args.match_max_moves,
                         "match_args": args.match_args},
              "checks": []}
    print("GoAI3 verify suite   repo=%s   python=%s"
          % (REPO, sys.version.split()[0]))
    print("exes: %s" % ", ".join(str(p) for p in exes))
    print()
    checks = result["checks"]
    labels = {}
    for exe in exes:
        label = exe_label(exe)
        labels[str(exe)] = label
        print("[1/4] artifact + selftest %s ..." % label)
        sys.stdout.flush()
        checks.append(check_artifact(label, exe))
        if not args.skip_selftest:
            checks.append(check_selftest(label, exe))
        else:
            checks.append({"name": "selftest:%s" % label, "status": "SKIP",
                           "detail": "skipped (--skip-selftest)", "values": {},
                           "duration_s": 0.0})
        if not args.skip_benchmark:
            print("[2/4] benchmark %s (time=%gs, threads=%d) ..."
                  % (label, args.benchmark_time, args.threads))
            sys.stdout.flush()
            checks.append(check_benchmark(label, exe, args.benchmark_time,
                                          args.threads))
        else:
            checks.append({"name": "benchmark:%s" % label, "status": "SKIP",
                           "detail": "skipped (--skip-benchmark)", "values": {},
                           "duration_s": 0.0})
        if not args.skip_gtp:
            print("[3/4] GTP protocol probe %s ..." % label)
            sys.stdout.flush()
            checks.append(check_gtp(label, exe, args.komi))
        else:
            checks.append({"name": "gtp:%s" % label, "status": "SKIP",
                           "detail": "skipped (--skip-gtp)", "values": {},
                           "duration_s": 0.0})
    print("[4/4] A/B match ...")
    sys.stdout.flush()
    if len(exes) >= 2:
        label = "%s-vs-%s" % (labels[str(exes[0])], labels[str(exes[1])])
        checks.append(check_match(label, str(exes[0]), str(exes[1]), args))
    else:
        checks.append({"name": "match", "status": "SKIP",
                       "detail": "need two exes for an A/B match",
                       "values": {}, "duration_s": 0.0})
    result["total_wall_s"] = round(time.time() - t_start, 1)
    result["ok"] = all(c["status"] != "FAIL" for c in checks)
    return result


def print_table(result):
    rows = []
    for chk in result["checks"]:
        rows.append([chk["name"], chk["status"],
                     "%5.1fs" % chk.get("duration_s", 0.0),
                     chk["detail"]])
    print()
    print(table(rows, ["CHECK", "STATUS", "TIME", "DETAIL"]))
    bad = [c for c in result["checks"] if c["status"] == "FAIL"]
    warn = [c for c in result["checks"] if c["status"] == "WARN"]
    print()
    print("RESULT: %s   (%d checks, %d FAIL, %d WARN, total %.1fs)"
          % ("OK" if result["ok"] else "FAILED", len(result["checks"]),
             len(bad), len(warn), result["total_wall_s"]))
    for c in bad:
        print("  FAIL %s: %s" % (c["name"], c["detail"]))


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    if argv and argv[0] == "compare":
        parser = argparse.ArgumentParser(
            description="Compare two saved verify/match JSON results.")
        parser.add_argument("old")
        parser.add_argument("new")
        parser.add_argument("--json", action="store_true")
        cmp_args = parser.parse_args(argv[1:])
        old = json.loads(Path(cmp_args.old).read_text(encoding="utf-8"))
        new = json.loads(Path(cmp_args.new).read_text(encoding="utf-8"))
        print("OLD: %s\nNEW: %s" % (cmp_args.old, cmp_args.new))
        verdict = compare_results(old, new)
        if cmp_args.json:
            print(json.dumps(verdict, indent=2, ensure_ascii=False))
        return 0 if verdict["verdict"] != "REGRESSION" else 1
    args = build_parser().parse_args(argv)
    result = run_suite(args)
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(result, indent=2, ensure_ascii=False),
                   encoding="utf-8")
    print_table(result)
    print("json: %s" % out)
    if args.json:
        print(json.dumps(result, indent=2, ensure_ascii=False))
    return 0 if result["ok"] else 1


if __name__ == "__main__":
    sys.exit(main())
