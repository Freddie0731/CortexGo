# -*- coding: utf-8 -*-
"""导出校验：确认 export_github/GoAI3 里都是围棋 AI 文件、没有二进制、git 能正常收录。

只读检查，不改任何东西。
"""
import os
import subprocess
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
EXP = os.path.join(ROOT, 'export_github', 'GoAI3')

BAD_EXT = {'.exe', '.dll', '.obj', '.pdb', '.bin', '.gz', '.onnx', '.pt', '.pth', '.zip'}
BAD_NAMES = {'todo.md', 'kali_key', 'kali_key.pub', 'screen.png'}


def main():
    if not os.path.isdir(EXP):
        print('找不到导出目录:', EXP)
        return 2
    files = []
    for base, dirs, fs in os.walk(EXP):
        dirs[:] = [d for d in dirs if d != '.git']
        for f in fs:
            files.append(os.path.join(base, f))

    total = sum(os.path.getsize(f) for f in files)
    print('文件数: %d  总大小: %.2f MB' % (len(files), total / 1e6))

    bad = [f for f in files
           if os.path.splitext(f)[1].lower() in BAD_EXT
           or os.path.basename(f).lower() in BAD_NAMES]
    if bad:
        print('\n[警告] 发现不该有的二进制/杂物:')
        for f in bad:
            print('  ', os.path.relpath(f, EXP))
    else:
        print('二进制/杂物: 无')

    big = [f for f in files if os.path.getsize(f) > 1024 * 1024]
    if big:
        print('\n[提示] 超过 1MB 的文件:')
        for f in big:
            print('   %-50s %.2f MB' % (os.path.relpath(f, EXP), os.path.getsize(f) / 1e6))

    # git 收录校验
    try:
        out = subprocess.run(['git', '-C', EXP, 'ls-files'],
                             capture_output=True, timeout=120)
        names = out.stdout.decode('utf-8', 'replace').splitlines()
        names = [n for n in names if n]
        print('\ngit 收录: %d 个文件' % len(names))
        tracked_total = 0
        for n in names:
            p = os.path.join(EXP, n)
            if os.path.isfile(p):
                tracked_total += os.path.getsize(p)
        print('git 收录总大小: %.2f MB' % (tracked_total / 1e6))
        missing = [n for n in names if not os.path.isfile(os.path.join(EXP, n))]
        if missing:
            print('[警告] git 记录但磁盘上没有: %d 个' % len(missing))
    except Exception as e:
        print('git 检查跳过:', type(e).__name__, e)

    # 顶层结构
    print('\n顶层结构:')
    for name in sorted(os.listdir(EXP)):
        p = os.path.join(EXP, name)
        if name == '.git':
            continue
        if os.path.isdir(p):
            n = sum(len(fs) for _b, _d, fs in os.walk(p))
            print('  %-16s %3d 个文件' % (name + '/', n))
        else:
            print('  %-16s %7.1f KB' % (name, os.path.getsize(p) / 1024))
    return 0


if __name__ == '__main__':
    sys.exit(main())
