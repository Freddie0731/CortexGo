# -*- coding: utf-8 -*-
"""把 ORT+DirectML GPU 后端接进引擎（三个文件各改一处）。

1) kg/infer/katago_backend.h —— 在 kgBackendForward() 里加 GPU 分支：
   同一个 encodeV7 输入，只是把前向搬到 GPU；**只有 provider 真的是 DirectML
   才用**（ORT 的 CPU EP 比原生内核慢，用它只会让引擎变慢）。
2) go_ai.cpp —— 新增 --no-gpu / --ort-model，启动时尝试加载 ONNX 后端并报告
   provider；--benchmark 里显示实际用的是 GPU 还是原生。
3) tools/verify.py —— GTP 探针原来假设"错误也用 '=' 回"，这只对旧引擎成立；
   现在引擎按规范用 '?'，探针要能接受这种（正确的）应答，否则会把修好的
   行为报成 FAIL。

三个文件的换行风格不同（go_ai.cpp=CRLF，另两个=LF），脚本按文件原样保留。
"""
import io
import sys

GB = '\u4f60'  # 只是为了确保文件按 utf-8 读写


def load(path):
    raw = io.open(path, 'r', encoding='utf-8', newline='').read()
    return raw.replace('\r\n', '\n'), ('\r\n' in raw)


def save(path, text, crlf):
    out = text.replace('\r\n', '\n')
    if crlf:
        out = out.replace('\n', '\r\n')
    io.open(path, 'w', encoding='utf-8', newline='').write(out)


def apply(path, edits):
    text, crlf = load(path)
    bad = []
    for i, (old, new) in enumerate(edits):
        c = text.count(old)
        if c != 1:
            bad.append((i + 1, c, old.split('\n')[0][:70]))
            continue
        text = text.replace(old, new)
        print('[ok] %s patch %d' % (path, i + 1))
    if bad:
        for b in bad:
            print('[FAIL] %s patch %d count=%d : %s' % (path,) + b)
        raise SystemExit('%s: 有补丁没打上，未写回' % path)
    save(path, text, crlf)
    print('[saved] %s (%d bytes)' % (path, len(text)))


# --------------------------------------------------------------------------
# 1) katago_backend.h
# --------------------------------------------------------------------------
KATAGO_EDITS = [
    (
        '#include "model_load.h"\n#include "forward.h"',
        '#include "model_load.h"\n#include "forward.h"\n'
        '// Optional GPU backend (ONNX Runtime + DirectML). Header-only and\n'
        '// runtime-loaded; if it is not configured this is a no-op.\n'
        '#include "ort_backend.h"'
    ),
    (
        '    EncodedInput in;\n'
        '    encodeV7(b, hist, toMove, rules, in);\n'
        '\n'
        '    std::lock_guard<std::mutex> lk(backend_detail::mtx());\n'
        '    ForwardResult r;\n'
        '    backend_detail::forwardPtr()->run(in.spatial, in.global,\n'
        '                                      std::vector<float>(), r);\n'
        '    if (r.policy.empty()) return false;',
        '    EncodedInput in;\n'
        '    encodeV7(b, hist, toMove, rules, in);\n'
        '\n'
        '    // ---- forward pass: GPU when it really is the GPU -------------------\n'
        '    // Same encoder, same post-processing below; only the forward moves.\n'
        '    // Deliberately gated on provider == "DirectML": the ORT CPU EP is\n'
        '    // slower than the native kernels (347 ms vs 239 ms), so silently using\n'
        '    // it would make the engine slower, not faster. See README_ort.md.\n'
        '    ForwardResult r;\n'
        '    bool haveLogits = false;\n'
        '    if (ortBackendReady() && ortBackendProvider() == "DirectML") {\n'
        '        std::vector<float> ownership;\n'
        '        if (ortBackendForward(in.spatial, in.global, r.policy, r.value,\n'
        '                              ownership)) {\n'
        '            r.S = b.N * b.N;\n'
        '            r.numPolicyOut = 6;\n'
        '            haveLogits = true;\n'
        '        }\n'
        '    }\n'
        '    if (!haveLogits) {\n'
        '        std::lock_guard<std::mutex> lk(backend_detail::mtx());\n'
        '        backend_detail::forwardPtr()->run(in.spatial, in.global,\n'
        '                                          std::vector<float>(), r);\n'
        '    }\n'
        '    if (r.policy.empty()) return false;'
    ),
]

# --------------------------------------------------------------------------
# 2) go_ai.cpp
# --------------------------------------------------------------------------
GOAI_EDITS = [
    # 2.1 全局开关 + 加载函数（放在 load_network_or_report 之前）
    (
        '// Loads nn_weights.bin and reports exactly what it got. Every entry point',
        '// ---------------------------------------------------------------------------\n'
        '// Optional GPU backend (ONNX Runtime + DirectML)\n'
        '//\n'
        '// The native CPU kernels do one forward in ~0.24 s; the same network exported\n'
        '// to ONNX and run on the Arc iGPU through DirectML does it in ~0.073 s, which\n'
        '// is where most of the remaining playing strength is. Everything is optional\n'
        '// and runtime-loaded: no ONNX model, no DLLs, or a non-DirectML provider all\n'
        '// mean "stay on the native kernels" (see kg/infer/README_ort.md).\n'
        '// ---------------------------------------------------------------------------\n'
        'static bool g_no_gpu = false;\n'
        'static std::string g_ort_model;\n'
        '\n'
        'static bool file_exists(const std::string& p) {\n'
        '    std::ifstream probe(p.c_str(), std::ios::binary);\n'
        '    return (bool)probe;\n'
        '}\n'
        '\n'
        'static void try_enable_gpu_backend() {\n'
        '    if (g_no_gpu) return;\n'
        '    std::string path = g_ort_model;\n'
        '    if (path.empty()) {\n'
        '        // kata1_value_fixed.onnx first: once the value head is retrained the\n'
        '        // GPU model has to be exported from the fixed weights as well.\n'
        '        static const char* kOnnx[] = {\n'
        '            "kata1_value_fixed.onnx", "kata1_b11.onnx",\n'
        '            "build_out/npu/models/kata1_b11_b1.onnx"\n'
        '        };\n'
        '        for (int i = 0; i < 3; ++i)\n'
        '            if (file_exists(kOnnx[i])) { path = kOnnx[i]; break; }\n'
        '    }\n'
        '    if (path.empty()) return;   // nothing exported: use the native kernels\n'
        '    std::string err;\n'
        '    if (!kg::ortBackendLoad(path, &err)) {\n'
        '        std::cerr << "[gpu] not used: " << err << "\\n";\n'
        '        return;\n'
        '    }\n'
        '    std::cerr << "[gpu] onnx model : " << path << "\\n"\n'
        '              << "[gpu] provider   : " << kg::ortBackendProvider()\n'
        '              << "  (onnxruntime " << kg::ortBackendOrtVersion() << ")\\n";\n'
        '    if (kg::ortBackendProvider() != "DirectML")\n'
        '        std::cerr << "[gpu] note: only the DirectML provider beats the native "\n'
        '                     "kernels, so it will be ignored.\\n";\n'
        '}\n'
        '\n'
        '// Loads nn_weights.bin and reports exactly what it got. Every entry point'
    ),
    # 2.2 启动报告里加上推理后端
    (
        '    if (g_nn.is_katago) {\n'
        '        std::cerr << "Neural net loaded: KataGo v17 (.bin.gz), "\n'
        '            << "22 input planes + 19 global features.\\n"\n'
        '            << "  前向约 1 秒/次（14 线程 CPU）：根节点做 8 对称平均，\\n"\n'
        '            << "  深层叶子只评 1 次（--root-symmetries N 可调）。\\n"\n'
        '            << std::endl;\n'
        '        return true;\n'
        '    }',
        '    if (g_nn.is_katago) {\n'
        '        try_enable_gpu_backend();\n'
        '        const bool gpu = kg::ortBackendReady()\n'
        '            && kg::ortBackendProvider() == "DirectML";\n'
        '        std::cerr << "Neural net loaded: KataGo v17 (.bin.gz), "\n'
        '            << "22 input planes + 19 global features.\\n";\n'
        '        if (gpu)\n'
        '            std::cerr << "  inference: DirectML GPU via ONNX Runtime"\n'
        '                         " (~0.07 s/call)\\n";\n'
        '        else\n'
        '            std::cerr << "  inference: native CPU kernels (~0.24 s/call, "\n'
        '                         "14 threads)\\n";\n'
        '        std::cerr << "  根节点做对称平均，深层叶子只评 1 次"\n'
        '                     "（--root-symmetries N 可调）。\\n"\n'
        '            << std::endl;\n'
        '        return true;\n'
        '    }'
    ),
    # 2.3 benchmark 里显示真实后端与平均前向耗时
    (
        '        std::printf("  backend=KataGo-v17 (.bin.gz)");\n'
        '        long long calls = 0; double secs = 0.0;\n'
        '        kg::kgBackendStats(&calls, &secs);\n'
        '        if (calls > 0)\n'
        '            std::printf("  avg_forward=%.2fs", secs / (double)calls);',
        '        long long calls = 0; double secs = 0.0;\n'
        '        if (kg::ortBackendReady() && kg::ortBackendProvider() == "DirectML") {\n'
        '            std::printf("  backend=KataGo-v17 (DirectML GPU)");\n'
        '            kg::ortBackendStats(&calls, &secs);\n'
        '            if (calls > 0)\n'
        '                std::printf("  avg_forward=%.3fs", secs / (double)calls);\n'
        '        }\n'
        '        else {\n'
        '            std::printf("  backend=KataGo-v17 (native CPU)");\n'
        '            kg::kgBackendStats(&calls, &secs);\n'
        '            if (calls > 0)\n'
        '                std::printf("  avg_forward=%.2fs", secs / (double)calls);\n'
        '        }'
    ),
    # 2.4 命令行参数
    (
        '        else if (a == "--no-nn") sp.use_nn = false;',
        '        else if (a == "--no-nn") sp.use_nn = false;\n'
        '        else if (a == "--no-gpu") g_no_gpu = true;\n'
        '        else if (a == "--ort-model" && i + 1 < argc) g_ort_model = argv[++i];'
    ),
    # 2.5 help 文案
    (
        '                "  --no-nn           ignore nn_weights.bin\\n";',
        '                "  --no-nn           ignore nn_weights.bin\\n"\n'
        '                "  --no-gpu          do not try the ONNX Runtime/DirectML GPU "\n'
        '                "backend\\n"\n'
        '                "  --ort-model P     ONNX model for the GPU backend "\n'
        '                "(default: kata1_value_fixed.onnx / kata1_b11.onnx)\\n";'
    ),
]

# --------------------------------------------------------------------------
# 3) tools/verify.py —— 让 GTP 探针接受规范的 "?" 错误应答
# --------------------------------------------------------------------------
VERIFY_EDITS = [
    (
        '        # GTP error reply style: go_ai.cpp answers "=" even for errors (bug).\n'
        '        body2, lines2, _ = engine.command(\n'
        '            "play B %s" % ("D4" if token != "D4" else "Q16"))\n'
        '        first_reply = lines2[0] if lines2 else ""\n'
        '        values["error_reply_uses_question_mark"] = first_reply.startswith("?")\n'
        '        values["error_reply_example"] = first_reply\n'
        '        if not values["error_reply_uses_question_mark"]:\n'
        '            notes.append("GTP errors are sent with \'=\' not \'?\' (spec violation)")\n'
        '        values["wrong_colour_play_response"] = body2.strip()\n'
        '        if not body2.strip():\n'
        '            notes.append("\'play B ...\' on White\'s turn was accepted (colour "\n'
        '                         "validation missing?)")',
        '        # After `genmove b` it is White\'s turn, so `play B ...` MUST be rejected.\n'
        '        # A spec-compliant engine answers with "?" -- GtpEngine.command() then\n'
        '        # raises GtpCommandError, which used to abort the whole probe (the old\n'
        '        # engine always answered "=", so this path was never exercised).\n'
        '        try:\n'
        '            body2, lines2, _ = engine.command(\n'
        '                "play B %s" % ("D4" if token != "D4" else "Q16"))\n'
        '            first_reply = lines2[0] if lines2 else ""\n'
        '            values["error_reply_uses_question_mark"] = first_reply.startswith("?")\n'
        '            values["error_reply_example"] = first_reply\n'
        '            if not values["error_reply_uses_question_mark"]:\n'
        '                notes.append("GTP errors are sent with \'=\' not \'?\' "\n'
        '                             "(spec violation)")\n'
        '            values["wrong_colour_play_response"] = body2.strip()\n'
        '            if not body2.strip():\n'
        '                notes.append("\'play B ...\' on White\'s turn was accepted "\n'
        '                             "(colour validation missing?)")\n'
        '        except match.GtpCommandError as exc:\n'
        '            values["error_reply_uses_question_mark"] = True\n'
        '            values["error_reply_example"] = "? " + str(exc.response)\n'
        '            values["wrong_colour_play_response"] = str(exc.response)'
    ),
    (
        '        body3, _, _ = engine.command("final_score")\n'
        '        values["final_score_response"] = body3.strip()',
        '        try:\n'
        '            body3, _, _ = engine.command("final_score")\n'
        '        except match.GtpCommandError as exc:\n'
        '            body3 = str(exc.response)\n'
        '        values["final_score_response"] = str(body3).strip()'
    ),
    (
        '        body6, _, _ = engine.command("komi")\n'
        '        values["komi_missing_arg_rejected"] = bool(body6.strip())',
        '        try:\n'
        '            body6, _, _ = engine.command("komi")\n'
        '            values["komi_missing_arg_rejected"] = bool(str(body6).strip())\n'
        '        except match.GtpCommandError as exc:\n'
        '            # Correct behaviour: a missing argument is a syntax error, which\n'
        '            # a spec-compliant engine reports with "?".\n'
        '            body6 = str(exc.response)\n'
        '            values["komi_missing_arg_rejected"] = True'
    ),
    (
        '        if not body6.strip():',
        '        if not str(body6).strip():'
    ),
]


def main():
    apply('kg/infer/katago_backend.h', KATAGO_EDITS)
    apply('go_ai.cpp', GOAI_EDITS)
    apply('tools/verify.py', VERIFY_EDITS)
    return 0


if __name__ == '__main__':
    sys.exit(main())
