﻿# NPU/GPU 推理环境：检测 + 安装 + 冒烟测试（Windows PowerShell 5.1）
#
# 这台机器的现实（2026-10 实测）：
#   * NPU 硬件和驱动都在：Intel(R) AI Boost，Status=Started，npu.inf 驱动 32.0.100.3104
#   * 磁盘上已经有两套 OpenVINO（小米 MiService / MI AIService 自带的），
#     其中 MiService 那套 2024.1 的 openvino_c.dll 能真正在 NPU 上执行模型
#   * Python 侧没有任何推理运行时；pip 默认走 HTTPS，而本机 HTTPS 被 RST，
#     只有明文 HTTP 的 PyPI 镜像可用
#
# 本脚本三件事：
#   -Mode detect  : 盘点 NPU 设备/驱动、磁盘上的 OpenVINO、系统 ORT 的 EP、pip 包
#   -Mode install : 用 HTTP 镜像把 onnx / openvino / onnxruntime-directml 装进
#                   build_out\npu\py（--target，不污染系统）
#   -Mode verify  : 冒烟：OpenVINO 设备枚举、ORT EP 枚举、ctypes 直连 NPU 推理
#
# 用法：
#   powershell -ExecutionPolicy Bypass -File tools\npu_setup.ps1 -Mode detect
#   powershell -ExecutionPolicy Bypass -File tools\npu_setup.ps1 -Mode install
#   powershell -ExecutionPolicy Bypass -File tools\npu_setup.ps1 -Mode verify
#   powershell -ExecutionPolicy Bypass -File tools\npu_setup.ps1 -Mode all
#
# 已踩过的坑（写进脚本就是为了别再踩）：
#  1. pip 默认把解包临时文件写到 %TEMP%，受限终端里会 errno 13；这里强制 TMP/TEMP
#     指到 build_out\npu\tmp。
#  2. HTTPS 不通，必须 -i http://... 且 --trusted-host，否则 pip 卡在 TLS。
#  3. 更极端（比如 DSH 沙箱）连 pip 解包都不行时：用 http 分块下载 wheel 再手工
#     解包，见 tools\README_npu.md 的"离线/受限环境"一节。

[CmdletBinding()]
param(
    [ValidateSet('detect', 'install', 'verify', 'all')]
    [string]$Mode = 'detect',
    [string]$Root = '',
    [string]$Python = '',
    [string]$Mirror = 'http://mirrors.aliyun.com/pypi/simple/',
    [string]$Target = '',
    [switch]$PreferWheelsOnly,
    [switch]$SkipSmoke
)

$ErrorActionPreference = 'Continue'

function Get-RootDir([string]$r) {
    if ($r -ne '') { return (Resolve-Path $r).Path }
    return (Split-Path -Parent (Split-Path -Parent $PSCommandPath))
}

$script:RootDir = Get-RootDir $Root
if ($Target -eq '') { $Target = Join-Path $script:RootDir 'build_out\npu\py' }
$TmpDir = Join-Path $script:RootDir 'build_out\npu\tmp'
$ModelsDir = Join-Path $script:RootDir 'build_out\npu\models'

function Write-Head([string]$t) {
    Write-Host ''
    Write-Host ('=' * 76) -ForegroundColor DarkCyan
    Write-Host "  $t" -ForegroundColor Cyan
    Write-Host ('=' * 76) -ForegroundColor DarkCyan
}

function Find-Python([string]$explicit) {
    if ($explicit -ne '') { return $explicit }
    $c = (Get-Command python -ErrorAction SilentlyContinue | Select-Object -First 1 -ExpandProperty Source)
    if ($c -and (Test-Path $c)) { return $c }
    $c = Get-ChildItem "$env:LOCALAPPDATA\Programs\Python\Python*\python.exe" -ErrorAction SilentlyContinue |
        Sort-Object FullName -Descending | Select-Object -First 1 -ExpandProperty FullName
    if ($c) { return $c }
    return 'python'
}

$script:Py = Find-Python $Python

function Invoke-Py([string]$code, [string[]]$extraPath = @()) {
    $old = $env:PYTHONPATH
    $paths = @($Target) + $extraPath
    $env:PYTHONPATH = ($paths -join ';')
    try { & $script:Py -c $code 2>&1 | ForEach-Object { "  $_" } }
    finally { $env:PYTHONPATH = $old }
}

# ------------------------------------------------------------------ detect
function Invoke-Detect {
    Write-Head '1. NPU 设备 / 驱动'
    $out = cmd /c "pnputil /enum-devices /class ComputeAccelerator" 2>&1
    $desc = ($out | Select-String 'Device Description').ToString()
    if ($desc -match ':\s*(.+)$') {
        Write-Host ("  设备: {0}" -f $Matches[1].Trim())
    } else {
        Write-Host '  未发现 ComputeAccelerator 设备（NPU 硬件或驱动缺失）' -ForegroundColor Yellow
    }
    ($out | Select-String 'Status') | ForEach-Object { Write-Host ("  {0}" -f $_.ToString().Trim()) }
    $drv = cmd /c "pnputil /enum-drivers" 2>&1
    $idx = ($drv | Select-String 'Original Name:\s+npu.inf' | Select-Object -First 1).LineNumber
    if ($idx) {
        $chunk = $drv[($idx - 1)..([Math]::Min($idx + 5, $drv.Count - 1))]
        $ver = ($chunk | Select-String 'Driver Version').ToString()
        Write-Host ("  {0}" -f $ver.Trim())
    }
    $drvStore = Join-Path $env:WINDIR 'System32\DriverStore\FileRepository'
    $pkg = Get-ChildItem $drvStore -Directory -ErrorAction SilentlyContinue |
        Where-Object { $_.Name -like 'npu.inf_*' } | Select-Object -First 1
    if ($pkg) {
        Write-Host ("  DriverStore: {0}" -f $pkg.Name)
        foreach ($f in @('npu_driver_compiler.dll', 'npu_level_zero_umd.dll', 'npu_dml_compiler.dll')) {
            $p = Join-Path $pkg.FullName $f
            Write-Host ("    {0,-28} {1}" -f $f, $(if (Test-Path $p) { '有' } else { '缺' }))
        }
    }

    Write-Head '2. 磁盘上已有的 OpenVINO 运行时（不用装就能跑）'
    $roots = @(
        'C:\Program Files\MI\AIService',
        (Join-Path ${env:ProgramFiles(x86)} 'Timi Personal Computing\MiService'),
        'C:\Program Files\Intel\openvino',
        'C:\Program Files (x86)\Intel\openvino'
    )
    $found = @()
    foreach ($r in $roots) {
        if (Test-Path $r) {
            Get-ChildItem $r -Recurse -Depth 4 -Filter 'openvino.dll' -ErrorAction SilentlyContinue |
                ForEach-Object { $found += $_.FullName }
        }
    }
    if ($found.Count -eq 0) {
        Write-Host '  未找到 OpenVINO（NPU 只能走 pip 安装）' -ForegroundColor Yellow
    }
    foreach ($f in $found) {
        $dir = Split-Path -Parent $f
        $ver = (Get-Item $f).VersionInfo.FileVersion
        $npuPlugin = Join-Path $dir 'openvino_intel_npu_plugin.dll'
        $cApi = Join-Path $dir 'openvino_c.dll'
        Write-Host ("  {0}" -f $f)
        Write-Host ("    version={0}  NPUplugin={1}  openvino_c.dll={2}" -f
            $ver, $(if (Test-Path $npuPlugin) { '有' } else { '无' }),
            $(if (Test-Path $cApi) { '有(可 ctypes)' } else { '无' }))
        if ((Test-Path $cApi) -and (Test-Path $script:Py) -and (Test-Path (Join-Path $script:RootDir 'build_out\npu\ov_c.py'))) {
            $env:OV_C_DIR = $dir
            Write-Host '    可用设备（ctypes 实测）:'
            Invoke-Py "import ov_c; o=ov_c.OpenVinoC(); c=o.core(); print(o.available_devices(c))" @((Join-Path $script:RootDir 'build_out\npu'))
        }
    }

    Write-Head '3. 系统 ONNX Runtime（C:\Windows\System32\onnxruntime.dll）'
    $ort = Join-Path $env:WINDIR 'System32\onnxruntime.dll'
    if (Test-Path $ort) {
        Write-Host ("  {0}  ({1})" -f $ort, (Get-Item $ort).VersionInfo.FileVersion)
        $pe = Join-Path $script:RootDir 'build_out\npu\pe_info.py'
        if ((Test-Path $pe) -and (Test-Path $script:Py)) {
            Write-Host '  导出的 Ort* / EP 符号（有没有 DML 看这里）:'
            & $script:Py $pe $ort 2>&1 |
                Select-String -Pattern 'ExecutionProvider|OrtGet' | ForEach-Object { "    $_" }
        }
    } else {
        Write-Host '  系统没有 onnxruntime.dll' -ForegroundColor Yellow
    }

    Write-Head '4. Python 侧已装包 / target 目录'
    if (Test-Path $script:Py) {
        & $script:Py -m pip list --disable-pip-version-check 2>&1 |
            Select-String -Pattern 'torch|onnx|openvino|numpy|protobuf' | ForEach-Object { "  $_" }
    }
    Write-Host ("  target {0}: {1}" -f $Target, $(if (Test-Path $Target) { '存在' } else { '不存在' }))
    $pyins = Join-Path $Target 'onnxruntime'
    Write-Host ("  target 里的 onnxruntime: {0}" -f $(if (Test-Path $pyins) { '有' } else { '无' }))
}

# ------------------------------------------------------------------ install
function Invoke-Install {
    Write-Head 'pip install（HTTP 镜像 + 工程内 TMP）'
    if (-not (Test-Path $script:Py)) {
        Write-Host '  找不到 python，先装 Python 3.10+' -ForegroundColor Red
        return
    }
    New-Item -ItemType Directory -Force -Path $Target | Out-Null
    New-Item -ItemType Directory -Force -Path $TmpDir | Out-Null
    $env:TMP = $TmpDir
    $env:TEMP = $TmpDir
    $mhost = ([uri]$Mirror).Host
    $pkgs = @('onnx', 'protobuf', 'openvino', 'onnxruntime-directml',
              'ml_dtypes', 'typing_extensions')
    $args = @('-m', 'pip', 'install', '--disable-pip-version-check', '--no-input',
              '--no-cache-dir', '--target', $Target,
              '-i', $Mirror, '--trusted-host', $mhost,
              '--timeout', '60', '--retries', '2')
    if ($PreferWheelsOnly) { $args += '--only-binary=:all:' }
    $args += $pkgs
    Write-Host ("  {0} {1}" -f $script:Py, ($args -join ' ')) -ForegroundColor DarkGray
    & $script:Py @args 2>&1 | ForEach-Object { "  $_" }
    Write-Host ''
    Write-Host '  若报 Permission denied（不是网络错误）：' -ForegroundColor Yellow
    Write-Host '    pip 临时目录被限制 -> 已指到 build_out\npu\tmp；仍失败就走 dl.py + extract.py'
    Write-Host '    的"手工 wheel 解包"路线（见 tools\README_npu.md）。'
}

# ------------------------------------------------------------------ verify
function Invoke-Verify {
    Write-Head 'verify: OpenVINO（pip 2026.x）设备枚举'
    Invoke-Py "import openvino as ov; c=ov.Core(); print('openvino', ov.__version__); print('devices', list(c.available_devices))"

    Write-Head 'verify: ONNX Runtime EP 枚举'
    Invoke-Py "import onnxruntime as ort; print('ort', ort.__version__); print('providers', ort.get_available_providers())"

    Write-Head 'verify: onnx 包'
    Invoke-Py "import onnx; print('onnx', onnx.__version__)"

    Write-Head 'verify: 2024.1 ctypes runtime 的设备枚举（NPU 关键路径）'
    $ovc = Join-Path $script:RootDir 'build_out\npu\ov_c.py'
    if (Test-Path $ovc) {
        Invoke-Py "import ov_c; o=ov_c.OpenVinoC(); c=o.core(); print('devices', o.available_devices(c))" @((Join-Path $script:RootDir 'build_out\npu'))
    } else {
        Write-Host '  缺 build_out\npu\ov_c.py（ctypes 绑定），跳过' -ForegroundColor Yellow
    }

    if ($SkipSmoke) { return }

    Write-Head 'smoke: 导出 ONNX（若还没有）'
    $onnxPath = Join-Path $ModelsDir 'kata1_b11_b1.onnx'
    $export = Join-Path $script:RootDir 'tools\export_onnx.py'
    if (-not (Test-Path $onnxPath)) {
        if (Test-Path $export) {
            $env:PYTHONPATH = $Target
            $env:OMP_NUM_THREADS = '4'
            $env:KATAGO_FLEX_ATTENTION = '0'
            & $script:Py $export --out $ModelsDir 2>&1 | ForEach-Object { "  $_" }
        }
    } else {
        Write-Host "  已存在 $onnxPath"
    }

    Write-Head 'smoke: NPU 单次前向（2024.1 ctypes 运行时）'
    $irPath = Join-Path $ModelsDir 'kata1_b11_b1.xml'
    $bench = Join-Path $script:RootDir 'tools\npu_bench.py'
    if ((Test-Path $irPath) -and (Test-Path $bench)) {
        $env:PYTHONPATH = "$Target;$(Join-Path $script:RootDir 'build_out\npu')"
        $env:OMP_NUM_THREADS = '4'
        & $script:Py $bench --backend openvino-ctypes --ir $irPath `
            --ref (Join-Path $ModelsDir 'ref_b1.npz') --streams 1 --iters 3 --warmup 1 2>&1 |
            ForEach-Object { "  $_" }
    } else {
        Write-Host '  缺 IR 或 npu_bench.py；先跑 build_out\npu\make_ir.py 生成 IR' -ForegroundColor Yellow
    }

    Write-Head '用户需要自己执行的提权 / 联网步骤（本脚本不做）'
    Write-Host '  * 想把 NPU 升级到"pip 版 OpenVINO 2026.x 也能跑"：装 Intel 新版 NPU 驱动'
    Write-Host '    （当前 32.0.100.3104）。来源：小米/Intel 官网或 Windows Update，需要管理员。'
    Write-Host '  * 想用 ONNX Runtime 原生 NPU EP：联网后 pip install onnxruntime-openvino，'
    Write-Host '    并确认 NPU 驱动 >= OpenVINO 对应版本要求。'
    Write-Host '  * 在完全断网的机器上：先在能联网的机器执行 -Mode install，再把整个'
    Write-Host '    build_out\npu\py 目录拷过来即可（PYTHONPATH 指过去就行）。'
}

# ------------------------------------------------------------------ main
Write-Host ("root   = {0}" -f $script:RootDir)
Write-Host ("python = {0}" -f $script:Py)
Write-Host ("target = {0}" -f $Target)

switch ($Mode) {
    'detect' { Invoke-Detect }
    'install' { Invoke-Install }
    'verify' { Invoke-Verify }
    'all' { Invoke-Detect; Invoke-Install; Invoke-Verify }
}
