# -*- coding: utf-8 -*-
"""Step D/E: 训练新的价值头（576->192->3，SiLU），评估，导出权重。

结构必须与引擎里价值头的既有链路**逐层对齐**：
    conv1(768->192, 冻结) -> bias1 -> SiLU -> gpool -> [linear2 576->192] -> SiLU
    -> [linear_valuehead 192->3]
所以这里训练的两个层正好替换 linear2 / linear_valuehead，其余张量不动。

视角：**行棋方视角**。标签 y=1 表示"该局面的行棋方最终赢了"。
KataGo 的输入平面本来就是行棋方视角（plane1=自己），引擎 nn_forward 也按
"当前行棋方视角"解读 forward() 的 value，所以这里不做任何翻转。

数据划分（按**棋局**，绝不按局面）：
    train 80% / val 10% / test 10%，用 val 做早停（选 epoch），只在 test 上报
    最终数字 —— 避免"用测试集挑 epoch"造成的乐观偏差。

用法:
  python tools/value_train.py --features build_out/value/features_p0.npz,build_out/value/features_p1.npz \
      --manifest build_out/value/manifest.txt \
      --out-weights build_out/value/value_head_new.npz \
      --report build_out/value/train_report.txt
"""
import os
import sys
import time
import argparse

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import value_lib as V

try:
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
except Exception:
    pass


def read_gids(manifest):
    gids = []
    with open(manifest, 'r', encoding='utf-8') as f:
        for ln in f:
            ln = ln.rstrip('\n').rstrip('\r')
            if not ln or ln.startswith('#'):
                continue
            gids.append(ln.split('\t')[0])
    return gids


def split3(gameIdx, gids, seed=12345):
    """按棋局划分 train(0)/val(1)/test(2)。用 gid 的 crc32 保证可复现。

    test = 20% 的棋局（h%5==0），val = 10%（h%10==1），其余 train。
    val 只用于早停挑 epoch；所有对外数字都只在 test 上算。
    """
    import zlib
    lab = np.zeros(gameIdx.max() + 1, dtype=np.int8)
    for gi in np.unique(gameIdx):
        key = ('%s|%d' % (gids[int(gi)], seed)) if gi < len(gids) else \
              ('game%d|%d' % (int(gi), seed))
        h = zlib.crc32(key.encode('utf-8')) & 0xffffffff
        if h % 5 == 0:
            lab[gi] = 2
        elif h % 10 == 1:
            lab[gi] = 1
        else:
            lab[gi] = 0
    return lab[gameIdx]


class Head(object):
    """576->192->3 的两层 MLP（SiLU），导出时直接映射成 linear2 + linear_valuehead。"""

    def __init__(self, nin=576, nhid=192, seed=0):
        import torch
        import torch.nn as nn
        torch.manual_seed(seed)
        self.net = nn.Sequential(nn.Linear(nin, nhid), nn.SiLU(), nn.Linear(nhid, 3))


def metrics(pw, y):
    pw = np.asarray(pw, np.float64)
    y = np.asarray(y, np.int32)
    return {
        'auc': V.auc_score(pw, y),
        'acc': float(((pw > 0.5).astype(np.int32) == y).mean()),
        'brier': V.brier(pw, y),
        'mean': float(pw.mean()),
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--features', default='build_out/value/features.npz')
    ap.add_argument('--manifest', default='build_out/value/manifest.txt')
    ap.add_argument('--out-weights', default='build_out/value/value_head_new.npz')
    ap.add_argument('--report', default='build_out/value/train_report.txt')
    ap.add_argument('--epochs', type=int, default=120)
    ap.add_argument('--batch', type=int, default=512)
    ap.add_argument('--lr', type=float, default=2e-3)
    ap.add_argument('--wd', type=float, default=2e-2)
    ap.add_argument('--seed', type=int, default=2026)
    ap.add_argument('--threads', type=int, default=6)
    ap.add_argument('--select', default='final', choices=('final', 'best'),
                    help='final=固定日程取最后模型（test 无挑选偏差）；best=按 val AUC 挑 epoch')
    ap.add_argument('--min-ply', type=int, default=0,
                    help='只用 ply>=该值的局面训练（早盘标签基本是噪声，拟合它们会污染'
                         '共享隐层；评估仍然用全部 test 局面）')
    ap.add_argument('--compare-bins', default='',
                    help='逗号分隔的若干 .bin.gz：用同一个 test 集评估这些已导出的价值头'
                         '（只走 gpool->linear2->act2->linear_valuehead，不重跑 trunk），'
                         '用来做"全量 vs v1"的严格对比')
    ap.add_argument('--limit', type=int, default=0)
    args = ap.parse_args()

    import torch
    torch.set_num_threads(args.threads)

    log_lines = []

    def log(s=''):
        print(s, flush=True)
        log_lines.append(s)

    log('=== 价值头重训 训练报告 ===')
    # --features 支持逗号分隔的多个文件（特征提取可分段/跨步跑）
    zs = []
    for fp in args.features.split(','):
        fp = fp.strip()
        if not fp:
            continue
        zz = np.load(fp)
        if 'posIdx' in zz:
            pidx = zz['posIdx'].astype(np.int64)
        else:
            pidx = np.arange(zz['gpool'].shape[0], dtype=np.int64)
        zs.append((int(pidx[0]), fp, pidx.shape[0], zz, pidx))
        log('  特征分片 %s : posIdx 起点 %d，%d 个局面' % (fp, int(pidx[0]), len(pidx)))
    zs.sort(key=lambda t: t[0])
    seen = set()
    for _, fp, _, _, pidx in zs:
        s = set(pidx.tolist())
        if seen & s:
            log('  !! 分片 %s 与前面的分片有重复局面' % fp)
            raise SystemExit(1)
        seen |= s
    gpool = np.concatenate([p[3]['gpool'] for p in zs]).astype(np.float32)
    value_old = np.concatenate([p[3]['value_old'] for p in zs]).astype(np.float32)
    gameIdx = np.concatenate([p[3]['meta_gameIdx'] for p in zs]).astype(np.int32)
    ply = np.concatenate([p[3]['meta_ply'] for p in zs]).astype(np.int32)
    toMove = np.concatenate([p[3]['meta_toMove'] for p in zs]).astype(np.int32)
    winner = np.concatenate([p[3]['meta_winner'] for p in zs]).astype(np.int32)
    komi = np.concatenate([p[3]['meta_komi'] for p in zs]).astype(np.float32)
    margin = np.concatenate([p[3]['meta_finalMargin'] for p in zs]).astype(np.float32)
    n = gpool.shape[0]
    if args.limit > 0:
        gpool, value_old = gpool[:args.limit], value_old[:args.limit]
        gameIdx, ply, toMove = gameIdx[:args.limit], ply[:args.limit], toMove[:args.limit]
        winner, komi = winner[:args.limit], komi[:args.limit]
        margin = margin[:args.limit]
        n = args.limit
    log('样本 %d  特征 %s  棋局 %d' % (n, gpool.shape, int(gameIdx.max()) + 1))

    y = (winner == toMove).astype(np.int32)       # 行棋方是否获胜（1=赢）
    # 类别索引约定（必须和 linear_valuehead 的 3 个输出通道一致）：
    #   通道 0 = win, 通道 1 = loss, 通道 2 = noresult
    # "行棋方赢了" -> 类别 0，"输了" -> 类别 1。千万别直接拿 y 当类别索引
    # （那会把标签反过来，训练出来的头 AUC 恰好是 1-正确值，看着像"完全学反"）。
    ycls = np.where(y == 1, 0, 1).astype(np.int64)

    gids = read_gids(args.manifest) if os.path.exists(args.manifest) else []
    lab = split3(gameIdx, gids)
    tr, va, te = (lab == 0), (lab == 1), (lab == 2)
    tr_fit = tr if args.min_ply <= 0 else (tr & (ply >= args.min_ply))
    log('按棋局划分：train %d 局面/%d 局（其中用于拟合 %d 个，ply>=%d），'
        'val %d/%d 局，test %d/%d 局' % (
            int(tr.sum()), int(np.unique(gameIdx[tr]).size), int(tr_fit.sum()),
            args.min_ply,
            int(va.sum()), int(np.unique(gameIdx[va]).size),
            int(te.sum()), int(np.unique(gameIdx[te]).size)))
    log('标签均值：train %.4f  val %.4f  test %.4f（0.5 附近说明采样没偏）'
        % (y[tr].mean(), y[va].mean(), y[te].mean()))

    # ---- baseline：旧价值头（同一份 test）----
    log('\n--- baseline: 旧价值头（引擎当前加载的 kata1.bin.gz 的价值头）---')
    wr_old = V.value_from_logits(value_old)
    pw_old = (wr_old + 1.0) * 0.5           # 与引擎 winrate -> [0,1] 的映射一致
    m_old_all = metrics(pw_old, y)
    log('  全部 %d 局面: AUC=%.4f acc=%.4f Brier=%.4f pred_mean=%.4f'
        % (n, m_old_all['auc'], m_old_all['acc'], m_old_all['brier'], m_old_all['mean']))
    m_old = metrics(pw_old[te], y[te])
    log('  test 上: AUC=%.4f acc=%.4f Brier=%.4f pred_mean=%.4f'
        % (m_old['auc'], m_old['acc'], m_old['brier'], m_old['mean']))

    # ---- 标准化（导出时精确折回 linear2）----
    # 统计量用 tr_fit（真正参与拟合的局面），保证与训练分布一致
    mu = gpool[tr_fit].mean(axis=0).astype(np.float64)
    sd = gpool[tr_fit].std(axis=0).astype(np.float64)
    sd = np.maximum(sd, 1e-6)
    Xtr = (gpool[tr_fit].astype(np.float64) - mu) / sd
    Xva = (gpool[va].astype(np.float64) - mu) / sd
    Xte = (gpool[te].astype(np.float64) - mu) / sd
    ytr_cls, yva, yte = ycls[tr_fit], y[va], y[te]
    ytr_all = y[tr_fit]

    # ---- 训练 ----
    net = Head(576, 192, seed=args.seed).net
    opt = torch.optim.AdamW([
        {'params': [net[0].weight], 'weight_decay': args.wd},
        {'params': [net[0].bias], 'weight_decay': 0.0},
        {'params': [net[2].weight], 'weight_decay': args.wd},
        {'params': [net[2].bias], 'weight_decay': 0.0},
    ], lr=args.lr)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=args.epochs)
    lossf = torch.nn.CrossEntropyLoss()

    Xtr_t = torch.from_numpy(Xtr).float()
    ytr_t = torch.from_numpy(ytr_cls).long()
    Xva_t = torch.from_numpy(Xva).float()

    def prob_win(X_t):
        if not torch.is_tensor(X_t):
            X_t = torch.from_numpy(np.ascontiguousarray(X_t)).float()
        with torch.no_grad():
            P = torch.softmax(net(X_t), dim=1).numpy()
        return (P[:, 0] - P[:, 1] + 1.0) * 0.5

    rng = np.random.RandomState(args.seed)
    best = (-1.0, None, -1)
    ntr = Xtr.shape[0]
    log('\n--- 训练 576->192->3 (SiLU)：目标 3 类 CE（通道0=win/1=loss/2=noresult，'
        'noresult 目标概率恒 0）---')
    log('  lr=%.1e wd=%.1e batch=%d epochs=%d train_n=%d'
        % (args.lr, args.wd, args.batch, args.epochs, ntr))
    t0 = time.time()
    for ep in range(args.epochs):
        net.train()
        perm = rng.permutation(ntr)
        tot, cnt = 0.0, 0
        for i in range(0, ntr, args.batch):
            idx = perm[i:i + args.batch]
            opt.zero_grad()
            loss = lossf(net(Xtr_t[idx]), ytr_t[idx])
            loss.backward()
            opt.step()
            tot += float(loss.detach()) * len(idx)
            cnt += len(idx)
        sched.step()
        net.eval()
        auc_va = V.auc_score(prob_win(Xva_t), yva)
        if auc_va > best[0]:
            best = (auc_va, {k: v.detach().clone() for k, v in net.state_dict().items()}, ep)
        if ep % 10 == 0 or ep == args.epochs - 1:
            log('  ep %3d  train_loss=%.4f  val AUC=%.4f  (%.1fs)'
                % (ep, tot / max(cnt, 1), auc_va, time.time() - t0))
    log('  best val AUC = %.4f @ epoch %d' % (best[0], best[2]))
    if args.select == 'final':
        # 固定日程训练到底（不用 val 挑 epoch）：报告"最后一个 epoch 的模型"，
        # 这样 test 上的数字完全没有被挑选过，连 val 都只用于监控。
        log('  --select final：直接取第 %d 个 epoch 的模型（不用 val 挑）' % (args.epochs - 1))
    else:
        net.load_state_dict(best[1])
        log('  --select best：取 val AUC 最高的那个 epoch（val 只有 %d 个局面，'
            '选择噪声不小）' % int(va.sum()))
    net.eval()
    final_val = V.auc_score(prob_win(Xva_t), yva)
    log('  最终模型 val AUC = %.4f（仅用于监控，不用于选模）' % final_val)

    # ---- test 评估 ----
    pw_new = prob_win(Xte)
    m_new = metrics(pw_new, yte)
    Xtr_full = torch.from_numpy(Xtr).float()
    m_tr = metrics(prob_win(Xtr_full), ytr_all)

    log('\n=== 关键对比（同一 test 集：%d 局面 / %d 局，按棋局划分）==='
        % (int(te.sum()), int(np.unique(gameIdx[te]).size)))
    log('  %-12s %8s %8s %8s %10s' % ('', 'AUC', 'acc', 'Brier', 'pred_mean'))
    log('  %-12s %8.4f %8.4f %8.4f %10.4f' % ('旧价值头', m_old['auc'], m_old['acc'],
                                              m_old['brier'], m_old['mean']))
    log('  %-12s %8.4f %8.4f %8.4f %10.4f' % ('新价值头', m_new['auc'], m_new['acc'],
                                              m_new['brier'], m_new['mean']))
    log('  %-12s %8.4f %8.4f %8.4f' % ('提升',
                                       m_new['auc'] - m_old['auc'],
                                       m_new['acc'] - m_old['acc'],
                                       m_old['brier'] - m_new['brier']))
    log('  （train 上 AUC=%.4f acc=%.4f — 与 test 差太多就是过拟合）'
        % (m_tr['auc'], m_tr['acc']))

    # ---- 用同一个 test 集评估任意已导出的 .bin.gz（做 v1 vs 全量的严格对比）----
    if args.compare_bins:
        from value_features import load_official_model
        log('\n  同一 test 集上评估已导出的权重文件（只走 gpool->linear2->act2->'
            'linear_valuehead，不重跑 trunk，与引擎里的计算完全一致）：')
        gt = torch.from_numpy(gpool[te]).float()
        for path in args.compare_bins.split(','):
            path = path.strip()
            if not path or not os.path.exists(path):
                log('    %s : 不存在，跳过' % path)
                continue
            try:
                mm_model, _ = load_official_model(path, verbose=False)
                with torch.no_grad():
                    l2 = mm_model.value_head.linear2(gt)
                    out = mm_model.value_head.linear_valuehead(
                        mm_model.value_head.act2(l2)).numpy()
                pw_b = (V.value_from_logits(out) + 1.0) * 0.5
                mb = metrics(pw_b, yte)
                log('    %-48s AUC=%.4f acc=%.4f Brier=%.4f pred_mean=%.4f'
                    % (os.path.basename(path), mb['auc'], mb['acc'], mb['brier'],
                       mb['mean']))
                del mm_model
            except Exception as e:
                log('    %s : 评估失败 %s' % (path, e))

    log('\n  test 分层 AUC（新头 / 旧头）：')
    for lo, hi in ((8, 40), (40, 80), (80, 120), (120, 160), (160, 201)):
        m = te & (ply >= lo) & (ply < hi)
        if m.sum() > 50:
            pw_n = prob_win(torch.from_numpy((gpool[m].astype(np.float64) - mu) / sd).float())
            log('    ply %3d-%-3d n=%-5d 新=%.4f  旧=%.4f'
                % (lo, hi, int(m.sum()), V.auc_score(pw_n, y[m]),
                   V.auc_score(pw_old[m], y[m])))
    log('  test 按贴目 AUC（新头 / 旧头）：')
    for k in sorted(set(np.round(komi[te], 1).tolist())):
        m = te & (np.abs(komi - k) < 1e-6)
        if m.sum() > 50:
            pw_n = prob_win(torch.from_numpy((gpool[m].astype(np.float64) - mu) / sd).float())
            log('    komi %.1f  n=%-5d 新=%.4f  旧=%.4f'
                % (k, int(m.sum()), V.auc_score(pw_n, y[m]), V.auc_score(pw_old[m], y[m])))
    log('  校准（test，新头）：')
    for lo, hi, c, pm, ym in V.calib_bins(pw_new, yte):
        if c:
            log('    [%.1f,%.1f) n=%-6d pred=%.3f actual=%.3f' % (lo, hi, c, pm, ym))
    log('  校准（test，旧头）：')
    for lo, hi, c, pm, ym in V.calib_bins(pw_old[te], yte):
        if c:
            log('    [%.1f,%.1f) n=%-6d pred=%.3f actual=%.3f' % (lo, hi, c, pm, ym))

    # 早盘"新头是否真的更差"这个问题用小样本 test 回答不了，合并 val+test
    # （两者都是新头的样本外）再把早盘那一桶放大一遍
    ho2 = va | te
    if ho2.sum() > 0:
        pw_n2 = prob_win(torch.from_numpy((gpool[ho2].astype(np.float64) - mu) / sd).float())
        log('  合并 val+test（%d 局面，都是新头样本外）分层 AUC（新/旧）：' % int(ho2.sum()))
        for lo, hi in ((8, 40), (40, 80), (80, 120), (120, 160), (160, 201)):
            m = ho2 & (ply >= lo) & (ply < hi)
            if m.sum() > 50:
                pw_n = prob_win(torch.from_numpy(
                    (gpool[m].astype(np.float64) - mu) / sd).float())
                a_n = V.auc_score(pw_n, y[m])
                a_o = V.auc_score(pw_old[m], y[m])
                log('    ply %3d-%-3d n=%-5d 新=%.4f 旧=%.4f 差=%+.4f'
                    '（n=%d 时 AUC 的 SE≈%.3f）'
                    % (lo, hi, int(m.sum()), a_n, a_o, a_n - a_o, int(m.sum()),
                       0.5 / max(int(m.sum()), 2) ** 0.5))

    # 与最终目差的相关（按行棋方取符号）——"学到的不是常数"的旁证
    if np.any(margin != 0):
        sgn = np.where(toMove == 1, 1.0, -1.0)
        mm = sgn * margin
        log('  预测胜率 vs 最终目差(行棋方视角) Spearman：新头 %+.4f  旧头 %+.4f'
            % (_spearman(pw_new, mm[te]), _spearman(pw_old[te], mm[te])))

    # ---- 导出用权重（把标准化折回 linear2）----
    W1 = net[0].weight.detach().numpy().astype(np.float64)    # (192,576)
    b1 = net[0].bias.detach().numpy().astype(np.float64)
    W2 = net[2].weight.detach().numpy().astype(np.float64)    # (3,192)
    b2 = net[2].bias.detach().numpy().astype(np.float64)
    W1f = W1 / sd[None, :]
    b1f = b1 - W1f.dot(mu)
    # 自检：折回前后对同一批特征输出必须一致
    with torch.no_grad():
        a = net(torch.from_numpy(Xte).float()).numpy()
    hlin = gpool[te].astype(np.float64).dot(W1f.T) + b1f
    h = hlin / (1.0 + np.exp(-hlin))
    logits2 = h.dot(W2.T) + b2
    log('  折回自检（standardize fold）max|logit diff| = %.3e'
        % float(np.abs(a - logits2).max()))

    np.savez(args.out_weights,
             linear2_weight=W1f.astype(np.float32),
             linear2_bias=b1f.astype(np.float32),
             v3_weight=W2.astype(np.float32),
             v3_bias=b2.astype(np.float32),
             feat_mean=mu.astype(np.float32), feat_std=sd.astype(np.float32))
    log('\nwrote %s' % args.out_weights)
    log('  linear2: %s   v3: %s' % (W1f.shape, W2.shape))

    with open(args.report, 'w', encoding='utf-8', newline='\n') as f:
        f.write('\n'.join(log_lines) + '\n')
    print('\nreport -> %s' % args.report)


def _spearman(a, b):
    a = np.asarray(a, np.float64)
    b = np.asarray(b, np.float64)
    ra = _rank(a)
    rb = _rank(b)
    ra = ra - ra.mean()
    rb = rb - rb.mean()
    den = np.sqrt((ra * ra).sum() * (rb * rb).sum())
    return float((ra * rb).sum() / den) if den > 0 else float('nan')


def _rank(x):
    order = np.argsort(x, kind='mergesort')
    r = np.empty(len(x), np.float64)
    r[order] = np.arange(1, len(x) + 1, dtype=np.float64)
    return r


if __name__ == '__main__':
    main()
