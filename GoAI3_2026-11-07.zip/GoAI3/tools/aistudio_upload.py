# -*- coding: utf-8 -*-
"""tools/aistudio_upload.py —— 用 AI Studio 官方 SDK 上传文件到数据集（命令行，不依赖浏览器）

## 为什么要有这个

网页上传必须弹 Windows 原生文件对话框，浏览器自动化驱动不了（`fill` 明确拒绝
`input[type=file]`）。官方推荐的 CLI 通道只要一个 **Access Token** 就能全自动传，
而且对 250 MB 的大权重更稳（分片直传，不会因为浏览器标签被关掉而中断）。

## 令牌怎么给（三选一，按优先级）

1. 环境变量 `AISTUDIO_TOKEN`
2. 文件 `aistudio/.token`（**推荐**：只写一行令牌，不要提交、不要贴聊天）
   令牌在 AI Studio「我的控制台 → 令牌」页面获取
3. 命令行 `--token xxx`

## 用法

    python tools\\aistudio_upload.py                                  # 传默认的 goai3_code.zip
    python tools\\aistudio_upload.py aistudio\\upload\\goai3_code.zip
    python tools\\aistudio_upload.py kata1.bin.gz --path-in-repo weights/   # 传大权重
    python tools\\aistudio_upload.py --repo caiqiyue2008/GOAI --dry-run     # 只打印将要执行的命令

依赖已用 `python tools\\install_aistudio_sdk.py --with-deps` 装到
`build_out\\aistudio_sdk`（没有走 pip，因为本机沙箱里 pip 解包会 Errno 13）。
"""
import argparse
import io
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
SDK_DIR = os.path.join(ROOT, 'build_out', 'aistudio_sdk')
DEFAULT_REPO = 'caiqiyue2008/GOAI'
DEFAULT_LOCAL = os.path.join(ROOT, 'aistudio', 'upload', 'goai3_code.zip')


def read_token(explicit=''):
    if explicit:
        return explicit
    tok = os.environ.get('AISTUDIO_TOKEN', '').strip()
    if tok:
        return tok
    p = os.path.join(ROOT, 'aistudio', '.token')
    if os.path.isfile(p):
        for line in io.open(p, encoding='utf-8', errors='replace'):
            line = line.strip()
            if line and not line.startswith('#'):
                return line
    return ''


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('local', nargs='?', default=DEFAULT_LOCAL, help='要上传的文件或目录')
    ap.add_argument('--repo', default=DEFAULT_REPO, help='repo_id，默认 %s' % DEFAULT_REPO)
    ap.add_argument('--repo-type', default='dataset', choices=['dataset', 'model'])
    ap.add_argument('--path-in-repo', default='', help='仓库内目标路径（目录需以 / 结尾）')
    ap.add_argument('--message', default='', help='commit 信息')
    ap.add_argument('--token', default='')
    ap.add_argument('--dry-run', action='store_true')
    args = ap.parse_args()

    if not os.path.exists(args.local):
        print('[error] 找不到本地文件: %s' % args.local)
        print('        先跑: python aistudio/make_upload_bundle.py')
        return 2
    size_mb = os.path.getsize(args.local) / 1e6 if os.path.isfile(args.local) else -1
    token = read_token(args.token)

    argv = ['aistudio', 'upload', args.repo, args.local]
    if args.path_in_repo:
        argv.append(args.path_in_repo)
    if args.message:
        argv += ['--commit-message', args.message]
    argv += ['--repo-type', args.repo_type]
    if token:
        argv += ['--token', '<%d 字符，已隐藏>' % len(token)]

    print('repo   : %s (%s)' % (args.repo, args.repo_type))
    print('local  : %s%s' % (args.local, ('  (%.1f MB)' % size_mb) if size_mb >= 0 else ''))
    if args.path_in_repo:
        print('远端路径: %s' % args.path_in_repo)
    print('token  : %s' % ('已找到' if token else '**没有**（见文件开头的三种给法）'))
    print('命令   : ' + ' '.join(argv))
    if args.dry_run:
        return 0
    if not token:
        print('\n[error] 没有令牌，无法上传。请把令牌写进 %s' % os.path.join(ROOT, 'aistudio', '.token'))
        return 3

    if SDK_DIR not in sys.path:
        sys.path.insert(0, SDK_DIR)
    try:
        from aistudio_sdk.cmdline import main as sdk_main
    except Exception as e:
        print('[error] 导入 aistudio_sdk 失败: %r' % (e,))
        print('        先跑: python tools/install_aistudio_sdk.py --with-deps')
        return 4

    argv[-1] = token          # 真正执行时用真令牌（打印时已隐藏）
    sys.argv = argv
    sdk_main()
    return 0


if __name__ == '__main__':
    sys.exit(main())
