# -*- coding: utf-8 -*-
"""价值头重训这条线的公共库。

设计原则（这是本项目最容易栽的地方，写在这里当提醒）：
  * **输入编码的唯一真源是 kg/infer/encode.h**。本文件只负责把
    kg/test/dump_enc.cpp 产出的位图读回来，绝不在这里重写任何编码逻辑。
  * 视角：KataGo 网络的输入永远是"行棋方视角"（平面 1 = 自己，平面 2 = 对手），
    所以价值头的输出也是**行棋方视角**。go_ai.cpp 的 nn_forward 正是这么用的
    （kgBackendForward 直接 value = r.winrate()）。本文件里所有标签都按
    "行棋方赢了没有" 构造：y = 1 if winner == toMove else 0。

dump 文件格式见 kg/test/dump_enc.cpp 顶部注释。
"""
import os
import struct
import sys

import numpy as np

N = 19
S = N * N
NF = 22
NG = 19
NBITS = NF * S
NBYTES = (NBITS + 7) // 8
REC = 4 * 4 + 4 * 2 + NBYTES + NG * 4 + S      # 1454
MAGIC = b'KGDUMP01'
AUX_MAGIC = b'KGAUX001'

# 记录内字段的字节偏移
OFF_GAMEIDX = 0
OFF_PLY = 4
OFF_TOMOVE = 8
OFF_WINNER = 12
OFF_KOMI = 16
OFF_MARGIN = 20
OFF_PLANES = 24
OFF_GLOBAL = OFF_PLANES + NBYTES
OFF_BOARD = OFF_GLOBAL + NG * 4


def read_dump(path, verbose=True):
    with open(path, 'rb') as f:
        head = f.read(8)
        if head != MAGIC:
            raise SystemExit('%s: bad magic %r' % (path, head))
        npos, npl, ss, ngl = struct.unpack('<4i', f.read(16))
        if (npl, ss, ngl) != (NF, S, NG):
            raise SystemExit('%s: unexpected (planes,S,global)=%r' % (path, (npl, ss, ngl)))
        body = f.read()
    if len(body) != npos * REC:
        raise SystemExit('%s: body %d != nPos*REC %d' % (path, len(body), npos * REC))
    a = np.frombuffer(body, dtype=np.uint8).reshape(npos, REC)
    d = {}
    d['n'] = npos
    for name, off, dt in (('gameIdx', OFF_GAMEIDX, '<i4'), ('ply', OFF_PLY, '<i4'),
                          ('toMove', OFF_TOMOVE, '<i4'), ('winner', OFF_WINNER, '<i4'),
                          ('komi', OFF_KOMI, '<f4'), ('finalMargin', OFF_MARGIN, '<f4')):
        d[name] = np.ascontiguousarray(a[:, off:off + 4]).view(dt).ravel().astype(
            np.int32 if dt == '<i4' else np.float32)
    d['planes'] = np.ascontiguousarray(a[:, OFF_PLANES:OFF_PLANES + NBYTES])
    d['global'] = np.ascontiguousarray(
        a[:, OFF_GLOBAL:OFF_GLOBAL + NG * 4]).view('<f4').reshape(npos, NG)
    d['board'] = np.ascontiguousarray(a[:, OFF_BOARD:OFF_BOARD + S]).astype(np.int8)
    if verbose:
        print('read %s : %d positions, %.1f MB' % (path, npos, len(body) / 1048576.0))
    return d


def planes_to_spatial(planes):
    """(n,NBYTES) uint8 位图 -> (n,22,19,19) float32。bit = plane*361 + s, LSB 优先。"""
    bits = np.unpackbits(planes, axis=1, bitorder='little')[:, :NBITS]
    return bits.reshape(-1, NF, N, N).astype(np.float32)


def read_aux(path):
    with open(path, 'rb') as f:
        if f.read(8) != AUX_MAGIC:
            raise SystemExit('%s: bad aux magic' % path)
        cnt = struct.unpack('<i', f.read(4))[0]
        per = 4 + 576 * 4 + 3 * 4 + (S + 1) * 4
        body = f.read()
    if len(body) != cnt * per:
        raise SystemExit('%s: aux body %d != %d' % (path, len(body), cnt * per))
    out = {'count': cnt}
    idx = np.empty(cnt, np.int32)
    gp = np.empty((cnt, 576), np.float32)
    val = np.empty((cnt, 3), np.float32)
    pol = np.empty((cnt, S + 1), np.float32)
    for k in range(cnt):
        o = k * per
        idx[k] = struct.unpack_from('<i', body, o)[0]
        gp[k] = np.frombuffer(body, '<f4', 576, o + 4)
        val[k] = np.frombuffer(body, '<f4', 3, o + 4 + 576 * 4)
        pol[k] = np.frombuffer(body, '<f4', S + 1, o + 4 + 576 * 4 + 12)
    out['posIdx'] = idx
    out['gpool'] = gp
    out['value'] = val
    out['policy'] = pol
    return out


# ---------------------------------------------------------------- 指标
def auc_score(score, label):
    """ROC-AUC（Mann-Whitney U，含并列取平均秩）。label: 1/0。"""
    score = np.asarray(score, dtype=np.float64)
    label = np.asarray(label, dtype=np.int32)
    pos = label == 1
    neg = label == 0
    npos, nneg = int(pos.sum()), int(neg.sum())
    if npos == 0 or nneg == 0:
        return float('nan')
    order = np.argsort(score, kind='mergesort')
    ranks = np.empty(len(score), dtype=np.float64)
    ranks[order] = np.arange(1, len(score) + 1, dtype=np.float64)
    # 并列取平均秩
    s_sorted = score[order]
    i = 0
    while i < len(s_sorted):
        j = i
        while j + 1 < len(s_sorted) and s_sorted[j + 1] == s_sorted[i]:
            j += 1
        if j > i:
            avg = 0.5 * (i + j) + 1.0
            ranks[order[i:j + 1]] = avg
        i = j + 1
    rp = ranks[pos].sum()
    return float((rp - npos * (npos + 1) / 2.0) / (npos * nneg))


def value_from_logits(val3):
    """(n,3) logits -> [-1,1] 胜率，与 kg::ForwardResult::winrate 完全一致。"""
    v = np.asarray(val3, dtype=np.float64)
    m = v.max(axis=1, keepdims=True)
    e = np.exp(v - m)
    s = e.sum(axis=1, keepdims=True)
    return ((e[:, 0] - e[:, 1]) / s[:, 0])


def brier(prob_win, label):
    """prob_win 是行棋方胜率 [0,1]。"""
    p = np.asarray(prob_win, np.float64)
    y = np.asarray(label, np.float64)
    return float(np.mean((p - y) ** 2))


def calib_bins(prob_win, label, edges=(0.0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0),
               min_count=30):
    p = np.asarray(prob_win, np.float64)
    y = np.asarray(label, np.float64)
    out = []
    for k in range(len(edges) - 1):
        lo, hi = edges[k], edges[k + 1]
        m = (p >= lo) & (p < hi) if k < len(edges) - 2 else (p >= lo) & (p <= hi)
        c = int(m.sum())
        if c == 0:
            out.append((lo, hi, 0, float('nan'), float('nan')))
        else:
            out.append((lo, hi, c, float(p[m].mean()), float(y[m].mean())))
    return out


# ---------------------------------------------------------------- 权重导出
def file_layout_mat(w):
    """torch (oc,ic) -> 文件里 (ic,oc) 行优先的裸 float32 字节。"""
    return np.ascontiguousarray(np.asarray(w, np.float32).T).tobytes()


def file_layout_bias(b):
    return np.ascontiguousarray(np.asarray(b, np.float32).ravel()).tobytes()


def decompress_model(path):
    import gzip
    with gzip.open(path, 'rb') as f:
        return f.read()


def locate_tensor_slots(data, M):
    """定位 value head 的 4 个张量在解压流里的字节区间。

    不用"数第几次调用"这种脆弱办法：直接把解析出来的数值按文件布局序列化，
    再去解压流里找这段字节。442KB 的 v2Mul 天然唯一；192/3 个 float 的偏置
    用"必须同时匹配且长度、内容精确相等"来判定，最后还会用补丁后重新解析
    + 逐张量比对兜底。
    """
    want = {
        'v2Mul': (M['valueHead']['v2Mul']['w'], 'mat'),
        'v2Bias': (M['valueHead']['v2Bias']['b'], 'bias'),
        'v3Mul': (M['valueHead']['v3Mul']['w'], 'mat'),
        'v3Bias': (M['valueHead']['v3Bias']['b'], 'bias'),
    }
    slots = {}
    for name, (val, kind) in want.items():
        blob = file_layout_mat(val) if kind == 'mat' else file_layout_bias(val)
        idx = data.find(blob)
        if idx < 0:
            raise SystemExit('cannot locate %s payload in decompressed stream' % name)
        if idx != data.rfind(blob):
            # 不唯一：把每次出现的位置都试一遍没有意义，直接报出来
            hits = []
            st = 0
            while True:
                k = data.find(blob, st)
                if k < 0:
                    break
                hits.append(k)
                st = k + 1
            raise SystemExit('%s payload appears %d times at %r' % (name, len(hits), hits))
        slots[name] = (idx, idx + len(blob))
    return slots
