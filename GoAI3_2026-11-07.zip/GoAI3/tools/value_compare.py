# -*- coding: utf-8 -*-
"""三方对比（同一 test 集，按棋局划分）：旧头 / v1（3,000 局面）/ 全量（7,560 局面）。

只走 gpool -> linear2 -> act2 -> linear_valuehead，与引擎里的计算完全一致
（gpool 就是 linear2 的输入，已经过 C++ vs PyTorch 的 1e-5 数值校验）。

用法:
  python tools/value_compare.py
"""
import os
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import value_lib as V
from value_features import load_official_model
from value_train import read_gids, split3

try:
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
except Exception:
    pass

FEATS = ['build_out/value/features_p0.npz', 'build_out/value/features_p1.npz']
BINS = [
    ('旧头 (kata1.bin.gz)', 'kata1.bin.gz'),
    ('v1 (3,000 局面)', 'build_out/value/kata1_value_fixed_v1.bin.gz'),
    ('全量 (7,560 局面)', 'build_out/value/kata1_value_fixed.bin.gz'),
]


def head_probs(bin_path, gp):
    import torch
    m, _ = load_official_model(bin_path, verbose=False)
    with torch.no_grad():
        out = m.value_head.linear_valuehead(
            m.value_head.act2(m.value_head.linear2(torch.from_numpy(gp)))).numpy()
    pw = (V.value_from_logits(out) + 1.0) * 0.5
    del m
    return pw


def main():
    import torch
    torch.set_num_threads(8)
    zs = []
    for fp in FEATS:
        z = np.load(fp)
        pidx = z['posIdx'] if 'posIdx' in z else np.arange(z['gpool'].shape[0])
        zs.append((int(pidx[0]), z))
    zs.sort(key=lambda t: t[0])
    gp = np.concatenate([z['gpool'] for _, z in zs]).astype(np.float32)
    ply = np.concatenate([z['meta_ply'] for _, z in zs]).astype(np.int32)
    tm = np.concatenate([z['meta_toMove'] for _, z in zs]).astype(np.int32)
    wi = np.concatenate([z['meta_winner'] for _, z in zs]).astype(np.int32)
    gi = np.concatenate([z['meta_gameIdx'] for _, z in zs]).astype(np.int32)
    ko = np.concatenate([z['meta_komi'] for _, z in zs]).astype(np.float32)
    y = (wi == tm).astype(np.int32)

    lab = split3(gi, read_gids('build_out/value/manifest.txt'))
    te = lab == 2
    print('test：%d 局面 / %d 局（总 %d 局面 / %d 局）'
          % (int(te.sum()), int(np.unique(gi[te]).size), len(y),
             int(np.unique(gi).size)))

    P = {}
    for name, path in BINS:
        if not os.path.exists(path):
            print('  跳过（不存在）: %s' % path)
            continue
        P[name] = head_probs(path, gp[te])

    pl = ply[te]
    print('\n%-22s %8s %8s %8s %10s' % ('', 'AUC', 'acc', 'Brier', 'pred_mean'))
    for name in P:
        pw = P[name]
        print('%-22s %8.4f %8.4f %8.4f %10.4f'
              % (name, V.auc_score(pw, y[te]),
                 float(((pw > 0.5).astype(int) == y[te]).mean()),
                 V.brier(pw, y[te]), pw.mean()))

    print('\n分层 AUC：')
    hdr = '%-16s %6s' % ('ply 区间', 'n')
    for name in P:
        hdr += ' %14s' % name.split(' ')[0]
    print(hdr)
    for lo, hi in ((8, 40), (40, 80), (80, 120), (120, 160), (160, 201)):
        m = (pl >= lo) & (pl < hi)
        if m.sum() < 50:
            continue
        row = '%-16s %6d' % ('%d-%d' % (lo, hi), int(m.sum()))
        for name in P:
            row += ' %14.4f' % V.auc_score(P[name][m], y[te][m])
        print(row)
    print('\n按贴目 AUC：')
    kt = ko[te]
    for k in sorted(set(np.round(kt, 1).tolist())):
        m = np.abs(kt - k) < 1e-6
        if m.sum() < 50:
            continue
        row = '%-16s %6d' % ('komi %.1f' % k, int(m.sum()))
        for name in P:
            row += ' %14.4f' % V.auc_score(P[name][m], y[te][m])
        print(row)


if __name__ == '__main__':
    main()
