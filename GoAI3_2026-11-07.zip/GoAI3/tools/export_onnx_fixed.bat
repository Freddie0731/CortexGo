@echo off
REM ===========================================================================
REM  从重训后的权重重新导出 ONNX（GPU 路径必须与原生路径同源）。
REM
REM  onnx / protobuf 装在 build_out\npu\py 里（离线手工解包的），所以要显式
REM  设 PYTHONPATH；系统 Python 里没有 onnx 包。
REM
REM  用法:  build_out\run_export.bat [weights] [outdir]
REM  默认:  build_out\value\kata1_value_fixed.bin.gz -> build_out\npu\models
REM ===========================================================================
setlocal
set "ROOT=D:\GoAI3\GoAI3\GoAI3"
set "PYTHONPATH=%ROOT%\build_out\npu\py"
set "PYTHONIOENCODING=utf-8"
set "W=%~1"
if "%W%"=="" set "W=%ROOT%\build_out\value\kata1_value_fixed.bin.gz"
set "OUT=%~2"
if "%OUT%"=="" set "OUT=%ROOT%\build_out\npu\models"
cd /d "%ROOT%"
echo [export] weights = %W%
echo [export] outdir  = %OUT%
python -c "import onnx, torch; print('[export] onnx', onnx.__version__, ' torch', torch.__version__)" || exit /b 1
python tools\export_onnx.py --weights "%W%" --out "%OUT%"
if errorlevel 1 ( echo [export] FAILED & exit /b 1 )
echo [export] done
endlocal
