# -*- coding: utf-8 -*-
"""go_ai.cpp 第五批补丁：把根节点对称平均改成"按预算自动决定"。

原因：默认固定 8 次的话，`--time 5`（引擎默认值）会把 8 次前向（约 8.8 秒）全部花在
根节点上，直接超出时间预算；`--benchmark` 的 0.15s 档同理会被拖成 8.8s。所以默认
改成 0 = auto，按本次搜索的预算决定，上限仍是 8：

    max_sims 给定 : ns = clamp(max_sims / 6, 1, 8)
    max_time 给定 : ns = clamp(max_time / 5, 1, 8)     (30s -> 6, 5s -> 1, 120s -> 8)

显式传 --root-symmetries N（1..8）仍然完全可控。
"""
import io
import sys

PATH = 'go_ai.cpp'

EDITS = [
    # 1) 默认值改成 auto
    (
        '    int root_symmetries = 8;',
        '    int root_symmetries = 0;   // 0 = auto: budget/5 evals, clamped to 1..8'
    ),
    # 2) 更新注释（原注释说的是固定 8）
    (
        '    // Network evaluations at the ROOT only (1..8). Averaging the policy over\n'
        '    // the 8 board symmetries removes the net\'s directional bias from the one\n'
        '    // thing that actually decides the move at low visit counts: the root\n'
        '    // prior. Deep leaves stay at 1 evaluation, so the cost is paid once per\n'
        '    // move, not once per simulation. Set to 1 to disable.\n'
        '    int root_symmetries = 0;   // 0 = auto: budget/5 evals, clamped to 1..8',
        '    // Network evaluations at the ROOT only (1..8), 0 = auto.\n'
        '    // Averaging the policy over the 8 board symmetries removes the net\'s\n'
        '    // directional bias from the one thing that actually decides the move at\n'
        '    // low visit counts: the root prior. Deep leaves stay at 1 evaluation, so\n'
        '    // the cost is paid once per move, not once per simulation -- but it is\n'
        '    // still 8 forwards, which is the whole budget for `--time 5`, so "auto"\n'
        '    // scales the count with the budget instead of always using 8.\n'
        '    int root_symmetries = 0;   // 0 = auto: budget/5 evals, clamped to 1..8'
    ),
    # 3) expand_node 里解析 auto
    (
        '        const bool is_root_expand = (idx == t->root);\n'
        '        int ns = is_root_expand ? params.root_symmetries : params.symmetries;\n'
        '        if (ns < 1) ns = 1;',
        '        const bool is_root_expand = (idx == t->root);\n'
        '        int ns = is_root_expand ? params.root_symmetries : params.symmetries;\n'
        '        if (is_root_expand && ns <= 0) {\n'
        '            // auto: aim to spend roughly a fifth of the budget on the root\'s\n'
        '            // symmetry averaging (a forward pass is ~1 s on this CPU).\n'
        '            double budget = (params.max_sims > 0)\n'
        '                ? (double)params.max_sims * 0.6\n'
        '                : params.max_time / 5.0;\n'
        '            ns = (int)(budget + 0.5);\n'
        '        }\n'
        '        if (ns < 1) ns = 1;'
    ),
    # 4) help 文案
    (
        '                "  --root-symmetries N  network evaluations at the root only, 1..8 (default 8)\\n"',
        '                "  --root-symmetries N  network evals at the root, 1..8, 0=auto (default 0)\\n"'
    ),
]


def main():
    raw = io.open(PATH, 'r', encoding='utf-8', newline='').read()
    text = raw.replace('\r\n', '\n')
    bad = []
    for i, (old, new) in enumerate(EDITS):
        c = text.count(old)
        if c != 1:
            bad.append((i + 1, c, old.split('\n')[0][:60]))
            continue
        text = text.replace(old, new)
        print('[ok] patch %d' % (i + 1))
    if bad:
        for b in bad:
            print('[FAIL] patch %d count=%d : %s' % b)
        raise SystemExit('有补丁没打上，文件未写回')
    out = text.replace('\r\n', '\n').replace('\n', '\r\n')
    io.open(PATH, 'w', encoding='utf-8', newline='').write(out)
    print('写回完成，%d 字节' % len(out))
    return 0


if __name__ == '__main__':
    sys.exit(main())
