# -*- coding: utf-8 -*-
"""把"云端训练所需的最小文件集"打成一个 tar.gz。

为什么需要它：训练包和推理目标是两回事 —— 云端只需要 Python 训练/导出管线、
官方 PyTorch 模型定义、编码好的数据、基础权重和棋谱库；不需要 C++ 引擎、GUI、
Windows 二进制、也不需要 build_out 里那些基准产物。

用法：
    python tools/pack_cloud_bundle.py                 # 默认输出 build_out/cloud_bundle.tar.gz
    python tools/pack_cloud_bundle.py --with-weights  # 加上 kata1.bin.gz（250MB，必带才能训）
    python tools/pack_cloud_bundle.py --no-sgf        # 不带 96k 棋谱（28MB）

输出会打印每个文件的大小与总计，并给出一条 scp 上传命令示例。
"""
import argparse
import io
import os
import sys
import tarfile

REPO = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# (归档内路径, 是否必须存在)
def collect(with_sgf=True, with_weights=True, with_features=True):
    items = []
    # 1) 云端脚本
    for f in sorted(os.listdir(os.path.join(REPO, 'cloud'))):
        if f.endswith(('.sh', '.md')):
            items.append(os.path.join('cloud', f))
    # 2) 训练/导出管线（Python）
    for f in ('value_lib.py', 'value_sgf_manifest.py', 'value_features.py',
              'value_train.py', 'value_export.py', 'value_selfcheck.py',
              'value_policy_eval.py', 'value_speed.py', 'export_onnx.py'):
        p = os.path.join('tools', f)
        if os.path.exists(os.path.join(REPO, p)):
            items.append(p)
    # 3) 官方 PyTorch 模型定义与权重解析/映射（只带 .py，不带 .cpp）
    for f in sorted(os.listdir(os.path.join(REPO, '_katago_src'))):
        if f.endswith('.py'):
            items.append(os.path.join('_katago_src', f))
    for f in ('_katago_v17_load.py', '_katago_official.py', '_kg_ref.py',
              '_kg_map.py', '_kg_export.py', '_kg_pipeline.py'):
        p = os.path.join(f)
        if os.path.exists(os.path.join(REPO, p)):
            items.append(p)
    # 4) 已经编码好的数据 + 清单（有它就不用重跑 C++ dump）
    for f in ('dump.bin', 'aux.bin', 'manifest.txt', 'selfcheck.bin'):
        p = os.path.join('build_out', 'value', f)
        if os.path.exists(os.path.join(REPO, p)):
            items.append(p)
    # 5) 本地已训出来的特征缓存（有就带，云端可以直接跳过特征提取）
    if with_features:
        p = os.path.join('build_out', 'value', 'features.npz')
        if os.path.exists(os.path.join(REPO, p)):
            items.append(p)
    # 6) 棋谱库（可在云端扩充数据量）
    if with_sgf:
        p = os.path.join('kg', 'build', 'sgf', 'games.7z')
        if os.path.exists(os.path.join(REPO, p)):
            items.append(p)
    # 7) 基础权重（训练必须）
    if with_weights:
        p = 'kata1.bin.gz'
        if os.path.exists(os.path.join(REPO, p)):
            items.append(p)
    # 8) 交接文档
    for f in ('HANDOFF.md',):
        if os.path.exists(os.path.join(REPO, f)):
            items.append(f)
    return items


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--out', default=os.path.join(REPO, 'build_out', 'cloud_bundle.tar.gz'))
    ap.add_argument('--no-sgf', action='store_true')
    ap.add_argument('--no-weights', action='store_true')
    ap.add_argument('--no-features', action='store_true')
    args = ap.parse_args()

    items = collect(with_sgf=not args.no_sgf, with_weights=not args.no_weights,
                    with_features=not args.no_features)
    if not items:
        raise SystemExit('没有可打包的文件（路径不对？）')

    total = 0
    print('%-62s %10s' % ('file', 'size'))
    print('-' * 74)
    for p in items:
        full = os.path.join(REPO, p)
        sz = os.path.getsize(full) if os.path.exists(full) else 0
        total += sz
        print('%-62s %9.1f MB' % (p, sz / 1e6))
    print('-' * 74)
    print('%-62s %9.1f MB' % ('TOTAL (uncompressed)', total / 1e6))

    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    with tarfile.open(args.out, 'w:gz') as tar:
        for p in items:
            full = os.path.join(REPO, p)
            tar.add(full, arcname=p.replace(os.sep, '/'))
    print('\nwrote %s  (%.1f MB)' % (args.out, os.path.getsize(args.out) / 1e6))
    print('\n上传示例（在本地仓库根执行）：')
    print('  scp "%s" user@your-gpu-box:/root/goai3/cloud_bundle.tar.gz'
          % os.path.relpath(args.out, REPO))
    print('云端解包：')
    print('  mkdir -p ~/goai3 && cd ~/goai3 && tar -xzf cloud_bundle.tar.gz')
    print('  bash cloud/setup.sh && bash cloud/run_value_full.sh')
    return 0


if __name__ == '__main__':
    sys.exit(main())
