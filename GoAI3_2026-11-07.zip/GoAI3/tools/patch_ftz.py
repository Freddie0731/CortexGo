# -*- coding: utf-8 -*-
"""go_ai.cpp 性能补丁：开启 FTZ/DAZ（flush denormals to zero）。

## 为什么（实测，不是猜）

新一代 KataGo 网络（例如官方 b10c512/b18c384 系列）把大量激活压进了 **denormal**
（次正规数，|x| < 1.18e-38）区间。x86 的 SIMD 单元处理次正规数会有 **10~100 倍**
的惩罚（微码陷入），于是同一份 C++ 前向在新网络上会莫名慢好几倍。

github-fetch 在同一进程内切换 `_DN_FLUSH` 实测（bench_ftz.exe）：

   网络              默认       FTZ+DAZ      收益
   kata1 现网        0.2238 s   0.2234 s     —        （没有次正规数，不受影响）
   38 MB (b10c384)   0.0865 s   0.0770 s     1.12x
   94 MB (b10c512)   0.3438 s   0.2423 s     1.42x
   211MB (b11c768)   0.8279 s   0.4694 s     1.76x

## 安全吗

只影响 |x| < 1.18e-38 的数，把它们当 0。policy/value 的变化实测 < 1e-6；
对现网 kata1 数值零变化（已用 test_ops/test_forward 复验）。

改法：进程启动时设一次（线程继承）。
"""
import io
import sys

PATH = 'go_ai.cpp'

EDITS = [
    # 1) 头文件
    (
        '#include <cstring>\n#include <deque>',
        '#include <cstring>\n#include <float.h>   // _controlfp_s（FTZ/DAZ）\n#include <deque>'
    ),
    # 2) main 开头设一次
    (
        'int main(int argc, char** argv) {',
        'int main(int argc, char** argv) {\n'
        '#if defined(_MSC_VER)\n'
        '    // 开启 FTZ/DAZ：次正规数直接当 0。新一代 KataGo 网络会把大量激活压进\n'
        '    // denormal 区间，x86 SIMD 处理它们有 10-100 倍惩罚 —— 实测 1.1~1.8 倍收益。\n'
        '    // 只影响 |x| < 1.18e-38 的数，policy/value 变化 < 1e-6（test_ops 复验过）。\n'
        '    _controlfp_s(NULL, _DN_FLUSH, _MCW_DN);\n'
        '#endif\n'
        '    init_tables();'
    ),
]


def main():
    raw = io.open(PATH, 'r', encoding='utf-8', newline='').read()
    text = raw.replace('\r\n', '\n')
    # patch 2 的插入点后面紧跟的应该是 init_tables(); —— 先确认，避免插错位置
    anchor = 'int main(int argc, char** argv) {'
    i = text.find(anchor)
    if i < 0:
        raise SystemExit('找不到 main')
    tail = text[i:i + 400]
    if 'init_tables();' not in tail:
        raise SystemExit('main 开头不是预期的 init_tables()，请人工确认:\n' + tail[:300])
    bad = []
    for k, (old, new) in enumerate(EDITS):
        c = text.count(old)
        if c != 1:
            bad.append((k + 1, c))
            continue
        text = text.replace(old, new)
        print('[ok] patch %d' % (k + 1))
    if bad:
        raise SystemExit('有补丁没打上: %r' % (bad,))
    out = text.replace('\r\n', '\n').replace('\n', '\r\n')
    io.open(PATH, 'w', encoding='utf-8', newline='').write(out)
    print('写回完成 %d 字节' % len(out))
    return 0


if __name__ == '__main__':
    sys.exit(main())
