#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""GoAI3 A/B match driver (the referee).

Runs two GoAI3 GTP engines against each other over a fixed opening + fixed
per-move simulation budget, records every move, decides the game by Chinese
area scoring after two consecutive passes (or when --max-moves is reached),
and reports the A win rate with a Wilson confidence interval, an exact
binomial test, SPRT and a "how many games do I need" power analysis.

Everything the harness needs to be reproducible is written into the result
JSON: exe paths + sha256 + mtime, engine command lines, openings, komi,
max-sims, max-moves, seeds, the full move list of every game, per-move engine
statistics, wall times and raw GTP transcripts (build_out/match/logs/).

IMPORTANT known engine limitations (verified 2026-10-17, go_ai.cpp):
  * GTP `genmove` ignores its colour argument and always generates for
    board.to_move.  This driver always alternates colours, so it is harmless
    here, but the harness records the bug (see --protocol notes / verify.py).
  * GTP `--seed` is only parsed by the --selfplay branch, and `genmove`
    overwrites sp.seed with a wall-clock value on every move.  Passing --seed
    to --cli therefore has no effect: two "identical" games are NOT
    bit-for-bit reproducible.  Use the recorded move list to replay a game
    deterministically via `play` instead.  This is an engine bug, not a
    harness bug.
  * GTP errors are reported with "=" (not "?") and there is no final_score /
    showboard command, so the driver keeps its own board replica and can only
    trust `play` acceptance to detect desynchronisation.

Usage (run from the repository root, which is also the engines' cwd; the
engine resolves kata1.bin.gz relative to the *working directory*):

  # tiny smoke test: same exe on both sides, fast heuristic search
  python tools\\match.py --games 4 --max-moves 40 --max-sims 1 --no-nn \\
      --a-args=--no-nn --b-args=--no-nn

  # real A/B: 20 games, 16 simulations per thread per move, 200 move cap
  python tools\\match.py --a x64\\Release\\GoAI3.exe --b build_out\\GoAI3_test.exe \\
      --games 20 --max-sims 16 --threads 2 --max-moves 200 --seed 1

  # statistics only, no engine started
  python tools\\match.py --plan-only

The JSON result is written to build_out/match/last_match.json by default.
SGF records go to build_out/match/sgf/<run>/.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import queue
import random
import re
import shlex
import shutil
import subprocess
import sys
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path

# ----------------------------------------------------------------------------
# Board model -- a faithful re-implementation of go_ai.cpp's Board,
# play_move(), is_legal() and area_score().  Keeping the replica exact matters:
# every genmove coordinate is validated against it, and a mismatch is reported
# as an engine bug instead of corrupting the game.
# ----------------------------------------------------------------------------

BOARD_N = 19
NN = BOARD_N * BOARD_N
PASS = -1
EMPTY, BLACK, WHITE = 0, 1, 2
GTP_LETTERS = "ABCDEFGHJKLMNOPQRSTUVWXYZ"   # GTP skips I
SGF_LETTERS = "abcdefghijklmnopqrs"          # SGF includes i


def _build_neighbors():
    nb = [[] for _ in range(NN)]
    for idx in range(NN):
        x, y = idx % BOARD_N, idx // BOARD_N
        if x > 0:
            nb[idx].append(idx - 1)
        if x < BOARD_N - 1:
            nb[idx].append(idx + 1)
        if y > 0:
            nb[idx].append(idx - BOARD_N)
        if y < BOARD_N - 1:
            nb[idx].append(idx + BOARD_N)
    return nb


NEIGHBORS = _build_neighbors()


def gtp_to_index(text):
    """go_ai.cpp gtp_to_coord() equivalent.  Returns PASS=-1, -2 on bad input."""
    if text is None:
        return -2
    s = text.strip()
    if s.lower() == "pass":
        return PASS
    if len(s) < 2:
        return -2
    c = s[0].upper()
    if c not in GTP_LETTERS:
        return -2
    x = GTP_LETTERS.index(c)
    try:
        row = int(s[1:])
    except ValueError:
        return -2
    if row < 1 or row > BOARD_N:
        return -2
    return (BOARD_N - row) * BOARD_N + x


def index_to_gtp(idx):
    if idx == PASS:
        return "pass"
    return GTP_LETTERS[idx % BOARD_N] + str(BOARD_N - idx // BOARD_N)


def index_to_sgf(idx):
    if idx == PASS:
        return ""
    return SGF_LETTERS[idx % BOARD_N] + SGF_LETTERS[idx // BOARD_N]


def sgf_to_index(s):
    if not s:
        return PASS
    if len(s) != 2:
        return -2
    x = SGF_LETTERS.find(s[0])
    y = SGF_LETTERS.find(s[1])
    if x < 0 or y < 0:
        return -2
    return y * BOARD_N + x


class Board:
    """Exact replica of go_ai.cpp Board rules: Chinese area scoring, simple
    (positional) ko, suicide illegal, captures propagate, passes toggle."""

    __slots__ = ("cells", "ko", "to_move", "passes", "caps")

    def __init__(self):
        self.cells = [EMPTY] * NN
        self.ko = -1
        self.to_move = BLACK
        self.passes = 0
        self.caps = [0, 0]

    def copy(self):
        b = Board()
        b.cells = list(self.cells)
        b.ko = self.ko
        b.to_move = self.to_move
        b.passes = self.passes
        b.caps = list(self.caps)
        return b

    # -- group search -------------------------------------------------------
    def _group(self, idx):
        color = self.cells[idx]
        group = []
        liberties = set()
        seen = {idx}
        stack = [idx]
        while stack:
            cur = stack.pop()
            group.append(cur)
            for nb in NEIGHBORS[cur]:
                v = self.cells[nb]
                if v == EMPTY:
                    liberties.add(nb)
                elif v == color and nb not in seen:
                    seen.add(nb)
                    stack.append(nb)
        return group, liberties

    def is_legal(self, idx):
        """go_ai.cpp is_legal()."""
        if idx == PASS:
            return True
        if idx < 0 or idx >= NN:
            return False
        if self.cells[idx] != EMPTY or idx == self.ko:
            return False
        color = self.to_move
        opp = 3 - color
        for nb in NEIGHBORS[idx]:
            if self.cells[nb] == EMPTY:
                return True
        for nb in NEIGHBORS[idx]:
            if self.cells[nb] == opp:
                _, libs = self._group(nb)
                if len(libs) == 1:
                    return True
        # Place and check suicide (multi-stone suicide is illegal here, same
        # as play_move() which reverts and returns false).
        saved = self.cells[idx]
        self.cells[idx] = color
        _, libs = self._group(idx)
        self.cells[idx] = saved
        return len(libs) > 0

    def play(self, idx):
        """go_ai.cpp play_move().  Returns False if illegal (board unchanged)."""
        if idx == PASS:
            self.ko = -1
            self.passes += 1
            self.to_move = 3 - self.to_move
            return True
        if idx < 0 or idx >= NN:
            return False
        if self.cells[idx] != EMPTY or idx == self.ko:
            return False
        color = self.to_move
        opp = 3 - color
        self.cells[idx] = color
        captured = []
        cap_set = set()
        for nb in NEIGHBORS[idx]:
            if self.cells[nb] != opp:
                continue
            group, libs = self._group(nb)
            if not libs:
                for c in group:
                    if c not in cap_set:
                        cap_set.add(c)
                        captured.append(c)
        if not captured:
            _, libs = self._group(idx)
            if not libs:
                self.cells[idx] = EMPTY
                return False
        for c in captured:
            self.cells[c] = EMPTY
        if color == BLACK:
            self.caps[0] += len(captured)
        else:
            self.caps[1] += len(captured)
        new_ko = -1
        if len(captured) == 1:
            group, libs = self._group(idx)
            if len(group) == 1 and len(libs) == 1:
                new_ko = captured[0]
        self.ko = new_ko
        self.to_move = opp
        self.passes = 0
        return True

    def area_score(self, komi):
        """go_ai.cpp area_score(): black stones+territory - white - komi.
        Dead stones are counted as alive (engine limitation, documented)."""
        black = sum(1 for c in self.cells if c == BLACK)
        white = sum(1 for c in self.cells if c == WHITE)
        vis = [False] * NN
        for i in range(NN):
            if self.cells[i] != EMPTY or vis[i]:
                continue
            region = 0
            border = 0
            stack = [i]
            vis[i] = True
            while stack:
                cur = stack.pop()
                region += 1
                for nb in NEIGHBORS[cur]:
                    if self.cells[nb] == EMPTY:
                        if not vis[nb]:
                            vis[nb] = True
                            stack.append(nb)
                    else:
                        border |= self.cells[nb]
            if border == BLACK:
                black += region
            elif border == WHITE:
                white += region
        return float(black - white) - float(komi)

    def stone_count(self):
        return (sum(1 for c in self.cells if c == BLACK),
                sum(1 for c in self.cells if c == WHITE))


# ----------------------------------------------------------------------------
# Statistics
# ----------------------------------------------------------------------------

Z95 = 1.959963984540054


def wilson_interval(wins, n, z=Z95):
    if n <= 0:
        return 0.0, 1.0
    p = wins / n
    denom = 1.0 + z * z / n
    centre = (p + z * z / (2.0 * n)) / denom
    half = z * math.sqrt(p * (1.0 - p) / n + z * z / (4.0 * n * n)) / denom
    return max(0.0, centre - half), min(1.0, centre + half)


def winrate_to_elo(p):
    if p <= 0.0:
        return -math.inf
    if p >= 1.0:
        return math.inf
    return -400.0 * math.log10(1.0 / p - 1.0)


def elo_to_winrate(elo):
    return 1.0 / (1.0 + 10.0 ** (-elo / 400.0))


def binomial_tail_ge(n, k, p):
    """P(X >= k) for X ~ Binomial(n, p), computed in log space."""
    if k <= 0:
        return 1.0
    if k > n:
        return 0.0
    lg_n = math.lgamma(n + 1)
    log_p = math.log(p)
    log_q = math.log1p(-p)
    logs = []
    for i in range(k, n + 1):
        logs.append(lg_n - math.lgamma(i + 1) - math.lgamma(n - i + 1)
                    + i * log_p + (n - i) * log_q)
    mx = max(logs)
    if mx < -745.0:   # underflow
        return 0.0
    s = sum(math.exp(v - mx) for v in logs)
    return min(1.0, math.exp(mx + math.log(s)))


def binomial_pmf_row(n, p):
    """Float pmf row, started at the mode so it never underflows for large n."""
    row = [0.0] * (n + 1)
    k0 = min(n, max(0, int(round(n * p))))
    row[k0] = math.exp(math.lgamma(n + 1) - math.lgamma(k0 + 1)
                       - math.lgamma(n - k0 + 1)
                       + k0 * math.log(p) + (n - k0) * math.log1p(-p))
    for k in range(k0, 0, -1):
        row[k - 1] = row[k] * k / (n - k + 1) * (1.0 - p) / p
    for k in range(k0, n):
        row[k + 1] = row[k] * (n - k) / (k + 1) * p / (1.0 - p)
    return row


def games_for_power(p1, alpha=0.05, power=0.8, two_sided=False):
    """Smallest number of games such that an exact one-sample binomial test of
    H0: p=0.5 rejects at `alpha` with probability >= `power` when the true win
    rate is p1.  Returns a dict with n, the critical win count, and the actual
    power achieved (so the caller can quote exact numbers, not an approximation).
    """
    a = alpha / 2.0 if two_sided else alpha
    for n in range(8, 3001):
        pmf = binomial_pmf_row(n, 0.5)
        tail = 0.0
        crit = 0
        for k in range(n, -1, -1):
            tail += pmf[k]
            if tail > a:
                crit = k + 1
                break
        if crit <= 0:
            continue
        achieved = binomial_tail_ge(n, crit, p1)
        if achieved >= power:
            return {"winrate": p1, "alpha": alpha, "power_requested": power,
                    "sided": "two-sided" if two_sided else "one-sided",
                    "games": n, "critical_wins": crit,
                    "power_achieved": round(achieved, 4)}
    return {"winrate": p1, "alpha": alpha, "power_requested": power,
            "sided": "two-sided" if two_sided else "one-sided",
            "games": None, "critical_wins": None, "power_achieved": None}


def sprt_bounds(elo0, elo1, alpha, beta):
    p0 = elo_to_winrate(elo0)
    p1 = elo_to_winrate(elo1)
    upper = math.log((1.0 - beta) / alpha)    # accept H1 (A stronger)
    lower = math.log(beta / (1.0 - alpha))    # accept H0 (no difference)
    return p0, p1, lower, upper


def sprt_llr(wins, losses, p0, p1):
    llr = 0.0
    if wins:
        llr += wins * math.log(p1 / p0)
    if losses:
        llr += losses * math.log((1.0 - p1) / (1.0 - p0))
    return llr


def sprt_result(wins, losses, elo0=0.0, elo1=20.0, alpha=0.05, beta=0.05):
    p0, p1, lower, upper = sprt_bounds(elo0, elo1, alpha, beta)
    llr = sprt_llr(wins, losses, p0, p1)
    if llr >= upper:
        decision = "H1_accept: A is stronger than +%g Elo" % elo1
    elif llr <= lower:
        decision = "H0_accept: no evidence A is stronger than +%g Elo" % elo1
    else:
        decision = "continue: not enough games to decide"
    span = max(upper - lower, 1e-9)
    return {
        "elo0": elo0, "elo1": elo1, "alpha": alpha, "beta": beta,
        "p0": round(p0, 6), "p1": round(p1, 6),
        "llr": round(llr, 4),
        "lower_bound": round(lower, 4), "upper_bound": round(upper, 4),
        "decision": decision,
        "need_more_games": decision.startswith("continue"),
    }


def simulate_sprt(p_true, elo0=0.0, elo1=20.0, alpha=0.05, beta=0.05,
                  runs=2000, cap=1200, seed=1234567):
    p0, p1, lower, upper = sprt_bounds(elo0, elo1, alpha, beta)
    lw = math.log(p1 / p0)
    ll = math.log((1.0 - p1) / (1.0 - p0))
    rnd = random.Random(seed)
    games = []
    dec_h1 = dec_h0 = undecided = 0
    for _ in range(runs):
        wins = losses = 0
        llr = 0.0
        n = 0
        while n < cap:
            if rnd.random() < p_true:
                wins += 1
                llr += lw
            else:
                losses += 1
                llr += ll
            n += 1
            if llr >= upper:
                dec_h1 += 1
                break
            if llr <= lower:
                dec_h0 += 1
                break
        else:
            undecided += 1
        games.append(n)
    games_sorted = sorted(games)
    return {
        "true_winrate": p_true,
        "runs": runs,
        "cap": cap,
        "mean_games": round(sum(games) / len(games), 1),
        "median_games": games_sorted[len(games_sorted) // 2],
        "p_h1_accept": round(dec_h1 / runs, 3),
        "p_h0_accept": round(dec_h0 / runs, 3),
        "p_undecided_at_cap": round(undecided / runs, 3),
    }


def build_power_report(elo0=0.0, elo1=20.0, alpha=0.05, beta=0.05,
                       runs=1500, seed=1234567):
    table = []
    for wr in (0.53, 0.55, 0.60, 0.65):
        one = games_for_power(wr, alpha=alpha, power=0.8, two_sided=False)
        two = games_for_power(wr, alpha=alpha, power=0.8, two_sided=True)
        one["elo"] = round(winrate_to_elo(wr), 1)
        one["games_two_sided_alpha05_power80"] = two["games"]
        table.append(one)
    p1 = elo_to_winrate(elo1)
    sims = []
    for p_true in (0.50, p1, 0.55, 0.60):
        sims.append(simulate_sprt(p_true, elo0, elo1, alpha, beta,
                                  runs=runs, seed=seed))
    return {
        "note": ("Games needed = exact one-sample binomial test against p=0.5. "
                 "SPRT uses the standard log-likelihood ratio for "
                 "elo0/elo1 with alpha/beta; expected games come from a seeded "
                 "Monte-Carlo of that SPRT (no draws; jigo ignored)."),
        "detect_winrate": table,
        "sprt_monte_carlo": sims,
    }


# ----------------------------------------------------------------------------
# GTP client
# ----------------------------------------------------------------------------

class EngineError(RuntimeError):
    pass


class GtpCommandError(EngineError):
    def __init__(self, command, response):
        super().__init__("GTP command %r rejected: %r" % (command, response))
        self.command = command
        self.response = response


class GtpEngine:
    """Line-based GTP client with response timeouts, multi-line handling and a
    drained stderr pipe (so a chatty engine can never deadlock the harness).

    The response to every command is a list of lines terminated by a blank
    line, as sent by go_ai.cpp run_gtp().  A leading "=" (or "?") and an echo
    of the numeric command id are stripped; the remaining text is returned.
    """

    def __init__(self, label, exe, args, cwd, log_path=None,
                 startup_timeout=300.0, verbose=False):
        self.label = label
        self.exe = str(exe)
        self.args = [str(a) for a in args]
        self.cwd = str(cwd)
        self.startup_timeout = startup_timeout
        self.verbose = verbose
        self.stderr_lines = []
        self.stdout_lines = 0
        self.last_wall = 0.0
        self.created = time.time()
        self._id = 0
        self._dead = False
        self._lock = threading.Lock()
        self._log_f = None
        if log_path:
            log_path = Path(log_path)
            log_path.parent.mkdir(parents=True, exist_ok=True)
            self._log_f = open(log_path, "a", encoding="utf-8", errors="replace")
        cmdline = [self.exe] + self.args
        kwargs = dict(stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                      stderr=subprocess.PIPE)
        if os.name == "nt":
            kwargs["creationflags"] = 0x08000000  # CREATE_NO_WINDOW
        try:
            self.proc = subprocess.Popen(cmdline, cwd=self.cwd, **kwargs)
        except OSError as exc:
            raise EngineError("cannot start %s (%s): %s"
                              % (self.label, self.exe, exc))
        self._q = queue.Queue()
        self._t_out = threading.Thread(target=self._pump_stdout, daemon=True)
        self._t_err = threading.Thread(target=self._pump_stderr, daemon=True)
        self._t_out.start()
        self._t_err.start()
        self._log("START %s" % " ".join(cmdline))

    # -- plumbing -----------------------------------------------------------
    def _log(self, text):
        if self._log_f is not None:
            ts = time.strftime("%H:%M:%S")
            try:
                self._log_f.write("[%s] %s\n" % (ts, text))
                self._log_f.flush()
            except Exception:
                pass

    @staticmethod
    def _decode(raw):
        for enc in ("utf-8", "gbk", "latin-1"):
            try:
                return raw.decode(enc)
            except UnicodeDecodeError:
                continue
        return raw.decode("utf-8", "replace")

    def _pump_stdout(self):
        while True:
            raw = self.proc.stdout.readline()
            if not raw:
                self._q.put(None)
                return
            line = self._decode(raw).rstrip("\r\n")
            self.stdout_lines += 1
            self._q.put(line)

    def _pump_stderr(self):
        while True:
            raw = self.proc.stderr.readline()
            if not raw:
                return
            line = self._decode(raw).rstrip("\r\n")
            self.stderr_lines.append(line)
            if len(self.stderr_lines) > 4000:
                del self.stderr_lines[:1000]
            self._log("STDERR %s" % line)

    # -- commands -----------------------------------------------------------
    def command(self, cmd, timeout=None):
        """Send one GTP command and return (body_text, raw_lines, wall_seconds).
        Raises EngineError on timeout/death and GtpCommandError on a "?" reply.
        """
        if self._dead:
            raise EngineError("%s is dead" % self.label)
        if timeout is None:
            timeout = self.startup_timeout
        with self._lock:
            self._id += 1
            mid = self._id
            payload = ("%d %s\n" % (mid, cmd)).encode("utf-8")
            try:
                self.proc.stdin.write(payload)
                self.proc.stdin.flush()
            except (BrokenPipeError, OSError) as exc:
                self._dead = True
                raise EngineError("%s pipe broken on %r: %s (stderr tail: %s)"
                                  % (self.label, cmd, exc,
                                     " | ".join(self.stderr_lines[-4:])))
            t0 = time.perf_counter()
            lines = []
            while True:
                try:
                    line = self._q.get(timeout=timeout)
                except queue.Empty:
                    self._dead = True
                    self._kill()
                    raise EngineError(
                        "%s timed out after %.1fs waiting for response to %r "
                        "(stderr tail: %s)"
                        % (self.label, timeout, cmd,
                           " | ".join(self.stderr_lines[-4:])))
                if line is None:
                    self._dead = True
                    raise EngineError(
                        "%s died while waiting for %r (exit=%r, stderr tail: %s)"
                        % (self.label, cmd, self.proc.poll(),
                           " | ".join(self.stderr_lines[-6:])))
                if line.strip() == "":
                    break
                lines.append(line)
            wall = time.perf_counter() - t0
            self.last_wall = wall
        self._log("CMD %r -> %r (%.3fs)" % (cmd, lines, wall))
        if not lines:
            raise EngineError("%s sent an empty response to %r"
                              % (self.label, cmd))
        first = lines[0]
        if first.startswith("?"):
            # A spec-compliant error.  go_ai.cpp never sends this (bug), so any
            # "?" here comes from a future/patched engine.
            body = first[1:].strip()
            for extra in lines[1:]:
                body += "\n" + extra
            body = self._strip_id(body, mid)
            raise GtpCommandError(cmd, body)
        if first.startswith("="):
            rest = first[1:]
        else:
            rest = first
            self._log("WARNING: %s response does not start with = or ?: %r"
                      % (self.label, first))
        rest = self._strip_id(rest, mid)
        body = rest
        for extra in lines[1:]:
            body += "\n" + extra
        return body, lines, wall

    @staticmethod
    def _strip_id(text, mid):
        s = text
        if s.startswith(" "):
            s = s[1:]
        parts = s.split(None, 1)
        if parts and parts[0].isdigit() and int(parts[0]) == mid:
            s = parts[1] if len(parts) > 1 else ""
        return s

    def send_ok(self, cmd, timeout=None):
        body, lines, wall = self.command(cmd, timeout=timeout)
        return body, wall

    def startup(self):
        body, _ = self.send_ok("protocol_version", timeout=self.startup_timeout)
        self.protocol_version = body.strip()
        if self.protocol_version != "2":
            raise EngineError("%s answered protocol_version %r (want '2')"
                              % (self.label, self.protocol_version))
        # The banner is written to stderr before run_gtp() starts reading
        # stdin, so it is normally already collected; this tiny wait only
        # removes a race with the stderr reader thread.
        deadline = time.time() + 1.5
        while time.time() < deadline and not any(
                ("Neural net" in ln or "heuristic priors" in ln
                 or "GoAI++ build" in ln) for ln in self.stderr_lines):
            time.sleep(0.02)
        name, _ = self.send_ok("name")
        version, _ = self.send_ok("version")
        self.name = name.strip()
        self.version = version.strip()
        try:
            cmds, _ = self.send_ok("list_commands")
            self.commands = [ln.strip() for ln in cmds.splitlines() if ln.strip()]
        except EngineError:
            self.commands = []
        # neural-net readiness is reported on stderr during load
        err = "\n".join(self.stderr_lines)
        self.nn_loaded = ("Neural net loaded" in err)
        self.nn_fallback = ("heuristic priors" in err
                            or "Run 转换权重.bat" in err)
        return {
            "name": self.name, "version": self.version,
            "protocol_version": self.protocol_version,
            "commands": self.commands,
            "nn_loaded": self.nn_loaded,
            "nn_fallback": self.nn_fallback,
            "startup_stderr": self.stderr_lines[:20],
        }

    # -- convenience wrappers ----------------------------------------------
    def clear_board(self):
        self.send_ok("clear_board")

    def set_komi(self, komi):
        self.send_ok("komi %g" % komi)

    def play(self, color, coord):
        body, wall = self.send_ok("play %s %s" % (color, coord))
        return body.strip(), wall

    def genmove(self, color):
        body, lines, wall = self.command("genmove %s" % color,
                                         timeout=self.move_timeout)
        return body, lines, wall

    move_timeout = 300.0

    def close(self, timeout=10.0):
        self._dead = True
        try:
            self.proc.stdin.write(b"quit\n")
            self.proc.stdin.flush()
            self.proc.wait(timeout=timeout)
        except Exception:
            self._kill()
        self._log("CLOSE exit=%r" % self.proc.poll())
        if self._log_f is not None:
            try:
                self._log_f.close()
            except Exception:
                pass

    def _kill(self):
        try:
            self.proc.kill()
        except Exception:
            pass
        try:
            self.proc.wait(timeout=5.0)
        except Exception:
            pass


GENMOVE_STATS_RE = re.compile(
    r"visits=(\d+)\s+winrate=([\d.]+)%\s+depth=(\d+)\s+([\d.]+)s(\s+no-nn)?")


def parse_genmove(body):
    """Split `Q16  (visits=.. winrate=..% depth=.. ..s)` into
    (move_token, stats_dict)."""
    text = body.strip()
    token, _, comment = text.partition(" ")
    stats = {"visits": None, "winrate": None, "depth": None,
             "seconds": None, "no_nn": False, "comment": comment.strip()}
    m = GENMOVE_STATS_RE.search(text)
    if m:
        stats["visits"] = int(m.group(1))
        stats["winrate"] = float(m.group(2))
        stats["depth"] = int(m.group(3))
        stats["seconds"] = float(m.group(4))
        stats["no_nn"] = bool(m.group(5))
    return token, stats


# ----------------------------------------------------------------------------
# Openings (fixed list, plain text file, or SGF main lines)
# ----------------------------------------------------------------------------

def parse_sgf_mainline(text, max_moves=30):
    """Extract (colour, sgf_coord) moves from the SGF main line (first child at
    every branch point).  Tolerant of the FF[4] files in kg/build/sgf."""
    s = text
    start = s.find("(")
    if start < 0:
        return []
    moves = []
    pos = start
    length = len(s)

    def skip_ws(i):
        while i < length and s[i] in " \t\r\n":
            i += 1
        return i

    def parse_nodes(i):
        while i < length:
            i = skip_ws(i)
            if i >= length or s[i] != ";":
                break
            i += 1
            props = {}
            i = skip_ws(i)
            while i < length and s[i].isalpha() and s[i].isupper():
                name_start = i
                while i < length and s[i].isalpha() and s[i].isupper():
                    i += 1
                name = s[name_start:i]
                values = []
                i = skip_ws(i)
                while i < length and s[i] == "[":
                    i += 1
                    buf = []
                    while i < length and s[i] != "]":
                        if s[i] == "\\" and i + 1 < length:
                            i += 1
                        buf.append(s[i])
                        i += 1
                    if i < length:
                        i += 1  # closing ]
                    values.append("".join(buf))
                    i = skip_ws(i)
                props[name] = values
            for colour, prop in (("B", "B"), ("W", "W")):
                if prop in props and props[prop]:
                    value = props[prop][0].strip()
                    if len(moves) < max_moves:
                        moves.append((colour, value))
        return i

    def parse_tree(i):
        # s[i] == '('
        i += 1
        i = parse_nodes(i)
        taken = False
        i = skip_ws(i)
        while i < length and s[i] == "(":
            if not taken:
                i = parse_tree(i)
                taken = True
            else:
                i = skip_tree(i)
            i = skip_ws(i)
        if i < length and s[i] == ")":
            i += 1
        return i

    def skip_tree(i):
        depth = 0
        while i < length:
            c = s[i]
            if c == "(":
                depth += 1
            elif c == ")":
                depth -= 1
                if depth == 0:
                    return i + 1
            elif c == "[":
                # do not count parentheses inside property values
                i += 1
                while i < length and s[i] != "]":
                    if s[i] == "\\" and i + 1 < length:
                        i += 1
                    i += 1
                if i < length:
                    i += 1
            i += 1
        return i

    parse_tree(pos)
    return moves


def opening_from_plain_moves(moves, source):
    """Turn a flat list of GTP coordinates into coloured opening moves."""
    result = []
    color = BLACK
    for token in moves:
        coord = token.strip()
        if not coord:
            continue
        idx = gtp_to_index(coord)
        if idx == -2:
            raise ValueError("bad opening coordinate %r in %s" % (coord, source))
        result.append(("B" if color == BLACK else "W", coord))
        color = 3 - color
    validate_opening(result, source)
    return result


def opening_from_sgf_moves(sgf_moves, source):
    result = []
    for color, sgf_coord in sgf_moves:
        idx = sgf_to_index(sgf_coord)
        if idx == -2:
            raise ValueError("bad SGF coordinate %r in %s" % (sgf_coord, source))
        if idx == PASS:
            break
        result.append((color, index_to_gtp(idx)))
    if not result:
        return []
    if result[0][0] != "B":
        raise ValueError("%s starts with a white move (handicap game?); "
                         "opening loader only supports even games" % source)
    validate_opening(result, source)
    return result


def validate_opening(opening, source):
    board = Board()
    for ply, (colour, coord) in enumerate(opening, 1):
        want = BLACK if colour == "B" else WHITE
        if board.to_move != want:
            raise ValueError("opening %s: %s move at ply %d is out of turn"
                             % (source, colour, ply))
        idx = gtp_to_index(coord)
        if idx == PASS or not board.play(idx):
            raise ValueError("opening %s: illegal move %s %s at ply %d"
                             % (source, colour, coord, ply))


def load_openings(args):
    """Returns a list of openings, each a list of (colour, gtp_coord)."""
    openings = []
    for spec in args.opening or []:
        openings.append(opening_from_plain_moves(spec.split(), "--opening"))
    for path in args.opening_file or []:
        p = Path(path)
        if not p.is_file():
            raise SystemExit("opening file not found: %s" % p)
        lines = p.read_text(encoding="utf-8", errors="replace").splitlines()
        for lineno, line in enumerate(lines, 1):
            line = line.split("#", 1)[0].strip()
            if not line:
                continue
            openings.append(opening_from_plain_moves(line.split(),
                                                     "%s:%d" % (p, lineno)))
    for directory in args.sgf_dir or []:
        root = Path(directory)
        if not root.exists():
            raise SystemExit("sgf dir not found: %s" % root)
        files = sorted(root.rglob("*.sgf"))[:args.sgf_limit]
        if not files:
            raise SystemExit("no .sgf files under %s" % root)
        for path in files:
            try:
                text = path.read_text(encoding="utf-8", errors="replace")
                moves = parse_sgf_mainline(text, max_moves=args.sgf_moves)
                opening = opening_from_sgf_moves(moves, str(path))
            except Exception as exc:
                print("WARNING: skipping SGF %s: %s" % (path, exc),
                      file=sys.stderr)
                continue
            if opening:
                openings.append(opening)
    if not openings:
        openings = [[]]
    if args.shuffle_openings:
        rnd = random.Random(args.seed)
        rnd.shuffle(openings)
    return openings


# ----------------------------------------------------------------------------
# Match configuration and engine arguments
# ----------------------------------------------------------------------------

DEFAULT_A = "x64/Release/GoAI3.exe"
DEFAULT_B = "build_out/GoAI3_test.exe"


@dataclass
class MatchConfig:
    repo: Path
    a_exe: str
    b_exe: str
    games: int = 10
    max_sims: int = 16
    threads: int = 2
    komi: float = 7.5
    max_moves: int = 200
    passes_to_end: int = 2
    seed: int = 1
    opening_specs: list = field(default_factory=list)
    openings: list = field(default_factory=list)
    a_extra_args: list = field(default_factory=list)
    b_extra_args: list = field(default_factory=list)
    engine_args: list = field(default_factory=list)
    move_timeout: float = 0.0
    startup_timeout: float = 300.0
    engine_time: float = 3600.0
    calibrate: bool = True
    fwd_est: float = 1.1
    out_dir: str = "build_out/match"
    out_json: str = ""
    sgf: bool = True
    verbose: bool = False
    quiet: bool = False
    max_total_minutes: float = 90.0
    force: bool = False
    estimate_only: bool = False
    elo0: float = 0.0
    elo1: float = 20.0
    sprt_alpha: float = 0.05
    sprt_beta: float = 0.05
    plan_only: bool = False

    def engine_argv(self, which):
        exe = self.a_exe if which == "a" else self.b_exe
        extra = list(self.engine_args)
        extra += self.a_extra_args if which == "a" else self.b_extra_args
        argv = [exe, "--cli", "--max-sims", str(self.max_sims),
                "--threads", str(self.threads),
                "--time", ("%g" % self.engine_time),
                "--seed", str(self.seed)]
        argv += extra
        return argv

    def as_dict(self):
        d = {k: getattr(self, k) for k in (
            "a_exe", "b_exe", "games", "max_sims", "threads", "komi",
            "max_moves", "passes_to_end", "seed", "a_extra_args",
            "b_extra_args", "engine_args", "move_timeout", "startup_timeout",
            "engine_time", "calibrate", "fwd_est", "out_dir", "elo0", "elo1",
            "sprt_alpha", "sprt_beta")}
        d["repo"] = str(self.repo)
        d["openings"] = [[list(m) for m in op] for op in self.openings]
        return d


def file_fingerprint(path):
    p = Path(path)
    info = {"path": str(p.resolve()) if p.exists() else str(p),
            "exists": p.is_file()}
    if not p.is_file():
        return info
    st = p.stat()
    info.update({"size": st.st_size,
                 "mtime": time.strftime("%Y-%m-%d %H:%M:%S",
                                        time.localtime(st.st_mtime))})
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    info["sha256"] = h.hexdigest()[:16]
    return info


def detect_build_tag(exe, repo, timeout=60.0):
    """Cheap fingerprint: --help returns before the network is loaded."""
    try:
        proc = subprocess.run([str(exe), "--help"], cwd=str(repo),
                              capture_output=True, timeout=timeout)
        out = (proc.stdout + proc.stderr).decode("utf-8", "replace")
        m = re.search(r"GoAI\+\+ build (\S+)", out)
        return m.group(1) if m else None
    except Exception:
        return None


# ----------------------------------------------------------------------------
# Match runner
# ----------------------------------------------------------------------------

class MatchRunner:
    def __init__(self, cfg):
        self.cfg = cfg
        self.repo = Path(cfg.repo)
        self.out_dir = self.repo / cfg.out_dir
        self.run_id = time.strftime("%Y%m%d-%H%M%S")
        self.sgf_dir = self.out_dir / "sgf" / self.run_id
        self.log_dir = self.out_dir / "logs"
        self.engines = {}
        self.engine_info = {}
        self.games = []
        self.notes = []
        self.engine_errors = []
        self.interrupted = False
        self.target_game = None

    # -- setup --------------------------------------------------------------
    def _timeout_for(self):
        if self.cfg.move_timeout and self.cfg.move_timeout > 0:
            return float(self.cfg.move_timeout)
        per_move = self.cfg.fwd_est * max(1, self.cfg.max_sims)
        return max(180.0, per_move * 10.0 + 60.0)

    def _start_engine(self, which):
        cfg = self.cfg
        label = "engine_%s" % which
        argv = cfg.engine_argv(which)
        eng = GtpEngine(label, argv[0], argv[1:], self.repo,
                        log_path=self.log_dir / ("%s_%s.log" % (label, self.run_id)),
                        startup_timeout=cfg.startup_timeout,
                        verbose=cfg.verbose)
        eng.move_timeout = self._timeout_for()
        t0 = time.time()
        info = eng.startup()
        info["startup_s"] = round(time.time() - t0, 2)
        info["argv"] = argv
        info["fingerprint"] = file_fingerprint(argv[0])
        info["build_tag"] = detect_build_tag(argv[0], self.repo)
        return eng, info

    def start_engines(self):
        for which in ("a", "b"):
            eng, info = self._start_engine(which)
            self.engines[which] = eng
            self.engine_info[which] = info
            if not self.cfg.quiet:
                print("[match] engine %s: %s  build=%s  netfile=%s  startup=%.1fs"
                      % (which.upper(), self.engine_info[which]["fingerprint"]["path"],
                         info.get("build_tag"), "yes" if info["nn_loaded"] else "NO",
                         info["startup_s"]))
        for which in ("a", "b"):
            info = self.engine_info[which]
            if info["nn_fallback"]:
                self.notes.append(
                    "engine %s reports heuristic fallback (weights not loaded): %s"
                    % (which.upper(), " | ".join(info["startup_stderr"][-4:])))
            if not info["nn_loaded"]:
                self.notes.append("engine %s: no 'Neural net loaded' line on stderr"
                                  % which.upper())
        komi = self.cfg.komi
        for which, eng in self.engines.items():
            eng.set_komi(komi)
            eng.send_ok("boardsize %d" % BOARD_N)

    def calibrate(self):
        """One real genmove on the empty board per engine: proves the engine
        answers GTP, gives the empty-board move, and measures the forward time
        so the total-time estimate is not fantasy on a loaded machine."""
        cfg = self.cfg
        measured = {}
        for which, eng in self.engines.items():
            eng.clear_board()
            body, lines, wall = eng.genmove("B")
            token, stats = parse_genmove(body)
            idx = gtp_to_index(token)
            legal = idx == PASS or (idx != -2 and Board().is_legal(idx))
            fwd = None
            if stats["seconds"] not in (None, 0.0) and stats["visits"]:
                fwd = stats["seconds"] / (stats["visits"] + 1.0)
            elif wall > 0:
                # no-nn (heuristic) search reports 0.00s; wall time is all we have
                fwd = wall / max(2.0, float(stats["visits"] or 1) + 1.0)
            if fwd:
                measured[which] = max(fwd, 1e-4)
            eng.clear_board()
            self.engine_info[which]["empty_genmove"] = {
                "token": token, "legal": bool(legal),
                "stats": stats, "wall_s": round(wall, 2),
                "forward_est_s": round(fwd, 3) if fwd else None,
            }
            if not legal:
                self.notes.append("engine %s genmove on empty board returned "
                                  "illegal coordinate %r" % (which.upper(), token))
                self.engine_errors.append({
                    "kind": "calibration_illegal_genmove", "engine": which.upper(),
                    "token": token, "stats": stats})
            if stats["no_nn"]:
                self.notes.append("engine %s is running with no-nn (heuristic) "
                                  "search" % which.upper())
            if not cfg.quiet:
                print("[match] calibration %s: %s %s  visits=%s wr=%s%%%.2fs wall%s"
                      % (which.upper(), token,
                         "" if legal else "(ILLEGAL)", stats["visits"],
                         stats["winrate"], wall,
                         "  [no-nn heuristic search]" if stats["no_nn"] else ""))
        if measured:
            self.cfg.fwd_est = min(measured.values()) if cfg.calibrate else cfg.fwd_est
        return measured

    def estimate(self):
        cfg = self.cfg
        per_move = cfg.fwd_est * max(1, cfg.max_sims) * 1.15 + 0.2
        opening_moves = 0
        if cfg.openings:
            opening_moves = sum(len(op) for op in cfg.openings) / len(cfg.openings)
        # max_moves counts the opening plies as well
        approx_moves = min(cfg.max_moves, 200)
        if opening_moves > approx_moves:
            approx_moves = opening_moves
        startup = 2.0 * (self.cfg.startup_timeout * 0.03 + 5.0)
        seconds = cfg.games * approx_moves * per_move + startup
        return {
            "forward_est_s": round(cfg.fwd_est, 3),
            "per_move_est_s": round(per_move, 2),
            "moves_per_game_est": round(approx_moves, 1),
            "games": cfg.games,
            "total_est_s": round(seconds, 1),
            "total_est_min": round(seconds / 60.0, 1),
            "assumes": ("wall time per genmove ~= max_sims * forward_time "
                        "(max_sims simulations per thread, 2 threads in "
                        "parallel); first move of a game costs one extra "
                        "forward for root expansion"),
        }

    # -- one game -----------------------------------------------------------
    def _opening_for(self, game_index):
        openings = self.cfg.openings or [[]]
        return openings[game_index % len(openings)]

    def play_game(self, game_index):
        cfg = self.cfg
        a_color_int = BLACK if game_index % 2 == 0 else WHITE
        b_color_int = 3 - a_color_int
        a_color = "B" if a_color_int == BLACK else "W"
        b_color = "B" if b_color_int == BLACK else "W"
        opening = self._opening_for(game_index)
        board = Board()
        game = {
            "index": game_index,
            "a_color": a_color,
            "b_color": b_color,
            "opening": [[c, m] for c, m in opening],
            "moves": [],
            "termination": None,
            "winner": None,
            "winner_color": None,
            "score_black_area": None,
            "score_margin": None,
            "invalid": False,
            "errors": [],
            "wall_s": None,
            "move_wall_total_s": 0.0,
            "raw_genmove_lines": [],
        }
        t_game = time.time()
        for eng in self.engines.values():
            eng.clear_board()
            eng.set_komi(cfg.komi)

        def abort(kind, detail):
            game["invalid"] = True
            game["termination"] = kind
            game["errors"].append(detail)
            self.engine_errors.append(dict(detail, game=game_index))
            if not cfg.quiet:
                print("[match] game %d ABORTED: %s: %s"
                      % (game_index + 1, kind, detail))

        # -- opening -------------------------------------------------------
        try:
            for colour, coord in opening:
                idx = gtp_to_index(coord)
                if not board.play(idx):
                    raise EngineError("opening move %s %s illegal on replica"
                                      % (colour, coord))
                for which, eng in self.engines.items():
                    body, _ = eng.play(colour, coord)
                    if body:
                        abort("opening_rejected", {
                            "kind": "opening_play_rejected",
                            "engine": which.upper(), "color": colour,
                            "coord": coord, "response": body,
                            "ply": len(game["moves"])})
                        return self._finish_game(game, board, t_game, None)
                game["moves"].append({
                    "ply": len(game["moves"]) + 1, "color": colour,
                    "coord": coord, "by": "opening",
                    "stats": None, "wall_s": None})
        except EngineError as exc:
            abort("engine_error", {"kind": "opening_engine_error",
                                   "detail": str(exc)})
            return self._finish_game(game, board, t_game, None)

        # -- main loop -----------------------------------------------------
        while len(game["moves"]) < cfg.max_moves:
            color = "B" if board.to_move == BLACK else "W"
            which = "a" if ((color == "B") == (a_color == "B")) else "b"
            eng = self.engines.get(which)
            other = self.engines.get("b" if which == "a" else "a")
            if eng is None or other is None:
                abort("engine_error", {"kind": "engine_missing", "engine": which})
                break
            try:
                body, lines, wall = eng.genmove(color)
            except EngineError as exc:
                abort("engine_error", {"kind": "genmove_engine_error",
                                       "engine": which.upper(), "detail": str(exc),
                                       "ply": len(game["moves"]) + 1})
                break
            token, stats = parse_genmove(body)
            game["raw_genmove_lines"].append(
                {"ply": len(game["moves"]) + 1, "engine": which.upper(),
                 "color": color, "raw": "\n".join(lines)})
            if token.lower().startswith("resign"):
                game["termination"] = "resign"
                game["winner_color"] = "W" if color == "B" else "B"
                game["winner"] = "A" if game["winner_color"] == a_color else "B"
                if not cfg.quiet:
                    print("[match] game %d: %s resigns"
                          % (game_index + 1, "Black" if color == "B" else "White"))
                break
            idx = gtp_to_index(token)
            if idx == -2:
                abort("illegal_output", {
                    "kind": "invalid_genmove_coordinate", "engine": which.upper(),
                    "color": color, "raw_token": token, "ply": len(game["moves"]) + 1})
                break
            if idx != PASS and not board.is_legal(idx):
                detail = {"kind": "illegal_genmove", "engine": which.upper(),
                          "color": color, "coord": token, "index": idx,
                          "ply": len(game["moves"]) + 1,
                          "board_to_move": color, "stats": stats,
                          "raw": body}
                abort("illegal_genmove", detail)
                break
            # feed the move to the opponent's engine first
            try:
                body2, wall2 = other.play(color, token)
            except EngineError as exc:
                abort("engine_error", {"kind": "play_engine_error",
                                       "engine": ("b" if which == "a" else "a").upper(),
                                       "detail": str(exc), "coord": token,
                                       "ply": len(game["moves"]) + 1})
                break
            if body2.strip():
                detail = {"kind": "play_rejected", "engine":
                          ("b" if which == "a" else "a").upper(),
                          "color": color, "coord": token,
                          "response": body2.strip(),
                          "ply": len(game["moves"]) + 1,
                          "note": ("engine and harness boards are out of sync; "
                                   "most likely the generating engine played a "
                                   "move its own board considered illegal")}
                abort("play_rejected", detail)
                break
            # both boards agree; apply to the replica
            if not board.play(idx):
                abort("desync", {"kind": "replica_rejected_move",
                                 "coord": token, "ply": len(game["moves"]) + 1})
                break
            game["moves"].append({
                "ply": len(game["moves"]) + 1, "color": color, "coord": token,
                "by": which.upper(), "stats": stats, "wall_s": round(wall, 2)})
            game["move_wall_total_s"] += wall
            if stats.get("no_nn"):
                game.setdefault("no_nn", True)
            if cfg.verbose:
                print("[match] game %d move %3d %s %-5s %-5s %5.1fs "
                      "(visits=%s wr=%s%% depth=%s)"
                      % (game_index + 1, len(game["moves"]), color,
                         ("A" if which == "a" else "B"), token, wall,
                         stats["visits"], stats["winrate"], stats["depth"]))
            if idx == PASS and board.passes >= cfg.passes_to_end:
                game["termination"] = "double_pass"
                break
        if game["termination"] is None:
            game["termination"] = "max_moves"
        return self._finish_game(game, board, t_game, None)

    def _finish_game(self, game, board, t_game, _unused):
        cfg = self.cfg
        game["wall_s"] = round(time.time() - t_game, 2)
        if game["termination"] != "resign":
            score = board.area_score(cfg.komi)
            game["score_black_area"] = round(score, 2)
            black_stones, white_stones = board.stone_count()
            game["stones"] = {"black": black_stones, "white": white_stones,
                              "total": black_stones + white_stones}
            if score > 0:
                game["winner_color"] = "B"
            elif score < 0:
                game["winner_color"] = "W"
            else:
                game["winner_color"] = "draw"
            if game["winner_color"] == "draw":
                game["winner"] = "draw"
                game["score_margin"] = 0.0
            else:
                game["score_margin"] = round(abs(score), 2)
                a_color = game["a_color"]
                game["winner"] = "A" if game["winner_color"] == a_color else "B"
        elif game["winner"] is None:
            game["winner"] = "draw"
        # SGF
        if cfg.sgf:
            self.sgf_dir.mkdir(parents=True, exist_ok=True)
            path = self.sgf_dir / ("game_%03d.sgf" % (game["index"] + 1))
            try:
                path.write_text(self._sgf_text(game), encoding="utf-8")
                game["sgf_path"] = str(path)
            except Exception as exc:
                self.notes.append("could not write SGF %s: %s" % (path, exc))
        if game["termination"] not in ("double_pass", "max_moves"):
            if not cfg.quiet:
                print("[match] game %d INVALID (%s), excluded from winrate"
                      % (game["index"] + 1, game["termination"]))
        elif not cfg.quiet:
            print("[match] game %d done: %s  %s+%.1f  moves=%d  %.1fs"
                  % (game["index"] + 1,
                     "A" if game["winner"] == "A" else
                     ("B" if game["winner"] == "B" else "draw"),
                     game["winner_color"] if game["winner_color"] != "draw" else "Jigo",
                     game["score_margin"] or 0.0, len(game["moves"]),
                     game["wall_s"]))
        return game

    def _sgf_text(self, game):
        cfg = self.cfg
        result = "RE[?]"
        if game["winner_color"] == "draw":
            result = "RE[0]"
        elif game["winner_color"] in ("B", "W"):
            if game["termination"] == "resign":
                result = "RE[%s+R]" % game["winner_color"]
            elif game["score_margin"] is not None:
                result = "RE[%s+%.1f]" % (game["winner_color"],
                                          game["score_margin"])
        elif game["termination"] in ("double_pass", "max_moves"):
            result = "RE[?]"
        info = ("GoAI3 match game %d: A=%s (B exe), B=%s (A exe) ... "
                % (game["index"] + 1, game["a_color"], game["b_color"]))
        comment = ("GoAI3 A/B match game=%d A_color=%s B_color=%s "
                   "max_sims=%d/thread threads=%d komi=%g max_moves=%d "
                   "termination=%s area_score_black=%s dead_stones_counted_alive=1"
                   % (game["index"] + 1, game["a_color"], game["b_color"],
                      cfg.max_sims, cfg.threads, cfg.komi, cfg.max_moves,
                      game["termination"], game.get("score_black_area")))
        pb = Path(cfg.a_exe).name
        pw = Path(cfg.b_exe).name
        if game["a_color"] == "W":
            pb, pw = pw, pb
        parts = ['(;GM[1]FF[4]CA[UTF-8]SZ[%d]KM[%g]' % (BOARD_N, cfg.komi),
                 result,
                 'PB[%s]PW[%s]' % (_sgf_escape(pb), _sgf_escape(pw)),
                 'DT[%s]' % time.strftime("%Y-%m-%d"),
                 'C[%s]' % _sgf_escape(comment)]
        for mv in game["moves"]:
            colour = "B" if mv["color"] == "B" else "W"
            idx = gtp_to_index(mv["coord"])
            parts.append(";%s[%s]" % (colour, index_to_sgf(idx)))
        parts.append(")")
        return "".join(parts) + "\n"

    # -- whole match --------------------------------------------------------
    def run(self):
        cfg = self.cfg
        t_start = time.time()
        self.out_dir.mkdir(parents=True, exist_ok=True)
        self.log_dir.mkdir(parents=True, exist_ok=True)
        if cfg.verbose:
            print("[match] config: %s" % json.dumps(cfg.as_dict(), indent=2))
        self.start_engines()
        if cfg.calibrate:
            self.calibrate()
        plan = self.estimate()
        if not cfg.quiet:
            print("[match] time plan: %d games x ~%.0f moves x %.2fs/move = "
                  "~%.1f min (forward est %.2fs from calibration)"
                  % (plan["games"], plan["moves_per_game_est"],
                     plan["per_move_est_s"], plan["total_est_min"],
                     plan["forward_est_s"]))
        if not cfg.force and cfg.max_total_minutes > 0 \
                and plan["total_est_min"] > cfg.max_total_minutes:
            print("[match] REFUSING TO START: estimated %.1f min > --max-total-minutes %.1f. "
                  "Lower --games/--max-moves/--max-sims, raise --max-total-minutes, "
                  "or pass --force." % (plan["total_est_min"],
                                        cfg.max_total_minutes))
            self.close()
            return {"error": "estimate_exceeds_cap", "estimated": plan}
        if cfg.estimate_only:
            self.close()
            return {"estimate": plan, "config": cfg.as_dict()}
        try:
            for gi in range(cfg.games):
                game = self.play_game(gi)
                self.games.append(game)
                if game["invalid"]:
                    # a dead engine gets one restart attempt so the rest of
                    # the match can continue; a merely illegal genmove does not
                    # need one.
                    for which in ("a", "b"):
                        eng = self.engines.get(which)
                        if eng is None or eng._dead:
                            try:
                                eng.close()
                            except Exception:
                                pass
                            new_eng, info = self._start_engine(which)
                            new_eng.set_komi(cfg.komi)
                            new_eng.send_ok("boardsize %d" % BOARD_N)
                            self.engines[which] = new_eng
                            self.engine_info[which] = info
                            self.notes.append("restarted engine %s after error"
                                              % which.upper())
                            if not cfg.quiet:
                                print("[match] restarted engine %s" % which.upper())
        except KeyboardInterrupt:
            self.interrupted = True
            print("[match] INTERRUPTED after %d games; writing partial result"
                  % len(self.games))
        finally:
            self.close()
        elapsed = time.time() - t_start
        result = self.build_result(plan, elapsed)
        out_json = Path(cfg.out_json) if cfg.out_json else \
            self.out_dir / "last_match.json"
        out_json.parent.mkdir(parents=True, exist_ok=True)
        out_json.write_text(json.dumps(result, indent=2, ensure_ascii=False),
                            encoding="utf-8")
        result["_json_path"] = str(out_json)
        return result

    def close(self):
        for eng in self.engines.values():
            try:
                eng.close()
            except Exception:
                pass
        self.engines = {}

    # -- reporting ----------------------------------------------------------
    def build_result(self, plan, elapsed):
        cfg = self.cfg
        valid = [g for g in self.games
                 if not g["invalid"] and g["termination"] in ("double_pass",
                                                              "max_moves", "resign")]
        a_wins = sum(1 for g in valid if g["winner"] == "A")
        b_wins = sum(1 for g in valid if g["winner"] == "B")
        draws = sum(1 for g in valid if g["winner"] == "draw")
        invalid = len(self.games) - len(valid)
        decided = a_wins + b_wins
        winrate = (a_wins / decided) if decided else None
        wilson = wilson_interval(a_wins, decided) if decided else (None, None)
        if decided:
            p_one = binomial_tail_ge(decided, a_wins, 0.5)
            elo = winrate_to_elo(winrate) if 0 < winrate < 1 else None
            elo_low = winrate_to_elo(wilson[0]) if 0 < wilson[0] < 1 else None
            elo_high = winrate_to_elo(wilson[1]) if 0 < wilson[1] < 1 else None
        else:
            p_one, elo, elo_low, elo_high = None, None, None, None
        summary = {
            "games_planned": cfg.games,
            "games_played": len(self.games),
            "games_valid": len(valid),
            "games_invalid": invalid,
            "a_wins": a_wins,
            "b_wins": b_wins,
            "draws": draws,
            "decided": decided,
            "a_winrate": round(winrate, 4) if winrate is not None else None,
            "wilson95_low": round(wilson[0], 4) if wilson[0] is not None else None,
            "wilson95_high": round(wilson[1], 4) if wilson[1] is not None else None,
            "elo_a_minus_b": round(elo, 1) if elo is not None else None,
            "elo_ci": [round(elo_low, 1) if elo_low is not None else None,
                       round(elo_high, 1) if elo_high is not None else None],
            "binomial_p_one_sided": (round(p_one, 5)
                                     if p_one is not None else None),
            "a_significantly_stronger_95": (bool(p_one is not None
                                                and p_one <= 0.05
                                                and winrate > 0.5)),
            "terminations": {},
            "double_pass_rate": (round(sum(1 for g in valid
                                           if g["termination"] == "double_pass")
                                       / len(valid), 3) if valid else None),
            "mean_moves": round(sum(len(g["moves"]) for g in valid) / len(valid), 1)
            if valid else None,
            "mean_game_wall_s": round(sum(g["wall_s"] for g in valid) / len(valid), 1)
            if valid else None,
            "total_wall_s": round(elapsed, 1),
            "engine_errors": self.engine_errors,
        }
        for g in valid:
            summary["terminations"][g["termination"]] = \
                summary["terminations"].get(g["termination"], 0) + 1
        if decided:
            summary["sprt"] = sprt_result(a_wins, b_wins, cfg.elo0, cfg.elo1,
                                          cfg.sprt_alpha, cfg.sprt_beta)
        else:
            summary["sprt"] = None
        summary["power_analysis"] = build_power_report(
            cfg.elo0, cfg.elo1, cfg.sprt_alpha, cfg.sprt_beta)
        return {
            "schema": "goai3-match/1",
            "generated": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
            "run_id": self.run_id,
            "harness": {"python": sys.version.split()[0],
                        "match_py": str(Path(__file__).resolve())},
            "config": cfg.as_dict(),
            "engines": self.engine_info,
            "estimate": plan,
            "summary": summary,
            "notes": self.notes,
            "interrupted": self.interrupted,
            "games": self.games,
        }

    # -- console summary ----------------------------------------------------
    def print_summary(self, result):
        s = result["summary"]
        print()
        print("=" * 78)
        print("MATCH RESULT  run=%s" % result["run_id"])
        print("  A: %s" % result["engines"]["a"]["fingerprint"]["path"])
        print("  B: %s" % result["engines"]["b"]["fingerprint"]["path"])
        print("  max-sims/thread=%d  threads=%d  komi=%g  max-moves=%d  games=%d"
              % (self.cfg.max_sims, self.cfg.threads, self.cfg.komi,
                 self.cfg.max_moves, self.cfg.games))
        print("  valid=%d  invalid=%d  A wins=%d  B wins=%d  draws=%d"
              % (s["games_valid"], s["games_invalid"], s["a_wins"],
                 s["b_wins"], s["draws"]))
        if s["a_winrate"] is not None:
            print("  A winrate = %.1f%%  (Wilson95 %.1f%% .. %.1f%%)"
                  % (s["a_winrate"] * 100, s["wilson95_low"] * 100,
                     s["wilson95_high"] * 100))
            print("  implied Elo A-B = %s  (95%% CI %s)"
                  % (_fmt(s["elo_a_minus_b"]), s["elo_ci"]))
            print("  one-sided binomial p(A>=%d | 50%%) = %s  -> %s"
                  % (s["a_wins"], _fmt(s["binomial_p_one_sided"]),
                     "A significantly stronger" if s["a_significantly_stronger_95"]
                     else "not significant yet"))
        print("  terminations=%s  mean moves=%s  mean game wall=%ss"
              % (s["terminations"], s["mean_moves"], s["mean_game_wall_s"]))
        if s.get("sprt"):
            sp = s["sprt"]
            print("  SPRT(elo0=%g, elo1=%g, a=%.2f, b=%.2f): LLR=%.3f "
                  "bounds=[%.3f, %.3f] -> %s"
                  % (sp["elo0"], sp["elo1"], sp["alpha"], sp["beta"],
                     sp["llr"], sp["lower_bound"], sp["upper_bound"],
                     sp["decision"]))
        pa = s.get("power_analysis")
        if pa:
            print("  games to detect a true winrate (exact binomial vs 50%, "
                  "80% power, one-sided alpha=0.05):")
            for row in pa["detect_winrate"]:
                print("    winrate %4.0f%% (~%+5.0f Elo): %s games%s"
                      % (row["winrate"] * 100, row["elo"],
                         row["games"] if row["games"] else ">3000",
                         "" if row["sided"] == "one-sided" else " (two-sided)"))
            print("  SPRT expected games (Monte-Carlo): %s"
                  % ", ".join("%.0f%% -> mean %.0f games, P(H1)=%.2f"
                              % (r["true_winrate"] * 100, r["mean_games"],
                                 r["p_h1_accept"])
                              for r in pa["sprt_monte_carlo"]))
        print("  total wall = %.1fs" % s["total_wall_s"])
        print("  json: %s" % result.get("_json_path", ""))
        if result["notes"]:
            print("  notes:")
            for note in result["notes"]:
                print("    - %s" % note)
        if s["engine_errors"]:
            print("  ENGINE PROBLEMS (see json .summary.engine_errors):")
            for err in s["engine_errors"]:
                print("    - %s" % json.dumps(err, ensure_ascii=False)[:300])
        print("=" * 78)


def _fmt(value, digits=3):
    if value is None:
        return "n/a"
    return ("%%.%df" % digits) % value


def _sgf_escape(text):
    return str(text).replace("\\", "\\\\").replace("]", "\\]")


# ----------------------------------------------------------------------------
# CLI
# ----------------------------------------------------------------------------

def build_parser():
    parser = argparse.ArgumentParser(
        description="GoAI3 A/B match driver (GTP, Chinese area scoring, "
                    "Wilson/SPRT statistics).",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__.split("Usage")[-1][:4000])
    parser.add_argument("--a", dest="a_exe", default=DEFAULT_A,
                        help="engine A executable (default %(default)s)")
    parser.add_argument("--b", dest="b_exe", default=DEFAULT_B,
                        help="engine B executable (default %(default)s)")
    parser.add_argument("--games", type=int, default=10,
                        help="number of games (default %(default)s)")
    parser.add_argument("--max-sims", type=int, default=16,
                        help="simulations per thread per move (default %(default)s); "
                             "total visits ~= threads*max_sims; wall ~= max_sims*fwd")
    parser.add_argument("--threads", type=int, default=2,
                        help="engine search threads (default %(default)s)")
    parser.add_argument("--komi", type=float, default=7.5,
                        help="komi used by both engines and the scorer")
    parser.add_argument("--max-moves", type=int, default=200,
                        help="score the position after this many plies if the "
                             "engine never passes twice (default %(default)s)")
    parser.add_argument("--seed", type=int, default=1,
                        help="recorded in the result and passed to the engines; "
                             "NOTE go_ai.cpp's GTP genmove overwrites the seed "
                             "with the wall clock, so games are not bit-exactly "
                             "reproducible (engine bug, documented)")
    parser.add_argument("--opening", action="append", default=[],
                        metavar="MOVES",
                        help='fixed opening, e.g. --opening "Q16 D4 Q4 D16" '
                             '(colours alternate B,W,...); repeatable')
    parser.add_argument("--opening-file", action="append", default=[],
                        metavar="FILE",
                        help="file with one opening per line (GTP coords)")
    parser.add_argument("--sgf-dir", action="append", default=[],
                        metavar="DIR",
                        help="use first moves of SGF files under DIR as openings "
                             "(e.g. build_out/sgf extracted from "
                             "kg/build/sgf/games.7z)")
    parser.add_argument("--sgf-limit", type=int, default=8,
                        help="max SGF files to load (default %(default)s)")
    parser.add_argument("--sgf-moves", type=int, default=8,
                        help="moves taken from each SGF (default %(default)s)")
    parser.add_argument("--shuffle-openings", action="store_true",
                        help="shuffle the opening list with --seed")
    parser.add_argument("--engine-args", default="",
                        help="extra args for BOTH engines (shlex string), "
                             'use --engine-args=--no-nn to avoid an argparse '
                             "value that starts with a dash")
    parser.add_argument("--a-args", default="",
                        help="extra args for engine A only (shlex string)")
    parser.add_argument("--b-args", default="",
                        help="extra args for engine B only (shlex string)")
    parser.add_argument("--no-nn", action="store_true",
                        help="add --no-nn to both engines (fast driver smoke test)")
    parser.add_argument("--no-calibrate", dest="calibrate", action="store_false",
                        help="skip the pre-flight empty-board genmove (saves a "
                             "search per engine, loses the forward-time measurement)")
    parser.add_argument("--fwd-est", type=float, default=1.1,
                        help="forward-pass seconds estimate when calibration is "
                             "off (default %(default)s on an idle machine)")
    parser.add_argument("--move-timeout", type=float, default=0.0,
                        help="per-genmove timeout in seconds (0 = derive from "
                             "max-sims and forward estimate)")
    parser.add_argument("--max-total-minutes", type=float, default=90.0,
                        help="refuse to start if the time estimate exceeds this "
                             "(0 disables; default %(default)s)")
    parser.add_argument("--force", action="store_true",
                        help="start even if the estimate exceeds the cap")
    parser.add_argument("--estimate-only", action="store_true",
                        help="start the engines, calibrate, print the time plan, "
                             "then exit without playing")
    parser.add_argument("--plan-only", action="store_true",
                        help="only print the statistics plan (no engines)")
    parser.add_argument("--out", dest="out_json", default="",
                        help="result JSON path (default "
                             "build_out/match/last_match.json)")
    parser.add_argument("--no-sgf", dest="sgf", action="store_false",
                        help="do not write SGF records")
    parser.add_argument("--json", action="store_true",
                        help="print the whole result JSON to stdout")
    parser.add_argument("--verbose", action="store_true")
    parser.add_argument("--quiet", action="store_true")
    parser.add_argument("--elo0", type=float, default=0.0)
    parser.add_argument("--elo1", type=float, default=20.0)
    return parser


def main(argv=None):
    parser = build_parser()
    args = parser.parse_args(argv)
    repo = Path.cwd()
    cfg = MatchConfig(
        repo=repo,
        a_exe=args.a_exe,
        b_exe=args.b_exe,
        games=args.games,
        max_sims=args.max_sims,
        threads=args.threads,
        komi=args.komi,
        max_moves=args.max_moves,
        seed=args.seed,
        a_extra_args=shlex.split(args.a_args),
        b_extra_args=shlex.split(args.b_args),
        engine_args=shlex.split(args.engine_args) + (["--no-nn"] if args.no_nn else []),
        move_timeout=args.move_timeout,
        calibrate=args.calibrate,
        fwd_est=args.fwd_est,
        out_json=args.out_json,
        sgf=args.sgf,
        verbose=args.verbose,
        quiet=args.quiet,
        max_total_minutes=args.max_total_minutes,
        force=args.force,
        estimate_only=args.estimate_only,
        elo0=args.elo0,
        elo1=args.elo1,
        plan_only=args.plan_only,
    )
    if cfg.plan_only:
        report = build_power_report(cfg.elo0, cfg.elo1)
        print(json.dumps(report, indent=2, ensure_ascii=False))
        print("\nRecommended games to prove a strength change:")
        print("  The exact-binomial numbers above are the honest answer: a true "
              "target winrate vs 50%.")
        print("  A +20 Elo improvement (52.9% winrate) needs ~1000+ games; +60 "
              "Elo (60%) needs ~200 games.")
        return 0
    # resolve openings before validating exes (cheap, catches config errors)
    cfg.openings = load_openings(argparse.Namespace(
        opening=args.opening, opening_file=args.opening_file,
        sgf_dir=args.sgf_dir, sgf_limit=args.sgf_limit,
        sgf_moves=args.sgf_moves, shuffle_openings=args.shuffle_openings,
        seed=args.seed))
    if not cfg.quiet:
        print("[match] %d opening(s), first has %d moves"
              % (len(cfg.openings), len(cfg.openings[0])))
    for exe in (cfg.a_exe, cfg.b_exe):
        if not (repo / exe).is_file() and not Path(exe).is_file():
            print("ERROR: engine executable not found: %s (cwd=%s)"
                  % (exe, repo), file=sys.stderr)
            return 2
    runner = MatchRunner(cfg)
    result = runner.run()
    if "error" in result:
        print("ERROR: match not started: %s" % result["error"], file=sys.stderr)
        if "estimated" in result:
            print(json.dumps(result["estimated"], indent=2), file=sys.stderr)
        return 3
    if "estimate" in result and "summary" not in result:
        # --estimate-only
        print(json.dumps(result["estimate"], indent=2))
        return 0
    if not cfg.quiet:
        runner.print_summary(result)
    if args.json:
        print(json.dumps(result, indent=2, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    sys.exit(main())
