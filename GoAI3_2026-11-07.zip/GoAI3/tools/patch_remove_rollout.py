# -*- coding: utf-8 -*-
"""go_ai.cpp 清理：删掉已经没人调用的随机模拟（rollout）整条链。

为什么可以安全删：叶子评估早就全部换成网络了（run_simulation 直接取 nn_v），
`rollout()` 的调用点是 0。它内部唯一的调用者链是

    rollout() -> tactical_move / atari_move / local_random_move / influence_winner
              -> rnd_int / rng_roll
    gen_candidates()   （旧的剪枝候选器，也只剩注释里提到）
    is_own_eye()       （只被 gen_candidates / local_random_move 使用）

删完后 is_own_eye 也变成死代码，一并删。`is_tiger_mouth` 保留（move_prior 还在用），
`move_prior` / `area_winner` / `PatternDB` 保留（无网络时的启发式先验、自对弈判定还要用）。

顺手把两处会误导人的注释改掉（它们还在提 rollout / gen_candidates）。
"""
import io
import sys

PATH = 'go_ai.cpp'


def find_func_end(lines, start, hint):
    """从 start 行往后找该函数体的结束行（第一行恰为 '}' 的行）。"""
    for j in range(start, len(lines)):
        if lines[j] == '}':
            return j
    raise SystemExit('找不到 %r 的函数结束行（从第 %d 行起）' % (hint, start + 1))


def find_line(lines, pred, start=0):
    for i in range(start, len(lines)):
        if pred(lines[i]):
            return i
    return -1


def main():
    raw = io.open(PATH, 'r', encoding='utf-8', newline='').read()
    text = raw.replace('\r\n', '\n')
    lines = text.split('\n')

    todo = []   # (start_idx, end_idx_inclusive) 要整段删除的行区间

    # 1) is_own_eye()
    s = find_line(lines, lambda l: l.startswith('inline bool is_own_eye(const Board& b, int idx, int color) {'))
    if s < 0:
        raise SystemExit('找不到 is_own_eye')
    e = find_func_end(lines, s, 'is_own_eye')
    todo.append((s, e + 1 if e + 1 < len(lines) and lines[e + 1] == '' else e))

    # 2) gen_candidates()
    s = find_line(lines, lambda l: l.startswith('void gen_candidates(const Board& b, std::vector<int>& out) {'))
    if s < 0:
        raise SystemExit('找不到 gen_candidates')
    e = find_func_end(lines, s, 'gen_candidates')
    todo.append((s, e + 1 if e + 1 < len(lines) and lines[e + 1] == '' else e))

    # 3) Rollout 整节：从它上面那行 '// ====' 开始，到 rollout() 的结束行
    r = find_line(lines, lambda l: l.strip() == '// Rollout')
    if r < 0:
        raise SystemExit('找不到 Rollout 小节标题')
    s = r - 1                     # 标题上方的 '// ====' 分隔线
    rs = find_line(lines, lambda l: l.startswith('int rollout(Board b, double komi, int max_moves,'))
    if rs < 0:
        raise SystemExit('找不到 rollout 定义')
    e = find_func_end(lines, rs, 'rollout')
    todo.append((s, e + 1 if e + 1 < len(lines) and lines[e + 1] == '' else e))

    todo.sort(reverse=True)
    for s, e in todo:
        print('删除第 %d..%d 行: %r' % (s + 1, e + 1, lines[s][:64]))
        del lines[s:e + 1]

    text = '\n'.join(lines)

    # 4) 改掉还会误导人的注释：enumerate_legal_moves 那段不再提 gen_candidates
    old_c = (
        '// Move enumeration (complete, unlike gen_candidates)\n'
        '//\n'
        '// gen_candidates() prunes to the 2-ring neighbourhood of existing stones: a\n'
        '// cheap move generator for random rollouts. A policy-guided search must not\n'
        '// inherit that pruning, because a single omitted legal move means the search\n'
        '// can never find a win by it. enumerate_legal_moves() instead visits all 361\n'
        '// points, so the network policy is the only thing that concentrates the\n'
        '// search. Own eyes are kept: they are legal, merely unlikely, and the priors\n'
        '// already give them almost no mass.\n'
    )
    new_c = (
        '// Move enumeration (complete)\n'
        '//\n'
        '// A policy-guided search must not prune the legal set: a single omitted legal\n'
        '// move means the search can never find a win by it. enumerate_legal_moves()\n'
        '// therefore visits all 361 points, so the network policy is the only thing\n'
        '// that concentrates the search. Own eyes are kept: they are legal, merely\n'
        '// unlikely, and the priors already give them almost no mass.\n'
    )
    if text.count(old_c) != 1:
        raise SystemExit('enumerate_legal_moves 的注释块没匹配上（%d 处）' % text.count(old_c))
    text = text.replace(old_c, new_c)

    # 5) 顶部那段说明 KataGo 接入范围的注释里还写着 rollout
    old_k = '// 分支，别的什么都不动 —— MCTS、rollout、prior 分配、GUI 全部沿用原逻辑。'
    new_k = '// 分支，别的什么都不动 —— MCTS、prior 分配、GUI 全部沿用原逻辑。'
    if text.count(old_k) != 1:
        raise SystemExit('顶部 kataGo 注释没匹配上')
    text = text.replace(old_k, new_k)

    out = text.replace('\r\n', '\n').replace('\n', '\r\n')
    io.open(PATH, 'w', encoding='utf-8', newline='').write(out)
    print('写回完成：%d 行, %d 字节' % (len(text.split('\n')), len(out)))
    return 0


if __name__ == '__main__':
    sys.exit(main())
