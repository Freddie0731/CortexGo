# -*- coding: utf-8 -*-
"""tools/export_for_github.py —— 把整个围棋 AI 项目整理成"可直接推到 GitHub"的目录 + zip

## 要解决什么问题

工作区里混着两类东西：
  1. 围棋 AI 本体：C++ 引擎、KataGo 推理栈、官方 PyTorch 模型定义、训练/评测脚本、
     云端脚本、AI Studio 包、文档；
  2. 与之无关的杂物：虚拟机/远程桌面脚本、aimy 安全测试工具、DSH 插件调试产物、
     构建中间产物、几十上百 MB 的权重/ONNX/数据集。

这个脚本只收 (1)，并额外做一个对 GitHub 友好的组织：
  * `docs/` 放文档（README 里给索引）；
  * 根目录 Python 脚本和 `_katago_src` 一起放进 `python/`（避免 GitHub 根目录堆几十个 `_kg_*.py`）；
  * `weights/` 只留 README 说明怎么下载，**不放二进制**（>100MB，用 GitHub Release 或网盘）；
  * 生成 `MANIFEST.txt` 列出每个文件与大小，方便核对。

## 输出

    export_github/GoAI3/          可直接 `git init` 或整目录拷进你的仓库
    export_github/GoAI3_<date>.zip

用法:
    python tools/export_for_github.py
    python tools/export_for_github.py --out D:\\tmp\\export      # 换输出目录
    python tools/export_for_github.py --with-dump                 # 额外带上 24MB 编码数据
"""
import argparse
import datetime
import os
import re
import shutil
import sys
import zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)

# ---------------------------------------------------------------- 收录清单
# 逐条写死，不做模糊匹配 —— 宁可漏，不可脏。（漏了会在报告里列出来提醒。）

# 1) 仓库原有、已在 git 里跟踪的文件（原样保留相对路径）
TRACKED_AS_IS = [
    '.gitattributes', '.gitignore', 'LICENSE', 'README.md',
    'GoAI3.vcxproj', 'GoAI3.vcxproj.filters',
    'go_ai.cpp',
    'kg/infer/board.h', 'kg/infer/encode.h', 'kg/infer/forward.h',
    'kg/infer/katago_backend.h', 'kg/infer/minigzip.h', 'kg/infer/model_load.h',
    'kg/infer/ops.h', 'kg/infer/ort_backend.h', 'kg/infer/refdata.h',
    'kg/infer/search.h', 'kg/infer/weights.h', 'kg/infer/README_ort.md',
    'kg/infer/ort/onnxruntime_c_api.h', 'kg/infer/ort/onnxruntime_ep_c_api.h',
    'kg/infer/ort/onnxruntime_float16.h',
    'kg/test/_kg_value_check.cpp', 'kg/test/bench_forward.cpp',
    'kg/test/dump_enc.cpp', 'kg/test/probe_encode.cpp', 'kg/test/test_forward.cpp',
    'kg/test/test_gzip.cpp', 'kg/test/test_ops.cpp', 'kg/test/test_parse.cpp',
    'kg/test/test_ort.cpp',
    '.github/workflows/build.yml',
]

# 2) 文档 -> docs/
DOCS = [
    'HANDOFF.md', 'KATAGO接入说明.md', '项目现状与操作指南.md',
    '自我对弈与学习方案.md', 'RELEASE_NOTES_v0.1.0.md', 'RELEASE_NOTES_v0.1.1.md',
    'tools/README_github.md', 'tools/README_match.md', 'tools/README_npu.md',
    'cloud/README_cloud.md', 'aistudio/AISTUDIO_README.md', 'aistudio/README_upload.md',
]

# 3) 根目录 Python（KataGo 权重解析 / 参考实现 / 自对弈训练管线）-> python/
ROOT_PY_MINUS = ['retouch_idphoto.py', '_transpose_check_tmp.py', '_probe_sources.py',
                 '_fetch_api.py', '_fetch_src.py', '_patch_cuda.py',
                 '_forensics_parse.js', 'vfix.pt']
ROOT_PY_DIRS = ['_katago_src']

# 4) tools/ 全部 .py/.ps1/.bat/.sh（都是围棋 AI 的构建/训练/评测工具）
# 5) cloud/ 全部；aistudio/ 的脚本（不含 upload/ 与旧的 kg.zip）
# 6) python/ 里的 debug 脚本（_kg_dbg_*）也收 —— 它们是排查过程的证据，体积很小


def _norm(p):
    return p.replace('\\', '/')


def collect(root, with_dump=False):
    """返回 [(源绝对路径, 目标相对路径), ...]"""
    items = []
    missing = []

    def add(src_rel, dst_rel=None):
        src = os.path.join(root, src_rel)
        if not os.path.isfile(src):
            missing.append(src_rel)
            return
        items.append((src, _norm(dst_rel or src_rel)))

    for rel in TRACKED_AS_IS:
        add(rel)
    for rel in DOCS:
        add(rel, 'docs/' + os.path.basename(rel))

    # 根目录 .py -> python/（排除杂物与大文件）
    for name in sorted(os.listdir(root)):
        full = os.path.join(root, name)
        if not os.path.isfile(full):
            continue
        if not name.endswith('.py'):
            continue
        if name in ROOT_PY_MINUS:
            continue
        if os.path.getsize(full) > 512 * 1024:      # 大文件大概率是数据，跳过
            continue
        items.append((full, 'python/' + name))
    add('tools/build.ps1', 'python/build.ps1')      # 老构建入口保留（指向 tools/）

    # _katago_src（官方 KataGo 源码，仅供对照，非本项目代码）
    for d in ROOT_PY_DIRS:
        dpath = os.path.join(root, d)
        if not os.path.isdir(dpath):
            missing.append(d + '/')
            continue
        for f in sorted(os.listdir(dpath)):
            if f.endswith(('.py', '.cpp', '.h')) and os.path.getsize(os.path.join(dpath, f)) < 2 * 1024 * 1024:
                items.append((os.path.join(dpath, f), 'third_party/katago_src/' + f))

    # tools/
    tdir = os.path.join(root, 'tools')
    for f in sorted(os.listdir(tdir)):
        full = os.path.join(tdir, f)
        if not os.path.isfile(full):
            continue
        if f.startswith('_probe_') or f.startswith('_diag_early'):
            continue
        if f.endswith(('.py', '.ps1', '.bat', '.sh', '.md')):
            items.append((full, 'tools/' + f))

    # cloud/
    cdir = os.path.join(root, 'cloud')
    for f in sorted(os.listdir(cdir)):
        full = os.path.join(cdir, f)
        if os.path.isfile(full) and not f.startswith('.'):
            items.append((full, 'cloud/' + f))

    # aistudio/（脚本 + 说明；不含 upload/ 里的 zip 和旧 kg.zip）
    adir = os.path.join(root, 'aistudio')
    for f in sorted(os.listdir(adir)):
        full = os.path.join(adir, f)
        if os.path.isfile(full) and f.endswith(('.py', '.sh', '.md')):
            items.append((full, 'aistudio/' + f))

    # 根目录的 .bat（中文名，保留）
    for f in sorted(os.listdir(root)):
        if f.endswith('.bat') and os.path.isfile(os.path.join(root, f)):
            items.append((os.path.join(root, f), 'bat/' + f))

    # 可选：编码数据集
    if with_dump:
        for rel in ['build_out/value/dump.bin', 'build_out/value/manifest.txt',
                    'build_out/value/selfcheck.bin']:
            add(rel, 'data/' + os.path.basename(rel))

    # 去重（同一目标只留一个）
    seen = {}
    out = []
    for src, dst in items:
        if dst in seen:
            continue
        seen[dst] = True
        out.append((src, dst))
    return out, missing


WEIGHTS_README = """# 权重文件说明

本目录**不放二进制权重**（单个 250MB，不适合进 git）。需要的文件按下面方式获取：

## 1. 引擎用的网络（`kata1.bin.gz`，约 250 MB）

这是本项目 C++ 引擎实际加载的 KataGo v17 网络
（`Model name: kata1-tf3-b11c768-s11003M-d5973M-7gres`，70.4M 参数）。

放到**仓库根目录**（与 `go_ai.cpp` 同级），引擎会自动按以下顺序查找：

```
kata1_value_fixed.bin.gz  ->  kata1.bin.gz  ->  nn_weights.bin.gz  ->  nn_weights.bin
```

获取方式（二选一）：

* **GitHub Releases**：把 `kata1.bin.gz` 作为 release asset 上传，然后
  `curl -L -o kata1.bin.gz <release-asset-url>`
* **官方 KataGo 网络**（等价、可直接用）：任何 **`-fs` 或 `-fson` 后缀**的 v15+ 网络都行，例如
  ```bash
  # 38MB 小网络，速度约为 70M 网络的 2.9 倍，每访问质量不输（空盘胜率与官方逐点一致）
  wget https://github.com/lightvector/KataGo/releases/download/v1.17.1/b10c384h6nbttflrs.bin.gz
  # 94MB 中等网络
  wget https://github.com/lightvector/KataGo/releases/download/v1.17.1/b10c512h8nbt3tflrs-fson-silu-rsnh.bin.gz
  ```
  > 命名规律：**只有 `-fs` / `-fson` 后缀才是 fixscale**，不带后缀的是 fixup（本引擎也支持，
  > 见 HANDOFF §10；但 `fson` 系列的末端是 batchnorm，务必选带 `-fson` 的版本）。

## 2. GPU 路径用的 ONNX（`kata1_b11.onnx`，约 279 MB）

由 `tools/export_onnx_fson.py` 从 `.bin.gz` 导出，**必须用 `-fson` 语义的图**，
否则 trunk 末端的 batchnorm 会被漏掉（这是本项目踩过的最深的一个坑，见 HANDOFF §10）。
导出后放在仓库根目录，引擎检测到 `onnxruntime.dll` 就自动走 DirectML GPU。

## 3. 训练用的编码数据集（`data/dump.bin`，约 24 MB）

16,680 个职业对局局面的 V7 编码 + 胜者标签，由 `kg/test/dump_enc.cpp` 生成。
仅在跑价值头训练时需要；`python tools/export_for_github.py --with-dump` 可以把
本地已有的那份一起打进来。
"""


def write_docs(dst_root, items):
    # 根 README 用专门写的版本（仓库原有那份写的是旧状态"棋力尚未验证"）
    # weights/README.md
    wdir = os.path.join(dst_root, 'weights')
    os.makedirs(wdir, exist_ok=True)
    with open(os.path.join(wdir, 'README.md'), 'w', encoding='utf-8', newline='\n') as f:
        f.write(WEIGHTS_README)

    total = sum(os.path.getsize(s) for s, _ in items)
    lines = ['# 导出清单（%s）' % datetime.date.today().isoformat(),
             '',
             '共 %d 个文件，%.2f MB（未压缩）' % (len(items), total / 1e6),
             '', '| 文件 | 字节 |', '|---|---:|']
    for src, dst in sorted(items, key=lambda x: x[1]):
        lines.append('| `%s` | %d |' % (dst, os.path.getsize(src)))
    # 放到 docs/ 下，不放根目录：这是产物清单，不该进 git
    with open(os.path.join(dst_root, 'docs', 'MANIFEST.txt'), 'w',
              encoding='utf-8', newline='\n') as f:
        f.write('\n'.join(lines) + '\n')
    return total


def zip_dir(src_dir, zip_path):
    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for base, _dirs, files in os.walk(src_dir):
            for f in files:
                full = os.path.join(base, f)
                arc = os.path.join(os.path.basename(src_dir), os.path.relpath(full, src_dir))
                z.write(full, _norm(arc))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--out', default=os.path.join(ROOT, 'export_github'))
    ap.add_argument('--with-dump', action='store_true')
    args = ap.parse_args()

    dst_root = os.path.join(args.out, 'GoAI3')
    if os.path.isdir(dst_root):
        shutil.rmtree(dst_root)
    os.makedirs(dst_root)

    items, missing = collect(ROOT, args.with_dump)
    copied = 0
    for src, dst in items:
        out = os.path.join(dst_root, dst.replace('/', os.sep))
        os.makedirs(os.path.dirname(out), exist_ok=True)
        shutil.copy2(src, out)
        copied += 1

    total = write_docs(dst_root, items)
    zip_path = os.path.join(args.out, 'GoAI3_%s.zip' % datetime.date.today().isoformat())
    zip_dir(dst_root, zip_path)

    print('导出目录 : %s' % dst_root)
    print('zip      : %s  (%.1f MB)' % (zip_path, os.path.getsize(zip_path) / 1e6))
    print('文件数   : %d   | 未压缩 %.2f MB' % (copied, total / 1e6))
    if missing:
        print('\n预期存在但没找到（不影响，列出来备忘）:')
        for m in missing:
            print('  -', m)
    print('\n下一步：')
    print('  cd %s' % dst_root)
    print('  git init && git add . && git commit -m "GoAI3: KataGo v17 engine + MCTS + training"')
    print('  git remote add origin <你的仓库地址> && git push -u origin main')
    return 0


if __name__ == '__main__':
    sys.exit(main())
