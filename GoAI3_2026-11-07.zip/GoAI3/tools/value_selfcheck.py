# -*- coding: utf-8 -*-
"""视角 / 对称性自检。

**先澄清一件事**（我第一次也差点写错）：KataGo 的输入是**行棋方视角规范化**的
（平面 1 = 行棋方的子、平面 2 = 对手的子、global[5] = 行棋方视角的贴目）。
因此"把棋盘黑白互换 + 把轮次也互换 + 贴目取负"之后，**编码出来的 22 个平面
应当逐位完全相同**，网络输出也应当完全相同 —— 不是取反!
（取反是"同一个棋盘、只把轮次换到对手"那种操作的结果，而那种编码在平面 1/2 上
本来就会互换，相当于把同一变换正着做一遍、反着做一遍。）

于是本脚本做两件事：
  [1] 规范化不变性：dump_enc --selfcheck-out 生成的成对局面，逐位比较 22 个平面，
      要求**完全一致**；同时比较网络 value，要求完全一致（差 < 1e-4）。
      这一条同时证明引擎编码器是严格的行棋方视角规范化。
  [2] 外部朝向锚点：真正判定"行棋方视角 vs 白方视角"必须用外部参照。这里用两个
      已知答案的局面（由 kg/test/dump_enc.cpp --orient-out 生成）：
        * 空盘、贴目 7.5、黑先：黑略吃亏（真实黑胜率约 47%）-> value 应为**小的负值**；
          若是白方视角，就会得到正的小值。
        * 黑领先约 76 目的畸形局面、黑先：value 应**接近 +1**（行棋方大优）。
      再配合训练侧：test 上"行棋方获胜"分类 accuracy 0.66 > 0.5，若价值头是白方
      视角，这个 accuracy 会掉到 0.34。

用法:
  python tools/value_selfcheck.py --weights build_out/value/kata1_value_fixed.bin.gz \
      --dump build_out/value/selfcheck.bin --orient build_out/value/orient.bin
"""
import os
import sys
import argparse

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import value_lib as V
from value_features import load_official_model, run_batch

try:
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
except Exception:
    pass


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--weights', required=True)
    ap.add_argument('--dump', default='build_out/value/selfcheck.bin')
    ap.add_argument('--orient', default='build_out/value/orient.bin')
    ap.add_argument('--threads', type=int, default=6)
    args = ap.parse_args()

    import torch
    torch.set_num_threads(args.threads)
    ok = True

    d = V.read_dump(args.dump)
    n = d['n']
    k = n // 2
    sp = V.planes_to_spatial(d['planes'])
    model, _ = load_official_model(args.weights, verbose=False)

    print('\n=== [1] 规范化不变性：黑白互换 + 轮次互换后，输入与输出都应完全相同 ===')
    print('    weights = %s' % args.weights)
    diff_planes = 0
    for i in range(k):
        diff_planes += int((sp[i] != sp[k + i]).sum())
    print('    22 个平面逐位比较：总共 %d 个元素不同（应为 0）' % diff_planes)
    g, val, pol = run_batch(model, sp, d['global'])
    wr = V.value_from_logits(val)
    print('     pair   ply  toMove(原->互换)  winrate(原)  winrate(互换)       差')
    for i in range(k):
        print('    %4d  %5d     %d -> %d        %+8.4f    %+8.4f   %+.2e'
              % (i, int(d['ply'][i]), int(d['toMove'][i]), int(d['toMove'][k + i]),
                 wr[i], wr[k + i], wr[k + i] - wr[i]))
    dmax = float(np.abs(wr[:k] - wr[k:]).max())
    print('    max|winrate(互换) - winrate(原)| = %.3e（应≈0）' % dmax)
    if diff_planes != 0 or dmax > 1e-4:
        print('    ==> FAIL：黑白互换后编码/输出不一致 —— 编码器不是严格的行棋方视角规范化')
        ok = False
    else:
        print('    ==> PASS：编码器是严格的行棋方视角规范化（互换黑白后输入逐位相同）')

    print('\n=== [2] 外部朝向锚点（判定"行棋方视角"还是"白方视角"）===')
    if not os.path.exists(args.orient):
        print('    (跳过：没有 %s —— 用 dump_enc --orient-out 生成)' % args.orient)
    else:
        o = V.read_dump(args.orient)
        spo = V.planes_to_spatial(o['planes'])
        g2, val2, _ = run_batch(model, spo, o['global'])
        wro = V.value_from_logits(val2)
        names = ['空盘 komi7.5 黑先', '空盘 komi7.5 白先',
                 '黑大优76目 黑先', '黑大优76目 白先']
        for i in range(o['n']):
            nm = names[i] if i < len(names) else ('case%d' % i)
            print('    %-20s toMove=%d  value=(%+.3f,%+.3f,%+.3f)  行棋方胜率=%+.4f'
                  % (nm, int(o['toMove'][i]), val2[i][0], val2[i][1], val2[i][2], wro[i]))
        if o['n'] >= 3:
            if not (-0.35 < wro[0] < 0.10):
                print('    ==> FAIL：空盘黑先的行棋方胜率 %+.4f 不像行棋方视角' % wro[0])
                ok = False
            else:
                print('    ==> 空盘黑先 %+.4f（真实约 -0.06：黑贴 7.5 略亏）✓ 行棋方视角'
                      % wro[0])
            if wro[2] < 0.5:
                print('    ==> FAIL：黑大优且黑先时 value = %+.4f，方向错了' % wro[2])
                ok = False
            else:
                print('    ==> 黑大优且黑先 %+.4f（应为强正值）✓' % wro[2])

    print('\n==> 视角/对称性自检 %s' % ('PASS' if ok else 'FAIL'))
    if not ok:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
