# -*- coding: utf-8 -*-
"""Export the official KataGo v17 network (b11c768h12nbt3tflrs-fs-silu) to ONNX.

Why legacy exporter: the dynamo exporter needs onnxscript/onnx_ir, and this box has
no general internet (only plain-HTTP package mirrors), so `torch.onnx.export(dynamo=False)`
with the TorchScript exporter is the lowest-dependency path.  The `onnx` package is
still required (torch's legacy exporter imports it).

The exporter needs an export-friendly attention: KataGo's transformer blocks call
`torch.nn.functional.scaled_dot_product_attention`, whose ONNX symbolics vary by
torch version, so we patch it to plain MatMul+Softmax+MatMul during export.

Usage:
  python tools/export_onnx.py --weights kata1.bin.gz --out build_out/npu/models
  python tools/export_onnx.py --weights kata1.bin.gz --out build_out/npu/models --dynamic-batch
"""
import argparse
import json
import os
import sys

REPO = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, REPO)

os.environ.setdefault("OMP_NUM_THREADS", "4")
os.environ.setdefault("MKL_NUM_THREADS", "4")
os.environ.setdefault("TORCHDYNAMO_DISABLE", "1")
os.environ.setdefault("TORCH_COMPILE_DISABLE", "1")
os.environ.setdefault("TORCHINDUCTOR_DISABLE", "1")
# must be set BEFORE importing model_pytorch: flex_attention uses a custom
# score_mod + HOP that cannot be traced by torch.onnx and needs torch.compile.
os.environ["KATAGO_FLEX_ATTENTION"] = "0"

import numpy as np  # noqa: E402
import torch  # noqa: E402
import torch.nn.functional as F  # noqa: E402

import _katago_v17_load as L  # noqa: E402
from _kg_ref import build_state_dict  # noqa: E402
from _katago_official import load_official  # noqa: E402

OUT_NAMES = ["policy", "value", "miscvalue", "moremiscvalue", "ownership",
             "scoring", "futurepos", "seki", "scorebelief"]
CFG_NAME = "b11c768h12nbt3tflrs-fs-silu"


def flatten_tensors(res, acc=None):
    if acc is None:
        acc = []
    if torch.is_tensor(res):
        acc.append(res)
    elif isinstance(res, (tuple, list)):
        for x in res:
            flatten_tensors(x, acc)
    elif isinstance(res, dict):
        for k in sorted(res):
            flatten_tensors(res[k], acc)
    return acc


class Wrapper(torch.nn.Module):
    """(spatial, global) -> flat tuple of outputs, traceable."""

    def __init__(self, model):
        super().__init__()
        self.model = model
        self.seq = bool(getattr(model, "transformer_seq_layout", False))
        try:
            self.model.disable_fused_attention_kernels()
        except Exception as e:  # noqa
            print("  warn: disable_fused_attention_kernels:", e)

    def forward(self, spatial, glob):
        if self.seq:
            res = self.model._forward_per_block_units(spatial, glob)
        else:
            mask = torch.ones((spatial.shape[0], 1, spatial.shape[2], spatial.shape[3]),
                              dtype=torch.float32)
            res = self.model(spatial, glob, mask)
        return tuple(flatten_tensors(res))


def patch_rmsnorm():
    """torch.nn.RMSNorm lowers to aten::rms_norm, which the TorchScript ONNX exporter
    does not know before opset 23.  Rewrite it as rsqrt(mean(x^2)) * x * weight, which
    exports as standard ReduceMean/Pow/Rsqrt/Mul."""
    def forward(self, x):
        nd = len(tuple(self.normalized_shape))
        dims = tuple(range(-nd, 0))
        v = x.pow(2).mean(dim=dims, keepdim=True)
        out = x * torch.rsqrt(v + self.eps)
        w = getattr(self, "weight", None)
        if w is not None:
            out = out * w
        return out

    torch.nn.RMSNorm.forward = forward
    print("  patched torch.nn.RMSNorm.forward for ONNX export")


def patch_sdpa():
    """Replace fused SDPA with plain ops that the TorchScript ONNX exporter handles."""

    def sdpa(q, k, v, attn_mask=None, dropout_p=0.0, is_causal=False,
             scale=None, enable_gqa=False, **kw):
        s = scale if scale is not None else q.shape[-1] ** -0.5
        logits = torch.matmul(q, k.transpose(-2, -1)) * s
        if attn_mask is not None:
            if attn_mask.dtype == torch.bool:
                logits = logits.masked_fill(~attn_mask, float("-inf"))
            else:
                logits = logits + attn_mask
        attn = torch.softmax(logits, dim=-1)
        return torch.matmul(attn, v)

    F.scaled_dot_product_attention = sdpa


def build_model(weights, threads=4):
    torch.set_num_threads(threads)
    M = L.load(weights, verbose=False)
    Model, mc = load_official()
    cfg = mc.config_of_name[CFG_NAME]  # -silu variant is mandatory for this checkpoint
    model = Model(cfg, 19).eval()
    model.initialize()
    sd = build_state_dict(M)
    ref = model.state_dict()
    target = {}
    for k, v in ref.items():
        if k in sd:
            a = np.array(sd[k], dtype=np.float32, copy=True, order="C")
            if tuple(a.shape) == tuple(v.shape):
                target[k] = torch.from_numpy(a).clone()
    missing = model.load_state_dict(target, strict=False)
    print("model: %s  activation=%s  tensor loaded=%d/%d  missing=%d" %
          (CFG_NAME, model.activation, len(target), len(ref), len(missing[0])))
    return model


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--weights", default=os.path.join(REPO, "kata1.bin.gz"))
    ap.add_argument("--out", default=os.path.join(REPO, "build_out", "npu", "models"))
    ap.add_argument("--batch", type=int, default=1, help="static batch size")
    ap.add_argument("--dynamic-batch", action="store_true")
    ap.add_argument("--opset", type=int, default=17)
    ap.add_argument("--seed", type=int, default=1234)
    ap.add_argument("--threads", type=int, default=4)
    args = ap.parse_args()
    os.makedirs(args.out, exist_ok=True)

    patch_rmsnorm()
    patch_sdpa()
    model = build_model(args.weights, args.threads)
    w = Wrapper(model).eval()

    rng = np.random.RandomState(args.seed)
    B = args.batch
    sp = (rng.randn(B, 22, 19, 19).astype(np.float32) * 0.5)
    sp[:, 0, :, :] = 1.0  # plane 0 is the legal-move / board mask
    gl = (rng.randn(B, 19).astype(np.float32) * 0.5)
    spatial = torch.from_numpy(sp)
    glob = torch.from_numpy(gl)

    out_path = os.path.join(args.out, "kata1_b11_b%d.onnx" % B)
    dyn = None
    if args.dynamic_batch:
        dyn = {"spatial": {0: "batch"}, "global": {0: "batch"}}
        for nm in OUT_NAMES:
            dyn[nm] = {0: "batch"}
    print("exporting ->", out_path, flush=True)
    torch.onnx.export(
        w, (spatial, glob), out_path,
        input_names=["spatial", "global"],
        output_names=OUT_NAMES,
        opset_version=args.opset,
        dynamo=False,
        do_constant_folding=True,
        dynamic_axes=dyn,
    )
    print("wrote %.1f MB" % (os.path.getsize(out_path) / 1e6), flush=True)

    # reference outputs from the same PyTorch forward, for numeric comparison later
    with torch.no_grad():
        ref = w(spatial, glob)
    np.savez(os.path.join(args.out, "ref_b%d.npz" % B),
             spatial=sp, global_=gl,
             **{OUT_NAMES[i]: t.numpy() for i, t in enumerate(ref)})

    meta = {"cfg": CFG_NAME, "batch": B, "opset": args.opset,
            "dynamic_batch": args.dynamic_batch,
            "inputs": {"spatial": list(sp.shape), "global": list(gl.shape)},
            "outputs": {OUT_NAMES[i]: list(t.shape) for i, t in enumerate(ref)},
            "onnx_bytes": os.path.getsize(out_path)}
    with open(os.path.join(args.out, "meta_b%d.json" % B), "w", encoding="utf-8") as f:
        json.dump(meta, f, indent=2)
    print("ok")
    return 0


if __name__ == "__main__":
    sys.exit(main())
