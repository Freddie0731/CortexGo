# -*- coding: utf-8 -*-
"""修掉 patch_loader.py 第 4 条补丁在字符串字面量里留下的裸换行。

补丁里误写成 `"..."\\n"`（转义反斜杠 + n），C++ 看到的是 `"\n"` 之前还有一个
字符串结束引号之外的裸换行。这里按行号相邻的两行整段替换成正确的两行。
"""
import io
import sys

PATH = 'go_ai.cpp'

BROKEN = ('            << "  前向约 1 秒/次（14 线程 CPU）：根节点做 8 对称平均，\\n"\n'
          '            << "  深层叶子只评 1 次（--root-symmetries N 可调）。\\n"')

FIXED = ('            << "  前向约 1 秒/次（14 线程 CPU）：根节点做 8 对称平均，\\n"\n'
         '            << "  深层叶子只评 1 次（--root-symmetries N 可调）。\\n"')


def main():
    raw = io.open(PATH, 'r', encoding='utf-8', newline='').read()
    text = raw.replace('\r\n', '\n')
    # 实际损坏形态：第一行末尾是 `，"\\n"`（引号内的 \\ 被当成长度 1 的反斜杠 + 字符 n）
    bad_line = '            << "  前向约 1 秒/次（14 线程 CPU）：根节点做 8 对称平均，"\\n"'
    good_line = '            << "  前向约 1 秒/次（14 线程 CPU）：根节点做 8 对称平均，\\n"'
    n = text.count(bad_line)
    print('损坏行出现次数: %d' % n)
    if n != 1:
        raise SystemExit('未找到预期损坏行，停止')
    text = text.replace(bad_line, good_line)
    out = text.replace('\r\n', '\n').replace('\n', '\r\n')
    io.open(PATH, 'w', encoding='utf-8', newline='').write(out)
    print('修复完成')
    return 0


if __name__ == '__main__':
    sys.exit(main())
