# -*- coding: utf-8 -*-
"""go_ai.cpp 第四批补丁：GTP 协议的 4 个真实 bug（由 eval-harness 的 GTP 探针发现）。

1. genmove 忽略颜色参数：空盘 `genmove w` 会给黑方生成并落子，客户端与引擎棋盘错乱。
2. --seed 在 --cli 下无效，且 genmove 每手用时钟覆盖 seed → 对局不可复现，
   直接导致 A/B 对局驱动无法靠 seed 复现。
3. 错误应答用 "=" 而不是 "?"，客户端无法按 GTP 规范判断成功/失败。
4. `komi` 缺参时读取未初始化 double（UB），且不报错。
另外顺手修掉：genmove 出的着法若非法（引擎内部 bug），原来会静默改走 pass 却仍返回
原坐标，现在改为报错并保持棋盘同步。
"""
import io
import sys

PATH = 'go_ai.cpp'

EDITS = [
    # ---- 1) 每个命令带一个错误标志 ----
    (
        '        std::string resp;\n'
        '        if (cmd == "protocol_version") resp = "2";',
        '        std::string resp;\n'
        '        bool is_error = false;\n'
        '        if (cmd == "protocol_version") resp = "2";'
    ),
    # ---- 2) komi 未初始化读 ----
    (
        '        else if (cmd == "komi") { double k; iss >> k; komi = k; }',
        '        else if (cmd == "komi") {\n'
        '            // Never read an uninitialised double: the old `double k; iss >> k;\n'
        '            // komi = k;` left komi holding whatever was on the stack when the\n'
        '            // argument was missing, silently corrupting every later score.\n'
        '            double k = 0.0;\n'
        '            if (iss >> k) komi = k;\n'
        '            else { resp = "syntax error"; is_error = true; }\n'
        '        }'
    ),
    # ---- 3) play: 坐标错误与轮次错误都标成 error ----
    (
        '            if (idx < -1) resp = "invalid coordinate";\n'
        '            else if (board.to_move != want) {',
        '            if (idx < -1) { resp = "invalid coordinate"; is_error = true; }\n'
        '            else if (board.to_move != want) {'
    ),
    (
        '                resp = "illegal move";\n'
        '            }\n'
        '            else if (idx == PASS) {',
        '                resp = "illegal move: it is "\n'
        '                    + std::string(board.to_move == BLACK ? "black" : "white")\n'
        '                    + " to move";\n'
        '                is_error = true;\n'
        '            }\n'
        '            else if (idx == PASS) {'
    ),
    # ---- 4) genmove：颜色校验 + 确定性 seed + 非法着法不再静默改 pass ----
    (
        '        else if (cmd == "genmove") {\n'
        '            std::string color; iss >> color;\n'
        '            SearchParams gp = sp;\n'
        '            gp.game_history = &hist;\n'
        '            gp.seed = (uint64_t)std::chrono::steady_clock::now()\n'
        '                .time_since_epoch().count();\n'
        '            SearchResult r = mcts_search(board, komi, gp);\n'
        '            if (r.move == PASS) { push_snapshot(hist, board); play_move(board, PASS); }\n'
        '            else {\n'
        '                push_snapshot(hist, board);\n'
        '                if (!play_move(board, r.move)) play_move(board, PASS);\n'
        '            }\n'
        '            resp = coord_to_gtp(r.move);',
        '        else if (cmd == "genmove") {\n'
        '            std::string color; iss >> color;\n'
        '            // The colour is part of the command. Generating a move for the\n'
        '            // other side and playing it puts a stone of the wrong colour on\n'
        '            // the board and desynchronises the client, so a mismatch is a\n'
        '            // client error rather than something to paper over.\n'
        '            int want = board.to_move;\n'
        '            if (!color.empty() && (color[0] == \'b\' || color[0] == \'B\')) want = BLACK;\n'
        '            else if (!color.empty() && (color[0] == \'w\' || color[0] == \'W\')) want = WHITE;\n'
        '            if (want != board.to_move) {\n'
        '                resp = "illegal move: it is "\n'
        '                    + std::string(board.to_move == BLACK ? "black" : "white")\n'
        '                    + " to move";\n'
        '                is_error = true;\n'
        '            }\n'
        '            else {\n'
        '            SearchParams gp = sp;\n'
        '            gp.game_history = &hist;\n'
        '            // Deterministic in --seed: seeding from the clock here made every\n'
        '            // A/B game irreproducible even when --seed was passed.\n'
        '            gp.seed = sp.seed ^ (uint64_t)(0x9E3779B97F4A7C15ULL\n'
        '                * (uint64_t)(hist.size() + 1));\n'
        '            SearchResult r = mcts_search(board, komi, gp);\n'
        '            push_snapshot(hist, board);\n'
        '            if (r.move != PASS && !play_move(board, r.move)) {\n'
        '                // Would leave the client and the engine on different boards.\n'
        '                resp = "internal error: generated an illegal move";\n'
        '                is_error = true;\n'
        '            }\n'
        '            else {\n'
        '                if (r.move == PASS) play_move(board, PASS);\n'
        '                resp = coord_to_gtp(r.move);'
    ),
    # ---- 5) genmove 尾部补上闭合大括号 ----
    (
        '                r.nn_used ? "" : " no-nn");\n'
        '            resp += info;\n'
        '        }\n'
        '        else if (cmd == "quit")',
        '                r.nn_used ? "" : " no-nn");\n'
        '            resp += info;\n'
        '            }\n'
        '            }\n'
        '        }\n'
        '        else if (cmd == "quit")'
    ),
    # ---- 6) unknown command 也是错误 ----
    (
        '        else resp = "unknown command";',
        '        else { resp = "unknown command"; is_error = true; }'
    ),
    # ---- 7) 应答前缀按错误标志选 ? 还是 = ----
    (
        '        if (!id.empty()) std::cout << "=" << id << " ";\n'
        '        else std::cout << "= ";\n'
        '        std::cout << resp << "\\n\\n" << std::flush;',
        '        // GTP reply grammar: "=" followed by an optional id on success,\n'
        '        // "?" followed by an optional id on failure. Clients rely on the\n'
        '        // first character, so every error path has to set is_error.\n'
        '        std::cout << (is_error ? "?" : "=");\n'
        '        if (!id.empty()) std::cout << id;\n'
        '        std::cout << " " << resp << "\\n\\n" << std::flush;'
    ),
    # ---- 8) 顶层 --seed 对 --cli 也生效 ----
    (
        '        else if (a == "--max-sims" && i + 1 < argc) sp.max_sims = std::stoll(argv[++i]);',
        '        else if (a == "--max-sims" && i + 1 < argc) sp.max_sims = std::stoll(argv[++i]);\n'
        '        // --seed also has to work for --cli, otherwise an A/B match cannot be\n'
        '        // replayed even with a fixed seed.\n'
        '        else if (a == "--seed" && i + 1 < argc) sp.seed = (uint64_t)std::stoll(argv[++i]);'
    ),
]


def main():
    raw = io.open(PATH, 'r', encoding='utf-8', newline='').read()
    text = raw.replace('\r\n', '\n')
    bad = []
    for i, (old, new) in enumerate(EDITS):
        c = text.count(old)
        if c != 1:
            bad.append((i + 1, c, old.split('\n')[0][:60]))
            continue
        text = text.replace(old, new)
        print('[ok] patch %d' % (i + 1))
    if bad:
        for b in bad:
            print('[FAIL] patch %d count=%d : %s' % b)
        raise SystemExit('有补丁没打上，文件未写回')
    out = text.replace('\r\n', '\n').replace('\n', '\r\n')
    io.open(PATH, 'w', encoding='utf-8', newline='').write(out)
    print('写回完成，%d 字节' % len(out))
    return 0


if __name__ == '__main__':
    sys.exit(main())
