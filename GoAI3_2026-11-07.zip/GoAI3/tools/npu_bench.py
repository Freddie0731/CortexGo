# -*- coding: utf-8 -*-
"""Benchmark the exported KataGo v17 network on CPU / GPU / NPU.

Three backends, same measurement protocol:

  openvino          pip OpenVINO (2026.x).  Works for CPU and GPU.  Its NPU plugin
                    can COMPILE but cannot create an infer request on this machine
                    (NPU driver 32.0.100.3104 is older than the plugin expects).
  openvino-ctypes   the OpenVINO 2024.1 runtime bundled with the Xiaomi MiService
                    driver package.  This is the one that can actually run on the
                    Intel NPU -- via the C API through ctypes, so no pip packages are
                    needed at runtime.  Loads IR (.xml).
  onnxruntime       ORT; the DirectML EP is the working GPU path on this box
                    (providers: DmlExecutionProvider, CPUExecutionProvider).

Protocol:
  * inputs: one fixed random-but-legal 19x19 board (input plane 0 = all ones).
    batch=K repeats it K times; for the NPU the useful knob is N concurrent batch-1
    requests (--streams), because the 2024.1 NPU compiler refuses this network at
    batch=8 ("Got non broadcastable dimensions pair: '6144' and 8'").
  * latency: warmup + measured iterations, median.
  * throughput: leaves/s = batch or streams * 361 / median_ms * 1000.
  * accuracy: output vs the PyTorch fp32 reference (ref_b1.npz written by
    tools/export_onnx.py): policy max |logprob diff|, top-1 move match,
    value/ownership max |diff|.

Usage (PYTHONPATH must contain build_out\\npu\\py and build_out\\npu):
  python tools/npu_bench.py --backend openvino-ctypes \\
      --ir build_out/npu/models/kata1_b11_b1.xml \\
      --ref build_out/npu/models/ref_b1.npz --streams 1 2 4
  python tools/npu_bench.py --backend onnxruntime \\
      --onnx build_out/npu/models/kata1_b11_b1.onnx \\
      --ref build_out/npu/models/ref_b1.npz --device DmlExecutionProvider --batches 1
  python tools/npu_bench.py --backend openvino \\
      --onnx build_out/npu/models/kata1_b11_b1.onnx --device CPU --batches 1
"""
import argparse
import json
import os
import sys
import time

import numpy as np

OUT_NAMES = ["policy", "value", "miscvalue", "moremiscvalue", "ownership",
             "scoring", "futurepos", "seki", "scorebelief"]
POS = 19 * 19
POS_AND_PASS = POS + 1
HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
NPU_DIR = os.path.join(ROOT, "build_out", "npu")


# ---------------------------------------------------------------- shared helpers
def load_ref(npz_path):
    d = np.load(npz_path)
    return d["spatial"], d["global_"], {k: d[k] for k in OUT_NAMES if k in d}


def make_batch(sp, gl, n):
    """n copies of the same board (the reference npz may be batch 1 or n)."""
    if sp.shape[0] == n:
        return sp.astype(np.float32), gl.astype(np.float32)
    if sp.shape[0] > n:
        return sp[:n].astype(np.float32), gl[:n].astype(np.float32)
    return (np.repeat(sp[:1], n, axis=0).astype(np.float32),
            np.repeat(gl[:1], n, axis=0).astype(np.float32))


def compare(out_by_name, ref):
    rows = []
    pol, rpol = out_by_name.get("policy"), ref.get("policy")
    if pol is not None and rpol is not None:
        pol, rpol = np.asarray(pol), np.asarray(rpol)
        if pol.ndim == 3 and rpol.ndim == 3:
            d = float(np.max(np.abs(pol - rpol)))
            p0, r0 = pol[0, 0, :POS_AND_PASS], rpol[0, 0, :POS_AND_PASS]
            t1, rt1 = int(np.argmax(p0)), int(np.argmax(r0))

            def to_prob(x):
                e = np.exp(x - x.max())
                return e / e.sum()
            rows.append(("policy max|logp d|", "%.5f" % d))
            rows.append(("policy top1 move", "%d %s" % (t1, "MATCH" if t1 == rt1
                                                        else "DIFF(ref=%d)" % rt1)))
            rows.append(("policy prob max|d|",
                         "%.6f" % float(np.max(np.abs(to_prob(p0) - to_prob(r0))))))
    for nm in ("value", "ownership", "scorebelief", "miscvalue", "moremiscvalue"):
        a, r = out_by_name.get(nm), ref.get(nm)
        if a is None or r is None:
            continue
        a, r = np.asarray(a), np.asarray(r)
        if a.shape != r.shape:
            continue
        rows.append(("%s max|d|" % nm, "%.5f" % float(np.max(np.abs(a - r)))))
    return rows


def print_table(title, results):
    print("\n" + "=" * 84)
    print(title)
    print("=" * 84)
    hdr = "%-30s %8s %10s %10s %10s" % ("device / ep", "batch", "ms/fwd", "leaves/s", "compile s")
    print(hdr)
    print("-" * len(hdr))
    for r in results:
        print("%-30s %8d %10.1f %10.0f %10.1f" %
              (r["device"], r["batch"], r["ms"], r["pos_per_s"], r.get("compile_s", 0)))
    print()


# ---------------------------------------------------------------- OpenVINO (pip)
def bench_openvino(args, sp, gl, ref):
    import openvino as ov
    core = ov.Core()
    print("openvino:", ov.__version__)
    print("available_devices:", list(core.available_devices))
    results = []
    for dev in args.device:
        for batch in args.batches:
            m = core.read_model(args.onnx)
            try:
                m.reshape({"spatial": [batch, 22, 19, 19], "global": [batch, 19]})
            except Exception as e:  # noqa
                print("  reshape to batch=%d not possible on this graph: %s"
                      % (batch, str(e).splitlines()[0]))
                continue
            cfg = {}
            if dev.upper().startswith("NPU"):
                cfg["INFERENCE_PRECISION_HINT"] = args.npu_precision
            t0 = time.perf_counter()
            try:
                cm = core.compile_model(m, dev, cfg)
            except Exception as e:  # noqa
                print("  compile %s batch=%d FAILED: %s"
                      % (dev, batch, str(e).strip().splitlines()[-1][:200]))
                continue
            ct = time.perf_counter() - t0
            print("  compiled %-4s batch=%d in %.1fs" % (dev, batch, ct), flush=True)
            try:
                req = cm.create_infer_request()
            except Exception as e:  # noqa
                print("  %s: cannot create infer request (%s)"
                      % (dev, str(e).splitlines()[-1][:160]))
                print("  -> the bundled OpenVINO 2024.1 runtime CAN run the NPU: "
                      "use --backend openvino-ctypes")
                continue
            spb, glb = make_batch(sp, gl, batch)
            ins = cm.inputs
            names = [ins[0].get_any_name(), ins[1].get_any_name()]
            outs = [o.get_any_name() for o in cm.outputs]

            def run():
                req.set_tensor(names[0], spb)
                req.set_tensor(names[1], glb)
                req.infer()

            for _ in range(args.warmup):
                run()
            ts = []
            for _ in range(args.iters):
                t0 = time.perf_counter()
                run()
                ts.append((time.perf_counter() - t0) * 1000.0)
            ts.sort()
            med = ts[len(ts) // 2]
            results.append({"device": "%s b%d" % (dev, batch), "batch": batch, "ms": med,
                            "pos_per_s": batch * POS / med * 1000.0, "compile_s": ct})
            if batch == 1:
                out = {}
                for i, nm in enumerate(OUT_NAMES):
                    if i < len(outs):
                        out[nm] = req.get_tensor(outs[i]).data
                print("  accuracy vs PyTorch fp32:")
                for k, v in compare(out, ref):
                    print("    %-22s %s" % (k, v))
    return results


# ---------------------------------------------------------------- OpenVINO 2024.1 ctypes
def bench_ctypes(args, sp, gl, ref):
    if not args.ir:
        print("--ir is required for the ctypes backend (IR produced by "
              "build_out/npu/make_ir.py)")
        return []
    sys.path.insert(0, NPU_DIR)
    import ov_c  # noqa
    o = ov_c.OpenVinoC()
    core = o.core()
    print("OpenVINO 2024.1 (MiService bundle) devices:", o.available_devices(core))
    model = o.read_model(core, args.ir)
    t0 = time.perf_counter()
    cm = o.compile_model(core, model, args.ctypes_device)
    ct = time.perf_counter() - t0
    ins, outs = o.compiled_io(cm)
    print("compiled %s in %.1fs  inputs=%s  outputs=%d"
          % (args.ctypes_device, ct, [i[:3] for i in ins], len(outs)), flush=True)

    res = o.infer(cm, [sp[:1], gl[:1]], n_outputs=len(outs))
    by_name = dict((outs[j][0], res[j]) for j in range(len(outs)))
    print("accuracy vs PyTorch fp32:")
    for k, v in compare(by_name, ref):
        print("    %-22s %s" % (k, v))

    def bench_streams(k, iters, warmup):
        import ctypes
        reqs, tens = [], []
        for _ in range(k):
            req = ctypes.c_void_p()
            o.check(o.ov_compiled_model_create_infer_request(cm, ctypes.byref(req)),
                    "create_infer_request")
            ts = []
            for arr in (sp[:1], gl[:1]):
                t, keep = o._make_input_tensor(arr)
                ts.append(t)
            for i, t in enumerate(ts):
                o.check(o.ov_infer_request_set_input_tensor_by_index(req, i, t), "set_input")
            reqs.append(req)
            tens.append(ts)
        try:
            def run_all():
                for r in reqs:
                    o.check(o.ov_infer_request_start_async(r), "start_async")
                for r in reqs:
                    o.check(o.ov_infer_request_wait(r), "wait")
            for _ in range(warmup):
                run_all()
            ts = []
            for _ in range(iters):
                t0 = time.perf_counter()
                run_all()
                ts.append((time.perf_counter() - t0) * 1000.0)
            ts.sort()
            return ts[len(ts) // 2]
        finally:
            for r in reqs:
                o.ov_infer_request_free(r)
            for ts_ in tens:
                for t in ts_:
                    o.ov_tensor_free(t)

    results = []
    for k in args.streams:
        med = bench_streams(k, args.iters, args.warmup)
        results.append({"device": "%s x%d streams" % (args.ctypes_device, k), "batch": k,
                        "ms": med, "pos_per_s": k * POS / med * 1000.0, "compile_s": ct})
        print("  %s streams=%d wall %.1f ms  per-request %.1f ms"
              % (args.ctypes_device, k, med, med / k), flush=True)
    return results


# ---------------------------------------------------------------- ONNX Runtime
def bench_ort(args, sp, gl, ref):
    import onnxruntime as ort
    print("onnxruntime:", ort.__version__)
    print("ORT available providers:", ort.get_available_providers())
    results = []
    for dev in args.device:
        for batch in args.batches:
            so = ort.SessionOptions()
            so.intra_op_num_threads = args.threads
            so.inter_op_num_threads = 1
            so.graph_optimization_level = ort.GraphOptimizationLevel.ORT_ENABLE_ALL
            providers = [dev] if dev == "CPUExecutionProvider" else [dev, "CPUExecutionProvider"]
            t0 = time.perf_counter()
            try:
                sess = ort.InferenceSession(args.onnx, sess_options=so, providers=providers)
            except Exception as e:  # noqa
                print("  session %s FAILED: %s" % (dev, str(e).splitlines()[-1][:200]))
                continue
            ct = time.perf_counter() - t0
            print("  session %-24s batch=%d create %.1fs" % (dev, batch, ct), flush=True)
            in_names = [i.name for i in sess.get_inputs()]
            spb, glb = make_batch(sp, gl, batch)
            feed = {in_names[0]: spb, in_names[1]: glb}
            for _ in range(args.warmup):
                sess.run(None, feed)
            ts = []
            for _ in range(args.iters):
                t0 = time.perf_counter()
                res = sess.run(None, feed)
                ts.append((time.perf_counter() - t0) * 1000.0)
            ts.sort()
            med = ts[len(ts) // 2]
            results.append({"device": "%s b%d" % (dev, batch), "batch": batch, "ms": med,
                            "pos_per_s": batch * POS / med * 1000.0, "compile_s": ct})
            if batch == 1:
                names = [o.name for o in sess.get_outputs()]
                out = {}
                for i, nm in enumerate(names):
                    if i < len(res):
                        out[nm] = res[i]
                print("  accuracy vs PyTorch fp32:")
                for k, v in compare(out, ref):
                    print("    %-22s %s" % (k, v))
    return results


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--backend", choices=["openvino", "openvino-ctypes", "onnxruntime"],
                    default="openvino-ctypes")
    ap.add_argument("--onnx", default=os.path.join(NPU_DIR, "models", "kata1_b11_b1.onnx"))
    ap.add_argument("--ir", default=os.path.join(NPU_DIR, "models", "kata1_b11_b1.xml"))
    ap.add_argument("--ref", default=None)
    ap.add_argument("--device", nargs="+", default=None,
                    help="openvino: CPU GPU; onnxruntime: CPUExecutionProvider DmlExecutionProvider")
    ap.add_argument("--ctypes-device", default="NPU")
    ap.add_argument("--batches", nargs="+", type=int, default=[1])
    ap.add_argument("--streams", nargs="+", type=int, default=[1, 2, 4])
    ap.add_argument("--warmup", type=int, default=3)
    ap.add_argument("--iters", type=int, default=10)
    ap.add_argument("--threads", type=int, default=4)
    ap.add_argument("--npu-precision", default="f16", choices=["f16", "f32"])
    ap.add_argument("--json", default=None)
    args = ap.parse_args()
    if args.device is None:
        args.device = {"openvino": ["CPU", "GPU"],
                       "onnxruntime": ["CPUExecutionProvider"]}.get(args.backend, [])
    if args.ref is None:
        args.ref = os.path.join(NPU_DIR, "models", "ref_b1.npz")
    if not os.path.exists(args.ref):
        print("missing reference:", args.ref, "- run tools/export_onnx.py first")
        return 2
    sp, gl, ref = load_ref(args.ref)

    if args.backend == "openvino":
        if not os.path.exists(args.onnx):
            print("missing onnx:", args.onnx)
            return 2
        results = bench_openvino(args, sp, gl, ref)
        print_table("OpenVINO pip (2026.x): KataGo b11c768", results)
    elif args.backend == "openvino-ctypes":
        if not os.path.exists(args.ir):
            print("missing IR:", args.ir, "- convert the ONNX with build_out/npu/make_ir.py")
            return 2
        results = bench_ctypes(args, sp, gl, ref)
        print_table("OpenVINO 2024.1 ctypes runtime (the NPU-capable one): KataGo b11c768",
                    results)
    else:
        if not os.path.exists(args.onnx):
            print("missing onnx:", args.onnx)
            return 2
        results = bench_ort(args, sp, gl, ref)
        print_table("ONNX Runtime: KataGo b11c768", results)
    if results and args.json:
        with open(args.json, "w", encoding="utf-8") as f:
            json.dump(results, f, indent=2)
    return 0


if __name__ == "__main__":
    sys.exit(main())
