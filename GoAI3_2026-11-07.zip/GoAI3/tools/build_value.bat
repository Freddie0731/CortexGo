@echo off
REM ===========================================================================
REM  build_value.bat -- build the C++ tools used by the value-head retrain line
REM
REM  Usage:
REM    tools\build_value.bat dump_enc   -> build_out\value\dump_enc.exe
REM    tools\build_value.bat main       -> build_out\value\GoAI3.exe
REM
REM  This session only has Windows PowerShell (no pwsh) and cl.exe is not on
REM  PATH, so vcvars64.bat must be called first. Wrapping the whole thing in
REM  cmd /c with escaped quotes gets eaten by PowerShell, hence this .bat.
REM  Keep all comments ASCII: cmd reads .bat files with the OEM codepage and
REM  non-ASCII bytes can turn into stray commands.
REM ===========================================================================
setlocal
set VCVARS="C:\Program Files\Microsoft Visual Studio\18\Community\VC\Auxiliary\Build\vcvars64.bat"
if not exist %VCVARS% (
  echo [build_value] vcvars64.bat not found at %VCVARS%
  exit /b 1
)
call %VCVARS% >nul
if errorlevel 1 (
  echo [build_value] vcvars64 failed
  exit /b 1
)
cd /d "%~dp0.."
if not exist build_out\value mkdir build_out\value

if /i "%~1"=="dump_enc" goto dump_enc
if /i "%~1"=="main" goto main
if /i "%~1"=="probe" goto probe
echo usage: tools\build_value.bat dump_enc ^| main ^| probe
exit /b 2

:dump_enc
echo [build_value] building dump_enc.exe
cl /nologo /O2 /EHsc /std:c++17 /W3 /DNDEBUG /utf-8 /openmp ^
   /Fe:build_out\value\dump_enc.exe /Fo:build_out\value\ kg\test\dump_enc.cpp
exit /b %errorlevel%

:main
echo [build_value] building GoAI3.exe
cl /nologo /O2 /EHsc /std:c++20 /W3 /DNDEBUG /utf-8 /openmp ^
   /Fe:build_out\value\GoAI3.exe /Fo:build_out\value\ go_ai.cpp ^
   /link gdiplus.lib gdi32.lib user32.lib
exit /b %errorlevel%

:probe
echo [build_value] building probe_encode.exe (own copy, current kg/infer headers)
cl /nologo /O2 /EHsc /std:c++17 /W3 /DNDEBUG /utf-8 /openmp ^
   /Fe:build_out\value\probe_encode.exe /Fo:build_out\value\ kg\test\probe_encode.cpp
exit /b %errorlevel%
