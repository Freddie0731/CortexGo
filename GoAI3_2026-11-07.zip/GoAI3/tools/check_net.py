# -*- coding: utf-8 -*-
"""tools/check_net.py -- one-stop validation for a KataGo .bin.gz network on this box.

Checks, in order (each step skipped if its tool is missing):
  1. file size + sha256 + gzip integrity
  2. parse with the validated Python loader (_katago_v17_load.py):
     modelVersion / input planes / blocks / channels / trunkNormKind / at_end
  3. native CPU forward timing with bench_forward.exe
     (RESULT line: median/min seconds, est_GFLOPS)
  4. encoding+forward smoke test with probe_encode.exe --empty:
     empty-board policy must land on the 4 star points (sum > 0.15)
     and the value must not be saturated.
     NOTE: this catches "parser ok but arithmetic wrong" nets, e.g.
     modelVersion-15 fixup nets that our C++ forward does not support yet.

Typical usage:
  python tools\\check_net.py build_out\\github\\nets\\b10c512h8nbt3tflrs-fson-silu-rsnh.bin.gz
  python tools\\check_net.py kata1.bin.gz --iters 3 --warmup 1

Exit code 0 = all performed checks passed; 1 = at least one failed.
"""
import argparse
import gzip
import hashlib
import os
import re
import subprocess
import sys

REPO = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, REPO)

DEFAULT_BENCH = os.path.join(REPO, 'build_out', 'integrate', 'bench_forward.exe')
DEFAULT_PROBE = os.path.join(REPO, 'build_out', 'v15', 'probe_encode.exe')


def sha256(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for b in iter(lambda: f.read(1 << 20), b''):
            h.update(b)
    return h.hexdigest()


def step_parse(path):
    import _katago_v17_load as L
    M = L.load(path, verbose=False)
    tr = M['trunk']
    print('  name            : %s' % M['name'])
    print('  modelVersion    : %d' % M['modelVersion'])
    print('  input           : %d spatial + %d global'
          % (M['numInputChannels'], M['numInputGlobalChannels']))
    print('  blocks          : %d' % tr['numBlocks'])
    print('  channels        : trunk=%d mid=%d regular=%d gpool=%d'
          % (tr['trunkNumChannels'], tr['midNumChannels'],
             tr['regularNumChannels'], tr['gpoolNumChannels']))
    print('  trunkNormKind   : %d  (0=standard/fixup-style, 1=RMSNorm)'
          % tr['trunkNormKind'])
    print('  params          : %.2f M' % (M['numParams'] / 1e6))
    print('  bytes consumed  : %d / %d  at_end=%s'
          % (M['bytes_consumed'], M['file_size'], M['at_end']))
    ok = bool(M['at_end'])
    warn = M['modelVersion'] == 15 and tr['trunkNormKind'] == 1
    if warn:
        print('  !! modelVersion 15 + RMSNorm trunk tip: needs the forward.h RMSNorm patch')
    if not ok:
        return ok, M
    return ok, M


def step_bench(path, exe, iters, warmup):
    if not os.path.exists(exe):
        print('  (bench_forward.exe not found at %s, skipped)' % exe)
        return None
    out = subprocess.run([exe, path, '--iters', str(iters), '--warmup', str(warmup)],
                         capture_output=True, text=True, errors='replace').stdout
    m = re.search(r'RESULT iters=(\d+) threads=(\d+) median=([\d.]+)s min=([\d.]+)s '
                  r'max=([\d.]+)s pos_per_sec=([\d.]+)', out)
    if not m:
        print('  (could not parse bench output)')
        print('\n'.join(out.splitlines()[-4:]))
        return None
    gf = re.search(r'est_GFLOPS=([\d.]+)', out)
    print('  median=%.4fs  min=%.4fs  pos/s=%.2f  est_GFLOPS=%s'
          % (float(m.group(3)), float(m.group(4)), float(m.group(6)),
             gf.group(1) if gf else '?'))
    return float(m.group(3))


def step_probe(path, exe):
    if not os.path.exists(exe):
        print('  (probe_encode.exe not found at %s, skipped)' % exe)
        return None
    out = subprocess.run([exe, path, '--empty'], capture_output=True, text=True,
                         errors='replace').stdout
    star = None
    m = re.search(r'star pts.*?\(sum=([\d.]+)\)', out)
    if m:
        star = float(m.group(1))
    top = re.search(r'policy top: (.*)', out)
    val = re.search(r'value=\(([^)]*)\)', out)
    print('  policy top      : %s' % (top.group(1) if top else '?'))
    print('  value logits    : %s' % (val.group(1) if val else '?'))
    print('  star pts sum    : %s' % ('%.4f' % star if star is not None else '?'))
    ok = star is not None and star > 0.15
    print('  star-point test : %s (needs > 0.15)'
          % ('PASS' if ok else 'FAIL -- encoding/norm arithmetic is wrong for this net'))
    if not ok and M['modelVersion'] == 15:
        print('    hint: a modelVersion-15 net whose training config was fixup (name without')
        print('          -fs/-fson) needs fixup norm constants that our forward.h does not')
        print('          implement; see build_out\\github\\ENGINE_COMPAT.md')
    return ok


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('net')
    ap.add_argument('--bench-exe', default=DEFAULT_BENCH)
    ap.add_argument('--probe-exe', default=DEFAULT_PROBE)
    ap.add_argument('--iters', type=int, default=3)
    ap.add_argument('--warmup', type=int, default=1)
    ap.add_argument('--no-bench', action='store_true')
    ap.add_argument('--no-probe', action='store_true')
    args = ap.parse_args()

    path = args.net
    if not os.path.isabs(path) and not os.path.exists(path):
        path = os.path.join(REPO, path)
    print('== check_net: %s' % path)
    sz = os.path.getsize(path)
    digest = sha256(path)
    print('  size            : %d bytes (%.2f MB)' % (sz, sz / 1e6))
    print('  sha256          : %s' % digest)
    with gzip.open(path, 'rb') as f:      # integrity: gzip CRC + truncated check
        tot = 0
        while True:
            b = f.read(1 << 20)
            if not b:
                break
            tot += len(b)
    print('  gzip stream     : OK (%d bytes uncompressed)' % tot)

    print('\n[1] python parser')
    ok_parse, M = step_parse(path)

    ok_bench = None
    ok_probe = None
    if not args.no_bench:
        print('\n[2] native CPU forward (bench_forward)')
        ok_bench = step_bench(path, args.bench_exe, args.iters, args.warmup)
    if not args.no_probe:
        print('\n[3] empty-board smoke test (probe_encode --empty)')
        ok_probe = step_probe(path, args.probe_exe)

    print('\n== summary')
    print('  parse at_end    : %s' % ('PASS' if ok_parse else 'FAIL'))
    if ok_probe is not None:
        print('  star-point test : %s' % ('PASS' if ok_probe else 'FAIL'))
    bad = (not ok_parse) or (ok_probe is False)
    print('  RESULT: %s' % ('OK' if not bad else 'NOK'))
    return 0 if not bad else 1


if __name__ == '__main__':
    sys.exit(main())
