# -*- coding: utf-8 -*-
"""go_ai.cpp 第三批补丁：
  1) 加载顺序优先用重训过价值头的 kata1_value_fixed.bin.gz（没有就回退原文件）
  2) 修掉启动时那句已经不准确的"单次前向约 2 秒 / 对称平均压到 1 次"
"""
import io
import sys

PATH = 'go_ai.cpp'

EDITS = [
    (
        '    static const char* kCandidates[] = { "kata1.bin.gz", "nn_weights.bin.gz",\n'
        '                                         "nn_weights.bin" };',
        '    static const char* kCandidates[] = { "kata1_value_fixed.bin.gz",\n'
        '                                         "kata1.bin.gz", "nn_weights.bin.gz",\n'
        '                                         "nn_weights.bin" };'
    ),
    (
        '    for (int i = 0; i < 3; ++i) {',
        '    const int nCand = (int)(sizeof(kCandidates) / sizeof(kCandidates[0]));\n'
        '    for (int i = 0; i < nCand; ++i) {'
    ),
    (
        '        std::cerr << "Not loading a neural network. Looked for kata1.bin.gz, "\n'
        '            "nn_weights.bin.gz, nn_weights.bin in the current directory";',
        '        std::cerr << "Not loading a neural network. Looked for "\n'
        '            "kata1_value_fixed.bin.gz, kata1.bin.gz, nn_weights.bin.gz, "\n'
        '            "nn_weights.bin in the current directory";'
    ),
    (
        '            << "  单次前向约 2 秒（CPU），对称平均已对 KataGo 压到 1 次。\\n"',
        '            << "  前向约 1 秒/次（14 线程 CPU）：根节点做 8 对称平均，"\\n"\n'
        '            << "  深层叶子只评 1 次（--root-symmetries N 可调）。\\n"'
    ),
]


def main():
    raw = io.open(PATH, 'r', encoding='utf-8', newline='').read()
    text = raw.replace('\r\n', '\n')
    bad = []
    for i, (old, new) in enumerate(EDITS):
        c = text.count(old)
        if c != 1:
            bad.append((i + 1, c))
            continue
        text = text.replace(old, new)
        print('[ok] patch %d' % (i + 1))
    if bad:
        print('[FAIL] %r' % (bad,))
        raise SystemExit('有补丁没打上，文件未写回')
    out = text.replace('\r\n', '\n').replace('\n', '\r\n')
    io.open(PATH, 'w', encoding='utf-8', newline='').write(out)
    print('写回完成，%d 字节' % len(out))
    return 0


if __name__ == '__main__':
    sys.exit(main())
