# -*- coding: utf-8 -*-
"""前向速度探针：确认 PyTorch 侧单次/批量前向的真实耗时，决定采样规模。"""
import os
import sys
import time

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import value_lib as V

try:
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
except Exception:
    pass


def main():
    import torch
    nthr = int(os.environ.get('KG_THREADS', '6'))
    torch.set_num_threads(nthr)
    print('torch %s threads=%d interop=%d' % (
        torch.__version__, torch.get_num_threads(), torch.get_num_interop_threads()),
        flush=True)

    t0 = time.time()
    from value_features import load_official_model, run_batch
    model, M = load_official_model('kata1.bin.gz')
    print('model build+load: %.1f s' % (time.time() - t0), flush=True)

    d = V.read_dump('build_out/value/dump20.bin')
    sp = V.planes_to_spatial(d['planes'])
    print('dump loaded: %s' % (sp.shape,), flush=True)

    # 预热（第一次调用含 lazy init）
    t0 = time.time()
    g, v, p = run_batch(model, sp[0:1], d['global'][0:1])
    print('first forward (warmup): %.2f s' % (time.time() - t0), flush=True)

    for b in (1, 2, 4, 8, 16):
        if b > sp.shape[0]:
            continue
        spb = sp[:b]
        glb = d['global'][:b]
        t0 = time.time()
        run_batch(model, spb, glb)
        dt = time.time() - t0
        # 再跑一次取稳态
        t0 = time.time()
        run_batch(model, spb, glb)
        dt2 = time.time() - t0
        print('batch=%-2d  first=%.2fs  steady=%.2fs  -> %.2f pos/s (steady)' % (
            b, dt, dt2, b / max(dt2, 1e-9)), flush=True)


if __name__ == '__main__':
    main()
