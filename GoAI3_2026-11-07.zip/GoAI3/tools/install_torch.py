# -*- coding: utf-8 -*-
"""tools/install_torch.py —— 手工装 CPU 版 PyTorch（不用 pip）

## 为什么不用 pip

本机 DSH 沙箱里 `pip install --target ...` 会在**它自己的解包目录**报
`Permission denied (Errno 13)`（解包/rename 被拒），跟网络无关。
所以复用 `install_aistudio_sdk.py` 里那套"挑 wheel → 下载 → 解压"的逻辑。

## 为什么需要 torch

自对弈训练要跑官方 KataGo 的 PyTorch 模型定义（`_katago_src/model_pytorch.py`）
和 `_kg_pipeline.py`（自对弈/微调/导出）。AI Studio 那边**平台层面拦截了
`import torch`**（提示 "AI Studio prepared an entire environment based on
PaddlePaddle already"），所以训练只能在本地或别的平台做。

安装到 `build_out/torch/`，用 `PYTHONPATH` 引入即可，不污染系统 Python。

用法:
    python tools/install_torch.py                 # 默认装 torch 2.9.1（稳定）
    python tools/install_torch.py --version 2.14.1
"""
import argparse
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import install_aistudio_sdk as I  # noqa: E402  复用 wheel 挑选/下载逻辑

ROOT = os.path.dirname(HERE)
DEST = os.path.join(ROOT, 'build_out', 'torch')

# torch 的运行时依赖（CPU 版），纯 Python 居多
DEPS = [
    'typing-extensions', 'filelock', 'mpmath', 'networkx', 'sympy',
    'MarkupSafe', 'jinja2', 'fsspec',
]

# 让 install_aistudio_sdk 的安装目录指向 build_out/torch
I.DEST = DEST
I.DL = os.path.join(ROOT, 'build_out', 'downloads')


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--version', default='2.9.1')
    ap.add_argument('--skip-deps', action='store_true')
    args = ap.parse_args()

    os.makedirs(DEST, exist_ok=True)
    os.makedirs(I.DL, exist_ok=True)
    print('安装目录: %s' % DEST)

    if not args.skip_deps:
        print('依赖:')
        for p in DEPS:
            try:
                I.install(p)
            except Exception as e:
                print('  [warn] %-18s %s' % (p, e))

    print('torch %s:' % args.version)
    ok = I.install('torch', args.version)
    if not ok:
        print('[error] 没装成功（镜像里可能没有 %s 的 cp314 win64 轮子）' % args.version)
        return 1

    pth = os.path.join(DEST, 'goai3_torch.pth')
    with open(pth, 'w', encoding='utf-8') as f:
        f.write(DEST + '\n')
    print('\n完成。自检：')
    print('  set PYTHONPATH=%s' % DEST)
    print('  python -c "import torch;print(torch.__version__)"')
    return 0


if __name__ == '__main__':
    sys.exit(main())
