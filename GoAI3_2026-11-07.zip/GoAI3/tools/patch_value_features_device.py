# -*- coding: utf-8 -*-
"""给 tools/value_features.py 加 --device 支持（云端 GPU 用）。

为什么：这个脚本原来只会跑 CPU。云端租 GPU 就是为了把"16,680 个局面的 trunk 前向"
从 1.9 pos/s 提到几十~上百 pos/s，所以必须有一步把模型和张量放到 cuda 上。

改动尽量小、且**不改变 CPU 行为**（默认 --device cpu）：
* 新增模块级 DEVICE，默认 'cpu'；
* load_official_model() 末尾把模型 .to(DEVICE)；
* run_batch() 把两个输入张量 .to(DEVICE)，autocast 的设备跟着走，
  hook 里已经有 .cpu()，所以特征仍然是 CPU numpy，下游脚本不用改；
* argparse 新增 --device，main() 里设置 DEVICE。
"""
import io
import sys

PATH = 'tools/value_features.py'

EDITS = [
    # 1) 模块级 DEVICE
    (
        '# ---------------------------------------------------------------- torch 模型\n'
        'def load_official_model(wpath, verbose=True):',
        '# ---------------------------------------------------------------- torch 模型\n'
        '# 前向所在设备。默认 cpu（与历史行为一致）；云端用 --device cuda。\n'
        '# 特征始终以 CPU numpy 返回，所以下游 value_train / value_export 不用改。\n'
        'DEVICE = \'cpu\'\n'
        '\n'
        '\n'
        'def load_official_model(wpath, verbose=True):'
    ),
    # 2) 模型搬到设备上
    (
        '    model.load_state_dict(target, strict=False)\n',
        '    model.load_state_dict(target, strict=False)\n'
        '    if DEVICE != \'cpu\':\n'
        '        model = model.to(DEVICE)\n'
    ),
    # 3) 输入张量搬到设备上
    (
        '            sp = torch.from_numpy(np.ascontiguousarray(spatial)).float()\n'
        '            gl = torch.from_numpy(np.ascontiguousarray(glob)).float()',
        '            sp = torch.from_numpy(np.ascontiguousarray(spatial)).float()\n'
        '            gl = torch.from_numpy(np.ascontiguousarray(glob)).float()\n'
        '            if DEVICE != \'cpu\':\n'
        '                sp = sp.to(DEVICE, non_blocking=True)\n'
        '                gl = gl.to(DEVICE, non_blocking=True)'
    ),
    # 4) autocast 的设备跟着走
    (
        '                with torch.autocast(\'cpu\', dtype=torch.bfloat16):',
        '                with torch.autocast(DEVICE if DEVICE != \'cpu\' else \'cpu\',\n'
        '                                    dtype=torch.bfloat16):'
    ),
    # 5) CLI
    (
        "    ap.add_argument('--threads', type=int, default=6)",
        "    ap.add_argument('--threads', type=int, default=6)\n"
        "    ap.add_argument('--device', default='cpu', choices=('cpu', 'cuda'),\n"
        "                    help='forward device; cuda when running on a cloud GPU')"
    ),
    # 6) main 里启用
    (
        "    import torch\n    torch.set_num_threads(args.threads)",
        "    import torch\n    global DEVICE\n    DEVICE = args.device\n"
        "    if DEVICE == 'cuda' and not torch.cuda.is_available():\n"
        "        raise SystemExit('--device cuda requested but torch.cuda.is_available() is False')\n"
        "    print('device=%s%s' % (DEVICE, (' (%s)' % torch.cuda.get_device_name(0))\n"
        "                          if DEVICE == 'cuda' else ''), flush=True)\n"
        "    torch.set_num_threads(args.threads)"
    ),
]


def main():
    raw = io.open(PATH, 'r', encoding='utf-8', newline='').read()
    text = raw.replace('\r\n', '\n')
    bad = []
    for i, (old, new) in enumerate(EDITS):
        c = text.count(old)
        if c != 1:
            bad.append((i + 1, c))
            continue
        text = text.replace(old, new)
        print('[ok] patch %d' % (i + 1))
    if bad:
        raise SystemExit('补丁没打上: %r' % (bad,))
    out = text.replace('\r\n', '\n').replace('\n', '\r\n')
    io.open(PATH, 'w', encoding='utf-8', newline='').write(out)
    print('写回完成 %d 字节' % len(out))
    return 0


if __name__ == '__main__':
    sys.exit(main())
