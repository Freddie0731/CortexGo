# -*- coding: utf-8 -*-
"""把 go_ai.cpp 的搜索选择逻辑替换成 PUCT（含未展开着法竞争）+ 修 FPU 符号。

go_ai.cpp 是 CRLF 文件，edit 工具按字面匹配会失败，所以这里按"行标记"做替换：
  1. 用 "// Picks the child with the best PUCT score." 定位 collect_child_order，整段换成 select_action
  2. 用 "static void descend(" 定位 descend，整段换成新实现
更新后统一写回 CRLF。
"""
import io
import sys

PATH = 'go_ai.cpp'

NEW_SELECT = r'''// Picks the best action at `node` by PUCT.
//
//   Q(s,a) = -Q(child)                   value from THIS node's mover perspective
//   U(s,a) = cpuct * P * sqrt(N) / (1+n)
//   score  = Q + U - virtual_loss * inflight / (1 + n)
//
// TWO things here are load-bearing, and both were wrong before:
//
// 1. Unvisited legal moves must COMPETE with visited children. The old code
//    materialised a child for every legal move (highest prior first) and only
//    ran PUCT once the legal list was empty. The b11c768 forward pass costs
//    about one visit per second on this CPU, so a 30-second move buys about 30
//    simulations -- while a 19x19 root has roughly 300 legal moves. The search
//    therefore never emptied the legal list, never ran PUCT at all, and the
//    engine simply played the network's highest-prior move: every simulation
//    was spent materialising a different root child that was never looked at
//    again.
//
// 2. The FPU value's sign. `parent_q` is from the parent's mover perspective,
//    but `q` below is from the CHILD's mover perspective (the opponent), so the
//    unvisited estimate must be negated: q_unvisited = -(parent_q - reduction).
//    The old code used q = parent_q - reduction and then scored -q, which
//    silently inverted the value term for unvisited moves: in a good position
//    unexplored moves looked bad (so the search refused to explore) and in a bad
//    position they looked good (so it fled into random moves).
//
// Returns a child node index (>= 0) when a visited child wins, or -1 with
// `slot_out` set to the winning legal move's slot in node->legal / targets.
static int select_action(int node, const SearchParams& params, int& slot_out) {
    slot_out = -1;
    SearchTree* t = &g_tree;
    TreeNode* n = t->pool[node];
    const std::vector<int>& ch = n->children;

    double parent_q = t->q_of(node);
    int parent_visits = n->visits.load();
    double sqrt_n = std::sqrt((double)(parent_visits > 0 ? parent_visits : 1));

    // Q(s,a) for an action with no visits yet, in THIS node's mover perspective.
    double q_unvisited = parent_q - params.fpu_reduction;
    if (q_unvisited < -1.0) q_unvisited = -1.0;
    if (q_unvisited > 1.0) q_unvisited = 1.0;

    double best = -1e300;
    int best_child = -1;
    int best_slot = -1;

    for (size_t i = 0; i < ch.size(); ++i) {
        TreeNode* c = t->pool[ch[i]];
        int nv = c->visits.load();
        // `value` is a SUM from the child's mover perspective; negate for ours.
        double q = (nv > 0) ? (-(c->value.load() / (double)nv)) : q_unvisited;
        double prior = (double)c->child_prior;
        double u = params.cpuct * prior * sqrt_n / (1.0 + (double)nv);
        double score = q + u;
        int inflight = c->vloss.load();
        if (inflight > 0)
            score -= params.virtual_loss * (double)inflight / (1.0 + (double)nv);
        if (score > best) { best = score; best_child = ch[i]; best_slot = -1; }
    }

    // Legal moves with no child yet are scored exactly like a visited child with
    // n = 0: Q = the FPU estimate, U = cpuct * P * sqrt(N).
    for (size_t i = 0; i < n->legal.size(); ++i) {
        double prior = (i < n->targets.size()) ? (double)n->targets[i] : 0.0;
        double score = q_unvisited + params.cpuct * prior * sqrt_n;
        if (score > best) { best = score; best_child = -1; best_slot = (int)i; }
    }

    slot_out = best_slot;
    return best_child;
}'''

NEW_DESCEND = r'''static void descend(const SearchParams& params, std::vector<int>& path) {
    SearchTree* t = &g_tree;
    path.clear();
    if (t->root < 0) return;
    int cur = t->root;
    path.push_back(cur);

    while (true) {
        TreeNode* n = t->pool[cur];
        if (n->terminal) break;

        if (!n->expanded) {
            // Expand either under the lock, or bail out if another thread is
            // already doing it or the pool is full.
            bool did = false;
            {
                std::lock_guard<std::mutex> lock(t->expand_mutex);
                if (!t->pool[cur]->expanded && !t->full(params.max_nodes)) {
                    expand_node(cur, params);
                    did = true;
                }
            }
            if (!did) {
                if (!t->pool[cur]->expanded) return;   // pool full / raced
            }
            n = t->pool[cur];
            if (n->terminal) break;
        }

        if (n->legal.empty() && n->children.empty()) break;   // nothing playable

        // Choose among visited children AND not-yet-materialised legal moves.
        // The selection has to happen under the expand mutex because make_child
        // mutates node->legal / node->targets, which the scoring reads.
        int slot = -1;
        int ci = -1;
        bool created = false;
        {
            std::lock_guard<std::mutex> lock(t->expand_mutex);
            if (t->full(params.max_nodes)) return;
            int pick = select_action(cur, params, slot);
            if (pick >= 0) {
                // Existing child: claim one in-flight visit so sibling threads
                // see the virtual loss and look elsewhere.
                t->pool[pick]->vloss.fetch_add(1);
                ci = pick;
            } else if (slot >= 0) {
                ci = make_child(cur, slot);
                if (ci >= 0) {
                    t->pool[ci]->vloss.fetch_add(1);
                    created = true;
                }
            } else {
                break;                      // nothing selectable
            }
        }
        if (ci < 0) continue;               // move was illegal: try again

        path.push_back(ci);
        // A freshly created child is the leaf of this simulation: run_simulation()
        // expands and evaluates exactly it, which keeps nn/sim at 1. Walking into
        // it would expand a whole chain per simulation instead.
        if (created) break;
        cur = ci;                           // otherwise keep descending
    }
}'''


def splice(lines, start_marker, end_is_brace_at_col0, new_text):
    """把从 start_marker 所在行到其后第一行恰为 '}' 的那一行整段替换掉。"""
    si = None
    for i, ln in enumerate(lines):
        if ln.startswith(start_marker):
            si = i
            break
    if si is None:
        raise SystemExit('marker not found: %r' % start_marker)
    ei = None
    for j in range(si, len(lines)):
        if lines[j] == '}':
            ei = j
            break
    if ei is None:
        raise SystemExit('closing brace not found after %r (line %d)' % (start_marker, si + 1))
    return lines[:si] + new_text.split('\n') + lines[ei + 1:], (si + 1, ei + 1)


def main():
    raw = io.open(PATH, 'r', encoding='utf-8', newline='').read()
    crlf = raw.count('\r\n')
    lf_only = raw.count('\n') - crlf
    print('原始文件: CRLF=%d, 仅LF=%d' % (crlf, lf_only))
    text = raw.replace('\r\n', '\n')
    lines = text.split('\n')

    lines, r1 = splice(lines, '// Picks the child with the best PUCT score.', True, NEW_SELECT)
    print('替换 collect_child_order -> select_action: 行 %d..%d' % r1)
    lines, r2 = splice(lines, 'static void descend(const SearchParams& params, std::vector<int>& path) {',
                       True, NEW_DESCEND)
    print('替换 descend: 行 %d..%d' % r2)

    out = '\n'.join(lines)
    # 原文件是纯 CRLF，保持一致
    out = out.replace('\r\n', '\n').replace('\n', '\r\n')
    io.open(PATH, 'w', encoding='utf-8', newline='').write(out)
    print('写回完成，%d 字节' % len(out))
    return 0


if __name__ == '__main__':
    sys.exit(main())
