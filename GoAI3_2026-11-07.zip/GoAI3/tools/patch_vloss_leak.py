# -*- coding: utf-8 -*-
"""go_ai.cpp 第六批补丁：修"提前返回时虚拟损失泄漏"。

descend() 里有两条提前返回路径（节点池满 / 展开竞争失败）。返回时路径上的节点
已经被打了 virtual-loss 计数，但 backup 不会再跑，于是这些计数永远不释放 ——
节点池满之后选择会永久偏向其它分支。默认 max_nodes=500000 时碰不到，但
--max-nodes 调小、或者做架构测试时会踩到，属于"悄悄坏掉"的那类 bug。

修法：抽出 descend_abort()，释放路径上的 claim 并清空 path（清空后
run_simulation 会因为 path 为空而直接返回，不会去评估一个本来不打算评估的节点）。
"""
import io
import sys

PATH = 'go_ai.cpp'

ANCHOR = 'static void descend(const SearchParams& params, std::vector<int>& path) {'

NEW_HELPER = '''// Releases the virtual-loss claims made along `path` and clears it, for the
// cases where descend() gives up before reaching a leaf. Without this the claims
// added while walking down are never released (backup never runs), and after the
// first abort a node pool that is full would permanently bias selection away from
// those branches.
static void descend_abort(std::vector<int>& path) {
    SearchTree* t = &g_tree;
    for (size_t i = 1; i < path.size(); ++i) {
        int ni = path[i];
        if (ni >= 0 && ni < (int)t->pool.size()) t->pool[ni]->vloss.fetch_sub(1);
    }
    path.clear();
}

static void descend(const SearchParams& params, std::vector<int>& path) {'''

EDITS = [
    # 1) 插入辅助函数
    (ANCHOR, NEW_HELPER),
    # 2) 展开竞争失败的提前返回
    (
        '            if (!did) {\n'
        '                if (!t->pool[cur]->expanded) return;   // pool full / raced\n'
        '            }',
        '            if (!did) {\n'
        '                if (!t->pool[cur]->expanded) {  // pool full / raced\n'
        '                    descend_abort(path);\n'
        '                    return;\n'
        '                }\n'
        '            }'
    ),
    # 3) 节点池满的提前返回
    (
        '            std::lock_guard<std::mutex> lock(t->expand_mutex);\n'
        '            if (t->full(params.max_nodes)) return;\n'
        '            int pick = select_action(cur, params, slot);',
        '            std::lock_guard<std::mutex> lock(t->expand_mutex);\n'
        '            if (t->full(params.max_nodes)) {\n'
        '                descend_abort(path);\n'
        '                return;\n'
        '            }\n'
        '            int pick = select_action(cur, params, slot);'
    ),
]


def main():
    raw = io.open(PATH, 'r', encoding='utf-8', newline='').read()
    text = raw.replace('\r\n', '\n')
    bad = []
    for i, (old, new) in enumerate(EDITS):
        c = text.count(old)
        if c != 1:
            bad.append((i + 1, c, old.split('\n')[0][:60]))
            continue
        text = text.replace(old, new)
        print('[ok] patch %d' % (i + 1))
    if bad:
        for b in bad:
            print('[FAIL] patch %d count=%d : %s' % b)
        raise SystemExit('有补丁没打上，文件未写回')
    out = text.replace('\r\n', '\n').replace('\n', '\r\n')
    io.open(PATH, 'w', encoding='utf-8', newline='').write(out)
    print('写回完成，%d 字节' % len(out))
    return 0


if __name__ == '__main__':
    sys.exit(main())
