# -*- coding: utf-8 -*-
"""修 kg/infer/model_load.h 的归一化语义（这是 policy/value 一起错的根因）。

## 证据链

官方导出器 `export_model_pytorch.py` 的 `write_bn()`（第 402-453 行）往 .bin.gz 写的是：

    running_mean                      = BN 的 running_mean（非 BN 时全 0）
    running_var                       = max(1e-20, running_std^2 - 1e-20)
                                        （非 BN 时 = 1 - 1e-20）
    "scale/gamma" 槽位                 = scale*(gamma+1) 或 scale*gamma 或 scale
                                        ← **已经把逐层 scale 乘进去了**
    beta

而官方的前向（model_pytorch.py `NormMask.forward` + `apply_gamma_beta_scale_mask`）：
  * BN 分支（norm_kind=bnorm，或 fixscaleonenorm 的最后一层）：
        y = ((x - running_mean) / running_std) * slot + beta
  * 非 BN 分支：y = x * slot + beta
两者其实是**同一条公式**（非 BN 时 mean=0、running_std=1）。

## 我们的实现错在哪

`setScaleMul()` 硬编码了：
    scaleMul = k（=1/sqrt(block+1)），若 useGamma 则 scaleMul = 0.5*(1+gamma)
    running_mean / running_var **读进来了但从来没用过**

对 kata1 的 p/q 分支，这个硬编码值恰好等于文件里的值（所以 test_forward 对得上、
一直没暴露），但 **trunk 末端那层真实 batchnorm 被整个丢掉了** —— 而那正是
policy/value 两个头的共同输入。于是出现：
  * 空盘 policy 全压在 4 个星位（0.92），官方是 komoku 轨道 0.66 + 星位 0.15；
  * value 完全错（我们 (-6.1, 6.7)，官方 whiteWin 0.656）。

## 修法

用文件里真实的四组数，统一按那条公式算，`eps` 用文件里的值（1e-20，
因为 var 是按 std^2 - eps 写的，加回去正好还原 std）。
另外删掉 `readNormActConv` 里 `if (!useGamma) n.norm.gamma.clear();`
—— 那个槽位不是"gamma"，是**最终乘子**，p 分支也要用。
"""
import io
import re
import sys

PATH = 'kg/infer/model_load.h'

NEW_FUNC = '''inline void setScaleMul(NormLayer& n, bool useGamma, float k) {
    // 官方导出器（export_model_pytorch.py write_bn）写进 .bin.gz 的四组数：
    //   running_mean       : BN 的均值（非 BN 时为全 0）
    //   running_var        : max(1e-20, std^2 - 1e-20)（非 BN 时为 1-1e-20）
    //   "scale/gamma" 槽位  : scale*(gamma+1) / scale*gamma / scale
    //                        —— **已经把逐层 scale 乘进去了**
    //   beta
    // 所以正确的前向只有一条公式：
    //     y = ((x - running_mean) / sqrt(running_var + eps)) * slot + beta
    // eps 用文件里的值（1e-20）：var 是按 std^2-eps 写的，加回去正好还原 std。
    // 非 BN 时 mean=0、sqrt(1-eps+eps)=1，自动退化成 y = x*slot + beta。
    //
    // 老实现硬编码 k=1/sqrt(block+1) 与 0.5*(1+gamma)，并把 mean/var 完全丢掉：
    // 对 kata1 的 p/q 分支恰好等值（所以一直没暴露），但 trunk 末端那层真实
    // batchnorm 被整个跳过 —— policy/value 两个头喂进去的 trunk 输出因此是错的。
    (void)useGamma;
    (void)k;
    n.fixScale = 1.0f;
    n.scaleMul.assign((size_t)n.c, 1.0f);
    const bool hasSlot = (n.gamma.size() == (size_t)n.c);
    const bool hasBeta = (n.bias.size() == (size_t)n.c);
    std::vector<float> newBias((size_t)n.c, 0.0f);
    for (int c = 0; c < n.c; ++c) {
        const float inv = 1.0f / std::sqrt(n.runningVar[c] + n.epsilon);
        const float slot = hasSlot ? n.gamma[c] : 1.0f;
        n.scaleMul[c] = slot * inv;
        newBias[c] = (hasBeta ? n.bias[c] : 0.0f) - n.runningMean[c] * n.scaleMul[c];
    }
    n.bias.swap(newBias);
}'''


def main():
    raw = io.open(PATH, 'r', encoding='utf-8', newline='').read()
    crlf = '\r\n' in raw
    text = raw.replace('\r\n', '\n')
    lines = text.split('\n')

    # 1) 替换 setScaleMul 整个函数体（从签名行到其后的第一个行首 '}'）
    si = None
    for i, ln in enumerate(lines):
        if ln.startswith('inline void setScaleMul(NormLayer& n, bool useGamma, float k) {'):
            si = i
            break
    if si is None:
        raise SystemExit('找不到 setScaleMul')
    ei = None
    for j in range(si, len(lines)):
        if lines[j] == '}':
            ei = j
            break
    if ei is None:
        raise SystemExit('找不到 setScaleMul 的结束行')
    print('替换 setScaleMul：原第 %d..%d 行' % (si + 1, ei + 1))
    lines = lines[:si] + NEW_FUNC.split('\n') + lines[ei + 1:]

    # 2) 删掉 "if (!useGamma) n.norm.gamma.clear();" 这行
    kept = []
    removed = 0
    for ln in lines:
        if ln.strip().startswith('if (!useGamma) n.norm.gamma.clear();'):
            removed += 1
            print('删除行: %s' % ln.strip())
            continue
        kept.append(ln)
    if removed != 1:
        raise SystemExit('预期删掉 1 行 gamma.clear()，实际 %d 行' % removed)
    lines = kept

    # 3) 确保有 <cmath>（sqrt）
    joined = '\n'.join(lines)
    if '#include <cmath>' not in joined:
        joined = joined.replace('#include "weights.h"', '#include "weights.h"\n\n#include <cmath>', 1)
        print('补上 #include <cmath>')

    out = joined.replace('\r\n', '\n')
    if crlf:
        out = out.replace('\n', '\r\n')
    io.open(PATH, 'w', encoding='utf-8', newline='').write(out)
    print('写回完成 %d 字节' % len(out))
    return 0


if __name__ == '__main__':
    sys.exit(main())
