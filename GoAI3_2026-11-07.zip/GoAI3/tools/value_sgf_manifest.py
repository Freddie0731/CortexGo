# -*- coding: utf-8 -*-
"""Step A: 扫描 SGF 棋谱 -> 过滤 -> 采样局面 -> 生成 dump_enc 能吃的清单。

只做「数据准备」这件事：解析、过滤、采样。
**不在这里做任何棋盘/编码相关的推导** —— 每次落子是否合法由 C++ 侧
(kg/test/dump_enc.cpp 用 kg::Board::playMove) 复验，两边不一致会立刻报出来。

输出格式（制表符分隔，一行一局，供 dump_enc.cpp 读）：
    <gameId>\t<komi>\t<winner>\t<nMoves>\t<m1,m2,...>\t<nSamples>\t<p1,p2,...>

  gameId  : SGF 相对路径（不含扩展名）
  komi    : float，缺失时用默认值（默认 6.5，并在统计里单独计数）
  winner  : 1=黑胜 2=白胜（只保留 RE 明确为 B+.../W+... 的对局）
  nMoves  : 总手数（含 pass，pass 用 -1）
  m*      : 逐手 loc，kg::Board 约定 loc = y*19 + x，y 向下（= SGF 的行号字母）
  nSamples/p*: 要 dump 的局面，p = 已经落了 p 手之后（0<=p<=nMoves）

用法:
  python tools/value_sgf_manifest.py --sgf-root build_out/value/sgf/games \
      --out build_out/value/manifest.txt --max-games 3000 --samples-per-game 24
"""
import sys, os, re, argparse, collections, zlib

try:
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
except Exception:
    pass

N = 19

# 主序列里的着法：;B[xx] / ;W[xx] / ;B[] (pass)
RE_MOVE = re.compile(rb';\s*([BW])\s*\[([a-zA-Z]{0,2})\]')
RE_PROP = re.compile(rb'([A-Za-z]+)\s*\[')


def find_prop(data, name):
    """在 root 节点里找第一个 name[value]，返回 bytes 或 None。

    只看第一个 ';' 之前/附近不算可靠，所以直接全文件找第一个出现，但要求
    它出现在第一个着法之前（属性都在 root 节点）。这里简化：取第一个匹配，
    并额外要求它前面没有 ';B[' 或 ';W['。
    """
    first_move = len(data)
    m = RE_MOVE.search(data)
    if m:
        first_move = m.start()
    for m in re.finditer(rb'(?<![A-Za-z])' + name.encode() + rb'\s*\[([^\]]*)\]', data):
        if m.start() > first_move:
            break
        return m.group(1)
    return None


def sgf_xy(s):
    """SGF 坐标 -> (col, row)。空串 = pass。"""
    if len(s) == 0:
        return None
    if len(s) < 2:
        return None
    col = ord(s[0:1]) - ord('a')
    row = ord(s[1:2]) - ord('a')
    if not (0 <= col < 26 and 0 <= row < 26):
        return None
    return col, row


def parse_game(path):
    with open(path, 'rb') as f:
        data = f.read()

    sz = find_prop(data, 'SZ')
    if sz is not None and sz.strip() != b'19':
        return None, 'sz'
    # 让子 / 摆子局：价值训练的分布和引擎启动局面不一致，直接排除
    if find_prop(data, 'AB') is not None or find_prop(data, 'AW') is not None:
        return None, 'setup'
    ha = find_prop(data, 'HA')
    if ha is not None:
        try:
            if float(ha.strip()) > 1:
                return None, 'handicap'
        except Exception:
            pass

    re_ = find_prop(data, 'RE')
    if re_ is None:
        return None, 'no_re'
    re_s = re_.strip().upper()
    m = re.match(rb'^(B|W)\s*\+', re_s)
    if not m:
        return None, 'bad_re'
    winner = 1 if m.group(1) == b'B' else 2

    km = find_prop(data, 'KM')
    komi = None
    if km is not None:
        try:
            komi = float(km.strip())
        except Exception:
            komi = None
    komi_missing = komi is None
    if komi is None:
        komi = 6.5

    moves = []
    for mm in RE_MOVE.finditer(data):
        who = 1 if mm.group(1) == b'B' else 2
        xy = sgf_xy(mm.group(2))
        if xy is None:
            moves.append((-1, who))
        else:
            col, row = xy
            if not (0 <= col < N and 0 <= row < N):
                return None, 'coord'
            moves.append((row * N + col, who))

    if len(moves) < 60:
        return None, 'short'

    g = {
        'path': path,
        'komi': komi,
        'komi_missing': komi_missing,
        'winner': winner,
        'moves': moves,
    }
    return g, None


def sample_plies(nmoves, k, lo=8, hi=200):
    """在前 hi 手里（跳过开局 lo 手）均匀取 k 个局面编号。

    局面编号 p = 已经落了 p 手；要求 p 落在 [lo, min(hi, nmoves-1)]。
    """
    top = min(hi, nmoves - 1)
    if top < lo:
        return []
    if k <= 1:
        return [top]
    step = (top - lo) / float(k - 1)
    out = []
    for i in range(k):
        p = int(round(lo + step * i))
        if out and p <= out[-1]:
            p = out[-1] + 1
        if p > top:
            break
        out.append(p)
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--sgf-root', default='build_out/value/sgf/games')
    ap.add_argument('--out', default='build_out/value/manifest.txt')
    ap.add_argument('--max-games', type=int, default=3000)
    ap.add_argument('--samples-per-game', type=int, default=24)
    ap.add_argument('--komi-lo', type=float, default=4.0)
    ap.add_argument('--komi-hi', type=float, default=8.5)
    ap.add_argument('--default-komi', type=float, default=6.5)
    ap.add_argument('--min-moves', type=int, default=100)
    ap.add_argument('--show', type=int, default=20)
    ap.add_argument('--seed', type=int, default=20260517)
    args = ap.parse_args()

    files = []
    for root, dirs, fnames in os.walk(args.sgf_root):
        for fn in fnames:
            if fn.lower().endswith('.sgf'):
                files.append(os.path.join(root, fn))
    files.sort()
    print('found %d sgf files under %s' % (len(files), args.sgf_root))

    # 打乱顺序（固定种子）后按 --max-games 截断，避免只取到 AJ1st 这种早期赛事
    import random
    rng = random.Random(args.seed)
    rng.shuffle(files)

    reasons = collections.Counter()
    komi_hist = collections.Counter()
    re_hist = collections.Counter()
    games = []
    for path in files:
        if len(games) >= args.max_games:
            break
        try:
            g, why = parse_game(path)
        except Exception as e:
            reasons['parse_error'] += 1
            continue
        if g is None:
            reasons[why] += 1
            continue
        if len(g['moves']) < args.min_moves:
            reasons['too_short_%d' % args.min_moves] += 1
            continue
        if not (args.komi_lo <= g['komi'] <= args.komi_hi):
            reasons['komi_out_of_range'] += 1
            komi_hist['out%.1f' % g['komi']] += 1
            continue
        # 着法颜色必须严格交替（黑先）
        ok = True
        for i, (loc, who) in enumerate(g['moves']):
            if who != (1 if i % 2 == 0 else 2):
                ok = False
                break
        if not ok:
            reasons['color_alt'] += 1
            continue
        rel = os.path.relpath(path, args.sgf_root)
        g['gid'] = os.path.splitext(rel)[0].replace('\\', '/')
        games.append(g)
        komi_hist['%.1f' % g['komi']] += 1
        re_hist['B' if g['winner'] == 1 else 'W'] += 1

    print('kept %d games  (rejected: %s)' % (
        len(games), ', '.join('%s=%d' % kv for kv in reasons.most_common(8))))
    print('komi histogram:', ' '.join('%s:%d' % kv for kv in sorted(komi_hist.items())))
    print('winner histogram:', dict(re_hist))

    lines = []
    n_pos = 0
    for g in games:
        plies = sample_plies(len(g['moves']), args.samples_per_game)
        if len(plies) < max(3, args.samples_per_game // 2):
            continue
        mv = ','.join(str(loc) for loc, who in g['moves'])
        pl = ','.join(str(p) for p in plies)
        lines.append('%s\t%.1f\t%d\t%d\t%s\t%d\t%s' % (
            g['gid'], g['komi'], g['winner'], len(g['moves']), mv, len(plies), pl))
        n_pos += len(plies)

    os.makedirs(os.path.dirname(os.path.abspath(args.out)), exist_ok=True)
    with open(args.out, 'w', encoding='utf-8', newline='\n') as f:
        f.write('# KGVMAN01 gameId<TAB>komi<TAB>winner<TAB>nMoves<TAB>moves<TAB>nSamples<TAB>plies\n')
        f.write('\n'.join(lines))
        f.write('\n')
    print('\nwrote %s : %d games, %d sampled positions' % (args.out, len(lines), n_pos))

    print('\n--- sample of %d parsed games (gid, KM, RE, nMoves) ---' % args.show)
    for g in games[:max(args.show, 1)]:
        print('  %-40s KM=%-5.1f RE=%s  moves=%d' % (
            g['gid'], g['komi'], 'B+' if g['winner'] == 1 else 'W+', len(g['moves'])))


if __name__ == '__main__':
    main()
