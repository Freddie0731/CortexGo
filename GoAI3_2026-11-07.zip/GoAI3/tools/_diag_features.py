# -*- coding: utf-8 -*-
"""临时诊断：确认特征里到底有没有"行棋方会赢"的信息，以及 AUC<0.5 是不是
(P0-P1) 这个映射在 noresult 通道很大时被扭曲造成的。"""
import os
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import value_lib as V

z = np.load(sys.argv[1] if len(sys.argv) > 1 else 'build_out/value/features_tiny.npz')
X = z['gpool'].astype(np.float64)
y = (z['meta_winner'] == z['meta_toMove']).astype(np.int32)
print('n=%d  y.mean=%.3f' % (len(y), y.mean()))

# 1) 线性可分性（最小二乘 + AUC）
A = np.hstack([X, np.ones((len(X), 1))])
w, *_ = np.linalg.lstsq(A, y.astype(np.float64) * 2 - 1, rcond=None)
pred = A.dot(w)
print('lstsq on all: AUC=%.4f' % V.auc_score(pred, y))

# 留一棋局交叉验证太慢，这里直接看"局内 vs 局间"方差
g = z['meta_gameIdx']
print('unique games:', np.unique(g)[:12], ' total', len(np.unique(g)))
means = np.array([X[g == k].mean(axis=0) for k in np.unique(g)])
print('gpool feature std (per-feature, 全样本): %.4f' % X.std(axis=0).mean())
print('gpool 局间 mean 的 std: %.4f' % means.std(axis=0).mean())

# 2) 训练一个小 MLP 到收敛，看训练集上的多重指标
import torch
torch.set_num_threads(4)
torch.manual_seed(0)
mu, sd = X.mean(0), np.maximum(X.std(0), 1e-6)
Xt = torch.from_numpy(((X - mu) / sd)).float()
yt = torch.from_numpy(y).long()
net = torch.nn.Sequential(torch.nn.Linear(576, 192), torch.nn.SiLU(), torch.nn.Linear(192, 3))
opt = torch.optim.AdamW(net.parameters(), lr=2e-3, weight_decay=1e-3)
for ep in range(600):
    opt.zero_grad()
    out = net(Xt)
    loss = torch.nn.functional.cross_entropy(out, yt)
    loss.backward()
    opt.step()
    if ep % 100 == 0:
        print('  ep %3d loss=%.4f' % (ep, float(loss)))
with torch.no_grad():
    out = net(Xt)
P = torch.softmax(out, 1).numpy()
print('train loss=%.4f' % float(torch.nn.functional.cross_entropy(out, yt)))
print('P2(noresult) mean=%.4f std=%.4f max=%.4f' % (P[:, 2].mean(), P[:, 2].std(), P[:, 2].max()))
print('AUC 用 P0          = %.4f' % V.auc_score(P[:, 0], y))
print('AUC 用 P0-P1       = %.4f' % V.auc_score(P[:, 0] - P[:, 1], y))
print('AUC 用 logit0-logit1 = %.4f' % V.auc_score(out[:, 0].numpy() - out[:, 1].numpy(), y))
print('acc(P0>0.5)=%.4f' % float(((P[:, 0] > 0.5) == (y == 1)).mean()))
