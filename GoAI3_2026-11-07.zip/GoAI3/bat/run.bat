@echo off
REM ===========================================================================
REM  GoAI++ with the KataGo v17 neural network  --  double-click to play
REM
REM  Usage:
REM    run.bat            AI thinks about 30 seconds per move
REM    run.bat 30         AI thinks about 30 seconds per move
REM    run.bat 20 gtp     GTP mode (for Sabaki / GoGui) instead of the GUI
REM
REM  Why this script exists: the engine looks for its weights relative to the
REM  WORKING DIRECTORY, not the executable. Double-clicking x64\Release\GoAI3.exe
REM  directly sets the working directory to x64\Release, where kata1.bin.gz is
REM  not present -- the engine would then silently fall back to heuristic priors
REM  and would NOT be using KataGo at all. This script cd's to the project root
REM  first, so the network is always found.
REM ===========================================================================
setlocal
cd /d "%~dp0"

set "EXE=x64\Release\GoAI3.exe"
set "WEIGHTS=kata1.bin.gz"
set "THINK=%~1"
if "%THINK%"=="" set "THINK=30"
set "MODE=%~2"

if not exist "%EXE%" (
  echo [ERROR] %EXE% not found. Build it first:
  echo     msbuild GoAI3.vcxproj /p:Configuration=Release /p:Platform=x64
  echo.
  pause
  exit /b 1
)

if not exist "%WEIGHTS%" (
  echo [ERROR] %WEIGHTS% not found in %CD%
  echo.
  echo Put the KataGo .bin.gz file here and rename it to kata1.bin.gz.
  echo Without it the engine falls back to heuristic priors ^(no network^).
  echo.
  pause
  exit /b 1
)

echo ================================================================
echo   GoAI++ with KataGo v17
echo   working dir : %CD%
echo   weights     : %WEIGHTS%
echo   think time  : %THINK% s per move
echo   mode        : %MODE%
echo ================================================================
echo.

if /i "%MODE%"=="gtp" (
  echo GTP mode on stdin/stdout. Feed it GTP commands, or quit to exit.
  echo.
  "%EXE%" --cli --time %THINK%
) else (
  echo Opening the game window...
  echo   - You play Black unless you pass --color white to the exe.
  echo   - First AI move after your first stone will take about %THINK% seconds.
  echo.
  "%EXE%" --time %THINK%
)

echo.
echo Engine exited.
pause
endlocal
